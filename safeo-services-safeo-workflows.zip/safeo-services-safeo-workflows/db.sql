
CREATE TABLE absence(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    is_absent DEFAULT 'N'
);

CREATE TABLE unauthorized(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    is_unauthorized DEFAULT 'N'
);

CREATE TABLE social_distancing(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL
);

CREATE TABLE mask_compliance(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL
);
 
CREATE TABLE safety_gear(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    gear_name VARCHAR DEFAULT NULL,
    is_violation VARCHAR DEFAULT 'N'
);

CREATE TABLE touchless_attendance(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    attendance_status VARCHAR DEFAULT "OUT",
    num_working_secs VARCHAR NOT NULL
);

CREATE TABLE schedule_mismatch(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    schedule_status VARCHAR DEFAULT 'OUT',
    is_violation VARCHAR DEFAULT 'N'
);

CREATE TABLE heat_map(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL,
    no_of_people INT NOT NULL,
    is_violation VARCHAR DEFAULT 'N'
    );

CREATE TABLE break_time(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    break_status VARCHAR DEFAULT 'OUT',
    break_time_taken VARCHAR NOT NULL,
    is_violation VARCHAR DEFAULT 'N'
);    

