"""
Safeo Safety Gear Workflow DAG
"""
from datetime import datetime
from airflow import DAG
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.state import State
from airflow.utils.trigger_rule import TriggerRule
import pytz  

default_args = {
    "owner" : "airflow"
}

dag = DAG('safety_gear_dag', 
        description='Safeo Safety Gear Workflow DAG',
        schedule_interval='@once',
        start_date=datetime(2021, 4, 1),
        default_args=default_args,
        catchup=False)

def safety_gear_comm(**kwargs):
    try:
        curr_time = datetime.now(pytz.utc)
        pg_hook = PostgresHook(postgres_conn_id='safeo_dev')
        conn = pg_hook.get_conn()
        cursor =  conn.cursor()   

        employee_email = kwargs['dag_run'].conf['employee_email']
        camera_id =  kwargs['dag_run'].conf['camera_id']
        gear_name = kwargs['dag_run'].conf['gear_name']
        function_id = 8 

        cursor.execute("INSERT INTO safety_gear (time , employee_email, camera_id, gear_name) VALUES (%s, %s, %s, %s)",(curr_time, employee_email, camera_id, gear_name)) 
        conn.commit()

        cursor.execute("SELECT user_id, business_id FROM tb_user_master WHERE email=%s AND is_employee=%s",(employee_email, 'Y'))
        employee = cursor.fetchone()
        if employee:
            
            cursor.execute("SELECT F.config_id, F.config_type, M.entity_id, S.safety_kit FROM tb_module_function_config F, tb_module_function_config_map M, tb_safety_gear_config S \
                WHERE S.status = %s AND S.camera_id = %s AND S.config_id = F.config_id AND M.status = %s AND M.config_id = F.config_id AND F.status = %s AND F.business_id = %s AND F.function_id = %s",('A', camera_id, 'A', 'A', employee[1], function_id))
            function_configs = cursor.fetchall()
            
            for function_config in function_configs:
                gear_list = function_config[3].split(',')
                if gear_name in gear_list:
                    if function_config[1] =='ROLE':
                        
                        cursor.execute("SELECT M.user_id FROM tb_user_role_resp R, tb_user_master M WHERE \
                            M.status=%s AND M.user_id = R.user_id AND R.role_id = %s",('A', function_config[2]))
                        config_employees = cursor.fetchall()
                        
                        for config_employee in config_employees:
                            if config_employee[0] == employee[0]:
                                insert_notification(function_config[0])
                                cursor.execute("SELECT time FROM safety_gear WHERE employee_email = %s AND camera_id = %s ORDER BY time DESC LIMIT 1 ",( employee_email, camera_id))
                                time_data = cursor.fetchone()
                                cursor.execute("UPDATE safety_gear SET is_violation = %s WHERE  time =  %s AND employee_email = %s AND camera_id = %s "
                                                        ,( 'Y', time_data[0], employee_email, camera_id))
                                conn.commit()  

                    elif function_config[1] =='EMPLOYEE':
                        if function_config[2] == employee[0]:
                            insert_notification(function_config[0])
                            cursor.execute("SELECT time FROM safety_gear WHERE employee_email = %s AND camera_id = %s ORDER BY time DESC LIMIT 1 ",( employee_email, camera_id))
                            time_data = cursor.fetchone()
                            cursor.execute("UPDATE safety_gear SET is_violation = %s WHERE  time =  %s AND employee_email = %s AND camera_id = %s "
                                                    ,( 'Y', time_data[0], employee_email, camera_id))
                            conn.commit()  
        cursor.close()
        conn.close()
    except Exception as e:
        print("safety_gear_comm : exception : {}".format(e))
    
def insert_notification(config_id):
    try:
        pg_hook = PostgresHook(postgres_conn_id='safeo_dev')
        conn = pg_hook.get_conn()
        cursor =  conn.cursor()
        title = "Safety Gear Notification"
        
        cursor.execute("SELECT F.comm_config_type, F.message, F.mode, M.entity_id FROM tb_module_function_comm_config F, tb_module_function_comm_config_map M \
            WHERE M.status = %s AND M.comm_config_id = F.comm_config_id AND F.status = %s AND F.config_id = %s",('A', 'A', config_id))
        comm_configs = cursor.fetchall()
        
        for comm_config in comm_configs:
            if comm_config[0] =='ROLE':
                
                cursor.execute("SELECT M.user_id, M.email, M.country_id, M.mobile FROM tb_user_role_resp R, tb_user_master M WHERE \
                    M.status=%s AND M.user_id = R.user_id AND R.role_id = %s",('A', comm_config[3]))
                employees = cursor.fetchall()
                modes = comm_config[2].split(',')
                for employee in employees:
                    if "SMS" in modes:
                        insert_sms(employee[2], employee[3], comm_config[1])
                    if  "EMAIL" in modes:
                        insert_mail(employee[1], "Safeo Notification", comm_config[1])
                    if "PUSH" in modes:
                        insert_push_notification(employee[0], title, comm_config[1])

            elif comm_config[0] =='EMPLOYEE':
                cursor.execute("SELECT user_id, email, country_id, mobile FROM tb_user_master WHERE status=%s AND user_id=%s",('A', comm_config[3]))
                employee = cursor.fetchone()
                
                if employee:
                    if "SMS" in modes:
                        insert_sms(employee[2], employee[3], comm_config[1])
                    if  "EMAIL" in modes:
                        insert_mail(employee[1], "Safeo Notification", comm_config[1])
                    if "PUSH" in modes:
                        insert_push_notification(employee[0], title, comm_config[1])
        cursor.close()
        conn.close()
    except Exception as e:
        print("insert_notification : exception : {}".format(e))

def insert_sms(country_id, mobile, message):
    try:
        pg_hook = PostgresHook(postgres_conn_id='safeo_dev')
        conn = pg_hook.get_conn()
        cursor =  conn.cursor()

        cursor.execute("INSERT INTO tb_sms_txn (country_id, mobile, message, created_date) VALUES \
                (%s, %s, %s, now())",(country_id, mobile, message)) 
        conn.commit()

        cursor.close()
        conn.close()
    except Exception as e:
        print("insert_sms : exception : {}".format(e))

def insert_mail(email, subject, message):
    try:
        pg_hook = PostgresHook(postgres_conn_id='safeo_dev')
        conn = pg_hook.get_conn()
        cursor =  conn.cursor()

        cursor.execute("INSERT INTO tb_mail_txn (email, subject, message, created_date) VALUES \
                (%s, %s, %s, now())",(email, subject, message)) 
        conn.commit()

        cursor.close()
        conn.close()
    except Exception as e:
        print("insert_mail : exception : {}".format(e))

def insert_push_notification(user_id, title, message):
    try:
        pg_hook = PostgresHook(postgres_conn_id='safeo_dev')
        conn = pg_hook.get_conn()
        cursor =  conn.cursor()

        cursor.execute("INSERT INTO tb_user_notifications (user_id, title, message, created_date) VALUES \
                (%s, %s, %s, now())",(user_id, title, message)) 
        conn.commit()

        cursor.close()
        conn.close()
    except Exception as e:
        print("insert_push_notification : exception : {}".format(e))

        
start_operator = DummyOperator(task_id='start_task', retries=1, dag=dag)
         
safety_gear_comm_operator =  PythonOperator(task_id='safety_gear_comm_task', python_callable=safety_gear_comm, dag=dag,  provide_context=True)  

status_operator = DummyOperator(task_id='status_task', trigger_rule=TriggerRule.ALL_SUCCESS,  dag=dag)

start_operator >> safety_gear_comm_operator >> status_operator
