import cv2
from social_distancing_inference import SocialDistancing

if __name__ == '__main__':
    # cap = cv2.VideoCapture('/home/surya/Downloads/Safeo Videos/business-people-shaking-hands-TWW7BJM.mov')
    cap = cv2.VideoCapture(0)
    cap.set(3, 1280)
    cap.set(4, 720)

    detector = SocialDistancing()

    while True:
        ret, img = cap.read()
        num_violations, violation_boxes, compliant_boxes = detector.monitor_social_distancing(img)

        print('NUM VIOLATING PEOPLE - {}'.format(num_violations))

        for i, curr_box in enumerate(violation_boxes):
            img = cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), (0, 0 , 255), 1)
        
        for i, curr_box in enumerate(compliant_boxes):
            img = cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), (0, 255 , 0), 1)

        cv2.imshow('Social Distancing Demo', img)
        cv2.waitKey(1)

    cap.release()
