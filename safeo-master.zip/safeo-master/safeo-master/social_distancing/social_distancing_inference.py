import numpy as np
from scipy.spatial.distance import cdist

import sys
sys.path.append("..")

from object_detection.detector_inference import ObjectDetector

class SocialDistancing():
    def __init__(self):
        self.min_distance = 750
        self.category_name = 'person'
        self.detector = ObjectDetector()

    def detect_people(self, img):
        class_list, score_list, bboxes_list = self.detector.detect_objects(img)

        class_list = np.array(class_list)
        bboxes_list = np.array(bboxes_list)

        people_category_idx, = np.where(class_list == self.category_name)

        people_bboxes_list = bboxes_list[people_category_idx]

        return people_bboxes_list
    
    def calculate_center(self, bbox_list):
        centroid_list = []

        for curr_box in bbox_list:
            center_x = int((curr_box[0] + curr_box[2]) / 2)
            center_y = curr_box[3]

            center_point = (center_x, center_y)

            centroid_list.append(center_point)
        
        return centroid_list
    
    def calculate_pairwise_dist(self, coord_list):
        dist_matrix = cdist(coord_list, coord_list, metric='euclidean')

        return dist_matrix

    def findDistance(self, p1, p2):
        return ((p1[0] - p2[0]) ** 2 + 550 / ((p1[1] + p2[1]) / 2) * (p1[1] - p2[1]) ** 2) ** 0.5

    def calculate_calibrated_dist(self,coord_list):
        dist_matrix=np.zeros((len(coord_list),len(coord_list)))

        for idx,coord_i in enumerate(coord_list):
            for jdx,coord_j in enumerate(coord_list):
                dist_matrix[idx,jdx] = self.findDistance(coord_i,coord_j)

        return dist_matrix

    def isClose(self, p1,  p2):
        dist = self.findDistance(p1, p2)
        calibration = (p1[1] + p2[1]) / 2
        
        if 0 < dist < 0.25 * calibration:
            return True
        else:
            return False


    def identify_violations(self, people_bboxes, dist_matrix):
        matrix_dimensions = dist_matrix.shape

        violations_list = []

        for i in range(matrix_dimensions[0]):
            
            for j in range(i+1, matrix_dimensions[1]):
                curr_distance = dist_matrix[i, j]
                first_person = people_bboxes[i]
                second_person = people_bboxes[j]
                
                first_person_width = (first_person[2] - first_person[0])
                second_person_width = (second_person[2] - second_person[0])
                threshold_distance = min(first_person_width, second_person_width) * 1.5

                if curr_distance < threshold_distance:
                    violations_list.append(i)
                    violations_list.append(j)
        
        violations_list = np.unique(violations_list)

        return violations_list
    
    def monitor_social_distancing(self, img):
        people_bboxes_list = self.detect_people(img)
        num_detected_people = len(people_bboxes_list)

        people_centroid_list = self.calculate_center(people_bboxes_list)
        people_centroid_list = np.array(people_centroid_list)

        num_people_violating = 0
        violation_people_bboxes = []
        compliant_people_bboxes = []

        # #TODO Delete this
        # violation_people_centroids = []
        # compliant_people_centroids = []

        if num_detected_people > 1:
            # people_pairwise_dist = self.calculate_calibrated_dist(people_centroid_list)
            people_pairwise_dist = self.calculate_pairwise_dist(people_centroid_list)

            violation_people_list = self.identify_violations(people_bboxes_list, people_pairwise_dist) 
            compliant_people_list = [idx for idx in range(num_detected_people) if idx not in violation_people_list]

            num_people_violating = len(violation_people_list)

            if num_people_violating > 0:
                violation_people_bboxes = people_bboxes_list[violation_people_list]
                
                # #TODO Delete this
                # violation_people_centroids = people_centroid_list[violation_people_list]

            if num_people_violating < num_detected_people:
                compliant_people_bboxes = people_bboxes_list[compliant_people_list]

                # #TODO Delete this
                # compliant_people_centroids = people_centroid_list[compliant_people_list]
        
        else:
            compliant_people_bboxes = people_bboxes_list

            # #TODO Delete this
            # compliant_people_centroids = people_centroid_list


        return num_people_violating, violation_people_bboxes, compliant_people_bboxes
    