# import statements
import torch
import torch.backends.cudnn as cudnn
import numpy as np
import cv2

from PIL import Image

from face_detection.models.retinaface import RetinaFace
from face_detection.data import cfg_mnet, cfg_re50
from face_detection.utils.box_utils import decode, decode_landm
from face_detection.layers.functions.prior_box import PriorBox
from face_detection.utils.nms.py_cpu_nms import py_cpu_nms

from face_alignment.align_faces import warp_and_crop_face, get_reference_facial_points


class RetinaFaceInference():
    def __init__(self, base_model_name="mobile0.25", conf_threshold=0.02, top_k=5000, nms_threshold=0.4, keep_top_k=750, vis_threshold=0.6):

        self.curr_compute = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        torch.set_grad_enabled(False)

        self.cfg = None
        if base_model_name == "mobile0.25":
            self.cfg = cfg_mnet
        elif base_model_name == "resnet50":
            self.cfg = cfg_re50

        # net and model
        self.model = RetinaFace(cfg=self.cfg, phase='test')
        self.load_model()

        self.confidence_threshold = conf_threshold
        self.top_k = top_k
        self.nms_threshold = nms_threshold
        self.keep_top_k = keep_top_k
        self.vis_threshold = vis_threshold

        self.refrence = get_reference_facial_points(default_square= True)


    
    def check_keys(self, pretrained_state_dict):

        #-------------------------
        # checks the model keys
        # to see if they are used
        #-------------------------
        
        ckpt_keys = set(pretrained_state_dict.keys())
        model_keys = set(self.model.state_dict().keys())
        used_pretrained_keys = model_keys & ckpt_keys
        unused_pretrained_keys = ckpt_keys - model_keys
        missing_keys = model_keys - ckpt_keys
        print('Missing keys:{}'.format(len(missing_keys)))
        print('Unused checkpoint keys:{}'.format(len(unused_pretrained_keys)))
        print('Used keys:{}'.format(len(used_pretrained_keys)))
        assert len(used_pretrained_keys) > 0, 'load NONE from pretrained checkpoint'
        return True



    def remove_prefix(self, state_dict, prefix):

        #-------------------------
        # removes "module" from the
        # front of all model files
        #-------------------------

        ''' Old style model is stored with all names of parameters sharing common prefix 'module.' '''
        print('remove prefix \'{}\''.format(prefix))
        f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
        return {f(key): value for key, value in state_dict.items()}
            


    def load_model(self):

        pretrained_weights_path = self.cfg['pretrained_weights_path']

        print('Loading pretrained model from {}'.format(pretrained_weights_path))

        if self.curr_compute == "cpu":
            pretrained_dict = torch.load(pretrained_weights_path, map_location=lambda storage, loc: storage)
        else:
            curr_device = torch.cuda.current_device()
            pretrained_dict = torch.load(pretrained_weights_path, map_location=lambda storage, loc: storage.cuda(curr_device))

        if "state_dict" in pretrained_dict.keys():
            pretrained_dict = self.remove_prefix(pretrained_dict['state_dict'], 'module.')
        else:
            pretrained_dict = self.remove_prefix(pretrained_dict, 'module.')

        self.check_keys(pretrained_dict)
        
        self.model.load_state_dict(pretrained_dict, strict=False)
        
        self.model.eval()
        cudnn.benchmark = True
        self.model = self.model.to(self.curr_compute)

        print('Finished loading model!')


    
    def detect_faces(self, image):

        #-------------------------
        # gets the bouding boxes
        # and facial landmarks for
        # a given input image
        #-------------------------

        resize = 1

        img = np.float32(image)

        im_height, im_width, _ = img.shape
        scale = torch.Tensor([img.shape[1], img.shape[0], img.shape[1], img.shape[0]])
        img -= (104, 117, 123)
        img = img.transpose(2, 0, 1)
        img = torch.from_numpy(img).unsqueeze(0)
        img = img.to(self.curr_compute)
        scale = scale.to(self.curr_compute)

        # forward pass
        loc, conf, landms = self.model(img)

        priorbox = PriorBox(self.cfg, image_size=(im_height, im_width))
        priors = priorbox.forward()
        priors = priors.to(self.curr_compute)
        prior_data = priors.data

        boxes = decode(loc.data.squeeze(0), prior_data, self.cfg['variance'])
        boxes = boxes * scale / resize
        boxes = boxes.cpu().numpy()

        scores = conf.squeeze(0).data.cpu().numpy()[:, 1]

        landms = decode_landm(landms.data.squeeze(0), prior_data, self.cfg['variance'])
        scale1 = torch.Tensor([img.shape[3], img.shape[2], img.shape[3], img.shape[2],
                            img.shape[3], img.shape[2], img.shape[3], img.shape[2],
                            img.shape[3], img.shape[2]])
        scale1 = scale1.to(self.curr_compute)
        landms = landms * scale1 / resize
        landms = landms.cpu().numpy()

        # ignore low scores
        inds = np.where(scores > self.confidence_threshold)[0]
        boxes = boxes[inds]
        landms = landms[inds]
        scores = scores[inds]

        # keep top-K before NMS
        order = scores.argsort()[::-1][:self.top_k]
        boxes = boxes[order]
        landms = landms[order]
        scores = scores[order]

        # do NMS
        bounding_boxes = np.hstack((boxes, scores[:, np.newaxis])).astype(np.float32, copy=False)
        keep = py_cpu_nms(bounding_boxes, self.nms_threshold)

        bounding_boxes = bounding_boxes[keep, :]
        landms = landms[keep]

        # keep top-K faster NMS
        bounding_boxes = bounding_boxes[:self.keep_top_k, :]
        landms = landms[:self.keep_top_k, :]

        # print(landms.shape)
        landms = landms.reshape((-1, 5, 2))
        # print(landms.shape)
        landms = landms.transpose((0, 2, 1))
        # print(landms.shape)
        landms = landms.reshape(-1, 10, )
        # print(landms.shape)

        final_bounding_boxes = []
        final_landms = []

        for i, curr_det in enumerate(bounding_boxes):
            if curr_det[4] > self.vis_threshold:
                final_bounding_boxes.append(curr_det)
                final_landms.append(landms[i])

        final_bounding_boxes = np.array(final_bounding_boxes)
        final_landms = np.array(final_landms)

        return final_bounding_boxes, final_landms   

    def align(self, img, output_size=(112,112)):

        img = np.array(img)

        _, facial5points = self.detect_faces(img)

        facial5points = np.reshape(facial5points[0], (2, 5))

        default_square = True
        inner_padding_factor = 0.25
        outer_padding = (0, 0)

        # get the reference 5 landmarks position in the crop settings
        reference_5pts = get_reference_facial_points(
            output_size, inner_padding_factor, outer_padding, default_square)

        dst_img = warp_and_crop_face(img, facial5points, reference_pts=reference_5pts, crop_size=output_size)

        dst_img = Image.fromarray(dst_img)

        return dst_img

    def align_multi(self, img, output_size=(112,112)):
        img = np.array(img)

        default_square = True
        inner_padding_factor = 0.25
        outer_padding = (0, 0)

        # get the reference 5 landmarks position in the crop settings
        reference_5pts = get_reference_facial_points(
            output_size, inner_padding_factor, outer_padding, default_square)

        boxes, facial5points = self.detect_faces(img)

        faces = []

        for curr_landmark in facial5points:

            curr_facial5points = np.reshape(curr_landmark, (2, 5))

            curr_dst_img = warp_and_crop_face(img, curr_facial5points, reference_pts=reference_5pts, crop_size=output_size)

            curr_dst_img = Image.fromarray(curr_dst_img)

            faces.append(curr_dst_img)

        return boxes, faces
