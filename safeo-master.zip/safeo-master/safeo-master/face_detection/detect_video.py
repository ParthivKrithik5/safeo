#-------------------------
# detects all faces in each 
# frame of a webcam video stream
#-------------------------

import cv2
import time
from imutils.video import VideoStream

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference

if __name__ == '__main__':

    # initialize model
    model = RetinaFaceInference()

    # initialize the video stream
    vs = VideoStream(src=0).start()

    # warm up the camera sensor
    time.sleep(2.0)

    cv2.namedWindow("Frame", cv2.WINDOW_NORMAL) 

    while True:
        img = vs.read()

        boxes, landmarks = model.detect_faces(img)

        # show image
        for i, curr_box in enumerate(boxes):
            
            curr_landmark = landmarks[i]

            text = "{:.4f}".format(curr_box[4])
            
            curr_box = list(map(int, curr_box))

            cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), (0, 0, 255), 1)
            cx = curr_box[0]
            cy = curr_box[1] + 12
            cv2.putText(img, text, (cx, cy),
                        cv2.FONT_HERSHEY_DUPLEX, 0.5, (255, 255, 255))

            # landms
            cv2.circle(img, (curr_landmark[0], curr_landmark[5]), 1, (0, 0, 255), 4)
            cv2.circle(img, (curr_landmark[1], curr_landmark[6]), 1, (0, 255, 255), 4)
            cv2.circle(img, (curr_landmark[2], curr_landmark[7]), 1, (255, 0, 255), 4)
            cv2.circle(img, (curr_landmark[3], curr_landmark[8]), 1, (0, 255, 0), 4)
            cv2.circle(img, (curr_landmark[4], curr_landmark[9]), 1, (255, 0, 0), 4)

        # display image
        cv2.imshow("Frame", img)
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    # closes the windows and stops the video stream
    cv2.destroyAllWindows()
    vs.stop()              
                

            
            

