import cv2
from heat_map_inference import HeatMap


if __name__ == '__main__':
    file_path = '/home/surya/Downloads/220116_01_ChelCity 7.mov'
    cap = cv2.VideoCapture(file_path)
    cap.set(3, 1280)
    cap.set(4, 720)

    detector = HeatMap()
    fourCC = cv2.VideoWriter_fourcc('X', 'V', 'I', 'D')
    # fourCC = cv2.VideoWriter_fourcc(*"MJPG")

    writer = cv2.VideoWriter('./Heatmap_Demo.avi', fourCC, 25, (1920, 1080) )
    
    while True:
        ret, img = cap.read()
        # print(img.shape)
        
        if img is not None:

            num_people = 0

            num_people, boxes = detector.detect_people(img)

            curr_string = 'NUM PEOPLE DETECTED - {}'.format(num_people)

            # print('DETECTED PEOPLE - {}'.format(num_people))

            for curr_box in boxes:
                img = cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), (255, 0 , 0), 5)
                # print(img.shape)
            
            img = cv2.putText(img, str(curr_string), (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color=(0,0,255))

            writer.write(img)

            cv2.imshow('HEAT MAP demo', img)
            cv2.waitKey(1)
        
        else:
            break

    cap.release()
    writer.release()
