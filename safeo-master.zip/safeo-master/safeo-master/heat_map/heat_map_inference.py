import numpy as np

import sys
sys.path.append("..")

from object_detection.detector_inference import ObjectDetector

class HeatMap():
    def __init__(self):
        self.detector = ObjectDetector()
        self.category_name = 'person'
    
    def detect_people(self, img):
        class_list, score_list, bboxes_list = self.detector.detect_objects(img)

        class_list = np.array(class_list)
        bboxes_list = np.array(bboxes_list)

        people_category_idx, = np.where(class_list == self.category_name)

        num_people = len(people_category_idx)
        people_bboxes_list = bboxes_list[people_category_idx]

        return num_people, people_bboxes_list