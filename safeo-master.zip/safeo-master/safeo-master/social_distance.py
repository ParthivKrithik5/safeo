from social_distancing.social_distancing_inference import SocialDistancing

# what if database connection fails
# change implementation to dynamic batch processing using queue
class SD:
    def __init__(self, in_data_queue, out_data_queue):
        self.in_data_queue = in_data_queue
        self.out_data_queue = out_data_queue
        self.stopped = False

        self.sd_monitor = SocialDistancing()
    
    def run(self):                    
        while True:
            curr_item = self.in_data_queue.get()

            if curr_item == 'KILL WORKER':
                break

            num_total_people, sd_risk_score = self.analyse(curr_item['frame'])

            curr_item['sd_risk_score'] = sd_risk_score
            curr_item['num_total_people'] = num_total_people

            del curr_item['frame']

            self.out_data_queue.put(curr_item)
        
    def analyse(self, img):
        # social distancing analysis
        num_people_violating, violating_bboxes, compliant_bboxes = self.sd_monitor.monitor_social_distancing(img)
        num_total_people = num_people_violating + len(compliant_bboxes)

        if num_total_people == 0:
            sd_risk_score = 0
        else:
            sd_risk_score = num_people_violating / num_total_people

        return (num_total_people, sd_risk_score)
    
    def stop(self):
        self.in_data_queue.put('KILL WORKER')

    