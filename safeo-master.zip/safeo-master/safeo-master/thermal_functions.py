# Thermal images function
import psycopg2
import os

db_url = 'postgres://sfsktusr01:_k9Bd#RP@localhost:5432/safeo_dev'

def check_thermal_camera_live_status(email):
    result_list = []
    connection = psycopg2.connect(db_url)
    cursor = connection.cursor()
    row=cursor.execute("SELECT C.camera_id, C.camera_name FROM tb_users U, thermal_camera_details C \
        WHERE C.user_id = U.user_id AND U.email =  %s", (email, ))
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            camera_id = row[0]
            row1 = cursor.execute("SELECT extract(epoch from (now()::timestamp - inserted_datetime::timestamp)) FROM thermal_camera_images \
                WHERE camera_id = %s ORDER BY image_id DESC LIMIT 1", (camera_id, ))
            row1 = cursor.fetchone()
            if row1[0] <= 600:
                result_list.append({'camera_name':row[1], 'camera_status': True})
            else:
                result_list.append({'camera_name':row[1], 'camera_status': False})
        cursor.close()
        connection.close()
    return result_list

def read_thermal_images():
    result_dict = {}
    connection = psycopg2.connect(db_url)
    cursor = connection.cursor()
    row  = cursor.execute("SELECT I.image_id, U.email, I.thermal_image_file_name, I.normal_image_file_name, I.temperature_image_file_name \
        FROM thermal_camera_images I, thermal_camera_details C, tb_users U \
        WHERE U.user_id =C.user_id AND C.camera_id=I.camera_id ORDER BY I.image_id ASC limit 1")
    row = cursor.fetchone()
    if row:
        result_dict['image_id'] = row[0]
        result_dict['email'] = row[1]
        result_dict['thermal_image_file_name'] = row[2]
        result_dict['normal_image_file_name'] = row[3]
        result_dict['temperature_image_file_name'] = row[4]
    cursor.close()
    connection.close()
    return result_dict

def delete_thermal_images(image_id):
    base_path = '/home/kathiravan/safeo/thermal-images/'
    connection = psycopg2.connect(db_url)
    cursor = connection.cursor()
    row  = cursor.execute("SELECT thermal_image_file_name, normal_image_file_name, temperature_image_file_name \
        FROM thermal_camera_images WHERE image_id = %s", (image_id, ))
    row = cursor.fetchone()
    if row:
        thermal_image_file_name = row[0]
        normal_image_file_name = row[1]
        temperature_image_file_name = row[2]
        cursor.execute("DELETE FROM thermal_camera_images WHERE image_id = %s", (image_id, ))
        connection.commit()

        if os.path.exists(os.path.join(base_path, thermal_image_file_name)):
            os.remove(os.path.join(base_path, thermal_image_file_name))
        if os.path.exists(os.path.join(base_path, normal_image_file_name)):
            os.remove(os.path.join(base_path, normal_image_file_name))
        if os.path.exists(os.path.join(base_path, temperature_image_file_name)):
            os.remove(os.path.join(base_path, temperature_image_file_name))
    cursor.close()
    connection.close()