import psycopg2.extras
import random
from datetime import datetime, timezone

connection = psycopg2.connect(
                    host="localhost",
                    database="safeotest",
                    user="postgres",
                    password="postgres"
                    )

employee_email = '999@345.com'
employee_email_2 = '000@345.com'

for i in range(10):
    temperature = random.choice([100, 105, 95])
    if temperature > 100:
        temperature_status = 'high'
    else:
        temperature_status = 'normal'
    curr_time = datetime.now(timezone.utc)
    curr_time = curr_time.replace(month=12)
    print(temperature)
    print(temperature_status)
    print(curr_time)

    cursor = connection.cursor()
    cursor.execute("INSERT INTO employee_temperature (time, employee_email, temperature, temperature_status) \
                                        VALUES (%s, %s, %s, %s)", (curr_time, employee_email, temperature, temperature_status))
                        
    connection.commit()

connection.close()