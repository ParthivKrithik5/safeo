import psycopg2
import psycopg2.extras

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()

from heat_map.heat_map_inference import HeatMap

# what if database connection fails
class HeatMapperson:
    def __init__(self, in_data_queue, out_data_queue):
        self.in_data_queue = in_data_queue
        self.out_data_queue = out_data_queue
        self.stopped = False
    
    def run(self):
        connection = psycopg2.connect(
                            host="localhost",
                            database="safeotest",
                            user="postgres",
                            password="postgres"
                            )
        cursor = connection.cursor()

        while True:
            curr_item = self.in_data_queue.get()

            if curr_item == 'KILL WORKER':
                break
            
            cursor.execute("SELECT max_occupancy \
                            FROM camera_details \
                            WHERE camera_id = %s", (curr_item['camera_id'], ))

            max_occupancy_data = cursor.fetchall()
            
            if len(max_occupancy_data) > 0:
                max_occupancy = list(zip(*max_occupancy_data))[0][0]
            
                heatmap_risk_score = self.analyse(curr_item['num_total_people'], max_occupancy)

                curr_item['heatmap_risk_score']  = heatmap_risk_score

                self.out_data_queue.put(curr_item)
        
        cursor.close()
        connection.close()
        
    def analyse(self, num_people_detected, max_occupancy):

        if max_occupancy == 0:
            heatmap_risk_score = 0
        else:
            heatmap_risk_score = num_people_detected / max_occupancy

        return heatmap_risk_score
    
    def stop(self):
        self.in_data_queue.put('KILL WORKER')

    