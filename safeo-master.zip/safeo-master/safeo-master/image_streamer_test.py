import weakref
from multiprocessing import Queue
from stream_reader import VideoStreamReader
import time
import cv2




q = Queue()
a = VideoStreamReader('1','http://62.75.122.162:80/image/2.jpg',q)

weak_a = weakref.ref(a)
weak_a().start()

print("Starting Feed")

for i in range(10):
    print('.')
    #$weak_a().update()
    item = q.get()
    cv2.imshow(item['frame'])
    #if cv2.waitkeys(1) & 0XFF == 27:
    #    break
    time.sleep(1)


weak_a().remove_stream_reader()


import threading
for thread in threading.enumerate():
    print(thread)
