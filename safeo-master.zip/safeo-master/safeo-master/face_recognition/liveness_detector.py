import numpy as np
import torch
from torchvision import transforms
from PIL import Image

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference

class LivenessDetector():
    def __init__(self):
        self.model = torch.load("./face_recognition/liveness_model_33")
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model = self.model.to(self.device)
        self.model.eval()
        self.data_transforms = transforms.Compose([
                                    transforms.Resize((224, 224)),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                                ])

    def infer_model(self, img):

        # img = Image.fromarray(img)

        processed_img = self.data_transforms(img)
        processed_img = torch.unsqueeze(processed_img, 0)

        preds = self.run_mask_model(processed_img)[0]
    
        if preds == 0:
            return "real"
        else:
            return "spoof"
    
    def run_mask_model(self, img_arr):

        img_arr = img_arr.to(self.device)

        # forward
        with torch.set_grad_enabled(False):

            outputs = self.model(img_arr)
            _, preds = torch.max(outputs, 1)
            preds = preds.cpu().numpy()
        
        return preds