import os
import numpy as np
import cv2
import argparse
from PIL import Image
from datetime import datetime

import config
from mtcnn import MTCNN

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference

parser = argparse.ArgumentParser(description='take a picture')
parser.add_argument('--name', '-n', default='unknown', type=str, help='input the name of the recording person')
args = parser.parse_args()

conf = config.get_config(False)

# get face bank path
data_path = conf.facebank_path
save_path = os.path.join(data_path, args.name)

# create directory for current identity in face bank
if not os.path.isdir(save_path):
    os.mkdir(save_path)

# initialize face detection model
# mtcnn = MTCNN()
face_detector = RetinaFaceInference()

# initialize camera
cap = cv2.VideoCapture(0)
cap.set(3,1280)
cap.set(4,720)

print("press t to take a picture, q to quit")

while cap.isOpened():
    isSuccess,frame = cap.read()

    cv2.imshow("Frame", frame)

    # take a picture, detect and align the face in the picture and store it in facebank
    if cv2.waitKey(1)&0xFF == ord('t'):

        try:            
            warped_face = np.array(face_detector.align(frame))

            warped_face_name = '{}.jpg'.format(str(datetime.now())[:-7].replace(":","-").replace(" ","-"))
            warped_face_path = os.path.join(save_path, warped_face_name)
            cv2.imwrite(warped_face_path, warped_face)

        except:
            print('no face captured')
        
    if cv2.waitKey(1)&0xFF == ord('q'):
        break

cap.release()
cv2.destoryAllWindows()
