import os
import numpy as np
import cv2
import argparse
from PIL import Image
from datetime import datetime

import config
from mtcnn import MTCNN

import sys
sys.path.append("../..")

from face_detection.run_inference import RetinaFaceInference

if __name__ == "__main__":
    face_detector = RetinaFaceInference()

    filename = 'pss.jpg'
    print('Loading image {}'.format(filename))

    raw = cv2.imread(filename)


    warped_face = np.array(face_detector.align(raw))

    warped_face_name = '{}_pss.jpg'.format(str(datetime.now())[:-7].replace(":","-").replace(" ","-"))
    warped_face_path = os.path.join(".", warped_face_name)
    cv2.imwrite(warped_face_path, warped_face)


    # raw = cv2.imread(filename)

    # detector.align(raw, output_size=(112, 112))
