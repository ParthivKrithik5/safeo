import os
import numpy as np
import cv2
import argparse
from PIL import Image
from datetime import datetime

import config
from mtcnn import MTCNN

import torch

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference
from recog_inference import FaceRecogInference

if __name__ == "__main__":
    # detector = RetinaFaceInference()

    # filename = 'raw.jpg'
    # print('Loading image {}'.format(filename))

    # raw = cv2.imread(filename)

    # detector.align(raw, output_size=(112, 112))

    facebank_path = '/home/surya/Documents/GitHub/safeo/face_recognition/data/facebank'
    recognizer = FaceRecogInference(face_bank_path=facebank_path)



    img = cv2.imread('/home/surya/Desktop/sami.jpeg')    

    recognizer.add_individual('sami', [img])