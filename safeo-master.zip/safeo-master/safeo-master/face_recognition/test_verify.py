import cv2

import sys
sys.path.insert(0, "/home/surya/Documents/GitHub/safeo")

from face_recognition.utils import draw_box_name

from face_recognition.recog_inference import FaceRecogInference

if __name__ == '__main__':
    # inital camera
    cap = cv2.VideoCapture(0)
    cap.set(3,1280)
    cap.set(4,720)

    facebank_path = '/home/surya/Documents/GitHub/safeo/face_recognition/data/facebank'
    face_recognizer = FaceRecogInference(face_bank_path=facebank_path)

    while cap.isOpened():
        isSuccess,frame = cap.read()

        if isSuccess:            
            individual_names, scores, bboxes = face_recognizer.recognize_individuals(frame)

            if len(individual_names) > 0:
                for idx,bbox in enumerate(bboxes):
                    frame = draw_box_name(bbox, individual_names[idx] + '_{:.2f}'.format(scores[idx]), frame)
                
            cv2.imshow('face Capture', frame)

        if cv2.waitKey(1)&0xFF == ord('q'):
            break

    cap.release()

    cv2.destroyAllWindows()    