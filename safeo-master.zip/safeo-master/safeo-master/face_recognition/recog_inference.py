import torch
from torchvision import transforms as trans
import numpy as np
import cv2
from pathlib import Path

from face_recognition.config import get_config
from face_recognition.Learner import face_learner
from face_recognition.utils import load_facebank, prepare_facebank
from face_recognition.model import l2_norm
# from face_recognition.liveness_detector import LivenessDetector old model
from face_recognition.tsn_predict import TSNPredictor

import sys
sys.path.append("..")
from face_detection.run_inference import RetinaFaceInference

class FaceRecogInference:
    def __init__(self, face_bank_path=None, tta=False):

        # update facebank path to that of current user
        self.config =  get_config(training=False)
        self.tta = tta
        self.config.facebank_path = Path(face_bank_path)

        # initialize face detector
        self.face_detector = RetinaFaceInference()

        # initialize liveness detector
        #self.liveness_detector = LivenessDetector()
        self.liveness_detector = TSNPredictor()

        # initialize face recog object
        self.learner = face_learner(self.config, inference=True)

        # load face recognition model
        if self.config.device.type == 'cpu':
            self.learner.load_state(self.config, 'cpu_final.pth', from_save_folder=True, model_only=True)
        else:
            self.learner.load_state(self.config, 'final.pth', from_save_folder=False, model_only=True)
        self.learner.model.eval()
        
        # [update] and load face bank
        self.prepare_facebank()
    
    def recognize_individuals(self, img, detect_faces=True):
        target_embedding, names = self.load_facebank()
        if detect_faces:
            bboxes, faces = self.face_detector.align_multi(img)

            live_bboxes = []
            live_faces = []
            for i, curr_face in enumerate(faces):
                liveness_status = self.liveness_detector.infer_model(np.array(curr_face))
                if liveness_status == "real":
                    live_faces.append(curr_face)
                    live_bboxes.append(bboxes[i])
            
            live_bboxes = np.array(live_bboxes)
    

            if len(live_faces) > 0 and len(target_embedding) > 0: 
                live_bboxes = live_bboxes[:,:-1] 
                live_bboxes = live_bboxes.astype(int)
                live_bboxes = live_bboxes + [-1,-1,1,1]    

                results, score = self.learner.infer(self.config, live_faces, target_embedding, self.tta)
                score = score.detach().cpu().numpy()

                individual_names = []
                for _, curr_result in enumerate(results):
                    curr_name = names[curr_result + 1]
                    individual_names.append(curr_name)
            
                return individual_names, score, live_bboxes
            else:
                return [], [], []

        else:
            results, score = self.learner.infer(self.config, img, target_embedding, self.tta)
            score = score.detach().cpu().numpy()

            individual_names = []
            for _, curr_result in enumerate(results):
                curr_name = names[curr_result + 1]
                individual_names.append(curr_name)

            return individual_names, score
    
    def calculate_embedding(self, path):
        if path.is_dir():
            embedding_list = []
            
            for file in path.iterdir():
                if file.is_file():
                    try:
                        img = cv2.imread(str(file))
                    except:
                        continue

                    img = self.face_detector.align(img)
                        
                    with torch.no_grad():
                        if self.tta:
                            mirror = trans.functional.hflip(img)
                            emb = self.learner.model(self.config.test_transform(img).to(self.config.device).unsqueeze(0))
                            emb_mirror = self.learner.model(self.config.test_transform(mirror).to(self.config.device).unsqueeze(0))
                            embedding_list.append(l2_norm(emb + emb_mirror))
                        else:                        
                            embedding_list.append(self.learner.model(self.config.test_transform(img).to(self.config.device).unsqueeze(0)))

            if len(embedding_list) > 0:
                avg_embedding = torch.cat(embedding_list).mean(0, keepdim=True)
                return avg_embedding
        
        return None


    def add_individual(self, name, img_arr):
        curr_path = self.config.facebank_path/name
        already_present = False
        num_existing_images = 0

        if not curr_path.is_dir():
            curr_path.mkdir()
        else:
            already_present = True

            for curr_img_name in curr_path.iterdir():
                if curr_img_name.is_file():
                    num_existing_images += 1
        
        for curr_img in img_arr:
            curr_warped_face = np.array(self.face_detector.align(curr_img))

            curr_image_name = str(num_existing_images) + ".jpg"
            curr_image_path = str(curr_path/curr_image_name)

            cv2.imwrite(curr_image_path, curr_warped_face)

            num_existing_images += 1
        
        all_embeddings, all_names = self.load_facebank()
        curr_name_embedding = self.calculate_embedding(curr_path)

        if already_present and num_existing_images > 1:
            curr_name_idx, = np.where(all_names == name)
            curr_name_idx = curr_name_idx[0] - 1

            if curr_name_embedding != None:
                all_embeddings[curr_name_idx] = curr_name_embedding
        
        else:
            all_embeddings = torch.cat((all_embeddings, curr_name_embedding))
            all_names = np.append(all_names, name)
        
        self.update_facebank(all_embeddings, all_names)

    
    def prepare_facebank(self):
        all_embeddings =  []
        all_names = ['unknown']

        for path in self.config.facebank_path.iterdir():

            curr_embedding = self.calculate_embedding(path)

            if curr_embedding != None:
                all_embeddings.append(curr_embedding)
                all_names.append(path.name)

        if len(all_embeddings) > 0:
            all_embeddings = torch.cat(all_embeddings)
        else:
            all_embeddings = torch.tensor([]).to(self.config.device.type)
        
        all_names = np.array(all_names)

        self.update_facebank(all_embeddings, all_names)


    def load_facebank(self):
        embeddings = torch.load(self.config.facebank_path/'embeddings.pth')
        names = np.load(self.config.facebank_path/'names.npy')
        return embeddings, names
    
    def update_facebank(self, embeddings, names):

        torch.save(embeddings, self.config.facebank_path/'embeddings.pth')
        np.save(self.config.facebank_path/'names', names)
