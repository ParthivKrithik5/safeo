#TODO BETTER WAY TO RUN BACKGROUND THREADS
#TODO BETTER WAY TO TERMINATE BACKGROUND THREADS
#TODO CUDA OUT OF MEMORY - check memory usage and if everything is released properly
#TODO FIX TIME ZONE CONVERSION - RN, assume that everything is in utc same time zone
#TODO IMPLEMENT STREAMING TASK QUEUE AND MESSAGE BROKER (SCALABLE)
#TODO IMPLEMENT DYNAMIC BATCH PROCESSING IN QUEUE MECHANISM
#TODO SET FPS LIMIT FOR CAMS
#TODO CONVERT MODELS TO TENSOR RT
#TODO CREATE REST API TO COMMUNICATE WITH MODEL
#TODO CONTAINERIZE EVERYTHING
#TODO CHANGE SCORING MECHANISM - (how heatmap factors into overall score)
#TODO OPTIMIZE DATABASE

#TODO When delete camera, check in queue processing
#TODO add weakref directly to db
#TODO delete user
#TODO check uniqueness of rtsp link ?
#TODO rethink handling of max occupancy in heatmap
#TODO rethink some settings functions maybe ?

import os
import numpy as np
import cv2
import shutil
from datetime import datetime, timedelta, timezone
import psycopg2
from psycopg2 import pool
from psycopg2 import sql
import uuid
import weakref
from threading import Thread
import threading
from multiprocessing import Queue
import base64

import socket
import concurrent.futures
import requests
import time
import sys
import re

import psycopg2.extras

#importing module 
import logging 

#Create and configure logger 
logging.basicConfig(filename="saferson.log", 
                    format='%(asctime)s %(message)s', 
                    filemode='w')

logger=logging.getLogger() 
  
#Setting the threshold of logger to DEBUG 
logger.setLevel(logging.DEBUG)

import pandas as pd

try:
    df = pd.read_csv('url.csv')
except:
    logger.exception('Exception in reading url.csv')
    df = pd.DataFrame

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()



# from face_recognition.recog_inference import FaceRecogInference

from stream_reader import VideoStreamReader
# from maskerson import Maskerson
from social_distance import SD
from heat_mapperson import HeatMapperson
from scoreson import Scoreson
# from facerson import Facerson

#to Get timezone info from IP
from geolite2 import geolite2
import pytz 

##FACE Detection for user image validation
from face_detection.run_inference import RetinaFaceInference

##FACE recognition
# from face_recognition.recog_inference import FaceRecogInference
BASE_FACEBANK_PATH = "./facebank"

#Default image path for employee with no profile picture
DEFAULT_PIC_PATH = "./default.png"


db_connection_pool = psycopg2.pool.SimpleConnectionPool(
                        minconn=1, 
                        maxconn=20,
                        user="postgres",
                        password="123456",
                        host="localhost",
                        database="safeotest")

# mask_queue = Queue()
# sd_queue = Queue()
# heatmap_queue = Queue()
# score_queue = Queue()

# mask_obj = Maskerson(in_data_queue=mask_queue, out_data_queue=sd_queue)
# mask_thread = Thread(target=mask_obj.run, args=())
# mask_thread.daemon = False
# mask_thread.start()

# sd_obj = SD(in_data_queue=sd_queue, out_data_queue=heatmap_queue)
# sd_thread = Thread(target=sd_obj.run, args=())
# sd_thread.daemon = False
# sd_thread.start()

# map_obj = HeatMapperson(in_data_queue=heatmap_queue, out_data_queue=score_queue)
# map_thread = Thread(target=map_obj.run, args=())
# map_thread.daemon = False
# map_thread.start()

# score_obj = Scoreson(in_data_queue=score_queue)
# score_thread = Thread(target=score_obj.run, args=())
# score_thread.daemon = False
# score_thread.start()

# face_obj = Facerson()
# face_thread = Thread(target=face_obj.run, args=())
# face_thread.daemon = False
# face_thread.start()

def get_camera_object_dict():
    '''A function to initialize camera object dict. If server restarts then camera objects are reconnected else
    empty camera object dictionary is created.
    '''
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id, rtsp_link \
                            FROM camera_details")
        
        camera_data = cursor.fetchall()
        cursor.close()    
        db_connection_pool.putconn(connection)

        if len(camera_data) == 0:
            return weakref.WeakValueDictionary()

        camera_object_dict = weakref.WeakValueDictionary()

        for camera_id,link in camera_data:
            camera = VideoStreamReader(camera_id=camera_id, rtsp_link=link, data_queue=mask_queue)
            if camera.get_connection_status():
                camera_object_dict[camera_id] = camera
                camera.start()
        return camera_object_dict
    except:
        logger.exception("Exception in get_camera_object_dict")
        return weakref.WeakValueDictionary()
    
    
camera_objects_dict = get_camera_object_dict()

def create_sql_function():
    """
    Description : A function used to create sql function
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("CREATE OR REPLACE FUNCTION attend(ftime timestamptz, fstatus boolean, fnum_sec float, ltime timestamptz,lstatus boolean, lnum float8, tnum_secs float8, start timestamptz, end_time timestamptz)\
                        returns float8\
                        language plpgsql\
                        as\
                        $$\
                            BEGIN\
                                IF FSTATUS = FALSE THEN\
                                    tnum_secs := tnum_secs - fnum_sec;\
                                    tnum_secs := tnum_secs + extract(epoch from ftime-start at time zone 'utc');\
                                END IF;\
                                IF LSTATUS THEN\
                                    tnum_secs := tnum_secs + extract(epoch from end_time at time zone 'utc' - ltime);\
                                END IF;\
                                return tnum_secs;\
                            END;\
                        $$;")


        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.error("Error in create_sql_function()",exc_info=True)
        raise

create_sql_function()


def data_type_check(**kwargs):
    """
        Description : A function used to check data type of the parameter using assertion.
        Parameters  : Multiple parameters.

    """
    if ('user_email' in kwargs):
        assert isinstance(kwargs['user_email'],str),'email must be a string' 
    if ('camera_name' in kwargs):
        assert isinstance(kwargs['camera_name'],str),'camera name must be a string' 
    if ('rtsp_link' in kwargs):
        assert isinstance(kwargs['rtsp_link'],str),'rtsp link must be a string'
    if ('username' in kwargs):
        assert isinstance(kwargs['username'],type(None)),'username must be a NoneType'
    if ('password' in kwargs):
        assert isinstance(kwargs['password'],type(None)),'password must be a Nonetype'
    if ('col_name' in kwargs):
        assert isinstance(kwargs['col_name'],str),'column name must be a string'
    if ('col_value' in kwargs):
        assert isinstance(kwargs['col_value'],int),'column value must be a integer'
    if ('camera_name_tuple' in kwargs):
        assert isinstance(kwargs['camera_name_tuple'],tuple),'camera name tuple must be a tuple'
    if ('floor_name' in kwargs):
        assert isinstance(kwargs['floor_name'],str),'floor name must be a string'
    if ('settings_dict' in kwargs):
        assert isinstance(kwargs['settings_dict'],dict),'settings dictionary must be a dictionary'
    if ('floor_dict' in kwargs):
        assert isinstance(kwargs['floor_dict'],dict),'floor dictionary must be a dictionary'
    if ('camera_name_list' in kwargs):
        assert isinstance(kwargs['camera_name_list'],list),'camera name list must be a list'
    if ('max_occupancy' in kwargs):
        assert isinstance(kwargs['max_occupancy'],int),'maximum occupancy must be a integer'
    if ('new_camera_name' in kwargs):
        assert isinstance(kwargs['new_camera_name'],str),'new camera name must be a string'
    if ('max_occupancy' in kwargs):
        assert isinstance(kwargs['max_occupancy'],int),'maximum occupancy must be a integer'
    if ('date_str' in kwargs):
        assert isinstance(kwargs['date_str'],str),'date_str must be string'
    if ('end_date' in kwargs):
        assert isinstance(kwargs['end_date'],datetime.date),'end_date must be date'
    if ('freq' in kwargs):
        assert isinstance(kwargs['freq'],str),'freq must be string'
    if ('start_date' in kwargs):
        assert isinstance(kwargs['start'],datetime.date),'start_date must be date'
    if ('module_name' in kwargs):
        assert isinstance(kwargs['module_name'],str),'module_name must be string'
    if ('camera_id_tuple' in kwargs):
        assert isinstance(kwargs['camera_id_tuple'],tuple),'camera_id_tuple must be tuple'
    if ('score' in kwargs):
        assert isinstance(kwargs['score'],tuple),'score must be int'
    if ('dashboard_name' in kwargs):
        assert isinstance(kwargs['dashboard_name'],str),'dashboard_name must be string'
    if ('precision' in kwargs):
        assert isinstance(kwargs['precision'],str),'precision must be string'
    if ('time_zone' in kwargs):
        assert isinstance(kwargs['time_zone'],tuple),'time_zone must be string'
    if ('start_date_str' in kwargs):
        assert isinstance(kwargs['start_date_str'],str) or isinstance(kwargs['start_date_str'],type(None)),'start_date_str must be string or None type'
    if ('end_date_str' in kwargs):
        assert isinstance(kwargs['end_date_str'],str) or isinstance(kwargs['end_date_str'],type(None)),'end_date_str must be string or None type'
    if ('employee_email_list' in kwargs):
        assert isinstance(kwargs['employee_email_list'],list),'employee_email_list must be list type'
    
        

    
    
    

def add_camera(user_email, camera_name, rtsp_link, username=None, password=None):
    """
    Description : A function used to add camera details to the database.
    Parameters  : user_email (string), camera_name (string), rtsp_link(string) , username(none), password(none).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:

        data_type_check(user_email =  user_email, camera_name = camera_name, rtsp_link = rtsp_link, username = username, password = password)

        max_occupancy = 10
        floor_name = 'ground floor'

        _, camera_name_list, _, _ = get_camera_details(user_email)
        if camera_name in camera_name_list:
            return "This camera name already exists"

        camera_id = uuid.uuid4()
        camera = VideoStreamReader(camera_id=camera_id, rtsp_link=rtsp_link, data_queue=mask_queue)
        
        if camera.get_connection_status():
            camera_objects_dict[camera_id] = camera

            connection = db_connection_pool.getconn()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO camera_details (user_email, camera_id, camera_name, rtsp_link, floor_name, max_occupancy) \
                                    VALUES (%s, %s, %s, %s, %s, %s)", (user_email, camera_id, camera_name, str(rtsp_link), floor_name, max_occupancy))
            connection.commit()
            cursor.close()
            db_connection_pool.putconn(connection)

            camera.start()

            return 'success'
        else:
            return 'failure'
    except:
        logger.exception("exception occured in add_camera")
        return 'failure'

def get_camera_details(user_email):
    """
    Description : A function used to get the camera's details from the database using user's email address.
    Parameters  : user_email (string) .
    Returns     : Returns camera details as a list.

    """
    try:
        data_type_check(user_email =  user_email)

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id, camera_name, floor_name, max_occupancy \
                        FROM camera_details \
                        WHERE user_email = %s \
                        ORDER BY floor_name ASC", (user_email, ))
        
        camera_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(camera_data) > 0:
            camera_id_list, camera_name_list, floor_name_list, max_occupancy_list =  map(list,zip(*camera_data))
        else:
            camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = [], [], [], []

        return (camera_id_list, camera_name_list, floor_name_list, max_occupancy_list)
    except:
        logger.exception('exception occured in get_camera details')
        return ([],[],[],[])

def update_camera_details(user_email, camera_name, col_name, col_value ):
    """
    Description : A function used to update the existing camera's details.
    Parameters  : user_email (string), camera_name (string), col_name (string), col_value (integer).

    """
    try:

        data_type_check(user_email =  user_email, camera_name = camera_name, col_name = col_name, col_value = col_value)

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute(sql.SQL("UPDATE camera_details \
                        SET {} = %s \
                        WHERE user_email = %s AND camera_name = %s").format(sql.Identifier(col_name)), [col_value, user_email, camera_name])

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.exception('Exception occured in update_camera_details')

def update_camera_floor(user_email, camera_name_tuple, floor_name):
    """
    Description : A function used to update the camera floor name in camera details.
    Parameters  : user_email (string), camera_name_tuple (tuple), floor_name (string) .

    """
    try:

        data_type_check(user_email =  user_email, camera_name_tuple = camera_name_tuple, floor_name = floor_name)

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("UPDATE camera_details \
                        SET floor_name = %s \
                        WHERE user_email = %s AND camera_name IN %s", (floor_name, user_email, camera_name_tuple))
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.exception("Exception in update_camera_floor")

def update_camera_settings(user_email, camera_name, settings_dict):
    """
    Description : A function used to update the camera settings (camera_name and rtsp_link).
    Parameters  : user_email (string), camera_name (string), settings_dict (dictionary).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:
        data_type_check(user_email =  user_email, camera_name = camera_name, settings_dict = settings_dict)

        curr_settings_dict = get_camera_settings(user_email, camera_name)

        res = 'success'

        if curr_settings_dict['camera_name'] != settings_dict['camera_name']:
            res = update_camera_name(user_email, camera_name, settings_dict['camera_name'])
            if res != 'success':
                return res

        if curr_settings_dict['rtsp_link'] != settings_dict['rtsp_link']:
            res = update_rtsp_link(user_email, camera_name, settings_dict['rtsp_link'])
        
        return res
    except:
        logger.exception('Exception in update_camera_setting')
        return 'faliure'

def update_floor(user_email, floor_dict):
    """
    Description : A function used to update camera floor details.
    Parameters  : user_email (string), floor_dict (dictionary).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:
        data_type_check(user_email =  user_email, floor_dict =  floor_dict)

        floor_name_list = floor_dict['floor_name']
        camera_name_list = floor_dict['camera_name_list']

        for i, floor_name in enumerate(floor_name_list):
            curr_camera_list = camera_name_list[i]
            update_camera_floor(user_email, tuple(curr_camera_list), floor_name)

        return 'success'
    except:
        logger.exception("Exception in update floor")
        return 'failure'

def add_floor(user_email, camera_name_list, floor_name):
    """
    Description : A function used to add floor name to camera details.
    Parameters  : user_email (string), camera_name_list (list), floor_name (string).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:

        data_type_check(user_email =  user_email, camera_name_list = camera_name_list, floor_name =  floor_name)
        
        _, _, floor_name_list, _ = get_camera_details(user_email)

        if floor_name in floor_name_list:
            return 'This floor name already exists'
        else:
            update_camera_floor(user_email, tuple(camera_name_list), floor_name)
            return 'success'
    except:
        logger.exception("Exception in add_floor")
        return 'faliure'

def get_floor_details(user_email):
    """
    Description : A function used to get camera floor details using user's email address.
    Parameters  : user_email (string) .
    Returns     : Returns floor details(floor_name and camera_name_list) as a dictionary

    """
    try:

        data_type_check(user_email =  user_email)

        _, camera_name_list, floor_name_list, _ = get_camera_details(user_email)

        floor_dict = dict()

        for i, camera_name in enumerate(camera_name_list):
            floor_name = floor_name_list[i]
            if floor_name in floor_dict:
                floor_dict[floor_name].append(camera_name)
            else:
                floor_dict[floor_name] = [camera_name]

        location_dict = dict()
        location_dict['floor_name'] = list(floor_dict.keys())
        location_dict['camera_name_list'] = list(floor_dict.values())
        
        return location_dict
    except:
        logger.exception("Exception in get_floor_details")
        return {'floor_name':[],'camera_name_list':[]}

def update_max_occupancy(user_email, camera_name, max_occupancy):
    """
    Description : A function used to update the maximum occupancy .
    Parameters  : user_email (string), camera_name (string), max_occupancy (integer).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:

        data_type_check(user_email =  user_email, camera_name = camera_name , max_occupancy = max_occupancy)

        update_camera_details(user_email, camera_name, 'max_occupancy', max_occupancy)
        return 'success'
    except:
        logger.exception("Exception in update_max_occupancy")
        return 'failure'

def update_camera_name(user_email, camera_name, new_camera_name):
    """
    Description : A function used to update the camera name.
    Parameters  : user_email (string), camera_name (string), new_camera_name (string).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:
        data_type_check(user_email =  user_email, camera_name = camera_name , new_camera_name = new_camera_name)

        _, camera_name_list, _, _ = get_camera_details(user_email)

        if new_camera_name in camera_name_list:
            return 'This camera name already exists'
        else:
            update_camera_details(user_email, camera_name, 'camera_name', new_camera_name)
            return 'success'
    except:
        logger.exception("Exception in update_camera_name")
        return 'failure'

def update_rtsp_link(user_email, camera_name, rtsp_link):
    """
    Description : A function used to update the rtsp link to camera details.
    Parameters  : user_email (string), camera_name (string) , rtsp_link (string).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:
        data_type_check(user_email =  user_email, camera_name = camera_name , rtsp_link = rtsp_link)

        camera_id = get_camera_id(user_email, camera_name)

        camera = VideoStreamReader(camera_id=camera_id, rtsp_link=rtsp_link, data_queue=mask_queue)
        
        if camera.get_connection_status():
            camera_objects_dict[camera_id].remove_stream_reader()

            camera_objects_dict[camera_id] = camera

            camera.start()

            update_camera_details(user_email, camera_name, 'rtsp_link', rtsp_link)

            return 'success'
        else:
            return 'failure'
    except:
        logger.exception("Exception in update_rtsp_link")
        return 'failure'

def delete_camera(user_email, camera_name):
    """
    Description : A function used to delete camera details from the database.
    Parameters  : user_email (string), camera_name (string).
    Returns     : Returns 'success' or 'failure' as a message

    """
    try:
        data_type_check(user_email =  user_email, camera_name = camera_name )

        camera_id = get_camera_id(user_email, camera_name)
        camera_objects_dict[camera_id].remove_stream_reader()

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("DELETE FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))
        
        cursor.execute("DELETE FROM score \
                        WHERE camera_id = %s", (camera_id, ))
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in delete camera")
        return 'faliure'

def get_camera_id(user_email, camera_name):
    """
    Description : A function used to get camera ids from camera details.
    Parameters  : user_email (string), camera_name (string).
    Returns     : Returns camera ids as a list

    """
    try:

        data_type_check(user_email =  user_email, camera_name = camera_name )

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id \
                        FROM camera_details \
                        WHERE user_email = %s and camera_name = %s", (user_email, camera_name))
        
        camera_id_data = cursor.fetchall()
        
        cursor.close()
        db_connection_pool.putconn(connection)
        
        camera_id = list(zip(*camera_id_data))[0][0]

        return camera_id
    except:
        logger.exception("Exception in get_camera_id")
        return uuid.uuid4()
    

def get_camera_names(user_email):
    """
    Description : A function used to get camera names from camera details.
    Parameters  : user_email (string).
    Returns     : Returns camera names as a list

    """
    try:

        data_type_check(user_email =  user_email )

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_name \
                        FROM camera_details \
                        WHERE user_email = %s \
                        ORDER BY camera_name ASC", (user_email, ))
        
        camera_name_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(camera_name_data) > 0:
            camera_name_list = list(list(zip(*camera_name_data))[0])
        else:
            camera_name_list = []

        return camera_name_list
    except:
        logger.exception("Exceptionn in get_camera name")
        return []

def get_camera_settings(user_email, camera_name):
    """
    Description : A function used to get camera settings(camera_name and rtsp_link) from database.
    Parameters  : user_email (string), camera_name (string).
    Returns     : Returns camera settings(camera_name and rtsp_link) as a dictionary

    """
    try:
        data_type_check(user_email =  user_email, camera_name = camera_name )

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT rtsp_link \
                        FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))
        
        settings_data = cursor.fetchall()
        settings_list = list(zip(*settings_data))[0]

        cursor.close()
        db_connection_pool.putconn(connection)

        rtsp_link = settings_list[0]

        settings_dict = dict()
        settings_dict['camera_name'] = camera_name
        settings_dict['rtsp_link'] = rtsp_link

        return settings_dict
    except:
        logger.exception("Exception in get_camera_settings")
        return {'camera_name':None,'rtsp_link':None}

def get_risk_status(score):
     """
    Description : A function used to get risk status by using score(score).
    Parameters  : score(int).
    Returns     : Returns the type of risk status (unsafe,cautious,safe).

    """
    data_type_check(score = score)
    if score > 80:
        return 'unsafe'
    elif score > 20:
        return 'cautious'
    else:
        return 'safe'

def get_safety_status(score):
     """
    Description : A function used to get safety status by using score(score).
    Parameters  : score(int).
    Returns     : Returns the type of safety status (unsafe,cautious,safe).

    """
    data_type_check(score = score)
    if score >= 80:
        return 'safe'
    elif score >= 20:
        return 'cautious'
    else:
        return 'unsafe'

def str_to_date(date_str):
     """
    Description : A function used to change the type of date format.
    Parameters  : date_str(string).
    Returns     : returns the value converted to date format(str -> Date).

    """
    data_type_check(date_str = date_str)

    date = datetime.strptime(date_str, '%Y-%m-%d').date()
    return date

def get_start_date(end_date, freq):
     """
    Description : A function used to get the start date by using end date and frequency.
    Parameters  : date_str(string).
    Returns     : returns the value converted to date format(str -> Date).

    """
    
    data_type_check(end_date = end_date, freq = freq)

    if freq == 'day':
        start_date = end_date
    elif freq == 'week':
        curr_week_day = end_date.weekday()
        start_date = end_date - timedelta(days=curr_week_day)
    elif freq == 'month':
        start_date = end_date.replace(day=1)
    
    return start_date

def get_date_frame(end_date):
     """
    Description : A function used to get the data frame of frequencies (day, week, month).
    Parameters  : end_date(date).
    Returns     : returns the data frame containing frequency dates.

    """
    data_type_check(end_date = end_date)
    date_frame = {}

    for freq in ['day', 'week', 'month']:
        if freq == 'day':
            curr_str = end_date.strftime('%b %-d, %Y')

        elif freq == 'week':
            start_date = get_start_date(end_date, freq)
            start_day = start_date.strftime('%-d')
            start_month = start_date.strftime('%b')
            end_day = end_date.strftime('%-d')
            end_month = end_date.strftime('%b')

            if start_month == end_month:
                curr_str =  start_month + ' ' + start_day + ' to ' + end_day
            else:
                curr_str = start_month + ' ' + start_day + ' to ' + end_month + ' ' + end_day
        
        elif freq == 'month':
            curr_str = end_date.strftime('%b 1 to %-d')
        
        date_frame[freq] = curr_str

    return date_frame 

def get_safety_score(module_name, camera_id_tuple, start_date, end_date):
     """
    Description : A function used to get the safety score by using module name, camera id, start date and end date.
    Parameters  : module_name(str), camera_id_tuple(int),start_date(date),end_date(date).
    Returns     : returns the safety score for the particular module.

    """
    try:

        data_type_check(module_name =  module_name, camera_id_tuple = camera_id_tuple, start_date = start_date, end_date = end_date)

        metric_name = module_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp AND \
                                        time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s").format(sql.Identifier(metric_name)), [start_date, end_date, camera_id_tuple])
            risk_data = cursor.fetchall()
        else:
            risk_data = []
        
        cursor.close()
        db_connection_pool.putconn(connection)

        if len(risk_data) > 0:
            risk_score = risk_data[0][0]
            if risk_score is None:
                safety_score = 1
            else:
                safety_score = 1 - risk_score
        else:
            safety_score = 1
        return safety_score
    except:
        logger.exception("Exception in get_safety_score")
        return -1

def get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision='day',time_zone='UTC'):
     """
    Description : A function used to get the risk score data by using dashboard name, camera id, start date and end date, precision, time zone.
    Parameters  : dashboard_name(str), camera_id_tuple(tuple),start_date(date),end_date(date), precision (str), time zone (str).
    Returns     : returns the list of X_arr, y_arr values for dashboard graphs.

    """
    try:

        data_type_check(dashboard_name =  dashboard_name, camera_id_tuple = camera_id_tuple, start_date = start_date, end_date = end_date, precision = precision, time_zone = time_zone)


        precision_str = '1 ' + precision

        if precision == 'hour':
            date_format_str = 'HH12 am'
        else:
            date_format_str = 'Mon DD'
        
        metric_name = dashboard_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT to_char(grouped_time, %s), avg \
                            FROM \
                                (SELECT time_bucket(%s, time AT TIME ZONE %s) AS grouped_time, avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp  \
                                        AND time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s \
                                    GROUP BY grouped_time \
                                    ORDER BY grouped_time ASC) AS temp_table").format(sql.Identifier(metric_name)), [date_format_str, precision_str, time_zone, start_date, end_date, camera_id_tuple])

            data = cursor.fetchall()
        
        else:
            data = []

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) > 0:
            x_arr, y_arr = map(list,zip(*data))
        else:
            x_arr, y_arr = [], []

        return (x_arr, y_arr)
    except:
        logger.exception("Exception in get_risk_score_data")
        return 


def get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date):
     """
    Description : A function used to get the camera risk score by using dashboard name, camera id tuple, start date , end date.
    Parameters  : dashboard_name(str), camera_id_tuple(tuple),start_date(date),end_date(date).
    Returns     : returns the camera risk score dictionary.

    """
    try:
        data_type_check(dashboard_name =  dashboard_name, camera_id_tuple = camera_id_tuple, start_date = start_date, end_date = end_date)


        metric_name = dashboard_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT camera_id, avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp AND \
                                            time < (SELECT %s::timestamp + interval '1 day') AND \
                                            camera_id IN %s \
                                    GROUP BY camera_id").format(sql.Identifier(metric_name)), [start_date, end_date, camera_id_tuple])
            data = cursor.fetchall()

        else:
            data = []
        
        cursor.close()
        db_connection_pool.putconn(connection)

        camera_score_dict = dict(data)

        return camera_score_dict
    except:
        logger.exception("Exception in get_camera_risk_score")
        return {}


def get_date_range(start_date_str=None, end_date_str=None, freq='day'):
     """
    Description : A function used to get the date range between the start date and end  date using frequency.
    Parameters  : start_date_str (str), end_date_str (str), freq(str).
    Returns     : returns the start date,  end date, precision.

    """
    try:
        data_type_check(start_date_str = start_date_str, end_date_str = end_date_str, freq = freq)

        if start_date_str and end_date_str:
            if start_date_str == end_date_str:
                precision = 'hour'
            else:
                precision = 'day'
            
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()

        else:
            if freq == 'day':
                precision = 'hour'
            else:
                precision = 'day'
            
            end_date = datetime.now(timezone.utc).date()
            start_date = get_start_date(end_date, freq)
        
        return (start_date, end_date, precision)
    except:
        logger.exception("Exception inn get_date_range")
        return (datetime.min,datetime.max,'hour')

def get_dashboard_data(user_email, dashboard_name, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
     """
    Description : A function used to get the dashboard data using user email, dashboard name, start date str, end date str, freq, time zone.
    Parameters  : start_date_str (str/none), end_date_str (str/none), freq(str), time zone(str), user email(str), dashboard name(str).
    Returns     : returns the dashboard data in the form of dictionary.

    """
    try:
        data_type_check(user_email = user_email, dashboard_name = dashboard_name, start_date_str= start_date_str, end_date_str=end_date_str, freq=freq,time_zone=time_zone)
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        date_frame = get_date_frame(end_date)
        
        camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        x_arr, y_arr = get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone=time_zone)
        scaled_y_arr = list(np.array(y_arr) * 100)
        graph_dict = dict()
        graph_dict['x'] = x_arr
        graph_dict['y'] = scaled_y_arr

        camera_score_dict = get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date) 

        floor_dict = dict()

        for i, camera_id in enumerate(camera_id_list):
            curr_dict = dict()

            if camera_id in camera_score_dict:
                camera_risk_score = int(camera_score_dict[camera_id] * 100)
            else:
                camera_risk_score = int(0)
            
            camera_risk_status = get_risk_status(camera_risk_score)

            curr_dict['name'] = camera_name_list[i]
            curr_dict['risk_score'] = camera_risk_score
            curr_dict['risk_status'] = camera_risk_status

            if dashboard_name == 'heatmap':
                curr_dict['max_occupancy'] = max_occupancy_list[i]

            camera_floor = floor_name_list[i]

            if camera_floor in floor_dict:
                floor_dict[camera_floor].append(curr_dict)
            else:
                floor_dict[camera_floor] = [curr_dict] 
        
        camera_dict = dict()
        camera_dict['floor_names'] = list(floor_dict.keys())
        camera_dict['camera_data'] = list(floor_dict.values())

        dashboard_dict = dict()
        dashboard_dict['date_frame'] = date_frame
        dashboard_dict['graph_data'] = graph_dict
        dashboard_dict['location_data'] = camera_dict


        get_safety_score(dashboard_name, camera_id_tuple, start_date, end_date)

        return dashboard_dict
    except:
        logger.exception("Exception in get_dashboard_data")
        return {'date_frame':[],'floor_names':[],'camera_data':[],'graph_data':[],'location_data':[]}

def get_safety_insights(user_email, start_date_str=None, end_date_str=None, freq='day'):
     """
    Description : A function used to get the safety insights using user email, start date str, end date str, freq.
    Parameters  : start_date_str (str/none), end_date_str (str/none), freq(str), user email(str).
    Returns     : returns the safety insights data in the form of dictionary.

    """
    try:
        data_type_check(user_email = user_email, start_date_str= start_date_str, end_date_str=end_date_str, freq=freq)

        dashboard_dict = dict()

        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        date_frame = get_date_frame(end_date)
        dashboard_dict['date_frame'] = date_frame
        
        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        x_arr, risk_y_arr = get_risk_score_data('overall', camera_id_tuple, start_date, end_date, precision)
        scaled_safe_y_arr = list( (1 - np.array(risk_y_arr)) * 100)
        graph_dict = dict()
        graph_dict['x'] = x_arr
        graph_dict['y'] = scaled_safe_y_arr
        dashboard_dict['graph_data'] = graph_dict

        module_list = ['mask', 'sd', 'heatmap']

        for module in module_list:
            curr_dict = dict()
            module_safety_score = int(get_safety_score(module, camera_id_tuple, start_date, end_date) * 100)
            module_safety_status = get_safety_status(module_safety_score)
            
            curr_dict['safety_score'] = module_safety_score 
            curr_dict['safety_status'] = module_safety_status

            dashboard_dict[module + '_data'] = curr_dict
        
        return dashboard_dict
    except:
        logger.exception("Exception in get_safety_insights")
        return {"safety_score":[],'safety_status':[]}

def get_overall_safety_score(user_email):
     """
    Description : A function used to get the over all safety score using user email.
    Parameters  : user email(str).
    Returns     : returns the safety score, safety status data in the form of dictionary.

    """
    try:
        data_type_check(user_email = user_email)

        start_date, end_date, _ = get_date_range(freq='day')

        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        overall_safety_score = int(get_safety_score('overall', camera_id_tuple, start_date, end_date) * 100)
        overall_safety_status = get_safety_status(overall_safety_score)

        dashboard_dict = dict()
        dashboard_dict['safety_score'] = overall_safety_score
        dashboard_dict['safety_status'] = overall_safety_status
        return dashboard_dict
    except:
        logger.exception("Exception in get_overall_safety_score")
        return {'safety_score':[],'safety_status':[]}


def add_employee_email(user_email, employee_email_list):
    """
    Description : A function used to add the employee email in the employee info table.
    Parameters  : user email(str), employee email list (list).
    Returns     : returns sucess if the employee emails are inserted into table.

    """
    try:
        data_type_check(user_email = user_email, employee_email_list = employee_email_list)

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT employee_email FROM employee_info\
                        WHERE user_email = %s", (user_email, ))

        data = cursor.fetchall()

        # unpack list of single tuple
        if len(data) > 0:
            existing_employees = list(list(zip(*data))[0]) 

            # filter out existing emails
            new_employee_emails = [x for x in employee_email_list if x not in existing_employees] 
        
        else:
            new_employee_emails = employee_email_list

        if len(new_employee_emails) > 0:
            number_employees = len(new_employee_emails)
            insert_cols = zip(new_employee_emails, [user_email]*number_employees, [False]* number_employees,
                            [None]*number_employees, [None]*number_employees, [None]*number_employees)
            
            insert_cols_srt = ','.join(cursor.mogrify("(%s, %s, %s, %s, %s, %s)", x).decode('utf-8') for x in insert_cols)
            cursor.execute("INSERT INTO employee_info VALUES " + insert_cols_srt) 
            
            connection.commit()

        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in add_employee_email")
        return 'failure'

def update_employee_info(employee_email, info_dict, mode=''):
    '''
    Description : A function to update employee info . 
    parameters  : employee_email, info_dict, mode 
    Return      : If employee email is same , reads from server else 
    Set employee name,employee id,employee pic_path.
    '''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(info_dict,str),'Entered info_dict is not a string'
        assert isinstance(mode,str),'Entered mode is not a string'
        

        employee_name = info_dict["name"]
        employee_id = info_dict["id"]


        connection = db_connection_pool.getconn()
        
        cursor = connection.cursor()
    
        cursor.execute("SELECT user_email FROM employee_info \
                                WHERE employee_email = %s", (employee_email, ))

        data = cursor.fetchall()
        user_email = data[0][0]

        if mode != 'QR':
            employee_pic_path = info_dict["pic_path"]


            cursor.execute("SELECT facebank_path FROM touchless_users \
                                    WHERE user_email = %s", (user_email, ))

            fb_data  = cursor.fetchall()
            fb_path = fb_data[0][0]

            img = cv2.imread(employee_pic_path)

            frec = FaceRecogInference(face_bank_path=fb_path)
            frec.add_individual(name=employee_email, img_arr=[img])
        else:
            employee_pic_path  = DEFAULT_PIC_PATH

        cursor.execute("UPDATE employee_info \
                    SET employee_name = %s, employee_id = %s, employee_pic_path = %s, info_uploaded = %s \
                    WHERE employee_email =  %s", (employee_name, employee_id, employee_pic_path, True, employee_email))
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in update_employee_info")
        return 'failure'

def enable_face_recog(user_email):
    '''
    Description : A function to enable face recognition using user email . 
    parameters  : user_email 
    Return      : If user email is given and available then return
    as enabled,  and provides unknown(new) facepath to save in existing facepath directory.
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email \
                        FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        data = cursor.fetchall()
        
        if len(data) > 0:
            cursor.close()
            db_connection_pool.putconn(connection)
            return "Face Recog is already enabled for user"

        curr_facebank_path = os.path.join(BASE_FACEBANK_PATH, user_email)
        os.mkdir(curr_facebank_path)
        unknown_identity_path = os.path.join(curr_facebank_path, 'unknown')
        os.mkdir(unknown_identity_path)

        cursor.execute("INSERT INTO touchless_users (user_email, facebank_path) \
                        VALUES (%s, %s)", (user_email, curr_facebank_path))
        connection.commit()
        
        cursor.close()
        db_connection_pool.putconn(connection)
        
        return "success"
    except:
        logger.exception("Exception in enable_face_recog")
        return "failure"

def disable_face_recog(user_email):
    '''
    Description :A function to disable face recognition using user email . 
    parameters  : user_email .
    Return      : If user email is  given and not available then return
    as already disabled, if employee data is present then asks to delete from touchless_attendance,employee_info and 
    touchless_users.
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email \
                        FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        data = cursor.fetchall()

        if len(data) <= 0:
            cursor.close()
            db_connection_pool.putconn(connection)
            return "Face Recog is already disabled for user"

        curr_facebank_path = os.path.join(BASE_FACEBANK_PATH, user_email)
        shutil.rmtree(curr_facebank_path)    

        cursor.execute("SELECT employee_email \
                        FROM employee_info \
                        WHERE user_email = %s", (user_email, ))
        employee_data = cursor.fetchall()

        if len(employee_data) > 0:
            employee_email_list = list(zip(*employee_data))[0]
            cursor.execute("DELETE FROM touchless_attendance \
                        WHERE employee_email IN %s", (employee_email_list, ))
            connection.commit()

            cursor.execute("DELETE FROM employee_info \
                            WHERE user_email = %s", (user_email, ))
            connection.commit()

        cursor.execute("DELETE FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        connection.commit()

        cursor.close()
        db_connection_pool.putconn(connection)

        return "success"
    except:
        logger.exception("Exception in disable_face_recog")
        return "failure"
    

def get_employee_info_list(user_email):
    '''
    Description :A function to get employee information list . 
    parameters  : user_email 
    Return      : Server Returns employee_mail, employee_name, 
    employee_id as one bundle if equals ,else give empty list for those.
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        connection = db_connection_pool.getconn()
        
        
        cursor = connection.cursor()
    
        cursor.execute("SELECT employee_email, employee_name, employee_id FROM employee_info \
                                WHERE user_email = %s AND \
                                info_uploaded = %s", (user_email, True))

        data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        data = list(zip(*data))
        if len(data) > 0:
            email_list = list(data[0])
            name_list = list(data[1])
            id_list = list(data[2])
        else:
            email_list, name_list, id_list = [], [], []

        employee_info_dict = dict()
        employee_info_dict["email"] = email_list
        employee_info_dict["name"] = name_list
        employee_info_dict["id"] = id_list

        return employee_info_dict
    except:
        logger.exception("Exception in get_employee_info_list")
        return "failure"

def get_employee_info(employee_email):
    # you can get this info from the employee_info table
    # return {"name" : emp_name, "id" : emp_id, "pic_path" : }
    # parameter : employee email
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        connection = db_connection_pool.getconn()
        
        cursor = connection.cursor()
    
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path FROM employee_info \
                                WHERE employee_email = %s",(employee_email, ))

        data = cursor.fetchall()

        email, name, eid, pic_path = data[0]

        cursor.close()
        db_connection_pool.putconn(connection)

        return {'email':email,'name':name,'id':eid,'pic_path':pic_path}
    except:
        logger.exception("Exception in get_employee_info")
        return {'email':[],'name':[],'id':[],'pic_path':[]}


def delete_employee(employee_email):
    '''
    Description : A function to delete employee . 
    parameters  : employee_email 
    Return      : Deletes employee email from employee_info on 
    selecting employee email from employee info by user email
    '''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email \
                        FROM employee_info \
                        WHERE employee_email = %s", (employee_email, ))
        
        data = cursor.fetchall()
        user_email = data[0][0]

        cursor.execute("DELETE FROM employee_info \
                        WHERE employee_email = %s", (employee_email, ))
        
        connection.commit()

        cursor.execute("SELECT facebank_path \
                        FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))

        data = cursor.fetchall()
        facebank_path = data[0][0]

        cursor.close()
        db_connection_pool.putconn(connection)

        employee_pic_dir = os.path.join(facebank_path, employee_email)
        shutil.rmtree(employee_pic_dir)

        face_recognizer = FaceRecogInference(face_bank_path=facebank_path)
        face_recognizer.prepare_facebank()

        return "success"
    except:
        logger.exception("Exception in delete_employee")
        return "failure"


def get_formatted_attendance(row, start_datetime, end_datetime):
    '''
    Description : A function for getting formatted attendance 
    parameters  : row, start_datetime,end_datetime 
    Return      : 
    '''

    try:
        assert isinstance(row,int),'Entered row is not an integer'
        assert isinstance(start_datetime,int),'Entered start_datetime is not an integer'
        assert isinstance(end_datetime,int),'Entered end_datetime is not an integer'
        final_working_secs = row['total_working_secs']
        if row["first_status"] == False:
            first_time = row['first_time'].to_pydatetime()
            first_time = first_time.replace(tzinfo=timezone.utc)
            top_time_elapsed = (first_time - start_datetime).total_seconds()
            final_working_secs = final_working_secs + top_time_elapsed
        if row['last_status'] == True:
            last_time = row['last_time'].to_pydatetime()
            last_time = last_time.replace(tzinfo=timezone.utc)
            bottom_time_elapsed = (end_datetime - last_time).total_seconds()
            final_working_secs = final_working_secs + bottom_time_elapsed
        
        final_working_hours = final_working_secs / 3600
        final_working_hours = round(final_working_hours, 1)

        curr_status = row['last_time'].strftime("%I:%M%p")
        if row['last_status'] == True:
            curr_status = "IN " + curr_status
        else:
            curr_status = "OUT " + curr_status

        return final_working_hours, curr_status
    except:
        logger.exception("Exception in get_formatted_attendance")
        return 0,''

def daily_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
    '''
    Description : A function for daily touchless dashboard .
    parameters  : user_email, start_date, end_date, filter_cond, time_zone
    Return      :  it displays all detail of 
    Particular employee when start_date equals end_date
    '''
    try:
        assert isinstance(user_email,str),'Entered user_email is not a string'
        assert isinstance(start_date,int),'Entered start_date is not an integer'
        assert isinstance(end_date,int),'Entered end_date is not an integer'
        assert isinstance(filter_cond,str),'Entered filter_cond is not a string'
        assert isinstance(time_zone,str),'Entered time_zone is not a string'

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email\
                        FROM employee_info \
                        WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

        employee_data = cursor.fetchall() 


        if len(employee_data) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['attendance_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict
        else:
            email_list = tuple([x[0] for x in employee_data])

        min_time = datetime.min.time()
        start_date_time = datetime.combine(start_date, min_time)
        #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
        start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
        now = datetime.now(timezone.utc)
        now = now.replace(tzinfo=pytz.timezone(time_zone))
        if (start_date == now.date()) and (start_date == end_date):
            end_date_time = now
        else:
            max_time = datetime.max.time()
            end_date_time = datetime.combine(end_date, max_time)
            #end_date_time = end_date_time.replace(tzinfo=timezone.utc)
            end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))

        cursor.execute("WITH PRE_TABLE AS  (SELECT employee_email, \
                        first(time AT TIME ZONE %s, time) as first_time, \
                        first(attendance_status, time) as first_status, \
                        first(num_working_secs, time) as first_working_secs, \
                        last(time AT TIME ZONE %s, time) as last_time, \
                        last(attendance_status, time) as last_status, \
                        last(num_working_secs, time) as last_working_secs, \
                        sum(num_working_secs) as total_working_secs \
                            FROM (SELECT * FROM touchless_attendance \
                            WHERE employee_email IN %s AND \
                            time > %s::timestamp AND \
                            time < %s::timestamp + interval '1 day' \
                            ORDER BY time ASC) AS filter_table\
                        GROUP BY employee_email)\
                        SELECT info.employee_email as employee_email,\
                            info.employee_name as employee_name, \
                            info.employee_id as employee_id,\
                            info.employee_pic_path as employee_pic_path,\
                            (CASE When pt.last_status IS FALSE then 'OUT' When pt.last_status is TRUE Then 'IN' ELSE 'ABSENT' end) as status,\
                            FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int as num_working_hrs\
                            FROM PRE_TABLE as pt RIGHT JOIN (SELECT employee_email,employee_name,employee_id,employee_pic_path from employee_info where user_email = %s AND info_uploaded = %s) as info ON\
                            pt.employee_email = info.employee_email",(time_zone, time_zone, email_list, start_date, end_date,start_date_time,end_date_time,user_email,True))
        attendance_data = cursor.fetchall() 
        attendance_df_col_list = [desc[0] for desc in cursor.description]
        attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)



        num_employees_in = sum(attendance_data_df['status'] == 'IN')
        num_employees_out = sum(attendance_data_df['status'] == 'OUT')
        num_employees_total = attendance_data_df.shape[0]
        num_employees_absent = num_employees_total - (num_employees_in + num_employees_out) 

        overall_stats_dict = dict()
        overall_stats_dict['Total'] = num_employees_total
        overall_stats_dict['IN'] = num_employees_in
        overall_stats_dict['OUT'] = num_employees_out
        overall_stats_dict['Absent'] = num_employees_absent


        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['attendance_table'] = list(attendance_data_df.to_dict(orient='index').values())

        return overall_dict
    except:
        logger.exception("Exception in daily_touchless_attendance")
        return {}


def agg_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
    '''
    Description : A function for aggregate touchless dashboard . 
    parameters  : user_email, start_date, end_date, filter_cond, time_zone
    Return      : it displays all detail of 
    Particular employee and returns none when employee data is None
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start_date is not an integer'
        assert isinstance(end_date,int),'Entered end_date is not an integer'
        assert isinstance(filter_cond,str),'Entered filter_cond is not a string'
        assert isinstance(time_zone,str),'Entered time_zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   
        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email\
                FROM employee_info \
                WHERE user_email = %s AND info_uploaded = %s", (user_email, True))
        
        employee_data = cursor.fetchall() 

        if len(employee_data) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['attendance_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict
        else:
            email_list = tuple([x[0] for x in employee_data])

        cursor.execute("SELECT time AT TIME ZONE %s AS day, employee_email, attendance_status, num_working_secs FROM touchless_attendance \
                    WHERE employee_email IN %s AND time > %s::timestamp \
                        AND time < %s::timestamp + interval '1 day' ORDER BY time ASC\
                        ", (time_zone,email_list, start_date, end_date))

        attendance_data = cursor.fetchall()
        attendance_dict_col_list = [desc[0] for desc in cursor.description]
        attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_dict_col_list)
        attendance_data_df['day'] = pd.to_datetime(attendance_data_df['day']).dt.strftime('%b %-d')

        two_way_table = pd.crosstab(attendance_data_df.day, attendance_data_df.employee_email)
        two_way_table[two_way_table > 0] = 1

        num_total_employees = len(email_list)

        daily_absences_data = two_way_table.sum(axis=1)
        daily_absences_list = (num_total_employees - daily_absences_data.values).tolist()
        daily_absences_dates = list(daily_absences_data.index.tolist())

        absences_graph_dict = dict()
        absences_graph_dict['x'] = daily_absences_dates
        absences_graph_dict['y'] = daily_absences_list

        total_number_days = (end_date - start_date).days + 1

        employee_absences_data = total_number_days - two_way_table.sum(axis=0)



        min_time = datetime.min.time()
        start_date_time = datetime.combine(start_date, min_time)
        #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
        start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
        now = datetime.now(timezone.utc)
        now = now.replace(tzinfo=pytz.timezone(time_zone))
        if (start_date == now.date()) and (start_date == end_date):
            end_date_time = now
        else:
            max_time = datetime.max.time()
            end_date_time = datetime.combine(end_date, max_time)
            #end_date_time = end_date_time.replace(tzinfo=timezone.utc)
            end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))

        cursor.execute("WITH PRE_TABLE AS  (SELECT employee_email, \
                first(time AT TIME ZONE %s, time) as first_time, \
                first(attendance_status, time) as first_status, \
                first(num_working_secs, time) as first_working_secs, \
                last(time AT TIME ZONE %s, time) as last_time, \
                last(attendance_status, time) as last_status, \
                last(num_working_secs, time) as last_working_secs, \
                sum(num_working_secs) as total_working_secs \
                    FROM (SELECT * FROM touchless_attendance \
                    WHERE employee_email IN %s AND \
                    time > %s::timestamp AND \
                    time < %s::timestamp + interval '1 day' \
                    ORDER BY time ASC) AS filter_table\
                GROUP BY employee_email)\
                SELECT info.employee_email as employee_email,\
                    info.employee_name as employee_name, \
                    info.employee_id as employee_id,\
                    info.employee_pic_path as employee_pic_path,\
                    SUM(CASE When pt.last_status IS FALSE then 0 When pt.last_status is TRUE Then 0 ELSE 1 end) as num_absent,\
                    SUM(FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int) as num_working_hrs\
                    FROM PRE_TABLE as pt RIGHT JOIN (SELECT employee_email,employee_name,employee_id,employee_pic_path from employee_info where user_email = %s and info_uploaded = %s) as info ON\
                    pt.employee_email = info.employee_email\
                    GROUP BY info.employee_email, info.employee_name, info.employee_id, info.employee_pic_path",(time_zone, time_zone, email_list, start_date, end_date,start_date_time,end_date_time,user_email,True))
        
        attendance_data = cursor.fetchall() 
        
        attendance_df_col_list = [desc[0] for desc in cursor.description]
        attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)

        num_absent_employees = attendance_data_df['num_absent'].sum()
        avg_working_hrs = round(attendance_data_df['num_working_hrs'].sum()/(num_total_employees * total_number_days), 2)
    
        overall_stats_dict = dict()
        overall_stats_dict['Total'] = int(num_total_employees)
        overall_stats_dict['Absent'] = int(num_absent_employees)
        overall_stats_dict['avg_working_hrs'] = avg_working_hrs

        attendance_table_dict = list(attendance_data_df.to_dict(orient='index').values())

        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['graph_data'] = absences_graph_dict
        overall_dict['attendance_table'] = attendance_table_dict

        return overall_dict
    except:
        logger.exception("Exception in agg_touchless_dashboard")
        return {}

def touchless_dashboard(user_email, start_date_str=None, end_date_str=None, freq='day', filter_cond='Total',time_zone='UTC'):
    '''
    Description :A function for touchless dashboard .
    parameters  : user_email, start_date_str, end_date_str, freq, filter_cond, time_zone
    Exeption    : it displays all detail of 
    Particular employee as Daily touchless dashboard if start_date_str equals end_date_str ,else 
    provide agg touchless dashboard
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        assert isinstance(start_date_str,str),'Entered date is not a string'
        assert isinstance(end_date_str,str),'Entered date is not a string'
        assert isinstance(freq,str),'Entered freq is not a string'
        assert isinstance(filter_cond,str),'Entered filter_cond is not a string'
        assert isinstance(time_zone,str),'Entered str is not a string'
        # get start and end dates
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        if start_date == end_date:
            overall_dict = daily_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)
        else:
            overall_dict = agg_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)

        date_frame = get_date_frame(end_date)
        overall_dict['date_frame'] = date_frame
        
        return overall_dict
    except:
        logger.exception("Exception in touchless_dashboard")
        return {}

def agg_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
    '''
    Description :A function for aggregate employee attendance .
    parameters  : employee_email, start_date, end_date, time zone
    Return      :  Displays total employee
    attendance by taking minimum time as start time and maximum time as end time
    '''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not an integer'
        assert isinstance(end_date,int),'Entered end date is not an integer'
        assert isinstance(time_zone,str),'Entered time zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        min_time = datetime.min.time()
        start_date_time = datetime.combine(start_date, min_time)
         #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
        start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
        max_time = datetime.max.time()
        end_date_time = datetime.combine(end_date, max_time)
        end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))



        cursor.execute("WITH agg_emp AS (SELECT time_bucket('1 day', time AT TIME ZONE %s) AS grouped_day, \
                        sum(num_working_secs) AS total_working_secs, \
                        first(attendance_status, time) AS first_status, \
                        first(time AT TIME ZONE %s, time) AS first_time, \
                        first(num_working_secs, time) AS first_working_secs, \
                        last(attendance_status, time) AS last_status, \
                        last(time  AT TIME ZONE %s, time) AS last_time, \
                        last(num_working_secs, time) AS last_working_secs \
                        FROM touchless_attendance \
                        WHERE employee_email = %s AND \
                        time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        GROUP BY grouped_day \
                        ORDER BY grouped_day ASC)\
                        SELECT  to_char(grouped_day, 'MON DD') as x,\
                        FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int as y\
                        FROM agg_emp as pt", (time_zone, time_zone, time_zone, employee_email, start_date, end_date,  start_date_time, end_date_time))
        
        attendance_data = cursor.fetchall()

        if len(attendance_data) == 0:
            cursor.close()
            db_connection_pool.putconn(connection)
            return {}
        
        x,y= map(list,zip(*attendance_data))

        cursor.close()
        db_connection_pool.putconn(connection)

        graph_data_dict = dict()
        graph_data_dict['x'] =x
        graph_data_dict['y'] = y

        return graph_data_dict
    except:
        logger.exception("Exception in agg_employee_attendance")
        return {}



def daily_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
    '''
    Description :A function for daily employee attendance .
    parameters  : employee_email, start_date, end_date, time zone
    Return      :  Displays daily employee
    attendance 
    '''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not an integer'
        assert isinstance(end_date,int),'Entered end date is not an integer'
        assert isinstance(time_zone,str),'Entered time zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT to_char(day,'HH MM') as start_hour, LEAD(to_char(day,'HH MM')) over(order by time) as end_hour, attendance_status FROM (SELECT time,time AT TIME ZONE %s AS day, attendance_status \
                        FROM touchless_attendance \
                        WHERE employee_email = %s AND \
                        time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        ORDER BY time ASC)as p", (time_zone, employee_email, start_date, end_date))
        
        attendance_data = cursor.fetchall()
        if len(attendance_data) == 0:

            cursor.close()
            db_connection_pool.putconn(connection)
            return {}

        start,end,att = map(list,zip(*attendance_data))
        graph_data_dict = {}
        graph_data_dict['end_hour'] = end[:-1]
        graph_data_dict['start_hour'] = start[:-1]
        graph_data_dict['status'] = att[:-1]

        cursor.close()
        db_connection_pool.putconn(connection)

        return graph_data_dict
    except:
        logger.exception("Exception in daily_employee_attendace")
        return {}



def get_employee_attendance(employee_email, start_date_str=None, end_date_str=None, freq='day', time_zone='UTC'):
    '''
    Description : Get employee Attendance
    Parameter   : employee_email, start_date_str,end_date_str,freq,time_zone
    Return      : get start and end dates
    '''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date_str,str),'Entered start date str is not a string'
        assert isinstance(end_date_str,int),'Entered end date str is not a string'
        assert isinstance(freq,str),'Entered freq is not a string'
        assert isinstance(time_zone,str),'Entered time zone is not a string'
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
        if start_date == end_date:
            graph_data_dict = daily_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
        else:
            graph_data_dict = agg_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
        
        return graph_data_dict
    except:
        logger.exception("Exception in get_employee_attendance")
        return {}


def daily_temperature_dashboard(user_email, start_date, end_date, filter_cond):
    '''
    Description : To check Daily Temperature 
    Parameter   : user_email, start_date,end_date,filter_cond
    Return      : returns overall stats and temperature table
    '''

    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not an integer'
        assert isinstance(end_date,int),'Entered end date is not an integer'
        assert isinstance(filter_cond,str),'Entered filter cond is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path \
                        FROM employee_info \
                        WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

        employee_data = cursor.fetchall() 
        employee_df_col_list = [desc[0] for desc in cursor.description]
        employee_data_df = pd.DataFrame(employee_data, columns=employee_df_col_list)


        email_list = tuple(employee_data_df["employee_email"].tolist())
        if len(email_list) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['temperature_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict

        cursor.execute("WITH temp AS (SELECT employee_email, \
                        last(temperature, time) as temperature, \
                        last(temperature_status, time) as temperature_status \
                        FROM (SELECT * FROM employee_temperature \
                            WHERE employee_email IN %s AND \
                            time > %s::timestamp AND \
                            time < %s::timestamp + interval '1 day' \
                            ORDER BY time ASC) AS filter_table\
                        GROUP BY employee_email)\
                        SELECT info.employee_email, info.employee_name, info.employee_id, info.employee_pic_path, temp.temperature, coalesce(temp.temperature_status,'Absent') as temperature_status FROM\
                            temp RIGHT JOIN (SELECT employee_email, employee_name, employee_id, employee_pic_path \
                                                FROM employee_info \
                                                WHERE user_email = %s AND info_uploaded = %s) as info on temp.employee_email = info.employee_email", (email_list, start_date, end_date,user_email, True))
        temperature_data = cursor.fetchall()

        temperature_df_col_list = [desc[0] for desc in cursor.description]
        temperature_data_df = pd.DataFrame(temperature_data, columns=temperature_df_col_list)

        
        
        cursor.close()
        db_connection_pool.putconn(connection)

        #final_employee_data_df = employee_data_df.merge(temperature_data_df, on='employee_email', how='left')
        temperature_data_df['temperature'].fillna("Absent", inplace=True)
        #final_employee_data_df = final_employee_data_df[ employee_df_col_list + ["temperature", "temperature_status"] ]


        num_total_employees = len(email_list)
        num_high_temp_employees = sum(temperature_data_df['temperature_status'] == 'high')

        #if filter_cond != "Total":
        #    final_employee_data_df = final_employee_data_df.loc[final_employee_data_df['temperature_status'] == filter_cond]
        
        
        overall_stats_dict = dict()
        overall_stats_dict['total'] = num_total_employees
        overall_stats_dict['high'] = num_high_temp_employees

        temperature_table_dict = list(temperature_data_df.to_dict(orient='index').values()) 

        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['temperature_table'] = temperature_table_dict

        return overall_dict
    except:
        logger.exception("Exception in daily_temperature_dashboard")
        return {}



def agg_temperature_dashboard(user_email, start_date, end_date, filter_cond, time_zone='UTC'):
    '''
    Description : Aggregate Temperature Dashboard
    Parameter   : user_email, start_date,end_date,filter_cond,time_zone
    Return      : returns overall stats, temperature table and graph data
    '''
    try:
        assert isinstance(user_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not an integer'
        assert isinstance(end_date,int),'Entered end date is not an integer'
        assert isinstance(filter_cond,str),'Entered filter cond is not a string'
        assert isinstance(time_zone,str),'Entered time_zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path \
                        FROM employee_info \
                        WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

        employee_data = cursor.fetchall() 
        employee_df_col_list = [desc[0] for desc in cursor.description]
        employee_data_df = pd.DataFrame(employee_data, columns=employee_df_col_list)


        email_list = tuple(employee_data_df["employee_email"].tolist())
        if len(email_list) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['temperature_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict

        cursor.execute("SELECT DISTINCT temp.employee_email, \
                        temp.temperature, temp.temperature_status \
                        FROM (SELECT employee_email, MAX(temperature) AS max_temperature \
                                FROM employee_temperature \
                                WHERE employee_email IN %s AND \
                                time > %s::timestamp AND \
                                time < %s::timestamp + interval '1 day' \
                                GROUP BY employee_email) AS max_table \
                        INNER JOIN employee_temperature AS temp \
                        ON temp.employee_email = max_table.employee_email AND \
                        temp.temperature = max_table.max_temperature", (email_list, start_date, end_date))
        
        temperature_data = cursor.fetchall()
        temperature_df_col_list = [desc[0] for desc in cursor.description]
        temperature_data_df = pd.DataFrame(temperature_data, columns=temperature_df_col_list)

        final_employee_data_df = employee_data_df.merge(temperature_data_df, on='employee_email', how='left')
        final_employee_data_df['temperature'].fillna("Absent", inplace=True)
        final_employee_data_df['temperature_status'].fillna("Absent", inplace=True)
        final_employee_data_df = final_employee_data_df[ employee_df_col_list + ["temperature", "temperature_status"] ]

        num_total_employees = len(email_list)
        num_high_temp_employees = sum(final_employee_data_df['temperature_status'] == 'high')

        if filter_cond != "Total":
            final_employee_data_df = final_employee_data_df.loc[final_employee_data_df['temperature_status'] == filter_cond]
        
        overall_stats_dict = dict()
        overall_stats_dict['total'] = num_total_employees
        overall_stats_dict['high'] = num_high_temp_employees

        temperature_table_dict = list(final_employee_data_df.to_dict(orient='index').values())

        cursor.execute("SELECT to_char(temp.date, 'MON DD') AS date, temp.temperature_count \
                        FROM (SELECT time_bucket('1 day', time AT TIME ZONE %s) AS date, \
                            COUNT(temperature_status) AS temperature_count \
                            FROM employee_temperature \
                            WHERE employee_email IN %s AND \
                            time > %s::timestamp AND \
                            time < %s::timestamp + interval '1 day' AND\
                            temperature_status = 'high' \
                            GROUP BY date \
                            ORDER BY date ASC) AS temp", (time_zone, email_list, start_date, end_date))
        temperature_graph_data = cursor.fetchall()
        temperature_graph_df_col_list = [desc[0] for desc in cursor.description]
        temperature_graph_data_df = pd.DataFrame(temperature_graph_data, columns=temperature_graph_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)

        temperature_graph_data_dict = dict()
        temperature_graph_data_dict['x'] = list(temperature_graph_data_df['date'])
        temperature_graph_data_dict['y'] = list(temperature_graph_data_df['temperature_count'])

        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['temperature_table'] = temperature_table_dict
        overall_dict['graph_data'] = temperature_graph_data_dict

        return overall_dict
    except:
        logger.exception("Exception in agg_temperature_dashboard")
        return {}

def temperature_dashboard(user_email, start_date_str=None, end_date_str=None, freq='day', filter_cond='Total', time_zone= "UTC"):
    ''' Description  : Temperature Dashboard
        parameter    : user_email,start_date_str,end_date_str,freq,filter_cond,time_zone
        Return       : get graph data dict'''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date_str,str),'Entered start date str is not a string'
        assert isinstance(end_date_str,str),'Entered end date str is not a string'
        assert isinstance(freq,str),'Entered freq is not a string'
        assert isinstance(filter_cond,str),'Entered filter_cond is not a string'
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        if start_date == end_date:
            overall_dict = daily_temperature_dashboard(user_email, start_date, end_date, filter_cond)
        else:
            overall_dict = agg_temperature_dashboard(user_email, start_date, end_date, filter_cond, time_zone=time_zone)

        date_frame = get_date_frame(end_date)
        overall_dict['date_frame'] = date_frame
        
        return overall_dict
    except:
        logger.exception("Exception in temperature_dashboard")
        return {}

def daily_employee_temperature(employee_email, start_date, end_date, time_zone='UTC'):
    ''' Description  :  Daily Temperature Dashboard
        parameter    : employee_email,start_date,end_date,time_zone
        Return       : get graph data dict'''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not a integer'
        assert isinstance(end_date,int),'Entered end date  is not a integer'
        assert isinstance(time_zone,str),'Entered time_zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT to_char(time AT TIME ZONE %s, 'HH12:MI am') AS time, temperature, temperature_status \
                        FROM employee_temperature \
                        WHERE employee_email = %s AND \
                        time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        ORDER BY time ASC", (time_zone, employee_email, start_date, end_date))
        
        temperature_graph_data = cursor.fetchall()
        temperature_graph_df_col_list = [desc[0] for desc in cursor.description]
        temperature_graph_data_df = pd.DataFrame(temperature_graph_data, columns=temperature_graph_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)

        graph_data_dict = dict()
        graph_data_dict['x'] = list(temperature_graph_data_df['time'])
        graph_data_dict['y'] = list(temperature_graph_data_df['temperature'])
        graph_data_dict['status'] = list(temperature_graph_data_df[['temperature', 'temperature_status']].to_dict(orient='index').values())

        return graph_data_dict
    except:
        logger.exception("Exception in daily_employee_temperature")
        return {}


def agg_employee_temperature(employee_email, start_date, end_date, time_zone='UTC'):
    ''' Description  :  Aggregate employee temperature
        parameter    : employee_email,start_date,end_date,time_zone
        Return       : get graph data dict'''
    try:
        assert isinstance(employee_email,str),'Entered email is not a string'
        assert isinstance(start_date,int),'Entered start date is not a integer'
        assert isinstance(end_date,int),'Entered end date  is not a integer'
        assert isinstance(time_zone,str),'Entered time_zone is not a string'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
    
        cursor.execute("SELECT DISTINCT to_char(temp.date, 'MON DD'), temp.temperature \
                        FROM (SELECT time_bucket('1 DAY', time AT TIME ZONE %s) + '0.5 day' AS date, max(temperature) as temperature \
                        FROM employee_temperature \
                        WHERE employee_email = %s \
                        AND time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        GROUP BY date \
                        ORDER BY date ASC) AS temp", (time_zone, employee_email, start_date, end_date))

        data = cursor.fetchall()
        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) > 0:
            data = list(zip(*data))
            date = list(data[0])
            max_temp = list(data[1])
        else:
            date,max_temp = [], []

        status = []
        for x in max_temp:
            if x >100:
                status.append({'temperature':x,'temperature_status':'high'})
            else:
                status.append({'temperature':x,'temperature_status':'normal'})

        graph_data_dict = dict()
        graph_data_dict['x'] = date
        graph_data_dict['y'] = max_temp
        graph_data_dict['status'] = status

        return graph_data_dict
    except:
        logger.exception("exception in agg_employee_temperature")
        return {}

def get_employee_temperature(employee_email, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
    # get start and end dates
    ''' 
        Description :  Retrives infromation of employees temperature, temperature status with respect to time in a dictionary.
        Parameters : employee_email (string)
        Returns : Dictionary (JSON) format for plotting temperature graph with time. 
    '''
    try:
        assert isinstance(employee_email, str),'Enter Email is not a string'
        assert isinstance(start_date_str, None),'Enter start date should be a NoneType'
        assert isinstance(end_date_str, None),'Enter end date should be a NoneType'
        assert isinstance(freq, str),'Enter freq is not a string'
        assert isinstance(time_zone, str),'Enter time_zone is not a string'

        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
        if start_date == end_date:
            graph_data_dict = daily_employee_temperature(employee_email, start_date, end_date, time_zone=time_zone)
        else:
            graph_data_dict = agg_employee_temperature(employee_email, start_date, end_date, time_zone=time_zone)
        
        return graph_data_dict
    except:
        logger.exception("Exception in get_employee_temperature")
        return {}



def validate_image(image):
    '''Function to validate the image (if image is a valid face) 
    uploaded by the user. A valid images is a image of a single face.
    This function calls the RetinaFaceInference module to detect face.
    If no face or multiple face are detected then it returns False.
    It also validates the image after alignemnt.

    params := img - base64 encoded image
    returns Boolean 
    '''
    try:
        assert isinstance(image, base64),'Entered image is not encoded as base64'
        detector = RetinaFaceInference()

        decoded_data = base64.b64decode(image)
        np_data = np.fromstring(decoded_data,np.uint8)
        img = cv2.imdecode(np_data,cv2.IMREAD_UNCHANGED)

        img = np.array(img)
        _,landmarks = detector.detect_faces(img)

        
        if landmarks.shape[0]>0:# or h<w:
            aligned = detector.align(img)
            _,aligned_marks = detector.detect_faces(aligned)
            if aligned_marks.shape[0]>0:
                return True
            else:
                return False    
        else:
            return False
    except:
        logger.exception("Exception in validate_image")
        return False


def update_qr_attendace(employee_email):
    
    ''' 
        Description : updates the attendance entry and exit time of the employees and calculates the working time in seconds. 
        Parameters : employee_email (string)
        Returns : attendance status (TRUE/FALSE), num_working_hours (>60seconds) 
    '''

    try:
        assert isinstance(employee_email, str), 'Entered Email is not a string'
        curr_time = datetime.now(timezone.utc)
        
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT time, attendance_status \
                                        FROM touchless_attendance \
                                        WHERE employee_email = %s \
                                        ORDER BY time \
                                        DESC LIMIT 1", (employee_email, ) )
        staus_data = cursor.fetchall()
        if len(staus_data) > 0:
            last_time, prev_status = staus_data[0][0], staus_data[0][1]
            time_elapsed = (curr_time - last_time).total_seconds()
        else:
            time_elapsed = sys.maxsize
            prev_status = False

        if time_elapsed > 60:
            curr_status = not prev_status
            if curr_status == True:
                num_working_secs = 0
            else:
                num_working_secs = time_elapsed

            cursor.execute("INSERT INTO touchless_attendance (time , employee_email, attendance_status, num_working_secs) \
                            VALUES (%s, %s, %s, %s)", (curr_time, employee_email, curr_status, num_working_secs))
            
            connection.commit()

            cursor.close()
            db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("exception in update_qr_attendance")
        return 'failure'

def get_timezone(IP):

    ''' Requires maxminddb (pip install maxminddb-geolite2)
        Description : Gets timezone according to device Location.
        Parameters : IP address (String)
        Returns : TIMESTAMP with timezone
    '''
    
    reader = geolite2.reader()
    try:
        assert isinstance(IP, str), 'Entered IP is not a string'
        r =reader.get(IP)
        return r['location']['time_zone']
    except:
        logger.warning('Time zone not found in location')
        return 'UTC'
    geolite2.close()
    return 'UTC'



def make_url(prefix,user,password,ip,port,url):
    # helper
    ''' 
        Description : used to make url with user details combined
        Parameters : prefix (string), user (string), password (string), ip (string), port (integer), url (string)
        Returns : url with user details combined
    '''

    assert isinstance(prefix, str),'Entered prefix is not a string'
    assert isinstance(password, str),'Entered password is not a string'
    assert isinstance(ip, str),'Entered ip is not a string'
    assert isinstance(port, int),'Entered port is not a integer'
    assert isinstance(url, str),'Entered url is not a string'

    url = url.lstrip('/')
    if 'CHANNEL' in url:
        url = url.replace('[CHANNEL]','1')
    if 'WIDTH' in url:
        url = url.replace('[WIDTH]','416')
    if 'HEIGHT' in url:
        url = url.replace('[HEIGHT]','416')
    if 'USERNAME' in url:
        url = url.replace('[USERNAME]',user)
        url = url.replace('[PASSWORD]',password)
        return prefix+ip+'/'+url
    return prefix+user+':'+password+'@'+ip+':'+str(port)+'/'+url

def get_urls(username,password,ip,port=None,br=None):
    #helper
    ''' 
        Description : Appends all the upcoming new urls added by the user.
        Parameters : username (string), password (string), ip (string)
        Returns : All the urls of the user as a list.
    '''
    assert isinstance(username, str),'Entered username is not a string'
    assert isinstance(password, str),'Entered password is not a string'
    assert isinstance(ip, str),'Entered ip is not a string'
    assert isinstance(port, None),'Entered port should be a NoneType'
    assert isinstance(br, None),'Entered br should be a NoneType'

    all_urls = []
    new_df = df.copy()
    if br:
        if br in df['brand'].unique():
            new_df = new_df.query('brand ==@br')
    for idx,i in new_df.iterrows():
        if port==None:
            if i['port'] == -1:
                if i['prefix'] == 'rtsp://':
                    all_urls.append(make_url(i['prefix'],username,password,ip,554,i['url']))
                    all_urls.append(make_url(i['prefix'],username,password,ip,5544,i['url']))
                else:
                    all_urls.append(make_url(i['prefix'],username,password,ip,80,i['url']))
                    all_urls.append(make_url(i['prefix'],username,password,ip,8000,i['url']))
            else:
                all_urls.append(make_url(i['prefix'],username,password,ip,i['port'],i['url']))
        else:
            all_urls.append(make_url(i['prefix'],username,password,ip,port,i['url']))
    del new_df
    return all_urls



def get_ip_from_url(url):
    #helper
    ''' 
        Description : Retrives information from the url. 
        Parameters : url (string)
        Returns : ip address and port number from url
    '''
    assert isinstance(url, str),'Entered url is not a string'
    ip,port = url.split('@')[1].split('/')[0].split(':')
    return ip,int(port)

def load_url(url, timeout):
    #helper
    ''' 
        Description : Used to load the url into the socket with description.
        Parameters : {url (string), timeout (integer)
        Returns : url (status code < 400), url (from socket if response < 400)
    '''

    if url.startswith('http://'):
        ans = requests.head(url,timeout=timeout)
        if ans.status_code < 400:
            if ans.headers['Content-type'] in ['image/jpeg','video/mp4']:
                return url
            else:
                return None
    else:
        ip,port = get_ip_from_url(url)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((ip,port))
        dest="DESCRIBE "+url+" RTSP/1.0\r\nCSeq: 2\r\nUser-Agent: python\r\nAccept: application/sdp\r\n\r\n"
        sock.send(dest.encode())
        if int(sock.recv(4096)[9:13]) < 400:
            return url
   
    return None

def try_channels(link_format):
    #helper
    ''' 
        Description : Uses RTSp link for finding similar channels.
        Parameters : link_format (string)
        Returns : List of similar channels as strings.
    '''

    channels = [link_format]
    for i in range(2,9):
        new_link = re.sub('/1',f'/{i}',link_format)
        if new_link.startswith('http://'):
            try:
                resp = requests.head(new_link,timeout=0.3)
                if resp.status_code < 400 and resp.headers['Content-type'] in ['image/jpeg','video/mp4']:#check for stream
                    channels.append(new_link)
            except requests.exceptions.Timeout:
                continue
    return channels

def search(username,password,ip,port=None,brand=None):
    # returns list of string of available camera
    ''' 
        Description : Used to get all cameras added by user.
        Parameters : username (string), password (string)
        Returns : List of user cameras.
    '''

    try:
        assert isinstance(username, str),'Entered username is not a string'
        assert isinstance(password, str),'Entered password is not a string'
        assert isinstance(port, None),'Entered port should be a NoneType'
        assert isinstance(brand, None),'Entered port should be a NoneType'
        all_urls= get_urls(username,password,ip,port=port,br=brand)
        
        cameras = []
        CONNECTIONS = 150
        TIMEOUT = 1
        #data=None
        c=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=CONNECTIONS) as executor:
            future_to_url = (executor.submit(load_url,url, TIMEOUT) for url in all_urls)
            time1 = time.time()
            for future in concurrent.futures.as_completed(future_to_url):
                try:
                    data = future.result()
                except Exception as exc:
                    #data = str(type(exc))
                    data=None
                finally:
                    if data:
                        cameras.append(data)
                    c+=1
                    

            time2 = time.time()
            
        if cameras:
            cameras = try_channels(cameras[0])
        
        return cameras
    except:
        logger.exception("Exception in serach")
        return []


def get_snapshot(ip_url):
    #returns a sample image
    ''' 
        Description : Retrives snapshot from the camera connected using given ip_url.
        Parameters : ip_url (string)       
        Returns : An image from the particular camera's (ip_url)
    '''

    try:
        assert isinstance(ip_url, str),'Entered ip_url is not a string'
        if ip_url.endswith('.jpg') or ip_url.endswith('.jpeg'):
            resp = requests.get(ip_url)
            #image = np.asarray(bytearray(resp.content),dtype="uint8")
            #image = cv2.imdecode(image, cv2.IMREAD_COLOR)
            reply = resp.content
        else:
            stream = cv2.VideoCapture(ip_url)
            retval, image = cap.read()
            retval, buffer = cv2.imencode('.jpg', image)
            reply = base64.b64encode(buffer)

            stream.release()
        reply = 'data:image/jpeg;base64,'+ str(base64.b64encode(reply).decode())
        return reply
    except:
        logger.exception("Exception in get_snapshot")
        return ""

def employee_checkin_status(user_email):

    ''' 
        Description : Used to get the employee CheckIn status.
        Parameters : user_email (string)         
        Returns : Dictionary with employees name, id, picture, and checkin status. 
    '''
    assert isinstance(user_email, str),'Entered Email is not a string'
    employee_dict = dict()
    connection = db_connection_pool.getconn()
    cursor = connection.cursor()
   
    cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path FROM employee_info WHERE user_email = %s", (user_email, ))
    employees = cursor.fetchall()
    for employee in employees:
        cursor.execute("SELECT time FROM touchless_attendance WHERE employee_email = %s ORDER BY time DESC LIMIT 1", (employee[0], ))
        time = cursor.fetchall()
        for t in time:
            current_time = datetime.now(timezone.utc)
            d = (current_time - t[0]).total_seconds()
            if d <= 5:
                employee_dict['employee_name'] = employee[1]
                employee_dict['employee_id'] = employee[2]
                employee_dict['employee_pic_path'] = employee[3]
                employee_dict['checkin_time'] = t[0]
    cursor.close()
    db_connection_pool.putconn(connection)
    return employee_dict

def flush_queue(q):
    while True:
        try:
            if q.qsize() > 0:
                q.get()
            else:
                break
        except:
            print('Exception occured')
            break

def join_queue(q):

    q.close()
    q.join_thread()

def kill_saferson():

    ''' 
        Description : used to kill threads in saferson.py file
        Parameters : None        
        Returns :  stops the camera feed and closes database connection of all the threads.
    '''

    for streamer in camera_objects_dict.values():
        streamer.remove_stream_reader()

    flush_queue(mask_queue)
    flush_queue(sd_queue)
    flush_queue(heatmap_queue)
    flush_queue(score_queue)

    mask_obj.stop()
    mask_thread.join()

    sd_obj.stop()
    sd_thread.join()

    map_obj.stop()
    map_thread.join()

    score_obj.stop()
    score_thread.join()

    face_obj.stop()
    face_thread.join()

    join_queue(mask_queue)
    join_queue(sd_queue)
    join_queue(heatmap_queue)
    join_queue(score_queue)

    db_connection_pool.closeall()

def restart():

    ''' 
        Description : Used to restart threads
        Parameters : None
        Returns : Restarts all threads except main thread
    '''

    main_thread = threading.current_thread()
    for thr in threading.enumerate():
        if thr is main_thread:
            continue
        else:
            print('Killing')
            thr.join() 