# import the necessary packages
from threading import Thread
import sys
import cv2
from queue import Queue
from datetime import datetime, timezone
import imutils
import time
import urllib
import requests
import numpy as np

# what if connection gets cut in the middle
# implement scalable queue
# rn the queue has unlimited capacity

class ImageCapture:

    def __init__(self,url):
        self.url = url
        self.resp = None

    def read(self):
        try:
            self.resp = requests.get(self.url)
            image = np.asarray(bytearray(self.resp.content),dtype="uint8")
            image = cv2.imdecode(image, cv2.IMREAD_COLOR)
        except:
            return False,[]
        
        return True,image

    def isOpened(self):
        try:
            resp =requests.head(self.url)
            if resp.status_code < 400:
                return True
            else:
                return False
        except:
            return False

    def release(self):
        self.resp.close()

class VideoStreamReader:
    def __init__(self, camera_id, rtsp_link, data_queue, fps=1):
        self.camera_id = camera_id
        
        if rtsp_link.endswith('.jpg') or rtsp_link.endswith('.jpeg'):
            self.stream = ImageCapture(rtsp_link)
        else:
            self.stream = cv2.VideoCapture(rtsp_link)
        
        self.stopped = False

        self.data_queue = data_queue

        self.fps = fps

        self.time_interval = 1 / self.fps
    
    def start(self):
        self.t = Thread(target=self.update, args=())
        self.t.start()
    
    # TODO remove the full check
    def update(self):
        prev_time = time.time()
        while True:
            if self.stopped:
                # cv2.destroyAllWindows() 
                return

            if not self.data_queue.full():
                time_elapsed = time.time() - prev_time
                (grabbed, frame) = self.stream.read()
                

                if grabbed and (time_elapsed >= self.time_interval):
                    prev_time = time.time()

                    # cv2.imshow(self.t.name, frame)
                    # cv2.waitKey(1)
                    frame = imutils.resize(frame, width=400)
                    
                    curr_time = datetime.now(timezone.utc)
                    
                    curr_dict = dict()
                    curr_dict['camera_id'] = self.camera_id
                    curr_dict['time'] = curr_time
                    curr_dict['frame'] = frame

                    self.data_queue.put(curr_dict)
    
    def get_connection_status(self):
        if self.stream.isOpened():
            return True
        else:
            return False

    def remove_stream_reader(self):
        self.stopped = True
        self.t.join()

        self.stream.release()
        del self.stream