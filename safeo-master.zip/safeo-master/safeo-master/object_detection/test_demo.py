import cv2

import sys
sys.path.append("..")

from object_detection.detector_inference import ObjectDetector


if __name__ == '__main__':
    cap = cv2.VideoCapture(0)
    # cap = cv2.VideoCapture("./test.mp4")
    cap.set(3, 1280)
    cap.set(4, 720)
    print("Starting the YOLO loop...")

    detector = ObjectDetector()

    while True:
        ret, img = cap.read()
        classes, scores, boxes = detector.detect_objects(img)

        print(classes)
        print(type(classes))

        for i, curr_class in enumerate(classes):
            curr_box = boxes[i]
            curr_conf_score = scores[i]


            img = cv2.putText(img, curr_class, (curr_box[0], curr_box[1]), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,255,0), 1)
            img = cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), (255, 0 , 0), 1)


        cv2.imshow('Yolo demo', img)
        cv2.waitKey(1)

    cap.release()

