import cv2
import torch
import numpy as np

from object_detection.tool.utils import load_class_names
from object_detection.tool.torch_utils import do_detect
from object_detection.tool.darknet2pytorch import Darknet

class ObjectDetector():
    def __init__(self):
        self.use_cuda = torch.cuda.is_available()
        self.cfg_file = './object_detection/cfg/yolov4.cfg'
        self.weights_file = './object_detection/checkpoints/yolov4_darknet.weights'
        self.conf_threshold = 0.4
        self.nms_threshold = 0.6

        self.load_model()
        self.img_width = self.model.width
        self.img_height = self.model.height


    def load_model(self):
        
        self.model = Darknet(self.cfg_file)
        self.model.load_weights(self.weights_file)
        self.model.eval()

        if self.use_cuda:
            self.model.cuda()

        num_classes = self.model.num_classes
        if num_classes == 20:
            namesfile = './object_detection/data/voc.names'
        elif num_classes == 80:
            namesfile = './object_detection/data/coco.names'
        else:
            namesfile = 'data/x.names'
        
        self.class_names = load_class_names(namesfile)

    def detect_objects(self, img):

        processed_img = cv2.resize(img, (self.img_width, self.img_height))
        processed_img = cv2.cvtColor(processed_img, cv2.COLOR_BGR2RGB)

        boxes = do_detect(self.model, processed_img, self.conf_threshold, self.nms_threshold, self.use_cuda)

        img_width = img.shape[1]
        img_height = img.shape[0]

        detected_classes = []
        detected_conf_scores = []
        detected_boxes = []
        for box in boxes[0]:
            x1 = int(box[0] * img_width)
            y1 = int(box[1] * img_height)
            x2 = int(box[2] * img_width)
            y2 = int(box[3] * img_height)
            detected_boxes.append((x1, y1, x2, y2))

            cls_conf = box[5]
            detected_conf_scores.append(cls_conf)

            cls_id = box[6]
            class_name = self.class_names[cls_id]
            detected_classes.append(class_name)
        
        return detected_classes, detected_conf_scores, detected_boxes

