import os
import numpy as np
import cv2
from tqdm import tqdm

import sys
sys.path.append("..")

from face_detection.Pytorch_Retinaface.run_inference import RetinaFaceInference

src_path = "/home/surya/Documents/GitHub/safe_return/mask_detection/dataset/pyimage_dataset/yes_mask"
dst_path = "/home/surya/Documents/GitHub/safe_return/mask_detection/dataset/yes_mask_aligned"

face_detector = RetinaFaceInference()

for curr_img_name in tqdm(os.listdir(src_path)):
    curr_img_path = os.path.join(src_path, curr_img_name)

    curr_img = cv2.imread(curr_img_path, cv2.IMREAD_COLOR)

    _, curr_warped_faces = face_detector.align_multi(curr_img, output_size=(224, 224))
    
    for i, warped_face in enumerate(curr_warped_faces):
        warped_face_name = str(i) + "_" + curr_img_name
        warped_face_path = os.path.join(dst_path, warped_face_name)
        cv2.imwrite(warped_face_path, np.array(warped_face))