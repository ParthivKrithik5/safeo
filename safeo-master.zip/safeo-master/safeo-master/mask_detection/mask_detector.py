import numpy as np
import torch
from torchvision import transforms
from PIL import Image

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference

class MaskDetector():
    def __init__(self):
        self.model = torch.load("./mask_detection/awesome_model_full")
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model = self.model.to(self.device)
        self.model.eval()
        self.data_transforms = transforms.Compose([
                                    transforms.Resize(224),
                                    transforms.CenterCrop(224),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                                ])
        self.face_detector = RetinaFaceInference()


    def infer_model(self, img, detect_faces=False):

        if detect_faces == True:
            boxes, faces = self.face_detector.align_multi(img, output_size=(224,224))

            if len(faces) > 0:
                processed_imgs = [self.data_transforms(curr_img) for curr_img in faces]
                processed_imgs = torch.stack(processed_imgs, dim=0)

                preds = self.run_mask_model(processed_imgs)

                mask_status_list = []
                for curr_pred in preds:
                    if curr_pred == 0:
                        mask_status_list.append("No Mask")
                    else:
                        mask_status_list.append("Yes Mask")
                
                return np.array(mask_status_list), np.array(boxes)
            
            else:
                return np.array([]), np.array([])

        else:

            img = Image.fromarray(img)

            processed_img = self.data_transforms(img)
            processed_img = torch.unsqueeze(processed_img, 0)

            preds = self.run_mask_model(processed_img)[0]
        
            if preds == 0:
                return "No Mask"
            else:
                return "Yes Mask"
    
    def run_mask_model(self, img_arr):

        img_arr = img_arr.to(self.device)

        # forward
        with torch.set_grad_enabled(False):

            outputs = self.model(img_arr)
            _, preds = torch.max(outputs, 1)
            preds = preds.cpu().numpy()
        
        return preds