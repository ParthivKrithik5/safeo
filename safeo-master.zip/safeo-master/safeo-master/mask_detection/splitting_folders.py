import splitfolders 

src_path = "/home/surya/Desktop/real_mask_data"
dst_path = "/home/surya/Desktop/real_mask_data_split"

splitfolders.ratio(src_path, output=dst_path, seed=1337, ratio=(.8, .2))