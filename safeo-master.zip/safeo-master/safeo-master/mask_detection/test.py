import cv2

import sys
sys.path.append("../")

from face_detection.Pytorch_Retinaface.run_inference import RetinaFaceInference
from mask_detection.mask_detector import MaskDetector

img = cv2.imread("/home/surya/Documents/GitHub/safe_return/face_recognition/InsightFace_Pytorch/data/facebank/surya/2020-08-04-02-29-26.jpg")

model = MaskDetector()

print(model.infer_model(img))