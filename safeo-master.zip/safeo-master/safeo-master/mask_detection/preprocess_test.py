from PIL import Image
import cv2
import matplotlib.pyplot as plt
import numpy as np
from medpy.filter.smoothing import anisotropic_diffusion
from anisotropic import anisodiff

spoof_img_path = "/home/surya/Desktop/data/train/spoof/0009_01_04_02_81.jpg"
real_img_path = "/home/surya/Desktop/data/train/real/0001_00_00_02_247.jpg"


real_img_arr = cv2.imread(real_img_path, 0)
real_img = Image.fromarray(real_img_arr)

diffused_img_arr = anisotropic_diffusion(img=real_img_arr, niter=100, gamma=0.25, kappa=25, option=3).astype(np.uint8)

# plt.imshow(diffused_img_arr, cmap="gray")
# plt.title("diffused image")
# plt.pause(100)


diffused_img = Image.fromarray(diffused_img_arr)
diffused_img.show()