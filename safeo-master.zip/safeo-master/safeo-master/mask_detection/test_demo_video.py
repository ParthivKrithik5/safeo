import cv2
import time
from imutils.video import VideoStream
import numpy as np

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference
from mask_detection.mask_detector import MaskDetector

if __name__ == '__main__':

    mask_detector = MaskDetector()

    # initialize the video stream
    vs = VideoStream(src=0).start()

    # warm up the camera sensor
    time.sleep(2.0)

    cv2.namedWindow("Frame", cv2.WINDOW_NORMAL) 

    while True:
        img = vs.read()

        preds, bboxes = mask_detector.infer_model(img, detect_faces=True)

        if len(preds) > 0:
            # show image
            for i, curr_pred in enumerate(preds):

                if curr_pred == "Yes Mask":
                    box_color = (0, 255, 0)
                else:
                    box_color = (0, 0, 255) 
                
                curr_box = bboxes[i]

                cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), box_color, 1)

        # display image
        cv2.imshow("Frame", img)
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    # closes the windows and stops the video stream
    cv2.destroyAllWindows()
    vs.stop()