import cv2
import time
from imutils.video import VideoStream
import numpy as np

import sys
sys.path.append("..")

from face_detection.run_inference import RetinaFaceInference
from mask_detection.mask_detector import MaskDetector

if __name__ == '__main__':

    # initialize model
    face_detector = RetinaFaceInference()
    mask_detector = MaskDetector()

    # initialize the video stream
    vs = VideoStream(src=0).start()

    # warm up the camera sensor
    time.sleep(2.0)

    cv2.namedWindow("Frame", cv2.WINDOW_NORMAL) 

    while True:
        img = vs.read()

        boxes, faces = face_detector.align_multi(img, output_size=(224,224))

        # show image
        for i, curr_face in enumerate(faces):
            # curr_box = list(map(int, curr_box))

            # curr_face = img[curr_box[1]:curr_box[3], curr_box[0]:curr_box[2]]



            mask_present = mask_detector.infer_model(np.array(curr_face))

            if mask_present == "Yes Mask":
                box_color = (0, 255, 0)
            else:
                box_color = (0, 0, 255) 
            
            curr_box = boxes[i]

            cv2.rectangle(img, (curr_box[0], curr_box[1]), (curr_box[2], curr_box[3]), box_color, 1)

        # display image
        cv2.imshow("Frame", img)
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    # closes the windows and stops the video stream
    cv2.destroyAllWindows()
    vs.stop()