import os
import threading
import numpy as np
import pandas as pd
import cv2
from datetime import datetime, timedelta
import shutil

from safeo_camera import SafeoCamera

# get time zone
class SafeoUser():

    base_data_path = "./data"

    def __init__(self, email_id):
        
        self.name = email_id
        self.floor_list = ['ground_floor']


        self.user_data_path = os.path.join(SafeoUser.base_data_path, self.name)

        self.face_recog_status = False
        self.touchless_checkin_camera_name = None

        self.camera_dict = dict()
        self.camera_thread_dict = dict()

        self.green_threshold = 90

        self.cautious_threshold = 75

        #TODO Uncomment this
        os.mkdir(self.user_data_path)
    
    # add camera
    # update camera
    # add face recognition 
    # add employeee picture to face recognition
    # get employee list
    # overall score
    # overall score chart
    # module level score
    # module dashboard
    # stop all camera
    # start all camera

    def add_camera(self, name, rtsp_link, username=None, password=None):
        base_camera_data_path = os.path.join(SafeoUser.base_data_path, self.name)

        camera = SafeoCamera(name=name, rtsp_link=rtsp_link, user_data_path=base_camera_data_path, floor=self.floor_list[0])
        self.camera_dict[name] = camera

        self.start_camera(name)

    def start_camera(self, name):
        camera = self.camera_dict[name]
        camera_thread = threading.Thread(target=camera.start_camera, daemon=False)
        self.camera_thread_dict[name] = camera_thread
        self.camera_thread_dict[name].start()

    def stop_camera(self, name):
        self.camera_dict[name].stop_camera()
        self.camera_thread_dict[name].join()
        self.camera_thread_dict.pop(name, None)

    def update_camera_name(self, old_name, new_name):
        camera = self.camera_dict[old_name]
        camera.update_name(new_name)

        self.camera_dict[new_name] = self.camera_dict.pop(old_name)
        
        if old_name in self.camera_thread_dict:
            self.camera_thread_dict[new_name] = self.camera_thread_dict.pop(old_name)
    
    def update_camera_rtsp(self, name, rtsp_link, username=None, password=None):
        camera = self.camera_dict[name]
        camera.update_rtsp_link(rtsp_link)
    
    def update_camera_details(self, name, rtsp_link=None, new_name=None, username=None, password=None):
        if rtsp_link or username or password:
            self.update_camera_rtsp(name, rtsp_link, username, password)
        
        if new_name:
            self.update_camera_name(name, new_name)
    
    def update_camera_max_capacity(self, name, max_capacity):
        camera = self.camera_dict[name]
        camera.update_max_capacity(max_capacity)
    
    def get_camera_details(self):
        camera_cam_dict_list = []

        for camera in self.camera_dict.values():
            curr_dict = {}
            curr_dict['name'] = camera.get_name()
            curr_dict['rtsp_link'] = camera.get_rtsp_link()
            curr_dict['max_capacity'] = camera.get_max_capacity()
            camera_cam_dict_list.append(curr_dict)

        return camera_cam_dict_list
    
    def delete_camera(self, name):
        self.stop_camera(name)
        self.camera_dict.pop(name)

    def add_floor(self, floor, camera_name_list):
        self.floor_list.append(floor)

        for camera_name in camera_name_list:
            camera = self.camera_dict[camera_name]
            camera.update_floor(floor)
    
    def update_camera_floor(self, camera_name_list, floor_list):
        for i, camera_name in enumerate(camera_name_list):
            camera = self.camera_dict[camera_name]
            floor = floor_list[i]
            camera.update_floor(floor)
    
    def enable_face_recog(self):
        
        self.facebank_data_path = os.path.join(self.user_data_path, 'facebank')

        if not os.path.isdir(self.facebank_data_path):
            os.mkdir(self.facebank_data_path)
            unknown_identity_path = os.path.join(self.facebank_data_path, 'unknown')
            os.mkdir(unknown_identity_path)

            self.employee_data_path = os.path.join(self.user_data_path, 'employee_data.xlsx')
            employee_data_columns = ['employee_id', 'employee_name']
            self.employee_data_df = pd.DataFrame(columns=employee_data_columns)
            self.employee_data_df.to_excel(self.employee_data_path, index=False)
        else:
            self.employee_data_path = os.path.join(self.user_data_path, 'employee_data.xlsx')
            self.employee_data_df = pd.read_excel(self.employee_data_path)

        self.face_recog_status = True
        i = 0
        for camera_name, camera in self.camera_dict.items():
            if i == 0:
                # this will be the touchless checkin camera
                camera.update_face_recog_status(True, self.facebank_data_path, True)
                self.touchless_checkin_camera_name = camera_name
            else:
                camera.update_face_recog_status(True, self.facebank_data_path)
            
            i += 1
            
    def add_employee(self, img_path, employee_id, employee_name):

        if employee_id not in self.employee_data_df['employee_id'].values:
            idx = len(self.employee_data_df)
            self.employee_data_df.loc[idx] = [employee_id, employee_name]
            self.employee_data_df.to_excel(self.employee_data_path, index=False)

        img = cv2.imread(img_path)

        camera_name = list(self.camera_dict.keys())[0]
        camera = self.camera_dict[camera_name]
        camera.add_employee(img, employee_id)
    
    def delete_employee(self, employee_id):
        self.employee_data_df = self.employee_data_df[self.employee_data_df['employee_id'] != employee_id]
        self.employee_data_df.to_excel(self.employee_data_path, index=False)
        curr_employee_path = os.path.join(self.facebank_data_path, employee_id)
        shutil.rmtree(curr_employee_path)

    def str_to_date(self, date_str):
        date = datetime.strptime(date_str, '%Y-%m-%d').date()
        return date

    def get_start_date(self, end_date, freq):
        if freq == 'day':
            start_date = end_date
        elif freq == 'week':
            curr_week_day = end_date.weekday()
            start_date = end_date - timedelta(days=curr_week_day)
        elif freq == 'month':
            start_date = end_date.replace(day=1)

        return start_date

    def get_date_frame(self, end_date):
        date_frame = {}

        for freq in ['day', 'week', 'month']:
            if freq == 'day':
                curr_day = str(end_date.day)
                curr_month = end_date.strftime('%b')
                curr_year = str(end_date.year)

                curr_str = curr_month + ' ' + curr_day + ' ' + curr_year

            elif freq == 'week':
                start_date = self.get_start_date(end_date, freq)
                start_day = str(start_date.day)
                start_month = start_date.strftime('%b')
                end_day = str(end_date.day)
                end_month = end_date.strftime('%b')

                if start_month == end_month:
                    curr_str =  start_month + ' ' + start_day + ' to ' + end_day
                else:
                    curr_str = start_month + ' ' + start_day + ' to ' + end_month + ' ' + end_day
            
            elif freq == 'month':
                start_date = self.get_start_date(end_date, freq)
                start_day = str(start_date.day)
                end_day = str(end_date.day)
                curr_month = end_date.strftime('%b')

                curr_str = start_month + ' ' + start_day + ' to ' + end_day
            
            date_frame[freq] = curr_str

        return date_frame 
    
    def get_risk_status(self, score):
        if score >= 90:
            risk_status = 'unsafe'
        elif score >= 75:
            risk_status = 'cautious'
        else:
            risk_status = 'safe'
        
        return risk_status
    
    def get_safety_status(self, score):
        if score >= 90:
            risk_status = 'safe'
        elif score >= 75:
            risk_status = 'cautious'
        else:
            risk_status = 'unsafe'
        
        return risk_status


    def get_chart_ds_data(self, ds_list, freq='day'):
        if freq == 'day':
            chart_ds_list = []
            for curr_ds in ds_list:
                curr_str = curr_ds.strftime('%I %p').lower()
                if curr_str[0] == '0':
                    curr_str = curr_str[1:]
                chart_ds_list.append(curr_str)
        else:
            chart_ds_list = []
            for curr_ds in ds_list:
                curr_str = curr_ds.strftime('%d %b')
                if curr_str[0] == '0':
                    curr_str = curr_str[1:]
                chart_ds_list.append(curr_str)

        return chart_ds_list

    def get_mask_data(self, end_date_str, freq='day', start_date_str=None):
        #TODO Facial Recognition
        if start_date_str:
            # convert start date and end date string to datetime format
            start_date = self.str_to_date(start_date_str)
            end_date = self.str_to_date(end_date_str)
        else:
            # based on frequency and end date, get start date
            end_date = self.str_to_date(end_date_str)
            start_date = self.get_start_date(end_date, freq)
            
            if start_date == end_date:
                freq = 'day'
            else:
                freq = 'month'
        
        overall_mask_data = pd.DataFrame()
        location_data = {}
        for camera_name, camera in self.camera_dict.items():
            curr_camera_data = camera.get_mask_data(start_date, end_date, freq)
            overall_mask_data = overall_mask_data.append(curr_camera_data, ignore_index=True)
            
            total_faces_seen = curr_camera_data['num_total_faces_mask'].sum()
            if total_faces_seen > 0:
                curr_camera_score = (curr_camera_data['num_mask_violation'].sum() / total_faces_seen) * 100
            else:
                curr_camera_score = 0

            curr_camera_risk_status = self.get_risk_status(curr_camera_score)
            
            curr_camera_floor = camera.get_floor()
            
            curr_camera_dict = {}
            curr_camera_dict['name'] = camera_name
            curr_camera_dict['risk_score'] = int(curr_camera_score) 
            curr_camera_dict['risk_status'] =  curr_camera_risk_status

            if curr_camera_floor in location_data:
                location_data[curr_camera_floor].append(curr_camera_dict)
            else:
                location_data[curr_camera_floor] = [curr_camera_dict]
        
        floor_data_dict = {}
        floor_data_dict['floor_names'] = list(location_data.keys())
        floor_data_dict['camera_data'] = list(location_data.values())


        overall_mask_data = overall_mask_data.groupby(['ds']).sum()
        overall_mask_data = overall_mask_data.reset_index()

        overall_mask_data['mask_risk_score'] = (overall_mask_data['num_mask_violation'] / overall_mask_data['num_total_faces_mask']).multiply(100)

        overall_mask_data.fillna(0, inplace=True)
        

        graph_data_dict = {}

        ds_list = overall_mask_data['ds']
        chart_ds_list = self.get_chart_ds_data(ds_list, freq)
        score_list = list(overall_mask_data['mask_risk_score'].values.astype(int))
        score_list = [int(i) for i in score_list]
        graph_data_dict['x'] = chart_ds_list
        graph_data_dict['y'] = score_list

    
        date_frame_data = self.get_date_frame(end_date)

        overall_data_dict = {}
        overall_data_dict['date_frame'] = date_frame_data
        overall_data_dict['graph_data'] = graph_data_dict
        overall_data_dict['location_data'] = floor_data_dict
        overall_data_dict['employee_data'] = None

        return overall_data_dict
    
    def get_distancing_data(self, end_date_str, freq='day', start_date_str=None):
        if start_date_str:
            # convert start date and end date string to datetime format
            start_date = self.str_to_date(start_date_str)
            end_date = self.str_to_date(end_date_str)
        else:
            # based on frequency and end date, get start date
            end_date = self.str_to_date(end_date_str)
            start_date = self.get_start_date(end_date, freq)
            
            if start_date == end_date:
                freq = 'day'
            else:
                freq = 'month'
        
        overall_distancing_data = pd.DataFrame()
        location_data = {}
        for camera_name, camera in self.camera_dict.items():
            curr_camera_data = camera.get_distancing_data(start_date, end_date, freq)
            overall_distancing_data = overall_distancing_data.append(curr_camera_data, ignore_index=True)
            
            total_preople_seen = curr_camera_data['num_total_people_sd'].sum()
            if total_preople_seen > 0:
                curr_camera_score = (curr_camera_data['num_sd_violation'].sum() / total_preople_seen) * 100
            else:
                curr_camera_score = 0

            curr_camera_risk_status = self.get_risk_status(curr_camera_score)
            
            curr_camera_floor = camera.get_floor()
            
            curr_camera_dict = {}
            curr_camera_dict['name'] = camera_name
            curr_camera_dict['risk_score'] = int(curr_camera_score) 
            curr_camera_dict['risk_status'] =  curr_camera_risk_status

            if curr_camera_floor in location_data:
                location_data[curr_camera_floor].append(curr_camera_dict)
            else:
                location_data[curr_camera_floor] = [curr_camera_dict]
        
        floor_data_dict = {}
        floor_data_dict['floor_names'] = list(location_data.keys())
        floor_data_dict['camera_data'] = list(location_data.values())


        overall_distancing_data = overall_distancing_data.groupby(['ds']).sum()
        overall_distancing_data = overall_distancing_data.reset_index()

        overall_distancing_data['sd_risk_score'] = (overall_distancing_data['num_sd_violation'] / overall_distancing_data['num_total_people_sd']).multiply(100)

        overall_distancing_data.fillna(0, inplace=True)
        

        graph_data_dict = {}

        ds_list = overall_distancing_data['ds']
        chart_ds_list = self.get_chart_ds_data(ds_list, freq)
        score_list = list(overall_distancing_data['sd_risk_score'].values.astype(int))
        score_list = [int(i) for i in score_list]
        graph_data_dict['x'] = chart_ds_list
        graph_data_dict['y'] = score_list

    
        date_frame_data = self.get_date_frame(end_date)

        overall_data_dict = {}
        overall_data_dict['date_frame'] = date_frame_data
        overall_data_dict['graph_data'] = graph_data_dict
        overall_data_dict['location_data'] = floor_data_dict

        return overall_data_dict

    def get_heatmap_data(self, end_date_str, freq='day', start_date_str=None):
        if start_date_str:
            # convert start date and end date string to datetime format
            start_date = self.str_to_date(start_date_str)
            end_date = self.str_to_date(end_date_str)
        else:
            # based on frequency and end date, get start date
            end_date = self.str_to_date(end_date_str)
            start_date = self.get_start_date(end_date, freq)
            
            if start_date == end_date:
                freq = 'day'
            else:
                freq = 'month'
        
        overall_heatmap_data = pd.DataFrame()
        location_data = {}
        for camera_name, camera in self.camera_dict.items():
            curr_camera_data = camera.get_heatmap_data(start_date, end_date, freq)
            overall_heatmap_data = overall_heatmap_data.append(curr_camera_data, ignore_index=True)
            
            total_preople_seen = curr_camera_data['max_capacity'].sum()
            if total_preople_seen > 0:
                curr_camera_score = (curr_camera_data['num_people_heatmap'].sum() / total_preople_seen) * 100
            else:
                curr_camera_score = 0

            curr_camera_risk_status = self.get_risk_status(curr_camera_score)
            
            curr_camera_floor = camera.get_floor()
            
            curr_camera_dict = {}
            curr_camera_dict['name'] = camera_name
            curr_camera_dict['risk_score'] = int(curr_camera_score) 
            curr_camera_dict['max_capacity'] = int(camera.get_max_capacity()) 
            curr_camera_dict['risk_status'] =  curr_camera_risk_status

            if curr_camera_floor in location_data:
                location_data[curr_camera_floor].append(curr_camera_dict)
            else:
                location_data[curr_camera_floor] = [curr_camera_dict]
        
        floor_data_dict = {}
        floor_data_dict['floor_names'] = list(location_data.keys())
        floor_data_dict['camera_data'] = list(location_data.values())


        overall_heatmap_data = overall_heatmap_data.groupby(['ds']).sum()
        overall_heatmap_data = overall_heatmap_data.reset_index()

        overall_heatmap_data['heatmap_risk_score'] = (overall_heatmap_data['num_people_heatmap'] / overall_heatmap_data['max_capacity']).multiply(100)

        overall_heatmap_data.fillna(0, inplace=True)
        

        graph_data_dict = {}

        ds_list = overall_heatmap_data['ds']
        chart_ds_list = self.get_chart_ds_data(ds_list, freq)
        score_list = list(overall_heatmap_data['heatmap_risk_score'].values.astype(int))
        score_list = [int(i) for i in score_list]
        graph_data_dict['x'] = chart_ds_list
        graph_data_dict['y'] = score_list

    
        date_frame_data = self.get_date_frame(end_date)

        overall_data_dict = {}
        overall_data_dict['date_frame'] = date_frame_data
        overall_data_dict['graph_data'] = graph_data_dict
        overall_data_dict['location_data'] = floor_data_dict

        return overall_data_dict
    
    def get_touchless_checkin_data(self, end_date_str, freq='day', start_date_str=None):
        if start_date_str:
            # convert start date and end date string to datetime format
            start_date = self.str_to_date(start_date_str)
            end_date = self.str_to_date(end_date_str)
        else:
            # based on frequency and end date, get start date
            end_date = self.str_to_date(end_date_str)
            start_date = self.get_start_date(end_date, freq)
            
            if start_date == end_date:
                freq = 'day'
            else:
                freq = 'month'
        
        camera = self.camera_dict[self.touchless_checkin_camera_name]
        camera_checkin_data = camera.get_touchless_checkin_data(start_date, end_date)

        
        day_diff = end_date - start_date
        dates_list = []
        for i in range(day_diff.days + 1):
            curr_day = start_date + timedelta(days=i)
            dates_list.append(curr_day)

        employee_list = self.employee_data_df['employee_id'].values

        default_checkin_data = self.employee_data_df.copy()
        default_checkin_data['date'] = ''
        default_checkin_data['in_time'] = 'NA'
        default_checkin_data['out_time'] = 'NA'
        default_checkin_data['num_hours'] = 0
        default_checkin_data['status'] = 'out'

        overall_checkin_data = pd.DataFrame()
        camera_checkin_date_list = camera_checkin_data['date'].values
        if len(camera_checkin_data) > 0:
            for curr_date in dates_list:
                curr_default_data = default_checkin_data.copy()
                curr_default_data['date'] = curr_date

                if curr_date in camera_checkin_date_list:
                    curr_date_camera_data = camera_checkin_data[camera_checkin_data['date'] == curr_date]
                    curr_date_employee_list = curr_date_camera_data['employee_id'].values

                    for curr_employee in employee_list:
                    
                        if curr_employee in curr_date_employee_list:
                            curr_employee_data = curr_date_camera_data[curr_date_camera_data['employee_id'] == curr_employee]

                            curr_status = 'absent'
                            num_hours = None
                            check_in_time = None
                            check_out_time = None

                            for i, row in curr_employee_data.iterrows():
                                curr_time = row['ds']
                                
                                if curr_status == 'out' or curr_status == 'absent':
                                    check_in_time = curr_time
                                    curr_status = 'in'
                                elif curr_status == 'in':
                                    check_out_time = curr_time
                                    curr_status = 'out'
                                    time_spent = check_out_time - check_in_time

                                    if num_hours is None:
                                        num_hours = time_spent
                                    else:
                                        num_hours += time_spent


                            curr_employee_idx = curr_default_data.index[curr_default_data['employee_id'] == curr_employee][0]

                            if check_in_time is not None:
                                check_in_time = check_in_time.strftime('%-I:%M %p')
                                curr_default_data.at[curr_employee_idx, 'in_time'] = check_in_time
                            if check_out_time is not None:
                                check_out_time = check_out_time.strftime('%-I:%M %p')
                                curr_default_data.at[curr_employee_idx, 'out_time'] = check_out_time
                            if num_hours is not None:
                                num_hours = num_hours.seconds / 3600

                                curr_default_data.at[curr_employee_idx, 'num_hours'] = num_hours
                            
                            curr_default_data.at[curr_employee_idx, 'status'] = curr_status
            
                overall_checkin_data = overall_checkin_data.append(curr_default_data, ignore_index=True)

            # grouped_overall_data = overall_checkin_data.grouby(['employee_id', 'employee_name']).mean()
            
        if len(overall_checkin_data) <= 0:
            overall_checkin_data = overall_checkin_data.append(default_checkin_data.copy(), ignore_index=True)

        final_employee_data = []
        overall_stats_dict = {}
        if freq == 'day':
            for i, row in overall_checkin_data.iterrows():
                curr_data_dict = {}
                curr_data_dict['employee_id'] = row['employee_id']
                curr_data_dict['name'] = row['employee_name']
                curr_data_dict['in_time'] = row['in_time']
                curr_data_dict['out_time'] = row['out_time']
                curr_data_dict['num_hours'] = row['num_hours']
                
                final_employee_data.append(curr_data_dict)
            overall_stats_dict['total_employees'] = len(overall_checkin_data)
            
            in_building_df = overall_checkin_data[overall_checkin_data['status'] == 'in']
            overall_stats_dict['in_building'] = len(in_building_df)

            out_building_df = overall_checkin_data[overall_checkin_data['status'] == 'out']
            overall_stats_dict['out_building'] = len(out_building_df)

            absent_building_df = overall_checkin_data[overall_checkin_data['status'] == 'absent']
            overall_stats_dict['absent'] = len(absent_building_df)
        
        else:
            grouped_overall_data = overall_checkin_data.groupby(['employee_id', 'employee_name']).mean()
            grouped_overall_data = grouped_overall_data.reset_index()

            for i, row in grouped_overall_data.iterrows():
                curr_data_dict = {}
                curr_data_dict['employee_id'] = row['employee_id']
                curr_data_dict['employee_name'] = row['employee_name']
                curr_data_dict['in_time'] = 'NA'
                curr_data_dict['out_time'] = 'NA'
                curr_data_dict['num_hours'] = row['num_hours']

                final_employee_data.append(curr_data_dict)
            
            today_data = overall_checkin_data.drop_duplicates(subset='employee_id', keep='last', ignore_index=True)
            overall_stats_dict['total_employees'] = len(today_data)
            
            in_building_df = today_data[today_data['status'] == 'in']
            overall_stats_dict['in_building'] = len(in_building_df)

            out_building_df = today_data[today_data['status'] == 'out']
            overall_stats_dict['out_building'] = len(out_building_df)

            absent_building_df = today_data[today_data['status'] == 'absent']
            overall_stats_dict['absent_building'] = len(absent_building_df)
        
        date_frame_data = self.get_date_frame(end_date)
        final_data_dict = {}

        final_data_dict['date_frame'] = date_frame_data
        final_data_dict['overall_stats'] = overall_stats_dict
        final_data_dict['employee_data'] = final_employee_data

        return final_data_dict

    def get_safety_insights(self, end_date_str, freq='day', start_date_str=None):
        mask_data = self.get_mask_data(end_date_str, freq, start_date_str)

        x_vals = mask_data['graph_data']['x']
        mask_vals = mask_data['graph_data']['y']
        sd_vals = self.get_distancing_data(end_date_str, freq, start_date_str)['graph_data']['y']
        heatmap_vals = self.get_heatmap_data(end_date_str, freq, start_date_str)['graph_data']['y']


        overall_score_vals = []

        for i in range(len(x_vals)):
            curr_score = 100 - np.array([mask_vals[i], sd_vals[i], heatmap_vals[i]]).mean()
            overall_score_vals.append(curr_score)
        
        overall_score_vals = [int(i) for i in overall_score_vals]
        graph_data_dict = {}
        graph_data_dict['x'] = x_vals
        graph_data_dict['y'] = overall_score_vals

        if len(x_vals) > 0:
            mask_score = 100 - np.array(mask_vals).mean()
            sd_score = 100 - np.array(sd_vals).mean()
            heatmap_score = 100 - np.array(heatmap_vals).mean()
        else:
            mask_score = 100
            sd_score = 100
            heatmap_score = 100

        mask_status = self.get_risk_status(100 - mask_score)
        sd_status = self.get_risk_status(100 - sd_score)
        heatmap_status = self.get_risk_status(100 - heatmap_score)

        final_data_dict = {}
        final_data_dict['date_frame'] = mask_data['date_frame']
        final_data_dict['graph_data'] = graph_data_dict
        final_data_dict['heatmap_data'] = {'score' : heatmap_score, 'safety_status' : heatmap_status}
        final_data_dict['mask_data'] = {'score' : mask_score, 'safety_status' : mask_status}
        final_data_dict['sd_data'] = {'score' : sd_score, 'safety_status' : sd_status}

        return final_data_dict
    
    def get_overall_score(self, end_date_str):
        scores_data = self.get_safety_insights(end_date_str, freq='day')['graph_data']['y']

        if len(scores_data) > 0:
            overall_score = np.array(scores_data).mean()
        else:
            overall_score = 100

        overall_status = self.get_safety_status(overall_score)

        overall_data_dict = {'score' : overall_score, 'safety_status' : overall_status}

        return overall_data_dict
