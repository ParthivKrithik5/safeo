import os, json, datetime, pickle
from dateutil.relativedelta import relativedelta

from flask import Blueprint, abort, jsonify, request

from app import auth, logging, db
from utils import get_plan_details, get_random_string, STATUS, create_customer_profile, create_an_accept_payment_transaction, \
    get_customer_payment_profile, update_user_pickle_obj, get_accept_customer_profile_page, get_customer_profile
from models import User, Business, PaymentCard, Invoice, Camera, User_Role_Map, Role, get_current_user, \
    get_business, get_camera_list, get_invoices, get_payment_card
import constants
from safeo_user import SafeoUser

# Admin API Services

admin_blueprint = Blueprint('admin', __name__)

@admin_blueprint.route('/api/purchase-plans', methods=['GET'])
@auth.login_required()
def purchase_plans():
    """Purchase Plans"""
    logging.info("purchase_plans : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        resp_dict['status'] = True
        resp_dict['object'] = get_plan_details()
    except Exception as e:
        logging.error("purchase_plans : exception : {}".format(e))
        abort(500)
    logging.info("purchase_plans : end")
    return jsonify(resp_dict)
    
@admin_blueprint.route('/api/payment-keys', methods=['GET'])
@auth.login_required()
def payment_keys():
    """Payment Authentication Keys"""
    logging.info("payment_keys : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        resp_dict['status'] = True
        resp_dict['object'] = {
            'api_login_key' :  constants.API_LOGIN_KEY,
            'transaction_key' : constants.CLIENT_KEY
        }
    except Exception as e:
        logging.error("payment_keys : exception : {}".format(e))
        abort(500)
    logging.info("payment_keys : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/select-freemimum-plan', methods=['POST'])
@auth.login_required()
def select_freemimum_plan():
    """Select Freemium Plan"""
    logging.info("select_freemimum_plan : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            if business:      
                business.selected_plan = constants.FREEMIUM
                business.active_users = constants.FREEMIUM_NO_OF_USERS
                business.updated_date = datetime.datetime.now()
                business.updated_by = user.user_id
                db.session.commit()

                if not os.path.exists('./data/'+user.email):
                    curr_user = SafeoUser(email_id=user.email)
                    curr_user.enable_face_recog()
                    update_user_pickle_obj(curr_user, user.email)
                
                resp_dict['status'] = True
                resp_dict['msg'] = 'Created Successfully'
            else:
                resp_dict['msg'] = 'Your login session has expired, please login again'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("select_freemimum_plan : exception : {}".format(e))
        abort(500)
    logging.info("select_freemimum_plan : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/select-pro-plan', methods=['POST'])
@auth.login_required()
def select_pro_plan():
    """Select Pro Plan"""
    logging.info("select-pro-plan : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        payable_term = request.json.get('payable_term') # Monthly/Yearly
        payable_amount = request.json.get('payable_amount')

        exp_date =None
        if payable_term == 'Monthly':
            exp_date = datetime.datetime.now()+relativedelta(months=1)
        elif payable_term == 'Yearly':
            exp_date = datetime.datetime.now()+relativedelta(years=1)

        user = get_current_user()
        if user:
            business = get_business(user)

            # Create Customer Profile
            paymentCard = get_payment_card(business.business_id)
            customerProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
                card_id = paymentCard.card_id
            else:
                card_id = paymentCard.card_id
                customerProfileId = paymentCard.customer_profile_id
            
            card_present, customerPaymentProfileId = get_customer_profile(customerProfileId)
            if card_present == STATUS['NO']:
                resp_dict['msg'] = 'No credit card available'
                return jsonify(resp_dict)

            invoice_sub_total_amount = payable_amount
            invoice_tax = 0
            invoice_total_amount = invoice_sub_total_amount+invoice_tax
            invoice_paid_amount = 0
            invoice = Invoice(business.business_id, card_id, invoice_sub_total_amount, invoice_tax, invoice_total_amount, invoice_paid_amount)
            db.session.add(invoice)
            db.session.commit()

            transId, error_message = create_an_accept_payment_transaction(customerProfileId, customerPaymentProfileId, \
                invoice.invoice_no, invoice_total_amount)      
            if not transId:
                invoice.status = STATUS['ERROR']
                invoice.remarks = error_message
                invoice.updated_by = user.user_id
                invoice.updated_date = datetime.datetime.now()
                db.session.commit()

                resp_dict['msg'] = error_message
                return jsonify(resp_dict)

            invoice.invoice_paid_amount = invoice_total_amount
            invoice.transcation_id = transId
            invoice.status = STATUS['COMPLETED']
            invoice.updated_date = datetime.datetime.now()
            invoice.updated_by = user.user_id
            db.session.commit()

            business.selected_plan = constants.PRO
            business.active_users = constants.PRO_NO_OF_USERS
            business.plan_exp_data = exp_date
            business.updated_date = datetime.datetime.now()
            business.updated_by = user.user_id
            db.session.commit()

            if not os.path.exists('./data/'+user.email):
                curr_user = SafeoUser(email_id=user.email)
                curr_user.enable_face_recog()
                update_user_pickle_obj(curr_user, user.email)
                
            resp_dict['status'] = True
            resp_dict['msg'] = 'Created Successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("select-pro-plan : exception : {}".format(e))
        abort(500)
    logging.info("select-pro-plan : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/user-profile', methods=['GET'])
@auth.login_required()
def user_profile():
    """Fetching User Profile"""
    logging.info("user_profile : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            profile_dict =  {
                'user_id' : user.user_id,
                'name' : user.name,
                'email' : user.email,
                'phone' : user.phone,
                'business_name' : business.business_name,
                'industry' : business.industry,
                'address': business.address
            }
            resp_dict['status'] = True
            resp_dict['object'] = profile_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("user_profile : exception : {}".format(e))
        abort(500)
    logging.info("user_profile : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/update-user-profile', methods=['POST'])
@auth.login_required()
def update_user_profile():
    """Update User Profile"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("update_user_profile : start")
    try:
        name = request.json.get('name')
        phone = request.json.get('phone')
        business_name =  request.json.get('business_name')
        industry = request.json.get('industry')
        address = request.json.get('address')
        
        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"
       
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        user = get_current_user()
        if user:
            user.name = name
            user.phone = phone
            user.updated_date = datetime.datetime.now()
            user.updated_by = user.user_id
            db.session.commit()

            business = get_business(user)
            business.business_name = business_name
            business.industry = industry
            business.address = address
            db.session.commit()

            resp_dict['status'] = True
            resp_dict['msg'] = 'User Profile updated successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("update_user_profile : exception : {}".format(e))
        abort(500)
    logging.info("update_user_profile : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/update-password', methods=['POST'])
@auth.login_required()
def update_password():
    """Update password"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("update_password : start")
    try:
        old_password = request.json.get('old_password')
        new_password = request.json.get('new_password')

        # Input validation
        if not old_password or not new_password :
            resp_dict['msg'] = 'Old password and New password are required'
            return jsonify(resp_dict)
        if old_password == new_password:
            resp_dict['msg'] = 'Old password and New password cannot be same'
            return jsonify(resp_dict)

        user = get_current_user()
        if user:
            # Old password validation
            if not user.verify_password(old_password):
                resp_dict['msg'] = 'Old password mismatch'
                return jsonify(resp_dict)

            user.hash_password(new_password)
            user.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
            resp_dict['msg'] = 'Password updated successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("update_password : exception : {}".format(e))
        abort(500)
    logging.info("update_password : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/billing-info', methods=['GET'])
@auth.login_required()
def billing_info():
    """Fetch Card, Billing address, Plan and Invoice Details"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("billing_info : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            invoices =  get_invoices(business.business_id)
            paymentCard = get_payment_card(business.business_id)
            card_number = ''
            card_holder_name = ''
            billing_address = ''
            response_dict ={}
            no_of_camera = 0

            cameras = get_camera_list(business)
            if cameras:
                no_of_camera = int(len(cameras))
            
            if paymentCard and paymentCard.customer_profile_id:
                card_present, customerPaymentProfileId = get_customer_profile(paymentCard.customer_profile_id)
                if customerPaymentProfileId != '':
                    response_dict = get_customer_payment_profile(paymentCard.customer_profile_id, customerPaymentProfileId)
            
            if response_dict:
                card_number = response_dict['credit_card']
                card_holder_name = response_dict['first_name']+" "+response_dict['last_name']
                billing_address = response_dict['address']+","+response_dict['city']+","+response_dict['state']+","+\
                    response_dict['zip_code']+","+response_dict['country']+","+response_dict['phone_number']
            
            invoice_list=[]
            for invoice in invoices:
                invoice_dict={}
                invoice_dict['invoice_paid_amount'] = invoice.invoice_paid_amount
                invoice_dict['invoice_date'] = (invoice.invoice_date).strftime("%b %d, %Y")
                invoice_list.append(invoice_dict)
                
            billing_info_dict =  {
                'plan' : business.selected_plan,
                'no_cameras' : no_of_camera,
                'no_users' : business.active_users,
                'payment_card_number' : card_number,
                'payment_card_holder_name' : card_holder_name,
                'billing_address' : str(billing_address),
                'invoice_list' : invoice_list
            }
            resp_dict['status'] = True
            resp_dict['object'] = billing_info_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("billing_info : exception : {}".format(e))
        abort(500)
    logging.info("billing_info : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/manage-cards', methods=['GET'])
@auth.login_required()
def manage_cards():
    """Payment Gateway Manage Cards"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("manage_cards : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            paymentCard = get_payment_card(business.business_id)
            
            customerProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
            else:
                customerProfileId = paymentCard.customer_profile_id

            token, error_message = get_accept_customer_profile_page(paymentCard.customer_profile_id)
            if token == '':
                resp_dict['msg'] = error_message
                return jsonify(resp_dict)

            auth_manage_cards_url = constants.auth_manage_cards_url_dev
            if constants.PRODUCTION:
                auth_manage_cards_url = constants.auth_manage_cards_url_prd
            
            manage_card_dict= {
                'token':token,
                'auth_manage_cards_url':auth_manage_cards_url,
                'manage_cards_success_url':constants.manage_cards_success_url,
                'manage_cards_init_url':constants.manage_cards_init_url,
            }
            resp_dict['status'] = True
            resp_dict['object'] = manage_card_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("manage_cards : exception : {}".format(e))
        abort(500)
    logging.info("manage_cards : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/check-card-status', methods=['GET'])
@auth.login_required()
def check_card_status():
    """Check Card Availability in the customer profile"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("check_card_status : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            paymentCard = get_payment_card(business.business_id)
            
            customerProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
            else:
                customerProfileId = paymentCard.customer_profile_id
            
            card_present, customerPaymentProfileId = get_customer_profile(customerProfileId)
            card_status_dict= {
                'card_present':card_present,
            }
            resp_dict['status'] = True
            resp_dict['object'] = card_status_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("check_card_status : exception : {}".format(e))
        abort(500)
    logging.info("check_card_status : end")
    return jsonify(resp_dict)