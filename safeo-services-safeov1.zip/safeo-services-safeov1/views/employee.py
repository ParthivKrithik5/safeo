import os, json, datetime, base64

from flask import Blueprint, abort, jsonify, send_from_directory, request
from werkzeug.utils import secure_filename

from app import app, auth, db, logging
from models import Role, User, User_Role_Map, Business, Camera, get_current_user, get_business, \
    get_camera_list, get_floor_list, get_admin_user
    
from utils import get_random_string, STATUS, forgot_password_mail, allowed_file, get_user_pickle_obj, update_user_pickle_obj
from safeo_user import SafeoUser

# Employee API Services

employee_blueprint = Blueprint('employee', __name__)

@employee_blueprint.route('/api/terms-conditions-agreement', methods=['POST'])
@auth.login_required()
def terms_conditions_agreement():
    """Terms & Conditions Agreement accepting status update"""
    logging.info("terms_conditions_agreement : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            user.terms_conditions_agreement = STATUS['YES']
            user.updated_date = datetime.datetime.now()
            user.updated_by = user.user_id
            db.session.commit()
            resp_dict['status'] = True
            resp_dict['msg'] = 'Terms & Conditions accept status updated'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("terms_conditions_agreement : exception : {}".format(e))
        abort(500)
    logging.info("terms_conditions_agreement : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/add-employee', methods=['POST'])
@auth.login_required()
def add_employee():
    """Add Employee"""
    logging.info("add_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        email_list = request.json.get('email_list')
        if email_list:
            email_list = [i.strip() for i in email_list]

        for email in email_list:
            if User.query.filter_by(email=email).first():
                resp_dict['msg'] = email+' address is already added, please remove it from email list'
                return jsonify(resp_dict)

        user = get_current_user()
        if user:
            business = get_business(user)
            role_name = str(business.business_id)+'_EMPLOYEE'
            role = Role.query.filter(Role.role_name == role_name).first()
            if not role:
                # Save Role
                role_desc = 'EMPLOYEE'
                role = Role(role_name, role_desc, business.business_id)
                db.session.add(role)
                db.session.commit()

            for email in email_list:
                # Save User
                new_password = get_random_string()
                user = User('', email, '', '')
                user.hash_password(new_password)
                user.terms_conditions_agreement = STATUS['NO']
                user.created_by = user.user_id
                db.session.add(user)
                db.session.commit()

                # User & Role Mapping
                user_role_map = User_Role_Map(user.user_id, role.role_id)
                db.session.add(user_role_map)
                db.session.commit()
    
                # Send mail with new password
                forgot_password_mail(user.email, new_password)

            business.active_users = (business.active_users+len(email_list))
            business.updated_date = datetime.datetime.now()
            business.updated_by = user.user_id
            db.session.commit()
            
            resp_dict['status'] = True
            resp_dict['msg'] = "Added Successfully"
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("add_employee : exception : {}".format(e))
        abort(500)
    logging.info("add_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/employee-list', methods=['GET'])
@auth.login_required()
def employee_list():
    """Employee List"""
    logging.info("employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        emp_list = []
        user = get_current_user()
        if user:
            business = get_business(user)            
            role_name = str(business.business_id)+'_EMPLOYEE'
            role = Role.query.filter(Role.role_name == role_name).first()
            if role:
                user_role_maps = User_Role_Map.query.filter(User_Role_Map.role_id == role.role_id).all() 
                if user_role_maps:
                    for user_role_map in user_role_maps:
                        user = User.query.filter((User.user_id == user_role_map.user_id) & (User.status == STATUS['ACTIVE'])).first()
                        if user:
                            user_dict = {}
                            user_dict['user_id'] = user.user_id
                            user_dict['name'] = user.name
                            user_dict['email'] = user.email
                            emp_list.append(user_dict)     
            resp_dict['status'] = True
            resp_dict['object'] = emp_list
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("employee_list : exception : {}".format(e))
        abort(500)
    logging.info("employee_list : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/employee-info', methods=['GET'])
@auth.login_required()
def employee_info():
    """Fetching Employee Info"""
    logging.info("employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            result_dict = {}
            if not user.employee_id or not user.profile_image_path:
                result_dict['update_status'] = True
            else:
                result_dict['update_status'] = False
            
            result_dict['profile'] = {
                'user_id' : user.user_id,
                'name' : user.name,
                'email' : user.email,
                'profile_image_url' : ('' if not user.profile_image_path else app.config['SERVER_PATH']+'/api/profile-image/'+user.profile_image_path),
                'employee_id': ('' if not user.employee_id else user.employee_id)
            }
            resp_dict['status'] = True
            resp_dict['object'] = result_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("employee_info : exception : {}".format(e))
        abort(500)
    logging.info("employee_info : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/update-employee', methods=['POST'])
@auth.login_required()
def update_employee():
    """Employee Info Update"""
    logging.info("update_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_name = request.json.get('employee_name')
        employee_id = request.json.get('employee_id')
        profile_image_data = request.json.get('profile_image_data')
        user = get_current_user()
        if user:
            profile_image_file_name = ''
            if profile_image_data:
                profile_image_data = profile_image_data.split(',')[1]
                profile_image_file_name = str(user.user_id)+'_profile.jpg'
                with open(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name), 'wb') as f:
                    f.write(base64.b64decode(profile_image_data))
                logging.info('Profile Image Saved {}'.format(profile_image_file_name))    
            
            user.name = employee_name
            user.employee_id = employee_id
            user.profile_image_path = profile_image_file_name
            user.updated_date = datetime.datetime.now()
            user.updated_by = user.user_id
            db.session.commit()

            business = get_business(user)
            email = get_admin_user(business)
            logging.info('Admin user - {}'.format(email))
            if email:
                curr_user, email = get_user_pickle_obj(email)
                cameras = get_camera_list(business)
                for camera in cameras:
                    curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
                    curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)

                floor_list = get_floor_list(business)
                for floor in floor_list:
                    curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])

                curr_user.enable_face_recog()
                curr_user.add_employee(os.path.join(app.config['PROFILE_IMAGES'], user.profile_image_path), user.employee_id, user.name)
                for camera in cameras:
                    curr_user.delete_camera(camera.name)
                update_user_pickle_obj(curr_user, email)

            resp_dict['status'] = True
            resp_dict['msg'] = "Saved Successfully"
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("update_employee : exception : {}".format(e))
        abort(500)
    logging.info("update_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/delete-employee', methods=['POST'])
@auth.login_required()
def delete_employee():
    """Delete Employee"""
    logging.info("delete_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user_id = request.json.get('user_id')
        user = get_current_user()
        if user:
            emp = User.query.filter(User.user_id == user_id).first()
            if emp :
                if emp.employee_id:
                    curr_user, email = get_user_pickle_obj(user.email)
                    business = get_business(user)
                    cameras = get_camera_list(business)
                    for camera in cameras:
                        curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)                
                        curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)
                        
                    floor_list = get_floor_list(business)
                    for floor in floor_list:
                        curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
                        
                    curr_user.enable_face_recog()
                    curr_user.delete_employee(emp.employee_id)
                    for camera in cameras:
                        curr_user.delete_camera(camera.name)
                    update_user_pickle_obj(curr_user, email)

                emp.status = STATUS['DE-ACTIVE']
                emp.updated_date = datetime.datetime.now()
                emp.updated_by = user.user_id
                db.session.commit()
                resp_dict['status'] = True
                resp_dict['msg'] = "Deleted Successfully"
            else:
                resp_dict['msg'] = "Employee data not found!"
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("delete_employee : exception : {}".format(e))
        abort(500)
    logging.info("delete_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/profile-image/<string:filename>', methods=['GET'])
def profile_image(filename):
    return send_from_directory(app.config['PROFILE_IMAGES'],filename)
