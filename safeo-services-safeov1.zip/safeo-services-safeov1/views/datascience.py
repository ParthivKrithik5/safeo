from safeo_user import SafeoUser
import os, json, datetime

from flask import Blueprint, abort, jsonify, request

from app import auth, logging, db, app
import constants
from models import User, Business, Camera, Floor, get_current_user, get_business, get_camera_list, get_floor_list
from utils import STATUS, get_user_pickle_obj, update_user_pickle_obj

# Data Science API Service

datascience_blueprint = Blueprint('datascience', __name__)

@datascience_blueprint.route('/api/add-camera', methods=['POST'])
@auth.login_required()
def add_camera():
    """Add Camera"""
    logging.info("add_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        password = request.json.get('password')

        user = get_current_user()
        business = get_business(user)
        camera = Camera(business.business_id, camera_name, rtsp_link, username, password)
        camera.max_capacity = 10 # Default Max Capacity
        camera.created_by = user.user_id
        db.session.add(camera)
        db.session.commit()

        floor = Floor(business.business_id, 'ground_floor', camera.camera_id)
        floor.created_by = user.user_id
        db.session.add(floor)
        db.session.commit()

        resp_dict['status'] = True
        resp_dict['msg'] = 'Camera Added Successfully'
    except Exception as e:
        logging.error("add_camera : exception : {}".format(e))
        abort(500)
    logging.info("add_camera : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-camera', methods=['POST'])
@auth.login_required()
def update_camera():
    """Update Camera"""
    logging.info("update_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        password = request.json.get('password')
        camera_id = request.json.get('camera_id')

        user = get_current_user()
        camera = Camera.query.filter(Camera.camera_id == camera_id).first()
        camera.name = camera_name
        camera.rtsp_link = rtsp_link
        camera.username = username
        camera.password = password
        camera.updated_date = datetime.datetime.now()
        camera.updated_by = user.user_id
        db.session.commit()

        resp_dict['status'] = True
        resp_dict['msg'] = 'Camera updated successfully'
    except Exception as e:
        logging.error("update_camera : exception : {}".format(e))
        abort(500)
    logging.info("update_camera : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-camera-max-capacity', methods=['POST'])
@auth.login_required()
def update_camera_max_capacity():
    """Updated Camera Maximum Allowed Capacity"""
    logging.info("update_camera_max_capacity : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        max_capacity = request.json.get('max_capacity')
        user = get_current_user()
        business =  get_business(user)
        camera = Camera.query.filter((Camera.business_id == business.business_id) & (Camera.name == camera_name)).first()
        camera.max_capacity = max_capacity
        camera.updated_date = datetime.datetime.now()
        camera.updated_by = user.user_id
        db.session.commit()
        resp_dict['status'] = True
        resp_dict['msg'] = 'Capacity Updated'        
    except Exception as e:
        logging.error("update_camera_max_capacity : exception : {}".format(e))
        abort(500)
    logging.info("update_camera_max_capacity : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/office-surveillance', methods=['GET'])
@auth.login_required()
def office_surveillance():
    """Office Surveillance"""
    logging.info("office_surveillance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_list = []
        user = get_current_user()
        if user:
            business = get_business(user)
            cameras = get_camera_list(business)
            for camera in cameras:
                camera_dict = {}
                camera_dict['name'] = camera.name
                camera_dict['rtsp_link'] = camera.rtsp_link
                camera_list.append(camera_dict)
        resp_dict['status'] = True
        resp_dict['object'] =  camera_list
    except Exception as e:
        logging.error("office_surveillance : exception : {}".format(e))
        abort(500)
    logging.info("office_surveillance: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/camera-list', methods=['GET'])
@auth.login_required()
def camera_list():
    """Camera List"""
    logging.info("camera_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_list = []
        user = get_current_user()
        if user:
            business = get_business(user)
            cameras = get_camera_list(business)
            for camera in cameras:
                camera_dict = {}
                camera_dict['name'] = camera.name
                camera_dict['rtsp_link'] = camera.rtsp_link
                camera_dict['username'] = camera.username
                camera_dict['password'] = camera.password
                camera_dict['camera_id'] = camera.camera_id
                camera_list.append(camera_dict)
        resp_dict['status'] = True
        resp_dict['object'] =  camera_list
    except Exception as e:
        logging.error("camera_list : exception : {}".format(e))
        abort(500)
    logging.info("camera_list: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/delete-camera', methods=['POST'])
@auth.login_required()
def delete_camera():
    """Delete Camera"""
    logging.info("delete_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_id = request.json.get('camera_id')
        user = get_current_user()
        if user:
            camera = Camera.query.filter(Camera.camera_id == camera_id).first()
            camera.status = STATUS['DE-ACTIVE']
            camera.updated_date = datetime.datetime.now()
            camera.updated_by = user.user_id
            db.session.commit()
        resp_dict['status'] = True
        resp_dict['msg'] = "Deleted Successfully"
    except Exception as e:
        logging.error("delete_camera : exception : {}".format(e))
        abort(500)
    logging.info("delete_camera: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/add-floor', methods=['POST'])
@auth.login_required()
def add_floor():
    """Add Floor"""
    logging.info("add_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_name = request.json.get('floor_name')
        camera_id_list = request.json.get('camera_id_list')
        user = get_current_user()
        
        for camera_id in camera_id_list:
            floor = Floor.query.filter(Floor.camera_id == camera_id).first()
            floor.floor_name = floor_name
            floor.updated_date = datetime.datetime.now()
            floor.created_by = user.user_id
            db.session.commit()

        resp_dict['status'] = True
        resp_dict['msg'] = 'Floor saved successfully'
    except Exception as e:
        logging.error("add_floor : exception : {}".format(e))
        abort(500)
    logging.info("add_floor : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-floor', methods=['POST'])
@auth.login_required()
def update_floor():
    """Add Floor"""
    logging.info("update_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_list = request.json.get('floor_list')
        list_camera_id_list = request.json.get('list_camera_id_list')
        user = get_current_user()

        i=0
        for floor_name in floor_list:
            camera_id_list = list_camera_id_list[i]
            for camera_id in camera_id_list:
                floor = Floor.query.filter(Floor.camera_id == camera_id).first()
                floor.floor_name = floor_name
                floor.updated_date = datetime.datetime.now()
                floor.created_by = user.user_id
                db.session.commit()
            i += 1

        resp_dict['status'] = True
        resp_dict['msg'] = 'Updated successfully'
    except Exception as e:
        logging.error("update_floor : exception : {}".format(e))
        abort(500)
    logging.info("update_floor : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/floor-list', methods=['GET'])
@auth.login_required()
def floor_list():
    """Floor Listing"""
    logging.info("floor_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        business = get_business(user)
        floor_list = []
        floors = Floor.query.filter((Floor.business_id == business.business_id) & (Floor.status  ==  STATUS['ACTIVE'])) \
            .order_by(Floor.floor_name).all() 
        
        lfloor_name = ''
        camera_list = []
        for floor in floors:
            if lfloor_name == floor.floor_name:
                camera = Camera.query.filter((Camera.camera_id == floor.camera_id) & (Camera.status == STATUS['ACTIVE'])).first()
                if camera:
                    camera_list.append({'camera_name':camera.name, 'camera_id': camera.camera_id})
            else:
                if len(camera_list)>0:
                    floor_list.append({'floor_name':lfloor_name,'camera_list':camera_list})
                    camera_list = []
                lfloor_name = floor.floor_name 
                camera = Camera.query.filter((Camera.camera_id == floor.camera_id) & (Camera.status == STATUS['ACTIVE'])).first()
                if camera:
                    camera_list.append({'camera_name':camera.name, 'camera_id': camera.camera_id}) 
        floor_list.append({'floor_name':lfloor_name,'camera_list':camera_list})
        
        resp_dict['status'] = True
        resp_dict['object'] = floor_list
    except Exception as e:
        logging.error("floor_list : exception : {}".format(e))
        abort(500)
    logging.info("floor_list : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/overall-safety-score', methods=['POST'])
@auth.login_required()
def overall_safety_score():
    """Overall Safety Score"""
    logging.info("overall_safety_score : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)        
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)
        
        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog()
        result = curr_user.get_overall_score(str(datetime.date.today()))
        for camera in cameras:
            curr_user.delete_camera(camera.name)

        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("overall_safety_score : exception : {}".format(e))
        abort(500)
    logging.info("overall_safety_score : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/safety-insights', methods=['POST'])
@auth.login_required()
def safety_insights():
    """Safety Insights"""
    logging.info("safety_insights : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date') 
        freq = request.json.get('freq')

        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)        
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)

        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog()
        result = curr_user.get_safety_insights(end_date_str=end_date, freq=freq, start_date_str=start_date)
        for camera in cameras:
            curr_user.delete_camera(camera.name)

        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("safety_insights : exception : {}".format(e))
        abort(500)
    logging.info("safety_insights : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/mask-compliance', methods=['POST'])
@auth.login_required()
def mask_compliance():
    """Mask Compliance"""
    logging.info("mask_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')

        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)        
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)

        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog()  
        result = curr_user.get_mask_data(end_date_str=end_date, freq=freq, start_date_str=start_date)
        for camera in cameras:
            curr_user.delete_camera(camera.name)
        
        result['employee_data'] = [{
            "employee_id": "SKT123",
            "employee_name": "Surya",
            "mask_risk": "90",
            "profile_image": app.config['SERVER_PATH']+'/api/profile-image/surya.jpg'
            }]
        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("mask_compliance : exception : {}".format(e))
        abort(500)
    logging.info("mask_compliance : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/social-distancing-compliance', methods=['POST'])
@auth.login_required()
def social_distancing_compliance():
    """Social Distancing Compliance"""
    logging.info("social_distancing_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date') 
        freq = request.json.get('freq')

        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)        
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)

        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog() 
        result = curr_user.get_distancing_data(end_date_str=end_date, freq=freq, start_date_str=start_date)
        for camera in cameras:
            curr_user.delete_camera(camera.name)

        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("social_distancing_compliance : exception : {}".format(e))
        abort(500)
    logging.info("social_distancing_compliance : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/heatmap-sanitization', methods=['POST'])
@auth.login_required()
def heatmap_sanitization():
    """Heatmap Sanitization"""
    logging.info("heatmap_sanitization : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')

        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)        
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)

        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog()
        result = curr_user.get_heatmap_data(end_date_str=end_date, freq=freq, start_date_str=start_date)
        for camera in cameras:
            curr_user.delete_camera(camera.name)

        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("heatmap_sanitization : exception : {}".format(e))
        abort(500)
    logging.info("heatmap_sanitization : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/touchless-checkin', methods=['POST'])
@auth.login_required()
def touchless_checkin():
    """Touch Less Checkin"""
    logging.info("touchless_checkin : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')

        user = get_current_user()
        business = get_business(user)
        cameras = get_camera_list(business)
        curr_user, email = get_user_pickle_obj(user.email)
        for camera in cameras:
            curr_user.add_camera(name=camera.name, rtsp_link=camera.rtsp_link, username=camera.username, password=camera.password)
            curr_user.update_camera_max_capacity(camera.name, camera.max_capacity)
            
        floor_list = get_floor_list(business)
        for floor in floor_list:
           curr_user.add_floor(floor['floor_name'], floor['camera_name_list'])
        
        curr_user.enable_face_recog()    
        result = curr_user.get_touchless_checkin_data(end_date_str=end_date, freq=freq, start_date_str=start_date)
        for camera in cameras:
            curr_user.delete_camera(camera.name)
        
        employee_data = result['employee_data']
        for employee in employee_data:
            user = User.query.filter(User.employee_id == str(employee['employee_id'])).first()
            employee['profile_image'] = ('' if user.profile_image_path is None else \
                app.config['SERVER_PATH']+'/api/profile-image/'+user.profile_image_path)
        
        resp_dict['status'] = True
        resp_dict['object'] = result
    except Exception as e:
        logging.error("touchless_checkin : exception : {}".format(e))
        abort(500)
    logging.info("touchless_checkin : end")
    return jsonify(resp_dict)
