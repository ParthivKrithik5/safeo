import json, datetime

from flask import Blueprint, abort, jsonify, request

from app import app, auth, db, logging
from models import User, Registration, Business, Role, User_Role_Map, Enquiry, get_user_role, get_business,\
    get_current_user, get_camera_list
from utils import email_confirmation_mail, STATUS, validate_token, enquiry_mail, get_random_string, forgot_password_mail

# User API Services

user_blueprint = Blueprint('user', __name__)

@user_blueprint.route('/api/registration', methods=['POST'])
def registration():
    """User registration"""
    logging.info("registration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get('name')
        email = request.json.get('email')
        password = request.json.get('password')
        phone = request.json.get('phone')
        business_name =  request.json.get('business_name')
        industry = request.json.get('industry')
        address = request.json.get('address')
        
        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not password:
            input_validation = "Password is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"
       
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        # User duplicate validation
        if User.query.filter_by(email=email).first():
            resp_dict['msg'] = 'Eamil address already exists, please try with different email address!'
            return jsonify(resp_dict)

        registration = Registration(name, email, phone, business_name, industry, address)
        registration.hash_password(password)
        db.session.add(registration)
        db.session.commit()

        # Send Email Verification Mail
        email_confirmation_mail(registration.reg_id, registration.email)
        resp_dict = {"status":True, \
            "msg":'Your account is registered successfully with us, please check your email for confirmation', \
            "object":None}

    except Exception as e:
        logging.error("registration : exception : {}".format(e))
        abort(500)
    logging.info("registration : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/send-verification-email', methods = ['POST'])
def send_verification_email():
    """Resending a verification email"""
    logging.info("send_verification_email : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        email = request.json.get('email')
        if not email:
            resp_dict['msg'] = 'Eamil address is required '
            return jsonify(resp_dict)

        registration = Registration.query.filter_by(email=email).order_by(Registration.reg_id.desc()).first()
        if not registration:
            resp_dict['msg'] = 'Eamil address is not registered with us'
            return jsonify(resp_dict)
        
        if registration.status == STATUS['VERIFIED']:
            resp_dict['msg'] = 'Your eamil address is already verified'
            return jsonify(resp_dict)
            
        # Send Email Verification Mail
        email_confirmation_mail(registration.reg_id, registration.email)
        resp_dict = {"status":True, \
            "msg":'Email verification mail sent successfully'}
        
    except Exception as e:
        logging.error("send_verification_email : exception : {}".format(e))
        abort(500)
    logging.info("send_verification_email : end")
    return jsonify(resp_dict)
    
@user_blueprint.route('/api/verify-email/<token>')
def verifyEmail(token):
    """Token verification"""
    try:
        # Token Validation
        reg_id = validate_token(token)

        # Update Registration Model
        registration = Registration.query.get(reg_id)
        if registration.email_verified_on or registration.status != STATUS['ENTRY']:
            return str('Account already confirmed. Please login.')
        
        registration.email_verified_on = datetime.datetime.now()
        registration.updated_date = datetime.datetime.now()
        registration.status = STATUS['VERIFIED']
        db.session.commit()

        # Save Address
        business = Business(registration.business_name,registration.industry, registration.address)
        db.session.add(business)
        db.session.commit()

        # Save Role
        role_name = str(business.business_id)+'_ADMIN'
        role_desc = 'ADMIN'
        role = Role(role_name, role_desc, business.business_id)
        db.session.add(role)
        db.session.commit()

        # Save User
        user = User(registration.name, registration.email, registration.password, registration.phone)
        db.session.add(user)
        db.session.commit()

        # User & Role Mapping
        user_role_map = User_Role_Map(user.user_id, role.role_id)
        db.session.add(user_role_map)
        db.session.commit()
        
        return str('You have confirmed your account. Thanks!')
    except Exception as e:
        return str('The confirmation link is invalid or has expired.')

@user_blueprint.route('/api/login', methods=['POST'])
def login():
    """Login authentication"""
    logging.info("login : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        email = request.json.get('email')
        password = request.json.get('password')

        if not email or not password:
            resp_dict['msg'] = 'Login credentials required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(email=email).first()
        if not user:
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        # User status validation
        if user.status != STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        # User password  verification
        if not user.verify_password(password):
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        token = user.generate_auth_token()
        plan = ''
        camera_count = 0
        business = get_business(user)
        if business:
            plan = ('' if not business.selected_plan else business.selected_plan)
            camera_count = int(len(get_camera_list(business)))
        role = get_user_role(user)
        
        resp_dict['status'] = True
        resp_dict['object'] = \
            {'token':token.decode('ascii'), 
            'user_id':user.user_id,
            'name':user.name, 
            'email':user.email,
            'role':role,
            'plan': plan,
            'camera_count':camera_count,
            'agreement_accept_status':user.terms_conditions_agreement}
    except Exception as e:
        logging.error("login : exception : {}".format(e))
        abort(500)
    logging.info("login : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/login-data', methods=['GET'])
@auth.login_required()
def login_data():
    """Login Data"""
    logging.info("login_data : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            plan = ''
            camera_count = 0
            business = get_business(user)
            if business:
                plan = ('' if not business.selected_plan else business.selected_plan)
                camera_count = int(len(get_camera_list(business)))
            role = get_user_role(user)

            resp_dict['status'] = True 
            resp_dict['object'] = {
                'user_id':user.user_id,
                'name':user.name, 
                'email':user.email,
                'role':role,
                'plan': plan,
                'camera_count':camera_count,
                'agreement_accept_status':user.terms_conditions_agreement
            }
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("login_data : exception : {}".format(e))
        abort(500)
    logging.info("login_data : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/reset-password', methods=['POST'])
def reset_password():
    """Reset password - Sending a mail with new password"""
    logging.info("reset_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        email = request.json.get('email')
        if not email:
            resp_dict['msg'] = 'Email address is required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(email=email).first()
        if not user:
            resp_dict['msg'] = 'This email address is not registered with Us'
            return jsonify(resp_dict)

        # User status validation
        if user.status != STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        new_password = get_random_string()
        user.hash_password(new_password)
        user.updated_date = datetime.datetime.now()
        db.session.commit()

        # Send mail with new password
        forgot_password_mail(user.email, new_password)
       
        resp_dict['status'] = True
        resp_dict['msg'] = 'Mail sent to you with reset password'
    except Exception as e:
        logging.error("reset_password : exception : {}".format(e))
        abort(500)
    logging.info("reset_password : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/save-enquiry', methods=['POST'])
def save_enquiry():
    """Reset password - Sending a mail with new password"""
    logging.info("save_enquiry : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        name = request.json.get('name')
        company = request.json.get('company')
        email = request.json.get('email')
        phone = request.json.get('phone')
        country = request.json.get('country')
        message = request.json.get('message')
        enquiry_type = request.json.get('enquiry_type')

        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif  not company:
            input_validation = "Company Name is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not country:
            input_validation = "Country is required"
        
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        enquiry = Enquiry(name, company, email, phone, country, message, enquiry_type)
        db.session.add(enquiry)
        db.session.commit()

        # Send enquiry email
        enquiry_mail('kathiravan.rajendran@skoruz.com', name, company, email, phone, country, message)
        resp_dict['status'] = True
        resp_dict['msg'] = 'Enquiry submitted successfully'
    except Exception as e:
        logging.error("save_enquiry : exception : {}".format(e))
        abort(500)
    logging.info("save_enquiry : end")
    return jsonify(resp_dict)
