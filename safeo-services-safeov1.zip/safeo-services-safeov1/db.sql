create database safeo;

CREATE TABLE tb_functions (
    function_id SERIAL NOT NULL, 
    function_name VARCHAR(200) NOT NULL, 
    function_desc VARCHAR(200) NULL, 
    parent_function_id INTEGER DEFAULT 0, 
    function_url VARCHAR(200) NULL, 
    status CHAR(1) DEFAULT 'A', 
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL, 
    PRIMARY KEY (function_id)
);

insert into tb_function_master values(1,'Safeo','Safeo Covid 19 Safety Solution',0,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(2,'Mask Compliance','Mask Compliance',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(3,'Social Distancing','Social Distancing',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(4,'Sanitization','Sanitization',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(5,'Temperature','Temperature',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(6,'Touch Less','Touch Less',1,'','A',0,NOW(),0,NOW(),'','U');

create table tb_businesses(
    business_id SERIAL NOT NULL, 
    business_name VARCHAR(200) NOT NULL,
    industry VARCHAR(120) NOT NULL,
    address VARCHAR(600) NOT NULL,
    selected_plan VARCHAR(60) NULL,
    active_users INTEGER DEFAULT 0,
    plan_exp_date TIMESTAMP NULL,  
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL, 
    PRIMARY KEY (business_id)
);

create table tb_billing_address(
    address_id SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    address VARCHAR(200) NULL,
    city VARCHAR(60) NULL,
    state VARCHAR(60) NULL,
    zip_code VARCHAR(10) NULL,
    country VARCHAR(60) NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL,
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY (address_id),
    CONSTRAINT fk_billing_business FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id)
);

create table tb_payment_cards(
    card_id SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    customer_profile_id VARCHAR(60) NULL,
    customer_payment_profile_id VARCHAR(60) NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL,
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY (card_id),
    CONSTRAINT fk_payment_card_business FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id)
);

create table tb_invoices(
    invoice_no SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    card_id INTEGER NOT NULL,
    invoice_sub_total_amount NUMERIC NOT NULL,
    invoice_tax NUMERIC NOT NULL,
    invoice_total_amount NUMERIC NOT NULL,
    invoice_date TIMESTAMP NOT NULL,
    invoice_paid_amount NUMERIC NOT NULL, 
    transcation_id VARCHAR(20) NULL,
    remarks VARCHAR(200) NULL,
    status CHAR(1) DEFAULT 'E',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL,
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY (invoice_no),
    CONSTRAINT fk_invoice_business FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id),
    CONSTRAINT fk_invoice_card FOREIGN KEY(card_id)  REFERENCES tb_payment_cards(card_id)
);

CREATE TABLE tb_roles (
    role_id SERIAL NOT NULL, 
    role_name VARCHAR(200) NOT NULL, 
    role_desc VARCHAR(1000) NULL,
    business_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP DEFAULT NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP DEFAULT NULL, 
    PRIMARY KEY (role_id),
    CONSTRAINT fk_role_business_map FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id)
);

CREATE TABLE tb_role_function_map (
    role_id INTEGER NOT NULL, 
    function_id INTEGER NOT NULL, 
    CONSTRAINT fk_rf_role_map FOREIGN KEY(role_id)  REFERENCES tb_roles(role_id),
    CONSTRAINT fk_rf_func_map FOREIGN KEY(function_id)  REFERENCES tb_functions(function_id)
);

create table tb_registrations(
   reg_id SERIAL NOT NULL,
   name VARCHAR(120) NOT NULL,
   email VARCHAR(160) NOT NULL,
   password VARCHAR(120) NOT NULL,
   phone VARCHAR(20) NOT NULL,
   business_name VARCHAR(120) NOT NULL,
   industry VARCHAR(120) NOT NULL,
   address VARCHAR(600) NOT NULL,
   status char(1) DEFAULT 'E',
   email_verified_on TIMESTAMP NULL,
   email_verification_token VARCHAR(160) NULL,
   created_date TIMESTAMP NULL,
   updated_date TIMESTAMP NULL,
   PRIMARY KEY (reg_id)
);

CREATE TABLE tb_users (
    user_id SERIAL NOT NULL,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL,
    password VARCHAR(120) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    employee_id VARCHAR(20) NULL,
    profile_image_path VARCHAR(60) NULL,
    terms_conditions_agreement CHAR(1) DEFAULT 'Y',
    default_password_changed CHAR(1) DEFAULT 'N',
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(user_id)
);

create table tb_enquires (
    enquiry_id SERIAL NOT NULL,
    name VARCHAR(120) NOT NULL,
    company VARCHAR(160) NOT NULL,
    email VARCHAR(160) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    country VARCHAR(60) NOT NULL,
    message varchar(600) NULL,
    enquiry_type varchar(20) DEFAULT 'DEMO',
    status CHAR(1) DEFAULT 'A',  
    created_date TIMESTAMP NULL, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(enquiry_id)
);

CREATE TABLE tb_user_role_map (
    user_id INTEGER NOT NULL, 
    role_id INTEGER NOT NULL, 
    CONSTRAINT fk_ur_user_map FOREIGN KEY(user_id)  REFERENCES tb_users(user_id),
    CONSTRAINT fk_ur_role_map FOREIGN KEY(role_id)  REFERENCES tb_roles(role_id)
);

create table tb_camera_details(
    camera_id SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    name VARCHAR(120) NOT NULL,
    rtsp_link VARCHAR(300) NOT NULL,
    username VARCHAR(120) NULL,
    password VARCHAR(120) NULL,
    max_capacity INTEGER DEFAULT 0,
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(camera_id)
);

create table tb_foor_details(
    floor_id SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    floor_name VARCHAR(120) NOT NULL,
    camera_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(floor_id)
);
