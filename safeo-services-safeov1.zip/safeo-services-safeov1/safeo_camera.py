import os
import numpy as np
import pandas as pd
import cv2
import imutils
from imutils.video import WebcamVideoStream
from datetime import datetime

from mask_detection.mask_detector import MaskDetector
from social_distancing.social_distancing_inference import SocialDistancing
from heat_map.heat_map_inference import HeatMap
from face_recognition.recog_inference import FaceRecogInference

import threading
import time
# write and read from a file
# group rows by hour every 10000 rows or so
#scalable database needed
#ensure no loss of frmaes by maintaining a queue

class SafeoCamera():
    def __init__(self, name, rtsp_link, user_data_path, floor, max_capacity=10):
        self.name = name
        self.rtsp_link = rtsp_link
        self.max_capacity = max_capacity
        self.floor = floor

        self.face_recog_enabled = False
        self.touchless_checkin = False
        self.user_data_path = user_data_path

        self.df = pd.DataFrame(columns=['ds', 'date', 'year', 'month', 'week', 'day', 'hour', 'num_mask_violation', 'num_total_faces_mask', 'num_sd_violation' , 'num_total_people_sd', 'num_people_heatmap', 'max_capacity'])
        self.curr_df_idx = 0
        self.df_path = os.path.join(self.user_data_path, (self.name + '.xlsx'))
        self.df.to_excel(self.df_path, index=False)

        self.mask_detector = MaskDetector()
        self.social_distancing_monitor = SocialDistancing()
        self.heat_map_monitor = HeatMap()

        self.employee_checkin_path = os.path.join(self.user_data_path, 'employee_checkin_data.xlsx')
        employee_checkin_columns = ['employee_id', 'ds', 'date']
        self.employee_checkin_df = pd.DataFrame(columns=employee_checkin_columns)
        self.employee_checkin_df_index = 0
        self.employee_checkin_df.to_excel(self.employee_checkin_path, index=False)

        self.touchless_checkin = True
        self.facebank_data_path = os.path.join(self.user_data_path, 'facebank')

        if not os.path.isdir(self.facebank_data_path):
            os.mkdir(self.facebank_data_path)
            unknown_identity_path = os.path.join(self.facebank_data_path, 'unknown')
            os.mkdir(unknown_identity_path)
        
        self.face_recog = FaceRecogInference(face_bank_path=self.facebank_data_path)
        
        self.video_stream = WebcamVideoStream(src=self.rtsp_link)
        self.run_camera = False

        self.lock = threading.Lock()

    def start_camera(self):
        with self.lock:
            self.df = pd.read_excel(self.df_path)
            self.df.loc[:, 'ds'] = self.df['ds'].apply(lambda x: x.to_pydatetime())
            self.df.loc[:, 'date'] = self.df['date'].apply(lambda x: x.date()) 
            self.curr_df_idx = len(self.df)

            if self.face_recog_enabled:
                self.employee_checkin_df = pd.read_excel(self.employee_checkin_path)
                self.employee_checkin_df_index = len(self.employee_checkin_df)

            # self.video_stream = WebcamVideoStream(src=self.rtsp_link)
            self.video_stream.start()
            time.sleep(5)
            self.run_camera = True
        self.analyse()
    
    def stop_camera(self):
        with self.lock:
            self.run_camera = False
            self.video_stream.stop()
            # self.video_stream.stream.release()

            self.df.to_excel(self.df_path, index=False)
            
            if self.face_recog_enabled:
                self.employee_checkin_df.to_excel(self.employee_checkin_path, index=False)
    
    def update_name(self, name):
        self.name = name
    
    def update_rtsp_link(self, rtsp_link):
        self.rtsp_link = rtsp_link
    
    def update_max_capacity(self, max_capacity):
        self.max_capacity = max_capacity
    
    def update_floor(self, floor):
        self.floor = floor
    
    def update_face_recog_status(self, enable_face_recog, facebank_data_path=None, touchless_checkin=False):
        with self.lock:
            if enable_face_recog:
                if touchless_checkin:
                    self.employee_checkin_path = os.path.join(self.user_data_path, 'employee_checkin_data.xlsx')
                    employee_checkin_columns = ['employee_id', 'ds', 'date']
                    self.employee_checkin_df = pd.DataFrame(columns=employee_checkin_columns)
                    self.employee_checkin_df_index = 0
                    self.employee_checkin_df.to_excel(self.employee_checkin_path, index=False)

                    self.touchless_checkin = True

                self.face_recog = FaceRecogInference(face_bank_path=facebank_data_path)

            self.face_recog_enabled = enable_face_recog
    

    def get_name(self):
        return self.name
    
    def get_rtsp_link(self):
        return self.rtsp_link
    
    def get_max_capacity(self):
        return self.max_capacity
    
    def get_floor(self):
        return self.floor

    def analyse(self):
        while True:
            time.sleep(0.001)
            with self.lock:
                if self.run_camera:
                    curr_frame = self.video_stream.read()
                    if curr_frame is not None:
                        curr_frame = imutils.resize(curr_frame, width=400)

                        curr_time = datetime.now()
                        curr_time = curr_time.replace(minute=0, second=0, microsecond=0)

                        curr_hour = curr_time.hour
                        curr_day = curr_time.day
                        curr_week = curr_time.isocalendar()[1]
                        curr_month = curr_time.month
                        curr_year = curr_time.year
                        curr_date = curr_time.date()

                        date_vals = [curr_time, curr_date, curr_year, curr_month, curr_week, curr_day, curr_hour]

                        # mask detection analysis
                        mask_status_list, face_bboxes = self.mask_detector.infer_model(curr_frame, detect_faces=True)
                        num_total_faces = len(mask_status_list)
                        no_mask_list,  = np.where(mask_status_list == 'No Mask')
                        num_no_mask = len(no_mask_list)
                        # no_mask_bboxes = face_bboxes[no_mask_list]

                        mask_vals = [num_no_mask, num_total_faces]


                        # social distancing analysis
                        num_people_violating, violating_bboxes, compliant_bboxes = self.social_distancing_monitor.monitor_social_distancing(curr_frame)
                        num_people_detected_sd = num_people_violating + len(compliant_bboxes)

                        distancing_vals = [num_people_violating, num_people_detected_sd]


                        # heat map analysis
                        num_people_detected,  _ = self.heat_map_monitor.detect_people(curr_frame)
                        heat_map_vals = [num_people_detected, self.max_capacity]

                        self.df.loc[self.curr_df_idx] = date_vals + mask_vals + distancing_vals + heat_map_vals
                        self.curr_df_idx += 1

                        # touchless check in analysis
                        if self.touchless_checkin:
                            identities, scores, bboxes = self.face_recog.recognize_individuals(curr_frame)

                            if len(identities) > 0:
                                curr_ds = datetime.now()
                                curr_ds = curr_ds.replace(second=0, microsecond=0)
                                for each in identities:
                                    if each != 'unknown':
                                        self.employee_checkin_df.loc[self.employee_checkin_df_index] = [each, curr_ds, curr_date]
                                        self.employee_checkin_df_index += 1

                        # cv2.imshow("Frame", curr_frame)
                        # key = cv2.waitKey(0) & 0xFF
                        # cv2.destroyAllWindows()

                        if self.face_recog_enabled:
                            # do face recog on people who violated
                            pass
                else:
                    return

    def group_data(self, start_period, end_period, frequency):
        filtered_df = self.df[(self.df['date'] >= start_period) & (self.df['date'] <= end_period)]

        if frequency == 'day':
            grouped_df = filtered_df.groupby(['year', 'month', 'day', 'hour']).sum()
        
        elif frequency == 'week':
            grouped_df = filtered_df.groupby(['year', 'month', 'week', 'day']).sum()
        
        else:
            grouped_df = filtered_df.groupby(['year', 'month', 'day']).sum()
        
        grouped_df = grouped_df.reset_index()

        return grouped_df

    def get_mask_data(self, start_period, end_period, frequency):
        with self.lock:
            grouped_df = self.group_data(start_period, end_period, frequency)
            
            grouped_df['ds'] = ''
            for i, row in grouped_df.iterrows():
                if frequency == 'day':
                    curr_date = datetime(row['year'], row['month'], row['day'], row['hour'])
                else:
                    curr_date = datetime(row['year'], row['month'], row['day'])                

                grouped_df.loc[i, 'ds'] = curr_date

            if 'num_mask_violation' in grouped_df.columns:
                mask_df = grouped_df[['ds', 'num_mask_violation', 'num_total_faces_mask']]
            else:
                mask_df = grouped_df.copy()
                mask_df['num_mask_violation'] = ''
                mask_df['num_total_faces_mask'] = ''

            # mask_df = grouped_df[['ds', 'num_mask_violation', 'num_total_faces_mask']]

            return mask_df
    
    def get_distancing_data(self, start_period, end_period, frequency):
        with self.lock:
            grouped_df = self.group_data(start_period, end_period, frequency)
            
            grouped_df['ds'] = ''
            for i, row in grouped_df.iterrows():
                if frequency == 'day':
                    curr_date = datetime(row['year'], row['month'], row['day'], row['hour'])
                else:
                    curr_date = datetime(row['year'], row['month'], row['day'])                

                grouped_df.loc[i, 'ds'] = curr_date
            
            if 'num_sd_violation' in grouped_df.columns:
                mask_df = grouped_df[['ds', 'num_sd_violation', 'num_total_people_sd']]
            else:
                mask_df = grouped_df.copy()
                mask_df['num_sd_violation'] = ''
                mask_df['num_total_people_sd'] = ''


            return mask_df
    
    def get_heatmap_data(self, start_period, end_period, frequency):
        with self.lock:
            grouped_df = self.group_data(start_period, end_period, frequency)
            
            grouped_df['ds'] = ''
            for i, row in grouped_df.iterrows():
                if frequency == 'day':
                    curr_date = datetime(row['year'], row['month'], row['day'], row['hour'])
                else:
                    curr_date = datetime(row['year'], row['month'], row['day'])                

                grouped_df.loc[i, 'ds'] = curr_date
            

            if 'num_people_heatmap' in grouped_df.columns:
                mask_df = grouped_df[['ds', 'num_people_heatmap', 'max_capacity']]
            else:
                mask_df = grouped_df.copy()
                mask_df['num_people_heatmap'] = ''
                mask_df['max_capacity'] = ''

            # mask_df = grouped_df[['ds', 'num_people_heatmap', 'max_capacity']]

            return mask_df

    def add_employee(self, img, employee_id):
        with self.lock:
            self.face_recog.add_individual(employee_id, [img])

    def get_touchless_checkin_data(self, start_period, end_period):
        with self.lock:
            
            filtered_df = self.employee_checkin_df[(self.employee_checkin_df['date'] >= start_period) & (self.employee_checkin_df['date'] <= end_period)]
            filtered_df = filtered_df.drop_duplicates(ignore_index=True)

            return filtered_df
