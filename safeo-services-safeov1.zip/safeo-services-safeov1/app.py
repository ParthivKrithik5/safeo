# Common packages import
import os, logging, random, string

# Flask packages import
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_httpauth import HTTPTokenAuth
from flask_cors import CORS
from flask_mail import Mail

# Safeo Application

"""
Author: Kathiravan
"""

# App log configuration
logging.basicConfig(filename="safeo_app.log", level=logging.DEBUG, format='%(asctime)s  %(name)s  %(levelname)s: %(message)s')

# Flask App
app = Flask(__name__)
cors = CORS(app)

# Secret key
secret_key = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(32))
app.config['SECRET_KEY'] = secret_key
app.config['SECURITY_PASSWORD_SALT'] = secret_key
app.config['TOKEN_EXPIRATION'] = 36000

# Postgres database connection
db_url = 'postgres://sfsktusr01:_k9Bd#RP@localhost:5432/safeo_dev'
app.config['SQLALCHEMY_DATABASE_URI'] = db_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # silence the deprecation warning
db = SQLAlchemy(app)

# Email Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'noreply@safeo.ai'
app.config['MAIL_PASSWORD'] = 'Artesia#94'
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
mail = Mail(app)

# Root directory
root_dir = os.getcwd()

# This is the path to the upload directory
app.config['PROFILE_IMAGES'] = 'profile-images/'
app.config['ALLOWED_EXTENSIONS'] = set(['png', 'jpg', 'jpeg'])

# Server Root URL
app.config['SERVER_PATH'] = 'https://safeo.ai/dev-services'

# Authentication
auth = HTTPTokenAuth('Bearer')
