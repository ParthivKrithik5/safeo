#Authorize.net Production Mode
PRODUCTION = False

# Authorize.net keys
# Dev
API_LOGIN_KEY_DEV = '4UZ3Kq2zkv'
TRANSACTION_KEY_DEV = '6a6Q5W6f8MDaf2qJ'

# PROD
API_LOGIN_KEY_PRD = '8AvZ47x8Tq'
TRANSACTION_KEY_PRD = '4KPX2m98334jHu3e'

manage_cards_success_url = 'https://www.chups.co/jasperserver/manageCardsSuccess.html'
manage_cards_init_url = 'https://www.chups.co/jasperserver/manageCardsInit.html'
auth_manage_cards_url_dev = 'https://test.authorize.net/customer/manage'
auth_manage_cards_url_prd =  'https://accept.authorize.net/customer/manage'

# Plans
FREEMIUM = 'Freemium'
PRO = 'Pro'
ENTERPRISE = 'Enterprise'

# No of Users
FREEMIUM_NO_OF_USERS = 4
PRO_NO_OF_USERS = 75

# Price
FREEMIUM_PRICE = 0
PRO_MONTHLY_PRICE = 59.99
PRO_YEALY_PRICE = 719.88
