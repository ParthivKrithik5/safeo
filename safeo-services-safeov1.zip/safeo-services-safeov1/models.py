import datetime

from app import app, db, auth, logging
from utils import STATUS

# Password Hashing Import
from passlib.hash import pbkdf2_sha256
from itsdangerous import (TimedJSONWebSignatureSerializer as Serializer, BadSignature, SignatureExpired)


# Safeo Model Class

# Function Model
class Function(db.Model):
    """ Function maintenance table """
    __tablename__ = 'tb_functions'
    function_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    function_name = db.Column(db.String(200), nullable=False)
    function_desc = db.Column(db.String(200), nullable=True)
    parent_function_id = db.Column(db.Integer, nullable=True, default=0)
    function_url = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)


# Business Model
class Business(db.Model):
    """ Business maintenance table """
    __tablename__ = 'tb_businesses'
    business_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_name = db.Column(db.String(200), nullable=False)
    industry = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(600), nullable=False)
    selected_plan = db.Column(db.String(60), nullable=True)
    active_users = db.Column(db.Integer, nullable=True, default=0)
    plan_exp_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_name, industry, address):
        self.business_name = business_name
        self.industry = industry
        self.address = address
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Payment Cards Model
class PaymentCard(db.Model):
    """Payment card maintenance table """
    __tablename__ = 'tb_payment_cards'
    card_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    customer_profile_id = db.Column(db.String(60), nullable=True)
    customer_payment_profile_id = db.Column(db.String(60), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_id, customer_profile_id, customer_payment_profile_id):
        self.business_id = business_id
        self.customer_profile_id = customer_profile_id
        self.customer_payment_profile_id = customer_payment_profile_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Invoice Model
class Invoice(db.Model):
    """Invoice maintenance table """
    __tablename__ = 'tb_invoices'
    invoice_no = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    card_id = db.Column(db.Integer, db.ForeignKey('tb_payment_cards.card_id'), nullable=False)
    invoice_sub_total_amount = db.Column(db.Float, nullable=True)
    invoice_tax = db.Column(db.Float, nullable=True)
    invoice_total_amount = db.Column(db.Float, nullable=True)
    invoice_date = db.Column(db.DateTime, nullable=False)
    invoice_paid_amount = db.Column(db.Float, nullable=False)
    transcation_id = db.Column(db.String(20), nullable=True)
    remarks = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_id, card_id, invoice_sub_total_amount, invoice_tax, invoice_total_amount,
                 invoice_paid_amount):
        self.business_id = business_id
        self.card_id = card_id
        self.invoice_sub_total_amount = invoice_sub_total_amount
        self.invoice_tax = invoice_tax
        self.invoice_total_amount = invoice_total_amount
        self.invoice_paid_amount = invoice_paid_amount
        self.invoice_date = datetime.datetime.now()
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Role Model
class Role(db.Model):
    """ Role maintenance table """
    __tablename__ = 'tb_roles'
    role_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    role_name = db.Column(db.String(200), nullable=False)
    role_desc = db.Column(db.String(1000), nullable=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, role_name, role_desc, business_id):
        self.role_name = role_name
        self.role_desc = role_desc
        self.business_id = business_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Role & Function Map
class Role_Function_Map(db.Model):
    """Function & Role Mapping table """
    __tablename__ = 'tb_role_function_map'
    __table_args__ = (db.PrimaryKeyConstraint('role_id', 'function_id'),)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_roles.role_id'), nullable=False)
    function_id = db.Column(db.Integer, db.ForeignKey('tb_functions.function_id'), nullable=False)

    def __init__(self, role_id, function_id):
        self.role_id = role_id
        self.function_id = function_id


# Registration Model
class Registration(db.Model):
    """ Registration maintenance table  """
    __tablename__ = 'tb_registrations'
    reg_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    password = db.Column(db.String(64), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    business_name = db.Column(db.String(120), nullable=False)
    industry = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(600), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    email_verified_on = db.Column(db.DateTime, nullable=True)
    email_verification_token = db.Column(db.String(160), nullable=True)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def __init__(self, name, email, phone, business_name, industry, address):
        self.name = name
        self.email = email
        self.phone = phone
        self.business_name = business_name
        self.industry = industry
        self.address = address
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# User Model
class User(db.Model):
    """ User maintenance table  """
    __tablename__ = 'tb_users'
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    password = db.Column(db.String(64), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    employee_id = db.Column(db.String(20), nullable=True)
    profile_image_path = db.Column(db.String(60), nullable=True)
    terms_conditions_agreement = db.Column(db.String(1), nullable=False, default=STATUS['YES'])
    default_password_changed = db.Column(db.String(1), nullable=False, default=STATUS['NO'])
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, name, email, password, phone):
        self.name = name
        self.email = email
        self.password = password
        self.phone = phone
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def verify_password(self, password):
        """ Password verification """
        return pbkdf2_sha256.verify(password, self.password)

    def generate_auth_token(self):
        """ Generate authentication token with expiration time """
        s = Serializer(app.config['SECRET_KEY'], expires_in=app.config['TOKEN_EXPIRATION'])
        return s.dumps({'user_id': self.user_id})


# User & Role Map
class User_Role_Map(db.Model):
    """ User & Role Mapping table """
    __tablename__ = 'tb_user_role_map'
    __table_args__ = (db.PrimaryKeyConstraint('user_id', 'role_id'),)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_roles.role_id'), nullable=False)

    def __init__(self, user_id, role_id):
        self.user_id = user_id
        self.role_id = role_id


# Enquiry Model
class Enquiry(db.Model):
    """ User maintenance table  """
    __tablename__ = 'tb_enquires'
    enquiry_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    company = db.Column(db.String(160), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(60), nullable=False)
    message = db.Column(db.String(600), nullable=False)
    enquiry_type = db.Column(db.String(20), nullable=False, default=STATUS['DEMO'])
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, name, company, email, phone, country, message, enquiry_type):
        self.name = name
        self.company = company
        self.email = email
        self.phone = phone
        self.country = country
        self.message = message
        self.enquiry_type = enquiry_type
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Camera Model
class Camera(db.Model):
    """ Class maintenance table  """
    __tablename__ = 'tb_camera_details'
    camera_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    rtsp_link = db.Column(db.String(300), nullable=False)
    username = db.Column(db.String(120), nullable=True)
    password = db.Column(db.String(120), nullable=True)
    max_capacity = db.Column(db.Integer, nullable=True, default=0)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, business_id, name, rtsp_link, username=None, password=None):
        self.business_id = business_id
        self.name = name
        self.rtsp_link = rtsp_link
        self.username = username
        self.password = password
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Floor Model
class Floor(db.Model):
    """ Floor maintenance table  """
    __tablename__ = 'tb_foor_details'
    floor_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, nullable=False)
    floor_name = db.Column(db.String(120), nullable=False)
    camera_id = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, business_id, floor_name, camera_id):
        self.business_id = business_id
        self.floor_name = floor_name
        self.camera_id = camera_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


@auth.verify_token
def verify_auth_token(token):
    """ Auth token verification """
    s = Serializer(app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except SignatureExpired:
        return None  # valid token, but expired
    except BadSignature:
        return None  # invalid token
    user = User.query.get(data['user_id'])
    return user


def get_current_user():
    user_id = 0
    if auth.current_user():
        user_id = auth.current_user().user_id
    user = User.query.get(user_id)
    return user


def get_business(user):
    business = None
    user_role_map = User_Role_Map.query.filter(User_Role_Map.user_id == user.user_id).first()
    if user_role_map:
        role = Role.query.filter(Role.role_id == user_role_map.role_id).first()
        if role:
            business = Business.query.filter(Business.business_id == role.business_id).first()
    return business


def get_payment_card(business_id):
    return PaymentCard.query.filter(
        (PaymentCard.business_id == business_id) and (PaymentCard.status == STATUS['ACTIVE'])).first()


def get_invoices(business_id):
    return Invoice.query.filter((Invoice.business_id == business_id) and (Invoice.status == STATUS['COMPLETED'])).all()


def get_camera_list(business):
    return Camera.query.filter((Camera.business_id == business.business_id) & (Camera.status == STATUS['ACTIVE'])).all()


def get_floor_list(business):
    floor_list = []
    floors = Floor.query.filter((Floor.business_id == business.business_id) & (Floor.status == STATUS['ACTIVE'])) \
        .order_by(Floor.floor_name).all()

    lfloor_name = ''
    camera_list = []
    for floor in floors:
        if lfloor_name == floor.floor_name:
            camera = Camera.query.filter(
                (Camera.camera_id == floor.camera_id) & (Camera.status == STATUS['ACTIVE'])).first()
            if camera:
                camera_list.append(camera.name)
        else:
            if len(camera_list) > 0:
                floor_list.append({'floor_name': lfloor_name, 'camera_name_list': camera_list})
                camera_list = []
            lfloor_name = floor.floor_name
            camera = Camera.query.filter(
                (Camera.camera_id == floor.camera_id) & (Camera.status == STATUS['ACTIVE'])).first()
            if camera:
                camera_list.append(camera.name)
    floor_list.append({'floor_name': lfloor_name, 'camera_name_list': camera_list})
    return floor_list


def get_user_role(user):
    user_role = ''
    user_role_map = User_Role_Map.query.filter(User_Role_Map.user_id == user.user_id).first()
    if user_role_map:
        role = Role.query.filter(Role.role_id == user_role_map.role_id).first()
        user_role = role.role_name.split('_')[1]
    return user_role


def get_admin_user(business):
    email = ''
    role_name = str(business.business_id) + '_ADMIN'
    role = Role.query.filter((Role.role_name == role_name)).first()
    if role:
        user_role_map = User_Role_Map.query.filter(User_Role_Map.role_id == role.role_id).first()
        if user_role_map:
            user = User.query.filter(User.user_id == user_role_map.user_id).first()
            if user:
                email = user.email
    return email
