import os, sys, string, random, time, pickle
from threading import Thread

from flask import render_template
from flask_mail import  Message
from itsdangerous import URLSafeTimedSerializer

from authorizenet import apicontractsv1
from authorizenet.apicontrollers import *
from decimal import *

from app import app, logging, mail
import constants as my_constants

logging.getLogger("authorizenet").setLevel(logging.ERROR)

# Safeo Utility functions

STATUS = {
    'ACTIVE':'A',
    'DE-ACTIVE':'D',
    'ENTRY':'E',
    'VERIFIED':'V',
    'YES':'Y',
    'NO':'N',
    'DEMO':'DEMO',
    'ISSUE':'ISSUE',
    'ERROR':'E',
    'COMPLETED':'C'
}

def get_plan_details():
    plan_list = []
    plan_list.append(freemium_plan())
    plan_list.append(pro_plan())
    plan_list.append(enterprise_plan())
    return plan_list

def freemium_plan():
     # Freemium
    plan_dict ={}
    plan_dict['plan_name'] = 'Freemium'
    plan_dict['plan_disc'] = 'Individuals and small teams'
    plan_dict['plan_price'] = my_constants.FREEMIUM_PRICE

    solution_list = []

    # Mask Comliance
    solution_dict1 = {}
    solution_dict1['solution_name'] = 'Mask Compliance'
    solution_dict1['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '5 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict1)

    # Social Distancing
    solution_dict2 = {}
    solution_dict2['solution_name'] = 'Social Distancing'
    solution_dict2['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '5 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict2)

    # HeatMap & Sanitization
    solution_dict3 = {}
    solution_dict3['solution_name'] = 'HeatMap & Sanitization'
    solution_dict3['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '5 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict3)

    # Body Temperature
    solution_dict4 = {}
    solution_dict4['solution_name'] = 'Body Temperature'
    solution_dict4['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '5 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict4)

    # Touch Less Check In
    solution_dict5 = {}
    solution_dict5['solution_name'] = 'Touch Less Check In'
    solution_dict5['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '5 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict5)
    plan_dict['solution_list'] = solution_list
    return plan_dict

def pro_plan():
    # Pro
    plan_dict ={}
    plan_dict['plan_name'] = 'Pro'
    plan_dict['plan_disc'] = 'Cross-collaborative teams'
    plan_dict['plan_monthly_price'] = my_constants.PRO_MONTHLY_PRICE
    plan_dict['plan_yealy_price'] = my_constants.PRO_YEALY_PRICE

    solution_list = []

    # Mask Comliance
    solution_dict1 = {}
    solution_dict1['solution_name'] = 'Mask Compliance'
    solution_dict1['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '75 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict1)

    # Social Distancing
    solution_dict2 = {}
    solution_dict2['solution_name'] = 'Social Distancing'
    solution_dict2['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '75 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict2)

    # HeatMap & Sanitization
    solution_dict3 = {}
    solution_dict3['solution_name'] = 'HeatMap & Sanitization'
    solution_dict3['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '75 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict3)

    # Body Temperature
    solution_dict4 = {}
    solution_dict4['solution_name'] = 'Body Temperature'
    solution_dict4['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '75 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict4)

    # Touch Less Check In
    solution_dict5 = {}
    solution_dict5['solution_name'] = 'Touch Less Check In'
    solution_dict5['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : '75 Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict5)
    plan_dict['solution_list'] = solution_list
    return plan_dict

def enterprise_plan():
    # Enterprise
    plan_dict ={}
    plan_dict['plan_name'] = 'Enterprise'
    plan_dict['plan_disc'] = 'Organization with advanced needs'
    plan_dict['plan_price'] = ''

    solution_list = []

    # Mask Comliance
    solution_dict1 = {}
    solution_dict1['solution_name'] = 'Mask Compliance'
    solution_dict1['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : 'Unlimited Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict1)

    # Social Distancing
    solution_dict2 = {}
    solution_dict2['solution_name'] = 'Social Distancing'
    solution_dict2['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : 'Unlimited Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict2)

    # HeatMap & Sanitization
    solution_dict3 = {}
    solution_dict3['solution_name'] = 'HeatMap & Sanitization'
    solution_dict3['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : 'Unlimited Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict3)

    # Body Temperature
    solution_dict4 = {}
    solution_dict4['solution_name'] = 'Body Temperature'
    solution_dict4['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : 'Unlimited Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict4)

    # Touch Less Check In
    solution_dict5 = {}
    solution_dict5['solution_name'] = 'Touch Less Check In'
    solution_dict5['solution_features'] = [
        {
        'key' : 'Mask Track',
        'value' : 'Unlimited Users',
        'availability' : ''
        },
        {
        'key' : 'Employee Mobile App',
        'value' : '',
        'availability' : 'Yes'
        }
    ]
    solution_list.append(solution_dict5)
    plan_dict['solution_list'] = solution_list
    return plan_dict

def get_random_string():
    # Random string with the combination of lower and upper case
    length = 8 
    letters = string.ascii_letters
    result_str = ''.join(random.choice(letters) for i in range(length))
    return result_str

def email_confirmation_mail(reg_id, email):
    """ Sending an email along with email confirmation link """
    token = generate_token(reg_id)
    confirm_url = app.config['SERVER_PATH']+'/api/verify-email/'+token
    html = render_template('verify-email.html', confirm_url=confirm_url)
    send_email([email], "Safeo - Email Confirmation", html)

def forgot_password_mail(email, new_password):
    """ Sending an email with reset password """
    html = render_template('forgot-password.html', email=email, new_password=new_password)
    send_email([email], "Safeo - Login Info", html)

def enquiry_mail(to_email, name, company, email, phone, country, message):
    """ Enquiry mail """
    html = render_template('enquiry.html', name = name, company = company, email =  email,\
        phone = phone, country = country, message = message)
    send_email([to_email], "Safeo - Enquiry", html)

def generate_token(value):
    """Generate a token for the give input value """
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    return serializer.dumps(value, salt=app.config['SECURITY_PASSWORD_SALT'])

def validate_token(token):
    """ Token validation """
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    try:
        value = serializer.loads(
            token,
            salt=app.config['SECURITY_PASSWORD_SALT'],
            max_age=app.config['TOKEN_EXPIRATION']
        )
        return value
    except Exception as e:
        logging.error("validate_token : exception : {}".format(e))
        raise Exception('The confirmation link is invalid or has expired.')

def send_email(to, subject, template):
    """ Mail Send """
    try:
        msg = Message(
            subject,
            recipients=to,
            html=template,
            sender=app.config['MAIL_USERNAME']
        )
        thread = Thread(target=send_async_email, args=[app, msg])
        thread.start()
        logging.info("Email sent successfully")
    except Exception as e:
       logging.error("send_email : exception : {}".format(e))

def send_async_email(app, msg):
    try:
        with app.app_context():
            mail.send(msg)
    except Exception as e:
        logging.error("send_async_email : exception : {}".format(e))

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in app.config['ALLOWED_EXTENSIONS']

def create_customer_profile(name, email):
    customerProfileId = ''
    error_message = ''
    try:
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        if my_constants.PRODUCTION:
            merchantAuth.name = my_constants.API_LOGIN_KEY_PRD
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_PRD
        else:
            merchantAuth.name = my_constants.API_LOGIN_KEY_DEV
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_DEV

        createCustomerProfile = apicontractsv1.createCustomerProfileRequest()
        createCustomerProfile.merchantAuthentication = merchantAuth
        createCustomerProfile.profile = apicontractsv1.customerProfileType('safeo' + str(random.randint(0, 10000)), name, email)

        controller = createCustomerProfileController(createCustomerProfile)
        if my_constants.PRODUCTION:
             controller.setenvironment(constants.PRODUCTION)
        controller.execute()

        response = controller.getresponse()

        if (response.messages.resultCode=="Ok"):
            logging.info("Successfully created a customer profile with id: %s" % response.customerProfileId)
            customerProfileId = str(response.customerProfileId)
        else:
            logging.info("Failed to create customer payment profile %s" % response.messages.message[0]['text'].text)
            error_message = str(response.messages.message[0]['text'].text)
    except Exception as e:
        logging.error('create_customer_profile : exception : {}'.format(e))
        error_message = 'Internal Error, Please try again after some time'
    return customerProfileId, error_message

def create_an_accept_payment_transaction(customerProfileId, paymentProfileId, invoiceNumber, amount):
    transId = ''
    error_message = ''
    try:
        # Create a merchantAuthenticationType object with authentication details
        # retrieved from the constants file
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        if my_constants.PRODUCTION:
            merchantAuth.name = my_constants.API_LOGIN_KEY_PRD
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_PRD
        else:
            merchantAuth.name = my_constants.API_LOGIN_KEY_DEV
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_DEV
        
        # Create order information
        order = apicontractsv1.orderType()
        order.invoiceNumber = str(invoiceNumber)

        # Create Customer Profile
        customerProfilePaymentType = apicontractsv1.customerProfilePaymentType()
        customerProfilePaymentType.customerProfileId = str(customerProfileId)
        paymentProfile = apicontractsv1.paymentProfile()
        paymentProfile.paymentProfileId = str(paymentProfileId)
        customerProfilePaymentType.paymentProfile = paymentProfile
        
        # Create a transactionRequestType object and add the previous objects to it
        transactionrequest = apicontractsv1.transactionRequestType()
        transactionrequest.transactionType = "authCaptureTransaction"
        transactionrequest.amount = str(amount)
        transactionrequest.order = order
        transactionrequest.profile = customerProfilePaymentType

        # Assemble the complete transaction request
        createtransactionrequest = apicontractsv1.createTransactionRequest()
        createtransactionrequest.merchantAuthentication = merchantAuth
        #createtransactionrequest.refId = refId
        createtransactionrequest.transactionRequest = transactionrequest
        
        # Create the controller and get response
        createtransactioncontroller = createTransactionController(createtransactionrequest)
        if my_constants.PRODUCTION:
             createtransactioncontroller.setenvironment(constants.PRODUCTION)
        createtransactioncontroller.execute()

        response = createtransactioncontroller.getresponse()

        if response is not None:
            # Check to see if the API request was successfully received and acted upon
            if response.messages.resultCode == "Ok":
                # Since the API request was successful, look for a transaction response
                # and parse it to display the results of authorizing the card
                if hasattr(response.transactionResponse, 'messages') == True:
                    transId = str(response.transactionResponse.transId)
                    logging.info ('Successfully created transaction with Transaction ID: %s' % response.transactionResponse.transId)
                    logging.info ('Transaction Response Code: %s' % response.transactionResponse.responseCode)
                    logging.info ('Message Code: %s' % response.transactionResponse.messages.message[0].code)
                    logging.info ('Auth Code: %s' % response.transactionResponse.authCode)
                    logging.info ('Description: %s' % response.transactionResponse.messages.message[0].description)
                else:
                    logging.info('Failed Transaction.')
                    error_message = 'Failed Transaction'
                    if hasattr(response.transactionResponse, 'errors') == True:
                        logging.info ('Error Code:  %s' % str(response.transactionResponse.errors.error[0].errorCode))
                        logging.info ('Error Message: %s' % response.transactionResponse.errors.error[0].errorText)
                        error_message = str(response.transactionResponse.errors.error[0].errorText)
            # Or, print errors if the API request wasn't successful
            else:
                logging.info('Failed Transaction.')
                error_message = 'Failed Transaction'
                if hasattr(response, 'transactionResponse') == True and hasattr(response.transactionResponse, 'errors') == True:
                    logging.info ('Error Code: %s' % str(response.transactionResponse.errors.error[0].errorCode))
                    logging.info ('Error Message: %s' % response.transactionResponse.errors.error[0].errorText)
                    error_message = str(response.transactionResponse.errors.error[0].errorText)
                else:
                    logging.info ('Error Code: %s' % response.messages.message[0]['code'].text)
                    logging.info ('Error Message: %s' % response.messages.message[0]['text'].text)
                    error_message = str(response.messages.message[0]['text'].text)
        else:
            logging.info('Null Response')
            error_message = 'Null Response'

    except Exception as e:
        logging.error('create_an_accept_payment_transaction : exception : {}'.format(e))
    return transId, error_message

def get_customer_payment_profile(customerProfileId, customerPaymentProfileId):
    response_dict = {}
    try:
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        if my_constants.PRODUCTION:
            merchantAuth.name = my_constants.API_LOGIN_KEY_PRD
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_PRD
        else:
            merchantAuth.name = my_constants.API_LOGIN_KEY_DEV
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_DEV

        getCustomerPaymentProfile = apicontractsv1.getCustomerPaymentProfileRequest()
        getCustomerPaymentProfile.merchantAuthentication = merchantAuth
        getCustomerPaymentProfile.customerProfileId = str(customerProfileId)
        getCustomerPaymentProfile.customerPaymentProfileId = str(customerPaymentProfileId)
        getCustomerPaymentProfile.unmaskExpirationDate = 'true'
        controller = getCustomerPaymentProfileController(getCustomerPaymentProfile)
        if my_constants.PRODUCTION:
             controller.setenvironment(constants.PRODUCTION)
        controller.execute()

        response = controller.getresponse()

        if (response.messages.resultCode=="Ok"):
            logging.info("Successfully retrieved a payment profile with profile id %s and customer id %s" % (getCustomerPaymentProfile.customerProfileId, getCustomerPaymentProfile.customerProfileId))
            response_dict['credit_card'] = str(response.paymentProfile.payment.creditCard.cardNumber)
            response_dict['first_name'] = str(response.paymentProfile.billTo.firstName)
            response_dict['last_name'] = str(response.paymentProfile.billTo.lastName)
            response_dict['address'] = str(response.paymentProfile.billTo.address)
            response_dict['city'] = str(response.paymentProfile.billTo.city)
            response_dict['state'] = str(response.paymentProfile.billTo.state)
            response_dict['zip_code'] = str(response.paymentProfile.billTo.zip)
            response_dict['country'] = str(response.paymentProfile.billTo.country)
            response_dict['phone_number'] = str(response.paymentProfile.billTo.phoneNumber)
        else:
            logging.info("response code: %s" % response.messages.resultCode)
            logging.info("Failed to get payment profile information with id %s" % getCustomerPaymentProfile.customerPaymentProfileId)
    except Exception as e:
        logging.error('get_customer_payment_profile : exception : {}'.format(e))
    return response_dict

def get_accept_customer_profile_page(customerProfileId):
    token = ''
    error_message = ''
    try:
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        if my_constants.PRODUCTION:
            merchantAuth.name = my_constants.API_LOGIN_KEY_PRD
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_PRD
        else:
            merchantAuth.name = my_constants.API_LOGIN_KEY_DEV
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_DEV

        setting1 = apicontractsv1.settingType()
        setting1.settingName = apicontractsv1.settingNameEnum.hostedProfileReturnUrl
        setting1.settingValue = my_constants.manage_cards_success_url

        setting2 = apicontractsv1.settingType()
        setting2.settingName = apicontractsv1.settingNameEnum.hostedProfilePaymentOptions
        setting2.settingValue = "showCreditCard"

        setting3 = apicontractsv1.settingType()
        setting3.settingName = apicontractsv1.settingNameEnum.hostedProfileValidationMode
        setting3.settingValue = "liveMode"

        setting4 = apicontractsv1.settingType()
        setting4.settingName = apicontractsv1.settingNameEnum.hostedProfileManageOptions
        setting4.settingValue = "showPayment"

        setting5 = apicontractsv1.settingType()
        setting5.settingName = apicontractsv1.settingNameEnum.hostedProfileCardCodeRequired
        setting5.settingValue = "true"

        settings = apicontractsv1.ArrayOfSetting()
        settings.setting.append(setting1)
        settings.setting.append(setting2)
        settings.setting.append(setting3)
        settings.setting.append(setting4)
        settings.setting.append(setting5)

        profilePageRequest = apicontractsv1.getHostedProfilePageRequest()
        profilePageRequest.merchantAuthentication = merchantAuth
        profilePageRequest.customerProfileId = str(customerProfileId)
        profilePageRequest.hostedProfileSettings = settings

        profilePageController = getHostedProfilePageController(profilePageRequest)
        if my_constants.PRODUCTION:
             profilePageController.setenvironment(constants.PRODUCTION)
        profilePageController.execute()

        profilePageResponse = profilePageController.getresponse()

        if profilePageResponse is not None:
            if profilePageResponse.messages.resultCode == apicontractsv1.messageTypeEnum.Ok:
                logging.info('Successfully got hosted profile page!')
                logging.info('Token : %s' % profilePageResponse.token)
                token =  str(profilePageResponse.token)

                if profilePageResponse.messages:
                    logging.info('Message Code : %s' % profilePageResponse.messages.message[0]['code'].text)
                    logging.info('Message Text : %s' % profilePageResponse.messages.message[0]['text'].text)
                    error_message = str(profilePageResponse.messages.message[0]['text'].text)
            else:
                if profilePageResponse.messages:
                    logging.info('Failed to get batch statistics.\nCode:%s \nText:%s' % \
                        (profilePageResponse.messages.message[0]['code'].text, profilePageResponse.messages.message[0]['text'].text))
                    error_message = str(profilePageResponse.messages.message[0]['text'].text)
    except Exception as e:
        logging.error('get_accept_customer_profile_page : exception : {}'.format(e))
        error_message = 'Internal Error, Please try again after some time'
    return token, error_message

def get_customer_profile(customerProfileId):
    card_present = STATUS['NO']
    customerPaymentProfileId = ''
    try:
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        if my_constants.PRODUCTION:
            merchantAuth.name = my_constants.API_LOGIN_KEY_PRD
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_PRD
        else:
            merchantAuth.name = my_constants.API_LOGIN_KEY_DEV
            merchantAuth.transactionKey = my_constants.TRANSACTION_KEY_DEV

        getCustomerProfile = apicontractsv1.getCustomerProfileRequest()
        getCustomerProfile.merchantAuthentication = merchantAuth
        getCustomerProfile.customerProfileId = str(customerProfileId)
        controller = getCustomerProfileController(getCustomerProfile)
        if my_constants.PRODUCTION:
             controller.setenvironment(constants.PRODUCTION)
        controller.execute()
    
        response = controller.getresponse()
    
        if (response.messages.resultCode=="Ok"):
            logging.info("Successfully retrieved a customer with profile id %s and customer id %s" % \
                (getCustomerProfile.customerProfileId, response.profile.merchantCustomerId))
            if hasattr(response, 'profile') == True:
                if hasattr(response.profile, 'paymentProfiles') == True:
                    for paymentProfile in response.profile.paymentProfiles:
                        logging.info ("paymentProfile in get_customerprofile is:" %paymentProfile)
                        logging.info ("Payment Profile ID %s" % str(paymentProfile.customerPaymentProfileId))
                        card_present = STATUS['YES']
                        customerPaymentProfileId = str(paymentProfile.customerPaymentProfileId)
                        break
        else:
            logging.info("response code: %s" % response.messages.resultCode)
            logging.info("Failed to get customer profile information with id %s" % getCustomerProfile.customerProfileId)
    except Exception as e:
        logging.error('get_customer_profile : exception : {}'.format(e))
    return card_present, customerPaymentProfileId

def get_user_pickle_obj(email):
    pickle_file = "./pickle-files/"+email+".pickle"
    pickle_in = open(pickle_file,"rb")
    return pickle.load(pickle_in), email
        
def update_user_pickle_obj(curr_user, email):
    pickle_file = "./pickle-files/"+email+".pickle"
    pickle_out = open(pickle_file,"wb")
    pickle.dump(curr_user, pickle_out)
    pickle_out.close()
