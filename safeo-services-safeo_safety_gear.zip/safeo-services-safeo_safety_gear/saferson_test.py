import time
import saferson
import threading
import json
import datetime

start_date_str = '2020-10-9'
end_date_str = '2020-10-9'

user_email = '001@678.com'
# employee_email = '999@345.com'
# employee_email_2 = '000@345.com'
# employee_email_3 = '123@545.com'
# employee_info_dict = {"name" : "yeeterson", "id" : "123", "pic_path" : "/home/surya/Desktop/nikhil.jpeg"}
# employee_info_dict_2 = {"name" : "sikerson", "id" : "456", "pic_path" : "/home/surya/Desktop/pritwik.jpeg"}
# employee_info_dict_3 = {"name":"testerson",'id':'666',"pic_path":"/home/surya/Desktop/pritwik.jpeg"}

#### TEST FOR CAMERA RECONNECTION AFTER SERVER RESTART ####

# CASE 1 - NO USER HAS REGISTERED / SERVER STARTED FOR THE FIRST TIME
# EXPECTED CAMERA_OBJECT_DICT TO BE EMPTY  

# CASE 2 - USER ALREADY EXISTS AND ALL LINKS WORKING, SERVER STARTING AFTER A CRASH
# EXPECTED CAMERA_OBJECT SHOULD BE EQUAL TO NUMBER OF USERS REGISTERED
# print(saferson.add_camera(user_email, 'first_camera', 'http://admin:admin123@69.75.122.162/image/1.jpg', username=None, password=None))
#print(saferson.delete_camera,'test_camera','0')
print(saferson.add_camera(user_email, 'test_camera', '0', username=None, password=None))
# print(saferson.add_camera(user_email, 'thrid_camera', 'http://admin:admin123@69.75.122.162/image/3.jpg', username=None, password=None))
# print(saferson.add_camera(user_email, 'fourth_camera', 'http://admin:admin123@69.75.122.162/image/4.jpg', username=None, password=None))
#saferson.kill_saferson()
# CASE 3 - USERS EXISTS BUT SOME DON'T HAVE WORKING LINKS
# EXPECTED CAMERA_OBJECT_DICT SHOULD BE LESS THAN THE NUMBER OF USERS AND EQUAL TO WORKING LINKS


# employee_email_4 = '234@345.com'
# employee_info_dict_4 = {"name":"testerson2","id":"777","pic_path":"/home/surya/Desktop/nikhil.jpeg"}

# employee_email_5 = '456@345.com'
# employee_info_dict_5 = {"name":"testorson2","id":"888","pic_path":"/home/surya/Desktop/pritwik.jpeg"}

# args = (user_email, camera_name, rtsp_link, username, password)
# return vals = success, failure
# print(saferson.add_camera(user_email, 'first_camera', 'rtsp://admin:123456@75.144.244.46:554/ch01/0', username=None, password=None))
# time.sleep(30)

#print(saferson.get_safety_insights_now(user_email))

# print(saferson.enable_face_recog(user_email))
# print(saferson.add_employee_email(user_email, [employee_email, employee_email_2, employee_email_3]))
# print(saferson.get_employee_info_list(user_email))
# print(saferson.update_employee_info(employee_email, employee_info_dict))
# print(saferson.update_employee_info(employee_email_2, employee_info_dict_2))
# print(saferson.update_employee_info(employee_email_3, employee_info_dict_3))
# print(saferson.update_employee_info(employee_email_4, employee_info_dict_4))
# print(saferson.update_employee_info(employee_email_5, employee_info_dict_5))

# print("After Update")
# print(saferson.get_employee_info_list(user_email))


# print("Delete")
# print(saferson.delete_employee(employee_email))
# print(saferson.delete_employee(employee_email_2))
# print(saferson.delete_employee(employee_email_3))
# print(saferson.delete_employee(employee_email_4))
# print(saferson.delete_employee(employee_email_5))

# print("After Delete")
# print(saferson.get_employee_info_list(user_email))
# print(saferson.get_employee_info_list(user_email))
# print(saferson.update_employee_info(employee_email_2, employee_info_dict_2))
# print(saferson.add_employee_email(user_email, [employee_email]))
# print(saferson.get_employee_info_list(user_email))
# print(saferson.get_employee_info(employee_email))

# print(saferson.delete_employee(employee_email))
# print("EMPLOYEE DELETED")
# print(saferson.get_employee_info_list(user_email))

# time.sleep(180)
# print(saferson.touchless_dashboard(user_email, start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.touchless_dashboard(user_email, freq='week'))
# print()
# print(saferson.get_employee_attendance(employee_email, freq='week'))
# print(saferson.get_employee_attendance(employee_email_2, freq='week'))
# print(saferson.touchless_dashboard('a', start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.touchless_dashboard('a', freq='week'))
# print(saferson.get_employee_attendance(employee_email, start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.get_employee_attendance(employee_email_2, start_date_str=start_date_str, end_date_str=end_date_str))

# print(saferson.temperature_dashboard(user_email, start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.temperature_dashboard(user_email, freq='week'))
# print(saferson.get_employee_temperature(employee_email, start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.get_employee_temperature(employee_email, freq='week'))
# print(saferson.get_employee_temperature(employee_email_2, start_date_str=start_date_str, end_date_str=end_date_str))
# print(saferson.get_employee_temperature(employee_email_2, freq='week'))

# print(saferson.disable_face_recog(user_email))


# # Dashboard names can eithher be 'mask', 'sd', or 'heatmap'
# # freq can be 'day', 'week', 'month'

# # args = (user_email, dashboard_name, start_date_str, end_date_str, freq)
# print(saferson.get_dashboard_data(user_email, 'mask', start_date_str, end_date_str, freq='day'))

# # args = (user_email, start_date_str, end_date_str, freq)
# print(saferson.get_safety_insights(user_email, start_date_str=start_date_str, end_date_str=end_date_str, freq='day'))

# # args = (user_email)
# print(saferson.get_overall_safety_score(user_email))

# print(saferson.update_max_occupancy(user_email, 'first_camera', 25))

# print(saferson.get_floor_details(user_email))

# print(saferson.add_floor(user_email, ['first_camera'], 'ground floor'))

# print(saferson.get_floor_details(user_email))

# print(saferson.add_floor(user_email, ['first_camera'], 'first_floor'))

# print(saferson.get_floor_details(user_email))

# print(saferson.update_floor(user_email, saferson.get_floor_details(user_email)))

# print(saferson.get_camera_names(user_email))

# print(saferson.get_camera_settings(user_email, 'first_camera'))

# print(saferson.update_camera_name(user_email, 'first_camera', 'first_camera'))

# print(saferson.update_camera_name(user_email, 'first_camera', 'second_camera'))

# print(saferson.get_camera_id(user_email, 'second_camera'))

# curr_settings = saferson.get_camera_settings(user_email, 'second_camera')
# new_settings = curr_settings.copy()
# new_settings['camera_name'] = 'second_camera'
# print(saferson.update_camera_settings(user_email, 'second_camera', curr_settings))

# new_settings['camera_name'] = 'first_camera'
# print(saferson.update_camera_settings(user_email, 'second_camera', new_settings))
# print(saferson.get_camera_settings(user_email, 'first_camera'))

# new_settings['rtsp_link'] = '1'
# print(saferson.update_camera_settings(user_email, 'first_camera', new_settings))

# new_settings['rtsp_link'] = 'rtsp://admin:123456@75.144.244.46:554/ch03/0'
# print(saferson.update_camera_settings(user_email, 'first_camera', new_settings))
# print(saferson.get_camera_settings(user_email, 'first_camera'))

# print(saferson.delete_camera(user_email, 'first_camera'))

# for thread in threading.enumerate():
    # print(thread)

# print(saferson.get_floor_details(user_email))

# UNCOMMENT TO KILL THE BACKGROUND THREADS
# saferson.kill_saferson()

# for thread in threading.enumerate():
    # print(thread)

# import base64
# import cv2
# img = cv2.imread('./noface.png')
# string = base64.b64encode(cv2.imencode('.jpg', img)[1]).decode()
# print(saferson.validate_image(string))

#QR TEST
# user_email = '007@678.com'
# employee_email = '999@xyz.com'
# employee_email_2 = '000@xyz.com'
# employee_email_3 = '123@xyz.com'
# employee_info_dict = {"name" : "yeeterson", "id" : "123"}
# employee_info_dict_2 = {"name" : "sikerson", "id" : "456"}
# employee_info_dict_3 = {"name":"testerson",'id':'666'}#"pic_path":"/home/surya/Desktop/fail.jpeg"}

# employee_email_4 = '234@xyz.com'
# employee_info_dict_4 = {"name":"testerson2","id":"777"}

# employee_email_5 = '456@xyz.com'
# employee_info_dict_5 = {"name":"testorson2","id":"888"}

#print(saferson.add_employee_email(user_email,employee_email_list=[employee_email,employee_email_2,employee_email_3,employee_email_4,employee_email_5]))

# print(saferson.update_employee_info(employee_email, employee_info_dict, mode='QR'))
# print(saferson.update_employee_info(employee_email_2, employee_info_dict_2, mode='QR'))
# print(saferson.update_employee_info(employee_email_3, employee_info_dict_3, mode='QR'))
# print(saferson.update_employee_info(employee_email_4, employee_info_dict_4, mode='QR'))
# print(saferson.update_employee_info(employee_email_5, employee_info_dict_5, mode='QR'))

# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)
# print(saferson.update_qr_attendace(employee_email))
# print(saferson.update_qr_attendace(employee_email_3))
# time.sleep(20)

# print(json.dumps(saferson.touchless_dashboard(user_email,freq='day')))
#print(saferson.temperature_dashboard('demo@demo.com',freq='month'))
# start = datetime.datetime(year =2020,month=10,day=14,tzinfo=datetime.timezone.utc)
# end = datetime.datetime(year =2020,month=10,day=15,tzinfo=datetime.timezone.utc)
# print(saferson.daily_employee_attendance('e3@demo.com',start,end))
# print(saferson.update_qr_attendace(employee_email))

# print(saferson.update_qr_attendace(employee_email_3))
# print(saferson.update_qr_attendace(employee_email_4))
# print(saferson.update_qr_attendace(employee_email_5))
# print(saferson.update_qr_attendace(employee_email_2))

# print(saferson.touchless_dashboard(user_email))

# time.sleep(10)

#
# print(saferson.get_dashboard_graph(user_email, 'mask', start_date_str=None, end_date_str=None, freq='now',time_zone='UTC'))

#seperate dashboard functions
print(saferson.get_dashboard_graph(user_email, 'mask', start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'))
print(saferson.get_dashboard_camera(user_email, 'mask', start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'))
time.sleep(10)
print(saferson.delete_camera('test_2','0'))

