import numpy as np


class BBox():

    def __init__(self,bbox_list, name, conf, mode = 'xywh'):
        self.bbox = bbox_list
        assert len(bbox_list) == 4, ("bboxes must contain only one point")
        self.x1 = bbox_list[0]
        self.y1 = bbox_list[1]
        
        if mode == 'xywh':
            self.w = bbox_list[2]
            self.h = bbox_list[3]
            self.x2 , self.y2 = self.get_bottom_right()
        else:
            self.x2 = bbox_list[2]
            self.y2 = bbox_list[3]
            self.w , self.h = self.get_width_height()
        
        self.name = name
        self.conf = conf

    def get_bottom_right(self): 
        return self.x1 + self.w, self.y1 + self.h

    def get_width_height(self):
        return self.x2 - self.x1, self.y2 - self.y1

    def area(self):
        return self.w * self.h

    def __lt__(self,box):
        return self.area() < box.area()

    def __gt__(self,box):
        return self.area() > box.area()

    def is_in(self,box):
        if self.x1 > box.x1:
            if self.x2 < box.x2 and self.y2 < box.y2:
                return True
        return False

    def __getitem__(self,index):
        return self.bbox[index]

    def intersection(self,other):
        '''Calculates intersection area of two rectagnles 
            and divides by area of smaller rectangle to 
            get overlap
        '''
        x_left = max(self.x1, other.x1)
        y_top = max(self.y1, other.y1)
        x_right = min(self.x2, other.x2)
        y_bottom = min(self.y2, other.y2)

        if x_right < x_left or y_bottom < y_top:
            return 0.0

        intersection_area = (x_right - x_left) * (y_bottom - y_top)

        # compute the area of both AABBs
        bb1_area = self.area()
        bb2_area = other.area()
        normalizing_factor = min(bb1_area,bb2_area)
        normalized_intersection = intersection_area / normalizing_factor
        assert normalized_intersection >= 0.0
        assert normalized_intersection <= 1.0
        return normalized_intersection
        

        



    def __repr__(self) -> str:
        return f"| x1:{self.x1} | y1:{self.y1} | x2:{self.x2} | y2:{self.y2} | w:{self.w} | h:{self.h} |"



class Face(BBox):

    def __init__(self, bbox_list, name, conf, keypoints,mode = 'xywh'):
        super().__init__(bbox_list, name, conf, mode = mode)
        self.keypoints = keypoints

class Person():

    def __init__(self,box):
        self.location = box
        self.belongings = []
        self.face  = None
        self.name = 'Unkown'
        self.belonging_names = []

    def get_face(self,faces):
        ''' A fucntion to find face object for the given person 
        '''
        # for i in faces:
        #     t= i.is_in(self.location)
        #     if t:
        #         self.face  = i
        #         self.name = i.name
        #         break
        for i in faces:
            overlap= i.intersection(self.location)
            # print(overlap)
            if overlap > 0.9:
                self.face  = i
                self.name = i.name
                break

    def get_belongings(self,boxes):
        '''
        '''
        for idx,i in enumerate(boxes):
            overlap= i.intersection(self.location)
            # print(overlap)
            if overlap > 0.9: 
                self.belongings.append(i)
                self.belonging_names.append(i.name)

    def __repr__(self):
        return f"NAME: {self.name}. Belongings: {self.belonging_names}"


        
