from os import name
from detector_inference import SafetyDetector
from bboxes import Face, Person, BBox

import sys
sys.path.append("..")

from face_recognition.recog_inference import FaceRecogInference

import cv2


import random

import time

det = SafetyDetector()

# facebank_path = '..\\face_recognition\\data\\facebank'
facebank_path = '../facebank/'
face_recognizer = FaceRecogInference(face_bank_path=facebank_path,liveness=False)


def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    # Plots one bounding box on image img
    tl = line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

if __name__ == "__main__":
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    while True:
        ret, img = cap.read()
        # sized = cv2.resize(img, )
        # sized = cv2.cvtColor(sized, cv2.COLOR_BGR2RGB)

        start = time.time()
        classes,conf,boxes = det.detect_objects(img)
        finish = time.time()

        persons = [Person(BBox(box,'person',c,mode='xywh')) for box,class_name,c in zip(boxes,classes,conf) if class_name =='person' ]
        objects =  [BBox(box,class_name,c,mode='xywh') for box,class_name,c in zip(boxes,classes,conf) if class_name !='person' ]
        # print(persons[0].location)
        individual_names, scores, bboxes = face_recognizer.recognize_individuals(img)

        faces = [Face(bbox_list=bbox, name = name, conf =conf, keypoints=None,mode='xyxy') for bbox,name,conf in zip(bboxes,individual_names,conf)]
        # names = []
        for person in persons:
            person.get_face(faces)
            # names.append(person.name)
            person.get_belongings(objects)
            print(person)
            plot_one_box(x = person.location, img=img, label=person.__repr__())
            # ious.append()
        # for f in faces:
        #     plot_one_box(x = f,img=img,label=f.name)
        #print(names)
        # if faces and persons:
        #     print(faces[0].is_in(persons[0].location))
        #     print(faces[0])
        #     print(persons[0].location)
        
        faces.clear()
        persons.clear()
        


        # print('Predicted in %f seconds.' % (finish - start))
        #result_img = plot_boxes_cv2(img, boxes, savename=None, class_names=)
        # print(f"Classes: {classes}")
        
        cv2.imshow('Advanced demo', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


