import cv2
import torch
import numpy as np
from torch import nn, device
from safety_detector.utils.general import check_img_size, check_requirements, non_max_suppression, apply_classifier, scale_coords, \
    xyxy2xywh, strip_optimizer, set_logging, increment_path
from safety_detector.models.experimental import attempt_load


from os import name
from detector_inference import SafetyDetector
from safety_detector.bboxes import Face, Person, BBox

import sys
sys.path.append("..")

from face_recognition.recog_inference import FaceRecogInference
from object_detection.detector_inference import ObjectDetector

import random

import time

facebank_path = '../facebank/'
face_recognizer = FaceRecogInference(face_bank_path=facebank_path,liveness=False)
person_detector = ObjectDetector()


DEFAULT_NAMES = [ 'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light',
         'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
         'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
         'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
         'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
         'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
         'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
         'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear',
         'hair drier', 'toothbrush' ]



def letterbox(img, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True):
    # Resize image to a 32-pixel-multiple rectangle https://github.com/ultralytics/yolov3/issues/232
    shape = img.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better test mAP)
        r = min(r, 1.0)

    # Compute padding
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, 32), np.mod(dh, 32)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return img, ratio, (dw, dh)

class SafetyDetector():
    def __init__(self,weight_file = 'yolov5x.pt',names = DEFAULT_NAMES):
        self.use_cuda = torch.cuda.is_available()
        self.device = torch.device(0 if self.use_cuda else "cpu")
        # self.cfg_file = './object_detection/cfg/yolov4.cfg'
        self.weights_file = weight_file
        # self.conf_threshold = 0.4
        # self.nms_threshold = 0.6
        self.conf_thres, self.iou_thres, self.classes, self.agnostic_nms = 0.4, 0.6, 2, 0

        self.load_model()
        self.names = names
        # self.img_width = self.model.width
        # self.img_height = self.model.height


    def load_model(self):
        self.model =attempt_load(self.weights_file, map_location=self.device)
        # self.model = Darknet(self.cfg_file)
        # self.model.load_weights(self.weights_file)
        # self.model.eval()

        # if self.use_cuda:
        #     self.model.cuda()

        # num_classes = self.model.num_classes
        # if num_classes == 20:
        #     namesfile = './object_detection/data/voc.names'
        # elif num_classes == 80:
        #     namesfile = './object_detection/data/coco.names'
        # else:
        #     namesfile = 'data/x.names'
        
        

    def detect_objects(self, img0):
        """Applies yolov5 inference to input image
        input - img0 cv2 image frame in BGR  H,W,C (channels last) format
        returns - list of detected class names, class confidence scores, class bounding box in xywh format
        """

        
        img = letterbox(img0, auto = False)[0]
        img = img[:,:,::-1].transpose(2,0,1) # bgr to rgb and channels last format
        img = np.ascontiguousarray(img)
        img = torch.from_numpy(img).to(self.device)
        
        # img = img.half() if half else img.float()  # uint8 to fp16/32
        img = img.float()
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Inference
        # t1 = time_synchronized()
        with torch.no_grad():
            pred = self.model(img, augment=False)[0]
        
        # Apply NMS
        pred = non_max_suppression(pred, self.conf_thres, self.iou_thres, agnostic=self.agnostic_nms)
        # t2 = time_synchronized()
        # print("Pred", pred)
        # Apply Classifier
        # if classify:
        #     pred = apply_classifier(pred, modelc, img, im0s)

        # Process detections
        detected_classes = []
        detected_conf_scores = []
        detected_boxes = []


        for i, dets in enumerate(pred):  # detections per image
            
            if len(dets) > 0:
                # Rescale boxes from img_size to im0 size
                dets[:, :4] = scale_coords(img.shape[2:], dets[:, :4], img0.shape).round()
                for det in dets:
                    # print("detection", det)
                    x1 = int(det[0])
                    y1 = int(det[1])
                    x2 = int(det[2])
                    y2 = int(det[3])
                    detected_boxes.append((x1, y1, x2, y2))

                    cls_conf =det[4]
                    detected_conf_scores.append(cls_conf)

                    cls_id = det[5]
                    class_name = self.names[int(cls_id)]
                    detected_classes.append(class_name)

              


        
        return detected_classes, detected_conf_scores, detected_boxes

    def advanced_inference(self,img):
        """Applies advnaced recognition on images. For ever person detected a face is identified and belongings are associated.
        input - image
        output - list of person object. see bboxes.py file for details on person object
        """
        classes,conf,boxes = person_detector.detect_objects(img) #TODO make an unified model for detecting people and belongings

        belongings,belongings_conf,belongings_boxes = self.detect_objects(img)

        persons = [Person(BBox(box,'person',c,mode='xywh')) for box,class_name,c in zip(boxes,classes,conf) if class_name =='person']
        objects =  [BBox(box,class_name,c,mode='xywh') for box,class_name,c in zip(belongings,belongings_conf,belongings_boxes ) if class_name !='person' ]
        # print(persons[0].location)
        individual_names, scores, bboxes = face_recognizer.recognize_individuals(img)

        faces = [Face(bbox_list=bbox, name = name, conf =conf, keypoints=None,mode='xywh') for bbox,name,conf in zip(bboxes,individual_names,scores)]
        # names = []
        for person in persons:
            person.get_face(faces)
            # names.append(person.name)
            person.get_belongings(objects)
            # print(person)
            
            
        
        # faces.clear()
        return persons


