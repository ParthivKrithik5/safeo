USER="sfsktusr01",
PASSWORD="_k9Bd#RP",
DATABASE="safeo_dev"