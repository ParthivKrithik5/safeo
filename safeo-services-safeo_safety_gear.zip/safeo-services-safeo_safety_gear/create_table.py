import psycopg2

import json

def create_tables(cur):
    """ create tables in the PostgreSQL database"""
    commands = (
        """CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
        """,

        """
        CREATE TABLE IF NOT EXISTS camera_details (
            user_email VARCHAR NOT NULL ,
            camera_id uuid DEFAULT uuid_generate_v4() UNIQUE,
            camera_name VARCHAR(255) NOT NULL,
            rtsp_link VARCHAR(255) NOT NULL,
            floor_name VARCHAR(255) NOT NULL,
            max_occupancy INTEGER NOT NULL,
            PRIMARY KEY (camera_id)
        )
        """,

        """
        CREATE TABLE IF NOT EXISTS score (
            time TIMESTAMPTZ NOT NULL,
            camera_id uuid NOT NULL,
            mask_risk_score DOUBLE PRECISION NOT NULL,
            sd_risk_score DOUBLE PRECISION NOT NULL,
            heatmap_risk_score DOUBLE PRECISION NOT NULL,
            overall_risk_score DOUBLE PRECISION NOT NULL,
            FOREIGN KEY (camera_id)
                REFERENCES camera_details (camera_id)
                
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS heatmap (
            time TIMESTAMPTZ NOT NULL,
            camera_id uuid NOT NULL,
            num_people_detected INTEGER NOT NULL,
            max_occupancy INTEGER NOT NULL,
            heat_map_risk_score DOUBLE PRECISION NOT NULL,
            FOREIGN KEY (camera_id)
                REFERENCES camera_details (camera_id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS social_distance (
            time TIMESTAMPTZ NOT NULL,
            camera_id uuid NOT NULL,
            num_people_violating INTEGER NOT NULL,
            num_total_people INTEGER NOT NULL,
            sd_risk_score DOUBLE PRECISION NOT NULL,
            FOREIGN KEY (camera_id)
                REFERENCES camera_details (camera_id)
        )
        """,
        
        """
        CREATE TABLE IF NOT EXISTS mask (
            time TIMESTAMPTZ NOT NULL,
            camera_id uuid NOT NULL,
            num_no_mask INTEGER NOT NULL,
            num_total_faces INTEGER NOT NULL,
            mask_risk_score DOUBLE PRECISION NOT NULL,
            FOREIGN KEY (camera_id)
                REFERENCES camera_details (camera_id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS user_dashboard (
            user_email VARCHAR NOT NULL ,
            mask BOOLEAN,
            sd BOOLEAN,
            heatmap BOOLEAN,
            safety_gear BOOLEAN,
            PRIMARY KEY (user_email)
        )
        """,

        """
        CREATE TABLE IF NOT EXISTS safety_gear_code (
            name VARCHAR NOT NULL,
            gear_code VARCHAR NOT NULL,
            PRIMARY KEY (gear_code),
            UNIQUE (name)
                
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS safety_gear_settings (
            user_email VARCHAR NOT NULL,
            mode BOOLEAN,
            gear_code VARCHAR,
            FOREIGN KEY (user_email)
                REFERENCES user_dashboard (user_email),
            UNIQUE (user_email)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS job_list (
            job VARCHAR,
            industry VARCHAR,
            gear_code VARCHAR,
            PRIMARY KEY (job)
        )
        """,

        """
        CREATE TABLE IF NOT EXISTS employee_info  (
            employee_email text NOT NULL,
            user_email text NOT NULL,
            info_uploaded boolean NOT NULL,
            employee_name text NULL,
            employee_id text NULL,
            employee_pic_path text NULL,
            PRIMARY KEY (employee_email)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS employee_job_info  (
            employee_email text NOT NULL,
            user_email text NOT NULL,
            info_uploaded boolean NOT NULL,
            job_type text NULL,
            gear_code text NULL,
            PRIMARY KEY (employee_email)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS violation  (
            time TIMESTAMPTZ NOT NULL,
            employee_id text NULL,
            camera_id uuid NOT NULL,
            gear_code text NULL
        )
        """

    )

    #conn = None
    try:

        # connect to the PostgreSQL server
        #conn = psycopg2.connect( user="postgres", password="123456",host="localhost", database="safeotest")
        #cur = conn.cursor()
        # create table one by one
        for command in commands:
            cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        # conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    # finally:
    #     if conn is not None:
    #         conn.close()

def drop_tables():

    try:

        # connect to the PostgreSQL server
        # conn = psycopg2.connect( user="postgres", password="123456",host="localhost", database="safeotest")
        # cur = conn.cursor()
        # drop tables
        cur.execute("\
                        DROP TABLE IF EXISTS \
                            user_dashboard,\
                            safety_gear_code,\
                            safety_gear_settings,\
                            job_list,\
                        CASCADE ;\
                    ")
        
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        # conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    # finally:
    #     if conn is not None:
    #         conn.close()

if __name__ == '__main__':
    # Save credentials as varaibales in a file called config
    # USER = "..."
    # PASSWORD = "..."
    # DATABASE = "..."
    
    try:
        conn = psycopg2.connect(user='sfsktusr01', password='_k9Bd#RP', host='54.148.121.100', database='safeo_dev')
        cur = conn.cursor()
        create_tables(cur)
        #drop_tables(cur) Not tested
        conn.commit()
        conn.close()
    except Exception as e:
        print(e)
    