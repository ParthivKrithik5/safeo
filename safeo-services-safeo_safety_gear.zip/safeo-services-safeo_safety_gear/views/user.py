import json, datetime, re

from flask import Blueprint, abort, jsonify, request
from sqlalchemy import desc

from app import app, auth, db, logging
from models import User, Registration, Business, Role, User_Role_Map, Enquiry, Country, get_user_role, \
    get_business, get_current_user, Compliance_Check_List_User, Compliance_Check_List, User_Device_Info, User_Notification,otp_insert,\
    OTP, sms_insert, otp_verify
from utils import email_confirmation_mail, validate_token, enquiry_mail, get_random_string, forgot_password_mail
import constants

import saferson
# User API Services

user_blueprint = Blueprint('user', __name__)

# Registration phone otp

@user_blueprint.route('/api/registration', methods=['POST'])
def registration():
    """User registration"""
    logging.info("registration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get('name')
        email = request.json.get('email')
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        password = request.json.get('password')
        business_name =  request.json.get('business_name')
        industry = request.json.get('industry')
        address = request.json.get('address')
        
        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not country_id:
            input_validation = "Country Id is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not password:
            input_validation = "Password is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"

        strong_pass_val_msg = strong_password_validation(password)
        if strong_pass_val_msg:
            input_validation = strong_pass_val_msg
        
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)
    
        # User duplicate validation
        if User.query.filter_by(country_id = country_id,phone=phone).first():
            resp_dict['msg'] = 'An account already exists with the same Mobile No.'
            return jsonify(resp_dict)

        registration = Registration(name, email, country_id,phone, business_name, industry, address)
        registration.hash_password(password)
        db.session.add(registration)
        db.session.commit()

        otp_id = otp_insert(country_id,phone)

        resp_dict["object"] = {
            "otp_id" : otp_id,
            "phone": ("xxx xxx "+phone[6:] if phone else "")
        }
        resp_dict ['status'] = True
    except Exception as e:
        logging.error("registration : exception : {}".format(e))
        abort(500)
    logging.info("registration : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/country-list')
def country_list():
    logging.debug("country_list: start")
    resp_dict = {"status":False, "msg":"", "object":None}
    
    try:
        country_code_list = []
        country_list = Country.query.all()
        for country in country_list:
            country_code_list.append({'country_id': country.country_id,'country_code': country.country_code}) 

        resp_dict['status'] = True
        resp_dict['object'] = {
            'country_code_list': country_code_list
        }   
    except Exception as e:
        logging.exception("country_list : exception : {}".format(e))
    logging.debug("country_list : end")
    
    return jsonify(resp_dict)

@user_blueprint.route("/api/resend-otp", methods=["POST"])
def resend_otp():
    logging.debug("resend_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get("otp_id")
        if not otp_id:
            resp_dict["msg"] = "OTP ID is required"
            return jsonify(resp_dict)
        
        otp_obj = OTP.query.get(str(otp_id))
        if not otp_obj:
            resp_dict["msg"] = "No records found!"
            return jsonify(resp_dict)

        msg = "Welcome! {} is your Safeo Verification Code to activate your account".format(otp_obj.otp_code)
        sms_insert(otp_obj.country_id,otp_obj.phone, msg)

        resp_dict["object"] = {
            "otp_id" : otp_id, 
            "phone": ("xxx xxx "+otp_obj.phone[6:] if otp_obj.phone else "")
        } 
        resp_dict["status"] = True
    except Exception as e:
        logging.exception("resend_otp : exception : {}".format(e))
    logging.debug("resend_otp : end")

    return jsonify(resp_dict)


@user_blueprint.route('/api/verify-otp', methods = ['POST'])
def verify_otp():
    """OTP Verification"""
    logging.info("verify_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get('otp_id')
        otp_code = request.json.get('otp_code')
        if not otp_code:
            resp_dict['msg'] = 'Verification code is required '
            return jsonify(resp_dict)

        
        otp_status = otp_verify(otp_id,otp_code)
        otp = None
        if otp_status:
            otp = OTP.query.filter_by(otp_id=otp_id,otp_code =otp_code).first() 
        
        if otp is not None:
            registration = Registration.query.filter_by(country_id = otp.country_id,phone=otp.phone).order_by(Registration.reg_id.desc()).first()
            if not registration:
                resp_dict['msg'] = 'phone number is not registered with us'
                return jsonify(resp_dict)
            
            if registration.sms_verified_on or registration.status != constants.STATUS['ENTRY']:
                resp_dict['msg'] = ' Your phone number already Verified.'

            registration.sms_verified_on = datetime.datetime.now()
            registration.updated_date = datetime.datetime.now()
            registration.status = constants.STATUS['VERIFIED']
            db.session.commit()

            # Save Address
            business = Business(registration.business_name,registration.industry, registration.address)
            business.touchless_checkin_option = ''
            #business.selected_plan = constants.FREEMIUM
            #business.active_users = constants.FREEMIUM_NO_OF_USERS
            db.session.add(business)
            db.session.commit()

            # Save Role
            role_name = str(business.business_id)+'_ADMIN'
            role_desc = 'ADMIN'
            role = Role(role_name, role_desc, business.business_id)
            db.session.add(role)
            db.session.commit()

            # Save User
            user = User(registration.name, registration.email, registration.password, registration.country_id ,registration.phone)
            db.session.add(user)
            db.session.commit()

            # User & Role Mapping
            user_role_map = User_Role_Map(user.user_id, role.role_id)
            db.session.add(user_role_map)
            db.session.commit()

            list_compliance_check_list = Compliance_Check_List.query.filter(Compliance_Check_List.compliance_id.in_(constants.DEFAULT_COMPLIANCE_LIST)).all()
            for compliance_check_list in list_compliance_check_list:
                compliance_check_list_user = Compliance_Check_List_User(compliance_check_list.compliance_id, compliance_check_list.check_list_id, user.user_id, constants.STATUS['NO'])
                db.session.add(compliance_check_list_user)
                db.session.commit()
            
            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone
            
            resp_dict['msg'] = "You're almost there! We verifed the mobile number {}".format(phone)

            # Send Verified msg
            
            sms_insert(registration.country_id ,registration.phone, 'Phone number verified successfully')
            resp_dict = {"status":True, \
                "msg":'phone number verified successfully'}
        else:
            resp_dict["msg"] = 'OTP Expired'
        
    except Exception as e:
        logging.error("verify_otp : exception : {}".format(e))
        abort(500)
    logging.info("verify_otp : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/login', methods=['POST'])
def login():
    """Login authentication"""
    logging.info("login : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        password = request.json.get('password')
        device_id = request.json.get('device_id')
        device_type = request.json.get('device_type')

        if not phone or not password:
            resp_dict['msg'] = 'phone number & password required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(country_id = country_id,phone=phone).first()
        if not user:
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        # User status validation
        if user.status != constants.STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        # User password  verification
        if not user.verify_password(password):
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        if device_id and device_type:
            user_device_info = User_Device_Info.query.filter(User_Device_Info.user_id == user.user_id).first()
            if user_device_info:
                if device_type == 'IOS':
                    user_device_info.ios_device_id =  device_id
                if device_type == 'ANDROID':
                    user_device_info.android_device_id =  device_id
                db.session.commit()
            else:
                user_device_info = User_Device_Info(user.user_id)
                user_device_info.ios_device_id = ''
                user_device_info.android_device_id = ''
                if device_type == 'IOS':
                    user_device_info.ios_device_id =  device_id
                if device_type == 'ANDROID':
                    user_device_info.android_device_id =  device_id
                db.session.add(user_device_info)
                db.session.commit()

        token = user.generate_auth_token()
        plan = ''
        camera_count = 0
        checkin_option = ''
        business = get_business(user)
        if business:
            plan = ('' if not business.selected_plan else business.selected_plan)
            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone
            camera_count = len(saferson.get_camera_names(phone))
            checkin_option =  business.touchless_checkin_option
        role = get_user_role(user)
        
        resp_dict['status'] = True
        resp_dict['object'] = \
            {'token':token.decode('ascii'), 
            'user_id':user.user_id,
            'name':user.name,
            'phone':phone,
            'role':role,
            'checkin_option':checkin_option,
            'plan': plan,
            'camera_count':camera_count,
            'agreement_accept_status':user.terms_conditions_agreement}
    except Exception as e:
        logging.error("login : exception : {}".format(e))
        abort(500)
    logging.info("login : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/login-data', methods=['GET'])
@auth.login_required()
def login_data():
    """Login Data"""
    logging.info("login_data : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone
            plan = ''
            camera_count = 0
            checkin_option = ''
            business = get_business(user)
            if business:
                plan = ('' if not business.selected_plan else business.selected_plan)
                camera_count = len(saferson.get_camera_names(phone))
                checkin_option =  business.touchless_checkin_option
            role = get_user_role(user)

            resp_dict['status'] = True 
            resp_dict['object'] = {
                'user_id':user.user_id,
                'name':user.name, 
                'phone':phone,
                'role':role,
                'checkin_option':checkin_option,
                'plan': plan,
                'camera_count':camera_count,
                'agreement_accept_status':user.terms_conditions_agreement
            }
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("login_data : exception : {}".format(e))
        abort(500)
    logging.info("login_data : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/forget-password', methods=['POST'])
def forget_password():
    """Forget password - Sending a sms with new password"""
    logging.info("forget_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        if not phone:
            resp_dict['msg'] = 'phone number is required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(country_id = country_id,phone=phone).first()
        if not user:
            resp_dict['msg'] = 'This phone number is not registered with Us'
            return jsonify(resp_dict)

        # User status validation
        if user.status != constants.STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        new_password = get_random_string()
        user.hash_password(new_password)
        user.updated_date = datetime.datetime.now()
        db.session.commit()

        # Send sms with new password

        msg = "Your new password is {}".format(new_password)
        sms_insert(user.country_id,user.phone, msg)
       
        resp_dict['status'] = True
        resp_dict['msg'] = 'SMS sent to you with reset password'
    except Exception as e:
        logging.error("forget_password : exception : {}".format(e))
        abort(500)
    logging.info("forget_password : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/save-enquiry', methods=['POST'])
def save_enquiry():
    logging.info("save_enquiry : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        name = request.json.get('name')
        company = request.json.get('company')
        email = request.json.get('email')
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        country = request.json.get('country')
        message = request.json.get('message')
        enquiry_type = request.json.get('enquiry_type')

        # Input data validations
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif  not company:
            input_validation = "Company Name is required"
        elif not country_id:
            input_validation = "Country Id is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not country:
            input_validation = "Country is required"
        
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        enquiry = Enquiry(name, company, email, country_id, phone, country, message, enquiry_type)
        db.session.add(enquiry)
        db.session.commit()

        country_obj = Country.query.filter_by(country_id = enquiry.country_id).first()
        phone = country_obj.country_code + enquiry.phone
        # Send enquiry sms
        msg = "Hello Admin \n {}\n {}\n {}\n {}\n {}\n {}\n {}\n Thanks\n Safeo Team".format(name, company, email, phone, country, message, enquiry_type)
        sms_insert(enquiry.country_id ,enquiry.phone, msg)

        resp_dict['status'] = True
        resp_dict['msg'] = 'Enquiry submitted successfully'
    except Exception as e:
        logging.error("save_enquiry : exception : {}".format(e))
        abort(500)
    logging.info("save_enquiry : end")
    return jsonify(resp_dict)

def strong_password_validation(password):
    message = ''
    try:
        if len(password) < 8:
            message = "Password should be at least 8 characters : 8-15"
        elif len(password) > 15:
            message = "Password should not exceed 15 characters : 8-15"
        elif not re.search("[a-z]", password):
            message = "Password should contain at least one lowercase : a-z"
        elif not re.search("[A-Z]", password):
            message = "Password should contain at least one uppercase : A-Z"
        elif not re.search("[0-9]", password):
            message = "Password should contain at least one digit : 0-9"
        elif not re.search("[_@$^&!%#*]", password):
            message = "Password should contain at least one character : {_@$^&!%#*}"
    except Exception as e:
        logging.error("strong_password_validation : exception : {}".format(e))
        message = ''
    return message

@user_blueprint.route('/api/get-notifications', methods=['GET'])
@auth.login_required()
def get_notifications():
    """Get User Notifications"""
    logging.info("get_notifications : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            user_notifications = User_Notification.query.filter((User_Notification.user_id==user.user_id) &
                    (User_Notification.status == constants.STATUS['ACTIVE'])
                    ).order_by(desc(User_Notification.notification_id)).all()
            
            notification_list=[]
            for user_notification in  user_notifications:
                notification_dict = dict()
                notification_dict['notification_id'] = user_notification.notification_id
                notification_dict['message'] = user_notification.message
                notification_list.append(notification_dict)

            resp_dict['status'] = True
            resp_dict['object'] = notification_list
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("get_notifications : exception : {}".format(e))
        abort(500)
    logging.info("get_notifications : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/read-notification', methods=['POST'])
@auth.login_required()
def read_notification():
    """Update User Notification As Read"""
    logging.info("read_notification : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        notification_id = request.json.get('notification_id')
        user = get_current_user()
        if user:
            user_notification = User_Notification.query.filter(User_Notification.notification_id==notification_id).first()
            user_notification.read_status = constants.READ_STATUS['READ']
            user_notification.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("read_notification : exception : {}".format(e))
        abort(500)
    logging.info("read_notification : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/delete-notification', methods=['POST'])
@auth.login_required()
def delete_notification():
    """Update User Notification As De-Active"""
    logging.info("delete_notification : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        notification_id = request.json.get('notification_id')
        user = get_current_user()
        if user:
            user_notification = User_Notification.query.filter(User_Notification.notification_id==notification_id).first()
            user_notification.status = constants.STATUS['DE-ACTIVE']
            user_notification.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("delete_notification : exception : {}".format(e))
        abort(500)
    logging.info("delete_notification : end")
    return jsonify(resp_dict)

