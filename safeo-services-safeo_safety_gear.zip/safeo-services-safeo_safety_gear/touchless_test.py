
#%%
import pandas as pd
import numpy as np
import random
import time
from datetime import datetime

#%%
def str_time_prop(start, end, format, prop):
    """Get a time at a proportion of a range of two formatted times.

    start and end should be strings specifying times formated in the
    given format (strftime-style), giving an interval [start, end].
    prop specifies how a proportion of the interval to be taken after
    start.  The returned time will be in the specified format.
    """

    stime = time.mktime(time.strptime(start, format))
    etime = time.mktime(time.strptime(end, format))

    ptime = stime + prop * (etime - stime)

    return time.strftime(format, time.localtime(ptime))


def random_date(start, end, prop):
    return str_time_prop(start, end, '%m/%d/%Y %I:%M %p', prop)


#%%
rdate = [random_date("1/1/2008 9:00 AM", "1/2/2008 6:00 PM", random.random()) for i in range(10)]

rts = [time.mktime(datetime.strptime(x, "%m/%d/%Y %I:%M %p").timetuple()) for x in rdate]

#employes =[random.choice(['e1','e2','e3']) for i in range(10)]
employes = ['e1', 'e2', 'e3', 'e2', 'e3', 'e3', 'e1', 'e3', 'e2', 'e3']
status   = [True,True,True,False,False,True,False,True,True,False]
num_hrs = [0,0,0,2,2,0,3,0,0,4]

date = sorted(rts,reverse=False)

df = pd.DataFrame({'time':date,'employee_email':employes,'status':status, 'num_hrs':num_hrs}).sort_values(by='time',ascending=True)

# %%
yeet = df.groupby(["employee_email"], as_index=False).agg(['last', 'first', 'sum'])
yeet.columns = ['_'.join(t) for t in yeet.columns]
print(yeet)

 # %%
two_way_table = pd.crosstab(df.time, df.employee_email)
daily_absences_data = two_way_table.sum(axis=1)
daily_absences_list = list(daily_absences_data.values)
daily_absences_dates = list(daily_absences_data.index.to_numpy())

print(daily_absences_dates)
print(daily_absences_list)

# %%
