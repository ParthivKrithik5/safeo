import psycopg2
import uuid
import numpy as np
import pandas as pd
from datetime import date,timedelta, datetime

np.random.seed(0)

def violation_seed(cur):
    dti = pd.date_range(datetime(2021,1,11),datetime.now(),freq='h').tz_localize('UTC').tz_convert('Asia/Kolkata')
    print(dti)
    # time = ['2020-12-21 09:30:00','2020-12-22 09:45:00','2020-12-23 10:50:00','2020-12-24 12:40:00','2020-12-25 011:30:00']
    employee_id = ['01','02','03','04']
    camera_id = ['5776c91f-6fb7-44e1-9ab4-4ad3e4822ec1','8593ef47-21fc-416b-a805-0a591670138d','fb6162a2-93df-4200-b3fd-aa13f2e7eb65','04a92f15-6298-41b7-b8cf-36d81feca4bf']
    gear_code = ['H','V','HV']

    for i in dti:

        m = min(0.98,abs(np.random.normal(0.5,0.2)))
        s =min(0.98,abs(np.random.normal(0.5,0.2)))
        h = min(0.98,abs(np.random.normal(0.5,0.2)))
        overall_risk_score = (m+s+h) / 3
        
        cur.execute("INSERT INTO score (time, camera_id, mask_risk_score, sd_risk_score, heatmap_risk_score, overall_risk_score) \
                        VALUES (%s, %s, %s, %s, %s, %s)", (i, np.random.choice(camera_id), m,s, h, overall_risk_score))
        
        cur.execute("INSERT INTO violation (time, employee_id, camera_id, gear_code) \
                                    VALUES (%s, %s, %s, %s)", ( i, np.random.choice(employee_id), np.random.choice(camera_id), np.random.choice(gear_code) ))

    print('violation seed completed')
if __name__ == '__main__':
    
    try:
        conn = psycopg2.connect(user="sfsktusr01", password="_k9Bd#RP", host="localhost", database="safeo_dev")
        cur = conn.cursor()
        violation_seed(cur)
        conn.commit()
        conn.close()
    except Exception as e:
        print(e)
    finally:
        if conn is not None:
            conn.close()
