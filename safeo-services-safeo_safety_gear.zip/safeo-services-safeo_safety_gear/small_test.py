import weakref
from multiprocessing import Queue
from stream_reader import VideoStreamReader
import time


q = Queue()
a = VideoStreamReader('1', 'rtsp://admin:123456@75.144.244.46:554/ch01/0', q)
print(a.get_connection_status())


weak_a = weakref.ref(a)
weak_a().start()

time.sleep(10)

weak_a().remove_stream_reader()

import threading
for thread in threading.enumerate():
    print(thread)

