import time
import saferson
from datetime import date,timedelta, datetime
import pandas as pd
import psycopg2
from psycopg2 import pool
from psycopg2 import sql
import numpy as np
import sys


db_connection_pool = psycopg2.pool.SimpleConnectionPool(
                        minconn=1, 
                        maxconn=20,
                        user="postgres",
                        password="postgres",
                        host="localhost",
                        database="safeotest")

dti = pd.date_range(datetime(2020,10,15),datetime.now(),freq='h').tz_localize('UTC').tz_convert('US/Pacific')

user_email = 'demo@demo.com'
employee_email = 'e1@demo.com'
employee_email_2 = 'e2@demo.com'
employee_email_3 = 'e3@demo.com'
employee_info_dict = {"name" : "e1", "id" : "1", "pic_path" : "e1.jpeg"}
employee_info_dict_2 = {"name" : "e2", "id" : "2", "pic_path" : "e2.jpeg"}
employee_info_dict_3 = {"name":"e3",'id':'3',"pic_path":"e3.jpeg"}



def update_attendace(time,employee_email):

    #curr_time = datetime.now(timezone.utc)

    temp = np.random.normal(98,1)
    temp_status =  'high' if temp > 100 else 'normal'
    
    connection = db_connection_pool.getconn()
    cursor = connection.cursor()

    cursor.execute("SELECT time, attendance_status \
                                    FROM touchless_attendance \
                                    WHERE employee_email = %s \
                                    ORDER BY time \
                                    DESC LIMIT 1", (employee_email, ) )
    staus_data = cursor.fetchall()
    if len(staus_data) > 0:
        last_time, prev_status = staus_data[0][0], staus_data[0][1]
        time_elapsed = (time - last_time).total_seconds()
    else:
        time_elapsed = sys.maxsize
        prev_status = False

    if time_elapsed > 60:
        curr_status = not prev_status
        if curr_status == True:
            num_working_secs = 0
        else:
            num_working_secs = time_elapsed

        cursor.execute("INSERT INTO touchless_attendance (time , employee_email, attendance_status, num_working_secs) \
                        VALUES (%s, %s, %s, %s)", (time, employee_email, curr_status, num_working_secs))
        
        connection.commit()

        cursor.execute("INSERT INTO employee_temperature (time, employee_email, temperature, temperature_status) \
                                        VALUES (%s, %s, %s, %s)", (time, employee_email, round(temp,2) , temp_status))


        connection.commit()

        cursor.close()
        db_connection_pool.putconn(connection)

    return 'success'


print(saferson.add_camera(user_email,'main entrance','http://69.75.122.162/image/1.jpg'))
print(saferson.add_camera(user_email,'hallway','http://69.75.122.162/image/2.jpg'))
print(saferson.add_camera(user_email,'conference','http://69.75.122.162/image/3.jpg'))

camera_id_list,_, _, _=saferson.get_camera_details(user_email)


connection = db_connection_pool.getconn()

cursor = connection.cursor()

#add mask,heatmap,sd, score
for cid in camera_id_list:
    for dt in dti:
        m = min(0.98,abs(np.random.normal(0.5,0.2)))
        s =min(0.98,abs(np.random.normal(0.5,0.2)))
        h = min(0.98,abs(np.random.normal(0.5,0.2)))
        overall_risk_score = (m+s+h) / 3
        
        cursor.execute("INSERT INTO score (time, camera_id, mask_risk_score, sd_risk_score, heatmap_risk_score, overall_risk_score) \
                        VALUES (%s, %s, %s, %s, %s, %s)", (dt.to_pydatetime(), cid, m,s, h, overall_risk_score))

        connection.commit()
        
cursor.close()
connection.close()

#add employees
print(saferson.enable_face_recog(user_email))
print(saferson.add_employee_email(user_email, [employee_email, employee_email_2, employee_email_3]))
# update employee info

print(saferson.update_employee_info(employee_email, employee_info_dict))
print(saferson.update_employee_info(employee_email_2, employee_info_dict_2))
print(saferson.update_employee_info(employee_email_3, employee_info_dict_3))


#update attendance and themp
for dt in dti:
    if np.random.uniform() >0.5:
        emp_email = np.random.choice([employee_email,employee_email_2,employee_email_3])
        print(update_attendace(dt.to_pydatetime(),emp_email))
print("DONE")
#exit()