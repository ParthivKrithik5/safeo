import time
from stream_reader import VideoStreamReader
import threading
from multiprocessing import Queue, set_start_method, get_start_method
import cv2
from threading import Thread

from maskerson import Maskerson
from social_distance import SD
from heat_mapperson import HeatMapperson
from scoreson import Scoreson

import uuid

def flush_queue(q):
    
    while True:
        try:
            if q.qsize() > 0:
                q.get()
            else:
                break
        except:
            print('Exception occured')
            break

def join_queue(q):
    q.close()
    q.join_thread()

def create_uuid():
    return uuid.uuid4()

def test_one_camera():
    q = Queue()
    curr_camera = VideoStreamReader(camera_id=rtsp_link, rtsp_link=rtsp_link, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(10)  

    curr_camera.remove_stream_reader()

    print(q.qsize())  

    print('REMOVED CAMERA')

    print(curr_camera)

    print('DELETED NAMESPACE')

    del curr_camera
    for thread in threading.enumerate(): 
        print(thread.name)


def test_two_cameras():
    q = Queue()
    print(q.qsize())
    first_camera = VideoStreamReader(camera_id='2', rtsp_link=rtsp_link, data_queue=q)
    first_camera.start()

    second_camera = VideoStreamReader(camera_id='3', rtsp_link=0, data_queue=q)
    second_camera.start()

    time.sleep(10)

    first_camera.remove_stream_reader()
    second_camera.remove_stream_reader()

    print(q.qsize())

    del first_camera
    del second_camera
    for thread in threading.enumerate(): 
        print(thread.name)
    
    for i in range(q.qsize()):
        curr_dict = q.get()
        frame = curr_dict['frame']
        print(curr_dict['camera_id'])
        print(curr_dict['time'])
        cv2.imshow('frame', frame)
        cv2.waitKey(1)
    
    cv2.destroyAllWindows() 

    print()
    print(q.qsize())


def test_base_maskerson():
    q = Queue()
    new_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED MASK")

    mask_obj = Maskerson(in_data_queue=q, out_data_queue=new_q)
    mask_thread = Thread(target=mask_obj.run, args=())
    mask_thread.daemon = False
    mask_thread.start()

    time.sleep(15)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())

    flush_queue(q)
    flush_queue(new_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())


    mask_obj.stop()
    mask_thread.join()
    print("STOPPED MASK")

    join_queue(q)
    join_queue(new_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())

def test_base_sd():
    q = Queue()
    new_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED SD")

    sd_obj = SD(in_data_queue=q, out_data_queue=new_q)
    sd_thread = Thread(target=sd_obj.run, args=())
    sd_thread.daemon = False
    sd_thread.start()

    time.sleep(15)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())

    flush_queue(q)
    flush_queue(new_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())


    sd_obj.stop()
    sd_thread.join()
    print("STOPPED SD")

    join_queue(q)
    join_queue(new_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())

def test_base_mapperson():
    q = Queue()
    new_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED MAP")

    map_obj = HeatMapperson(in_data_queue=q, out_data_queue=new_q)
    map_thread = Thread(target=map_obj.run, args=())
    map_thread.daemon = False
    map_thread.start()

    time.sleep(15)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())

    flush_queue(q)
    flush_queue(new_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())


    map_obj.stop()
    map_thread.join()
    print("STOPPED MAP")

    join_queue(q)
    join_queue(new_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())

def test_base_mask_sd():
    q = Queue()
    new_q = Queue()
    super_new_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED MASK")

    mask_obj = Maskerson(in_data_queue=q, out_data_queue=new_q)
    mask_thread = Thread(target=mask_obj.run, args=())
    mask_thread.daemon = False
    mask_thread.start()

    print("STARTED SD")

    sd_obj = SD(in_data_queue=new_q, out_data_queue=super_new_q)
    sd_thread = Thread(target=sd_obj.run, args=())
    sd_thread.daemon = False
    sd_thread.start()

    time.sleep(60)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())

    flush_queue(q)
    flush_queue(new_q)
    flush_queue(super_new_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())

    mask_obj.stop()
    mask_thread.join()
    print("STOPPED MASK")

    sd_obj.stop()
    sd_thread.join()
    print("STOPPED SD")

    join_queue(q)
    join_queue(new_q)
    join_queue(super_new_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())

def test_base_mask_sd_map():
    q = Queue()
    new_q = Queue()
    super_new_q = Queue()
    final_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED MASK")

    mask_obj = Maskerson(in_data_queue=q, out_data_queue=new_q)
    mask_thread = Thread(target=mask_obj.run, args=())
    mask_thread.daemon = False
    mask_thread.start()

    print("STARTED SD")

    sd_obj = SD(in_data_queue=new_q, out_data_queue=super_new_q)
    sd_thread = Thread(target=sd_obj.run, args=())
    sd_thread.daemon = False
    sd_thread.start()

    print("STARTED SD")

    map_obj = HeatMapperson(in_data_queue=super_new_q, out_data_queue=final_q)
    map_thread = Thread(target=map_obj.run, args=())
    map_thread.daemon = False
    map_thread.start()

    print("STARTED MAP")

    time.sleep(60)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

    flush_queue(q)
    flush_queue(new_q)
    flush_queue(super_new_q)
    flush_queue(final_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

    mask_obj.stop()
    mask_thread.join()
    print("STOPPED MASK")

    sd_obj.stop()
    sd_thread.join()
    print("STOPPED SD")

    map_obj.stop()
    map_thread.join()
    print("STOPPED MAP")

    join_queue(q)
    join_queue(new_q)
    join_queue(super_new_q)
    join_queue(final_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

def test_base_mask_sd_map_score():
    q = Queue()
    new_q = Queue()
    super_new_q = Queue()
    final_q = Queue()

    curr_camera_id = create_uuid()
    curr_camera = VideoStreamReader(camera_id=curr_camera_id, rtsp_link=0, data_queue=q)
    print(curr_camera.get_connection_status())
    curr_camera.start()

    print('Started camera')
    print('Running camera for the first time')

    time.sleep(2)  

    print("STARTED MASK")

    mask_obj = Maskerson(in_data_queue=q, out_data_queue=new_q)
    mask_thread = Thread(target=mask_obj.run, args=())
    mask_thread.daemon = False
    mask_thread.start()

    print("STARTED SD")

    sd_obj = SD(in_data_queue=new_q, out_data_queue=super_new_q)
    sd_thread = Thread(target=sd_obj.run, args=())
    sd_thread.daemon = False
    sd_thread.start()

    print("STARTED SD")

    map_obj = HeatMapperson(in_data_queue=super_new_q, out_data_queue=final_q)
    map_thread = Thread(target=map_obj.run, args=())
    map_thread.daemon = False
    map_thread.start()

    print("STARTED MAP")

    score_obj = Scoreson(in_data_queue=final_q)
    score_thread = Thread(target=score_obj.run, args=())
    score_thread.daemon = False
    score_thread.start()

    print("STARTED SCORE")

    time.sleep(60)

    print('Stopped camera')
    curr_camera.remove_stream_reader()

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

    flush_queue(q)
    flush_queue(new_q)
    flush_queue(super_new_q)
    flush_queue(final_q)

    print('FLUSHED')
    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

    mask_obj.stop()
    mask_thread.join()
    print("STOPPED MASK")

    sd_obj.stop()
    sd_thread.join()
    print("STOPPED SD")

    map_obj.stop()
    map_thread.join()
    print("STOPPED MAP")

    score_obj.stop()
    score_thread.join()
    print("STOPPED SCORE")

    join_queue(q)
    join_queue(new_q)
    join_queue(super_new_q)
    join_queue(final_q)

    for thread in threading.enumerate(): 
        print(thread.name)

    print(q.qsize())
    print(new_q.qsize())
    print(super_new_q.qsize())
    print(final_q.qsize())

if __name__ == '__main__':

    rtsp_link = 'rtsp://admin:123456@75.144.244.46:554/ch03/0'
    # test_one_camera()
    # test_two_cameras()
    # test_base_maskerson()
    # test_base_sd()
    # test_base_mapperson()
    # test_base_mask_sd()
    # test_base_mask_sd_map()
    # test_base_mask_sd_map_score()

    # create_uuid()