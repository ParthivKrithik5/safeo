import numpy as np
import os
from safety_detector.safety_inference import SafetyDetector
import cv2
import config
import datetime

# from saferson import get_safety_codes

import psycopg2.extras

# what if database connection fails
# change implementation to dynamic batch processing using queue
class SafetyGear():
    def __init__(self, in_data_queue, out_data_queue):
        self.in_data_queue = in_data_queue
        self.out_data_queue = out_data_queue
        self.stopped = False

        self.connection = psycopg2.connect(
                            host="localhost",
                            database="safeo_dev",
                            user="sfsktusr01",
                            password="_k9Bd#RP"
                            )
        self.safety_gears = SafetyDetector()
    
    def run(self):
        while True:
            curr_item = self.in_data_queue.get()

            print(curr_item)

            if curr_item == 'KILL WORKER':
                break
            
            _ = self.analyse(curr_item['frame'],curr_item['user_email'],curr_item['camera_id'])
            
            # curr_item['mask_risk_score'] = mask_risk_score

            del curr_item['frame']

            self.out_data_queue.put(curr_item)
        
    def analyse(self, img, user_email,camera_id):
        
        cursor = self.connection.cursor()
        cursor.execute("SELECT user_email, mode, gear_code \
                        FROM safety_gear_settings \
                        WHERE user_email = %s ", (user_email,))
        
        safety_gear_settings = cursor.fetchall()

        cursor.close()

        if len(safety_gear_settings) > 0:
           
            user_email = safety_gear_settings[0][0]
            mode = safety_gear_settings[0][1]
            gear_code = safety_gear_settings[0][2]
           
            # print(user_email,mode,gear_code)
        
            #return  {'user_email' : user_email, 'mode' : mode, 'gear_code' : gear_code}
        
        #if dashboard is not active
        else:
            return -1

        # mode is normal
        if not mode:
         
            #get violation TODO
            violation_list, _, _  = self.safety_gears.detect_objects(img)
            # violation_list = ['hard_hat','vest','hard_hat','vest','hard_hat']
            # violation_groups = list_to_group(violation_list)
            # violation_groups = [['hard_hat','vest'],['hard_hat','vest'],['hard_hat']]
            if len(violation_list) < 1:
                return 0
            violation_group = self.list_to_group(violation_list)


            cursor = self.connection.cursor()
            
            for violation_list in violation_group:
                gear_code = self.get_safety_codes(list(violation_list))
                if gear_code:
                    cursor.execute("INSERT INTO violation (time, employee_id, camera_id, gear_code) \
                                        VALUES (%s, %s, %s, %s)", (datetime.now(), 'NA', camera_id, gear_code))

                    cursor.commit()
            cursor.close()
           
        #mode advanced use Face recognition
        else:
            persons = self.safety_gears.advanced_inference(img)

            if len(persons) < 1:
                return 0

            cursor = self.connection.cursor()
            
            for p in persons:
                employee_email = p.name
                violation_list = p.belongings
                gear_code = self.get_safety_codes(list(violation_list))
                if gear_code:
                    cursor.execute("INSERT INTO violation (time, employee_id, camera_id, gear_code) \
                                        VALUES (%s, %s, %s, %s)", (datetime.now(), employee_email, camera_id, gear_code))

                    cursor.commit()
            cursor.close()


            # safety_risk_score=[0]

        return 0

    def list_to_group(self,gears):
        list_groups = []
        gear_list = []
        gear_dict= {}
        for gear in gears:
            if gear not in gear_dict.keys():
                gear_dict[gear]=1
                gear_list.append(gear)
            else:
                list_groups.append(tuple(gear_list))
                gear_list.clear()
                gear_dict={}
                gear_list.append(gear)
        list_groups.append(tuple(gear_list))
        return list_groups
    
    def get_safety_codes(self,gear_names):
        """
            Description : A function used to get safety gear code details.
            Parameters  : gear_names (list) .
            Returns     : Returns gear code.
        """
        try:
            gear_codes = ''
            gear_names.sort()
            cursor = self.connection.cursor()
            for gear_name in gear_names:
                # get code for all the gear names

                # connection = self.getconn()
                

                cursor.execute("SELECT gear_code \
                                FROM safety_gear_code \
                                WHERE name = %s ", (gear_name,))
                
                gear_code = cursor.fetchall()

                

                if len(gear_code) > 0:
                    gear_code = gear_code[0][0]
                else:
                    gear_code=''
                    # raise Exception('gear name " {} " not found'.format(gear_name))
                
                gear_codes = gear_codes+gear_code
            
            cursor.close()

            return gear_codes
        except:
            return []
    
    
    def stop(self):
        self.connection.close()
        self.in_data_queue.put('KILL WORKER')
