
import requests, logging, urllib, base64, time 

from urllib.parse import urlencode

import psycopg2

from twilio.rest import Client

# Log property file config
logging.basicConfig(filename="safeo_sms.log", level=logging.DEBUG, format='%(asctime)s  %(name)s  %(levelname)s: %(message)s')


# Postgres database connection
DB_HOST = 'localhost'
DB_USER_NAME = 'sfsktusr01'
DB_USER_PASSWORD = '_k9Bd#RP'
DB_NAME = 'safeo_dev'

# Twilio 
ACCOUNT_SID = "ACf692426747f65d59c8ac4ddfea6d28c1"
AUTH_TOKEN = "77b2df1dcde7ab144b167c2f85a98a0a"
FROM_MOBILE = "+13158492627"

def get_sms():
    """
    Read the all SMS with entry status
    """
    try:
        sms_list = []
        connection = psycopg2.connect(
                            host=DB_HOST,
                            database=DB_NAME,
                            user=DB_USER_NAME,
                            password=DB_USER_PASSWORD
                            )

        cursor = connection.cursor()
        cursor.execute("SELECT seq_id, country_id , phone, message FROM tb_sms_txn WHERE status=%s", ('E', ))
        sms_txns = cursor.fetchall()
        for sms_txn in sms_txns:
            sms_list.append({'seq_id' : sms_txn[0],'country_id' : sms_txn[1], 'phone': sms_txn[2],'message' : sms_txn[3]})
        cursor.close()
        connection.close()
        return sms_list
    except Exception as e:
        logging.error('get_sms : exception : {}'.format(e))
    return []

def update_sms(seq_id, status):
    """
    Update SMS transaction status Sent(S)/Failure(F)
    """
    try:
        status = ("S" if status else "F")
        connection = psycopg2.connect(
                    host=DB_HOST,
                    database=DB_NAME,
                    user=DB_USER_NAME,
                    password=DB_USER_PASSWORD
                    )

        cursor = connection.cursor()
        cursor.execute(" UPDATE tb_sms_txn set status=%s, updated_date=now() WHERE seq_id = %s", (status, seq_id))
        connection.commit()
        cursor.close()
        connection.close()
    except Exception as e:
        logging.error('update_sms : exception : {}'.format(e))

def send_twilio_sms(country_id ,to_mobile, message):
    try:
        connection = psycopg2.connect(
                    host=DB_HOST,
                    database=DB_NAME,
                    user=DB_USER_NAME,
                    password=DB_USER_PASSWORD
                    )

        cursor = connection.cursor()
        cursor.execute(" SELECT country_code From tb_country Where status=%s AND country_id = %s",('A',country_id))
        country_code = cursor.fetchone()
        to_mobile =  '+'+country_code[0]+to_mobile
        client = Client(ACCOUNT_SID, AUTH_TOKEN)
        message = client.messages.create(to=to_mobile, from_=FROM_MOBILE, body=message)
        return True
    except Exception as e:
        logging.error("send_twilio_sms : Exception : {}".format(e))
    return False

def process():
    try:
        while True:
            sms_list = get_sms()
            for sms in sms_list:
                status = False #send_twilio_sms(sms['country_id'],sms['phone'], sms['message'])
                update_sms(sms['seq_id'], status)
                time.sleep(1)
    except Exception as e:
        logging.error('process : exception : {}'.format(e))
        
if __name__ == "__main__":
    process()
