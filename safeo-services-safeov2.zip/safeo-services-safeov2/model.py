import datetime

from sqlalchemy import and_

# Password Hashing Import
from passlib.hash import pbkdf2_sha256

from app import app, logging, auth, db

from utils import *

import uuid

# Model Class

# Country Model
class Country(db.Model):
    """Country Table """
    __tablename__ = "tb_country_master"
    country_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    long_name = db.Column(db.String(100), nullable=False)
    short_name = db.Column(db.String(2), nullable=False)
    country_code = db.Column(db.String(4), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, long_name, short_name, country_code):
        self.long_name = long_name
        self.short_name = short_name
        self.country_code = country_code
        self.created_date = datetime.datetime.now()   

# Industry Model
class Industry(db.Model):
    """Industry Table"""
    __tablename__ = "tb_industry_master"
    industry_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    industry_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, industry_name, created_by=0):
        self.industry_name = industry_name
        self.created_by =  created_by
        self.created_date = datetime.datetime.now()

# Registration Model
class Registration(db.Model):
    """ Registration  Table """
    __tablename__  = 'tb_registrations'
    reg_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    password = db.Column(db.String(120), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country_master.country_id'),nullable=False)
    mobile = db.Column(db.String(20), nullable=False)
    business_name = db.Column(db.String(120), nullable=False)
    industry_id = db.Column(db.Integer, nullable=False)
    address = db.Column(db.String(600), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    mobile_verified_on = db.Column(db.DateTime, nullable=True)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def __init__(self, name, email, country_id, mobile, business_name, industry_id, address):
        self.name = name
        self.email = email
        self.country_id = country_id
        self.mobile = mobile
        self.business_name = business_name
        self.industry_id = industry_id
        self.address = address
        self.created_date = datetime.datetime.now()

# OTP Model
class OTP(db.Model):
    """ OTP Table """
    __tablename__  = "tb_otp_txn"
    otp_id = db.Column(db.Integer, primary_key=True, nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country_master.country_id'),nullable=False)
    mobile = db.Column(db.String(16), nullable=False)
    otp_code = db.Column(db.String(6), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    exp_date = db.Column(db.DateTime, nullable=False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, country_id, mobile, otp_code):
        self.country_id = country_id
        self.mobile =  mobile
        self.otp_code = otp_code
        # OTP Code will be valid for 3 minutes
        self.exp_date = datetime.datetime.now() + datetime.timedelta(minutes = OTP_VALID_MINUTES)
        self.created_date = datetime.datetime.now()

# SMS Master Model
class SMS(db.Model):
    """ SMS Txn table  """
    __tablename__ = "tb_sms_txn"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country_master.country_id'),nullable=False)
    mobile = db.Column(db.String(16), nullable=False)
    message = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ENTRY"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, country_id, mobile, message):
        self.country_id = country_id
        self.mobile = mobile
        self.message = message
        self.created_date = datetime.datetime.now()

# Mail Txn Model
class Mail(db.Model):
    """ Mail Txn table  """
    __tablename__ = "tb_mail_txn"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(64), nullable=False)
    subject = db.Column(db.String(64), nullable=False)
    message = db.Column(db.String(2000), nullable=False)
    attachment = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ENTRY"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, email, subject, message):
        self.email = email
        self.subject = subject
        self.message = message
        self.created_date = datetime.datetime.now()

# Business Model
class Business(db.Model):
    """Business Table"""
    __tablename__  = "tb_business_master"
    business_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_name = db.Column(db.String(200), nullable=False)    
    industry_id = db.Column(db.Integer, db.ForeignKey('tb_industry_master.industry_id'), nullable=True)
    address = db.Column(db.String(600), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_name, industry_id, address, created_by=0):
        self.business_name = business_name
        self.industry_id = industry_id
        self.address = address
        self.created_by =  created_by
        self.created_date = datetime.datetime.now() 

# User Model
class User(db.Model):
    """User Table"""
    __tablename__ = "tb_user_master"
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String(16), nullable=True)
    name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    country_id = db.Column(db.Integer,  db.ForeignKey("tb_country_master.country_id"), nullable=False)
    mobile = db.Column(db.String(15), nullable=False)
    password = db.Column(db.String(258), nullable=False)
    designation = db.Column(db.String(128), nullable=False)
    is_employee = db.Column(db.String(1), nullable=False, default=STATUS["NO"])
    profile_image = db.Column(db.String(64), nullable=False, default="") 
    default_password_changed = db.Column(db.String(1), nullable=False, default=STATUS["NO"])
    business_id = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, name, email, country_id, mobile,  business_id, is_employee = STATUS["NO"], designation = "", created_by=0):

        self.name = name
        self.email = email
        self.country_id =  country_id
        self.mobile = mobile
        self.designation = designation
        self.is_employee = is_employee
        self.business_id = business_id
        self.created_by = created_by
        self.created_date = datetime.datetime.now()

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def verify_password(self, password):
        """ Password verification """
        return pbkdf2_sha256.verify(password, self.password)    

# Role Model
class Role(db.Model):
    """Role Table"""
    __tablename__ = "tb_role_master"
    role_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    role_name = db.Column(db.String(200), nullable=False)
    role_desc = db.Column(db.String(1000), nullable=False)
    role_type = db.Column(db.String(64), nullable=False, default=ROLE_TYPE["CLIENT-ADMIN"])
    role_modification = db.Column(db.String(1), nullable=False, default=STATUS["NO"])
    business_id = db.Column(db.Integer,db.ForeignKey("tb_business_master.business_id"), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, role_name, role_desc, business_id, created_by=0):
        self.role_name = role_name
        self.role_desc = role_desc
        self.business_id  = business_id
        self.created_by = created_by
        self.created_date = datetime.datetime.now()

# Function Model
class Function(db.Model):
    """Function Table"""
    __tablename__ = "tb_function_master"
    function_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    function_name = db.Column(db.String(200), nullable=False)
    function_desc = db.Column(db.String(1000), nullable=False)
    parent_function_id = db.Column(db.Integer, nullable=False, default=0)
    function_url = db.Column(db.String(1000), nullable=False, default=0)
    function_approach = db.Column(db.String(20), nullable=False, default=FUNCTION_TYPE["NONE"])
    function_icon = db.Column(db.String(100000), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, function_name, function_desc, parent_function_id, function_url, function_approach, function_icon, created_by=0):
        self.function_name = function_name
        self.function_desc = function_desc
        self.parent_function_id = parent_function_id
        self.function_url = function_url
        self.function_approach = function_approach
        self.function_icon = function_icon
        self.created_by = created_by
        self.created_date = datetime.datetime.now()

#  User & Role Resp Model
class User_Role_Resp(db.Model):
    """User Role Resp Table"""
    __tablename__ = "tb_user_role_resp"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer,  db.ForeignKey("tb_user_master.user_id"), nullable=False)
    role_id = db.Column(db.Integer,  db.ForeignKey("tb_role_master.role_id"), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, user_id, role_id):
        self.user_id = user_id
        self.role_id = role_id
        self.created_date = datetime.datetime.now()

# Role & Function Map Model
class Role_Function_Map(db.Model):
    """Role & Function Map Table"""
    __tablename__ = "tb_role_function_map"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    role_id = db.Column(db.Integer, db.ForeignKey("tb_role_master.role_id"), nullable=False)
    function_id = db.Column(db.Integer, db.ForeignKey("tb_function_master.function_id"), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, role_id, function_id):
        self.role_id = role_id
        self.function_id = function_id
        self.created_date = datetime.datetime.now()

# Industry Role Map  
class Industry_Role_Resp(db.Model):
    """industry_role_resp Table"""
    __tablename__ = "tb_industry_role_resp"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    industry_id = db.Column(db.Integer, db.ForeignKey('tb_industry_master.industry_id'),  nullable = False)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_role_master.role_id'),  nullable = False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, camera_id):
        self.config_id = config_id
        self.camera_id = camera_id
        self.created_date = datetime.datetime.now()

# Login Token Model
class Login_Token(db.Model):
    """ Login Token Table  """
    __tablename__ = "tb_login_token"
    token = db.Column(db.Text, primary_key=True, nullable=False)
    access_mode = db.Column(db.String(64), nullable=False, default="WEB")
    user_id = db.Column(db.Integer, db.ForeignKey("tb_user_master.user_id"), nullable=False)
    last_request_date = db.Column(db.DateTime, nullable=True)
    is_logged_in = db.Column(db.String(1), nullable=False, default=STATUS["NO"])
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    exp_date = db.Column(db.DateTime, nullable=False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, token, user_id, access_mode="WEB"):
        self.token = token
        self.user_id = user_id
        self.access_mode = access_mode
        # Login token will be valid for 1 hours
        self.exp_date = datetime.datetime.now() + datetime.timedelta(hours = 1)
        self.created_date = datetime.datetime.now()  

# User Device Model
class User_Device_Info(db.Model):
    """ User device info maintenance table  """
    __tablename__ = 'tb_user_device_info'
    info_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_user_master.user_id'), nullable=False)
    android_device_id = db.Column(db.String(500), nullable=False)
    ios_device_id = db.Column(db.String(500), nullable=False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, user_id):
        self.user_id = user_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

# Module Model
class Module(db.Model):
    """Module Table"""
    __tablename__  = "tb_module_master"
    module_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    module_name = db.Column(db.String(64), nullable=False)
    module_desc = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, module_name, module_desc, created_by=0):
        self.module_name = module_name
        self.module_desc = module_desc
        self.created_by =  created_by
        self.created_date = datetime.datetime.now()       

# Module Function
class Module_Function(db.Model):
    """Module Function"""
    __tablename__ = "tb_module_function"
    function_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    module_id = db.Column(db.Integer, db.ForeignKey('tb_module_master.module_id'), nullable=False)
    function_name = db.Column(db.String(64), nullable=False)
    function_desc = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, module_id, function_name, function_desc, created_by=0):
        self.module_id = module_id
        self.function_name = function_name
        self.function_desc = function_desc
        self.created_by =  created_by
        self.created_date = datetime.datetime.now()
        
#  Module Function Config
class Module_Function_Config(db.Model):
    __tablename__ = 'tb_module_function_config'
    config_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_name = db.Column(db.String(64), nullable=True)
    config_type = db.Column(db.String(64), nullable=True)
    business_id = db.Column(db.Integer,  db.ForeignKey('tb_business_master.business_id'), nullable=False)
    function_id = db.Column(db.Integer,  db.ForeignKey('tb_module_function.function_id'), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_id, function_id, config_name, config_type, created_by=0):
        self.business_id = business_id
        self.function_id = function_id
        self.config_name = config_name
        self.config_type = config_type
        self.created_date = datetime.datetime.now()
        self.created_by = created_by

# Module Function Config Map
class Module_Function_Config_Map(db.Model):
    __tablename__ = 'tb_module_function_config_map'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable=False )
    entity_id = db.Column(db.Integer, nullable=False)  #if config_type- group - group_id or config_type- employee - employee_id
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, entity_id):
        self.config_id = config_id
        self.entity_id = entity_id
        self.created_date = datetime.datetime.now()

# Module Function Comm Config
class Module_Function_Comm_Config(db.Model):
    __tablename__ = 'tb_module_function_comm_config'
    comm_config_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'),  nullable=False)
    message = db.Column(db.String(256), nullable=False)
    mode = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, message, mode, created_by=0):
        self.config_id = config_id
        self.message = message
        self.mode = mode
        self.created_date = datetime.datetime.now()
        self.created_by = created_by  
  
# Module Function Comm Config Map
class Module_Function_Comm_Config_Map(db.Model):
    __tablename__ = 'tb_module_function_comm_config_map'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    comm_config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_comm_config.comm_config_id'), nullable=False)
    comm_employee_id = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, comm_config_id, comm_employee_id):
        self.comm_config_id = comm_config_id
        self.comm_employee_id = comm_employee_id
        self.created_date = datetime.datetime.now()

# Checkin Checkout Config
class Checkin_Checkout_Config(db.Model):
    """Checkin_Checkout_Config Table"""
    __tablename__ = "tb_checkin_checkout_config"
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), primary_key=True, nullable = False)
    checkin = db.Column(db.String(1), nullable=False, default=STATUS["YES"])
    checkout = db.Column(db.String(1), nullable=False, default=STATUS["YES"])
    notification_delay = db.Column(db.Integer, nullable=True )
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, checkin, checkout, notification_delay):
        self.config_id = config_id
        self.checkin = checkin
        self.checkout = checkout
        self.notification_delay = notification_delay
        self.created_date = datetime.datetime.now()

#Unauthorized Access Config
class Unauthorized_Access_Config(db.Model):
    """unauthorized_access_config Table"""
    __tablename__ = "tb_unauthorized_access_config"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'),  nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    is_time_slot = db.Column(db.Boolean, nullable = False, default = False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, camera_id):
        self.config_id = config_id
        self.camera_id = camera_id
        self.created_date = datetime.datetime.now()

#Unauthorized Access Config
class Unauthorized_Timeslot(db.Model):
    """unauthorized_timeslot Table"""
    __tablename__ = "tb_unauthorized_time_slots"
    slot_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'),  nullable = False)
    start_time = db.Column(db.Time, nullable = False)
    end_time = db.Column(db.Time, nullable = False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, start_time, end_time):
        self.config_id = config_id
        self.start_time = start_time
        self.end_time = end_time
        self.created_date = datetime.datetime.now()

# Mask Compliance Config  
class Mask_Compliance_Config(db.Model):
    """unauthorized_access_config Table"""
    __tablename__ = "tb_mask_compliance_config"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'),  nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, camera_id):
        self.config_id = config_id
        self.camera_id = camera_id
        self.created_date = datetime.datetime.now()

# Social Distancing Config      
class Social_Distancing_Config(db.Model):
    """Social_Distancing_Config Table"""
    __tablename__ = "tb_social_distancing_config"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    is_heatmap = db.Column(db.Boolean, nullable = False, default = False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, camera_id, is_heatmap):
        self.config_id = config_id
        self.camera_id = camera_id
        self.is_heatmap = is_heatmap
        self.created_date = datetime.datetime.now()

# Saftey Gear Config
class Safety_Gear_Config(db.Model):
    """Safety_Gear_Config Table"""
    __tablename__ = "tb_safety_gear_config"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'),  nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    safety_kit = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, camera_id, safety_kit):
        self.config_id = config_id
        self.camera_id = camera_id
        self.safety_kit = safety_kit
        self.created_date = datetime.datetime.now() 
        
# Camera Model
class Camera_Details(db.Model):
    __tablename__ = "camera_details"
    camera_id = db.Column(db.Text, nullable=False, primary_key=True)
    user_email = db.Column(db.String(128), db.ForeignKey('tb_user_master.email'), nullable = False)
    camera_name = db.Column(db.String(64), nullable=False)
    rtsp_link = db.Column(db.String(256), nullable=False)
    floor_name = db.Column(db.String(128), nullable=False)
    max_occupancy = db.Column(db.Integer, nullable=False)
    is_checkin_checkout = db.Column(db.Boolean, nullable = False, default = False)
    is_exit = db.Column(db.Boolean, nullable = False, default = False)

    def __init__(self, user_email, camera_id, camera_name, rtsp_link, floor_name, max_occupancy ):
        self.user_email = user_email
        self.camera_id = camera_id
        self.camera_name = camera_name
        self.rtsp_link = rtsp_link
        self.floor_name = floor_name
        self.max_occupancy = max_occupancy

# Schedule Mismatch Breaktime Config
class Schedule_Mismatch_Breaktime_Config(db.Model):
    __tablename__ = "tb_schedule_mismatch_breaktime_config"
    config_seq_id = db.Column(db.Integer, primary_key = True, nullable = False)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable = False)
    start_date =  db.Column(db.Date, nullable=False)
    end_date =  db.Column(db.Date, nullable=True)
    notification_delay = db.Column(db.Integer, nullable=False )
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_id, start_date, end_date, notification_delay):
        self.config_id = config_id
        self.start_date = start_date
        self.end_date = end_date
        self.notification_delay = notification_delay
        self.created_date = datetime.datetime.now()

# Schedule_Config
class Schedule_Config (db.Model):
    """Schedule_Config Table"""
    __tablename__= "tb_schedule_config"
    schedule_config_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_seq_id = db.Column(db.Integer, db.ForeignKey('tb_schedule_mismatch_breaktime_config.config_seq_id'),  nullable=False)
    days = db.Column(db.String(128), nullable = False)
    start_time = db.Column(db.Time, nullable = False)
    end_time = db.Column(db.Time, nullable = False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable = False)
    updated_date = db.Column(db.DateTime, nullable = True)

    def __init__(self, config_seq_id, days, start_time, end_time):
        self.config_seq_id = config_seq_id
        self.days = days
        self.start_time = start_time
        self.end_time = end_time
        self.created_date = datetime.datetime.now()        

# Breaktime Config
class Breaktime_Config(db.Model):
    """breaktime_config Table"""
    __tablename__ = "tb_breaktime_config"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    schedule_config_seq_id = db.Column(db.Integer, db.ForeignKey('tb_schedule_config.schedule_config_seq_id'),  nullable = False)
    break_name = db.Column(db.String(64), nullable=False)
    break_time = db.Column(db.Integer, nullable=False)
    no_of_times = db.Column(db.Integer, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, schedule_config_seq_id, break_name, break_time, no_of_times, start_time, end_time):
        self.schedule_config_seq_id = schedule_config_seq_id
        self.break_name = break_name
        self.break_time = break_time
        self.no_of_times = no_of_times
        self.start_time = start_time
        self.end_time = end_time
        self.created_date = datetime.datetime.now()

#Food Temperatur config
class Food_Temperature_Config(db.Model):
    __tablename__ = 'tb_food_temperature_config'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    low_temp = db.Column(db.String(64), nullable=False)
    high_temp = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  config_id, camera_id, low_temp, high_temp):
        self.config_id = config_id
        self.camera_id = camera_id
        self.low_temp = low_temp
        self.high_temp = high_temp
        self.created_date = datetime.datetime.now()


#Food idle time config
class Food_IdleTime_Config(db.Model):
    __tablename__ = 'tb_food_idletime_config'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable = False)
    camera_id = db.Column(db.Text, nullable=False)
    idle_thresold = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  config_id, camera_id, idle_thresold ):
        self.config_id = config_id
        self.camera_id = camera_id
        self.idle_thresold = idle_thresold
        self.created_date = datetime.datetime.now()


class Activity_Master(db.Model):
    __tablename__ = 'tb_activity_master'
    activity_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    activity_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  activity_name):
        self.activity_name = activity_name
        self.created_date = datetime.datetime.now()      

 
class Activity_Group_Config(db.Model):
    __tablename__ = 'tb_activity_group_config'
    activity_group_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    activity_group_name = db.Column(db.String(64), nullable=False)
    activity_ids = db.Column(db.String(64), nullable=False)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_business_master.business_id'), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, activity_group_name, activity_ids, business_id):
        self.activity_group_name = activity_group_name
        self.activity_ids = activity_ids
        self.business_id = business_id
        self.created_date = datetime.datetime.now()

#Activity Monitoring config
class Activity_Monitoring_Config(db.Model):
    __tablename__ = 'tb_activity_config'
    config_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_id = db.Column(db.Integer, db.ForeignKey('tb_module_function_config.config_id'), nullable = False)
    monitor_type = db.Column(db.String(64), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  config_id, monitor_type ):
        self.config_id = config_id
        self.monitor_type = monitor_type
        self.created_date = datetime.datetime.now()

#Activity Group Map
class Activity_Group_Map(db.Model):
    __tablename__ = 'tb_activity_group_map'
    activity_map_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    config_seq_id = db.Column(db.Integer, db.ForeignKey('tb_activity_config.config_seq_id'), nullable=False)
    entity_id = db.Column(db.String(64), nullable=False)
    continuous_activity_status = db.Column(db.Boolean, nullable = False, default = False)
    cumulative_activity_status = db.Column(db.Boolean, nullable = False, default = False)
    continuous_activity_limit = db.Column(db.Integer, nullable=False)
    cumulative_activity_limit = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, config_seq_id, entity_id,continuous_activity_status, continuous_activity_limit,cumulative_activity_status , cumulative_activity_limit):
        self.config_seq_id = config_seq_id
        self.entity_id = entity_id
        self.continuous_activity_status = continuous_activity_status
        self.cumulative_activity_status = cumulative_activity_status
        self.continuous_activity_limit = continuous_activity_limit
        self.cumulative_activity_limit = cumulative_activity_limit
        self.created_date = datetime.datetime.now()

class Notification(db.Model):
    """ Notification Modal table """
    __tablename__ = "tb_user_notifications"
    notification_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_user_master.user_id'), nullable=False)
    title = db.Column(db.String(64), nullable=False)
    message = db.Column(db.String(2000), nullable=True)
    read_status = db.Column(db.String(1), nullable=False, default=STATUS["NO"])
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, user_id, title, message):
        self.user_id = user_id
        self.title = title
        self.message = message
        self.created_date = datetime.datetime.now()
        
# airflow models:
# Absence table
class Absence(db.Model):
    __tablename__= "absence"
    time = db.Column(db.DateTime(timezone = True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    is_absent = db.Column(db.String(64), nullable = False, default = STATUS["NO"])

# Unauthorized table  
class Unauthorized(db.Model):
    __tablename__= "unauthorized"
    time = db.Column(db.DateTime(timezone = True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    is_unauthorized = db.Column(db.String(64), nullable = False, default = STATUS["NO"])

# Social_Distancing table  
class Social_Distancing(db.Model):
    __tablename__= "social_distancing"
    time = db.Column(db.DateTime(timezone = True), primary_key=True, nullable=False)
    camera_id = db.Column(db.Text, nullable=False)

# Mask_Compliance table 
class Mask_Compliance(db.Model):
    __tablename__= "mask_compliance"
    time = db.Column(db.DateTime(timezone = True), primary_key=True, nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    
# Safety Gear table
class Safety_Gear(db.Model):
    __tablename__ = "safety_gear"
    time = db.Column(db.DateTime(timezone=True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    is_violation = db.Column(db.String(64), nullable = False, default = STATUS["NO"])
    
# Touchless Attendance table
class Touchless_Attendance(db.Model):
    __tablename__= "touchless_attendance"
    time = db.Column(db.DateTime(timezone=True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    attendance_status = db.Column(db.String(1), nullable=False, default=STATUS["OUT"])
    num_working_secs = db.Column(db.String(1), nullable=False)
    
# Break Time table
class Break_Time(db.Model):
    __tablename__ = "break_time"
    time = db.Column(db.DateTime(timezone=True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    break_status = db.Column(db.String(1), nullable=False, default=STATUS["OUT"])
    break_time_taken = db.Column(db.String(1), nullable=False)
    is_violation = db.Column(db.String(64), nullable = False, default = STATUS["NO"])

# Schedule Mismatch table
class Schedule_Mismatch(db.Model):
    __tablename__ = "schedule_mismatch"
    time = db.Column(db.DateTime(timezone=True), primary_key=True, nullable=False)
    employee_mobile = db.Column(db.String(64), nullable=False)
    camera_id = db.Column(db.Text, nullable=False)
    schedule_status = db.Column(db.String(1), nullable=False, default=STATUS["OUT"])
    is_violation = db.Column(db.String(64), nullable = False, default = STATUS["NO"])

#  Dashboard Configuration :
# Element Master
class Element(db.Model):
    """Element Master Table """
    __tablename__ = "tb_element_master"
    element_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    element_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, element_name):
        self.element_name = element_name
        self.created_date = datetime.datetime.now()  

# Chart Master
class Chart(db.Model):
    """Chart Master Table """
    __tablename__ = "tb_chart_master"
    chart_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    chart_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, chart_name):
        self.chart_name = chart_name
        self.created_date = datetime.datetime.now() 

 # Dataset Master

class Dataset(db.Model):
    """Dataset Master Table """
    __tablename__ = "tb_dataset_master"
    dataset_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dataset_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, dataset_name):
        self.dataset_name = dataset_name
        self.created_date = datetime.datetime.now()

# Dashboard Master
class Dashboard(db.Model):
    """Dashboard Master Table """
    __tablename__ = "tb_dashboard_master"
    dashboard_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dashboard_name = db.Column(db.String(64), nullable=False)
    business_id = db.Column(db.Integer,db.ForeignKey("tb_business_master.business_id"), nullable=True)
    module_id = db.Column(db.Integer, db.ForeignKey('tb_module_master.module_id'), nullable=False)
    structure = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, dashboard_name, business_id, module_id):
        self.dashboard_name = dashboard_name
        self.business_id = business_id
        self.module_id = module_id
        self.created_date = datetime.datetime.now()  

# Dashboard Element
class Dashboard_Element(db.Model):
    __tablename__ = 'tb_dashboard_element'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dashboard_id = db.Column(db.Integer, db.ForeignKey('tb_dashboard_master.dashboard_id'),  nullable=False)
    element_id = db.Column(db.Integer, db.ForeignKey('tb_element_master.element_id'),  nullable=False)
    dataset_id = db.Column(db.Integer,  nullable=True)
    box_position = db.Column(db.String(200), nullable=False)
    element_alignment = db.Column(db.String(64), nullable=False)
    cell_height = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, dashboard_id, element_id, box_position, element_alignment , cell_height, dataset_id = 0):
        self.dashboard_id = dashboard_id
        self.element_id = element_id
        self.dataset_id = dataset_id
        self.box_position = box_position
        self.element_alignment = element_alignment
        self.cell_height = cell_height
        self.created_date = datetime.datetime.now()
        
# Dashboard Element Config
class Dashboard_Element_Config(db.Model):
    __tablename__ = 'tb_dashboard_element_config'
    element_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    seq_id = db.Column(db.Integer, db.ForeignKey('tb_dashboard_element.seq_id'),  nullable=False)
    highlighter_title = db.Column(db.String(64), nullable=False)
    data_column_id = db.Column(db.String(64), nullable=True)
    measure = db.Column(db.String(64), nullable=True)
    date_range = db.Column(db.String(64), nullable=True)

    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, seq_id, highlighter_title = "", data_column_id = "", measure = "", date_range = "" ):
        self.seq_id = seq_id
        self.highlighter_title = highlighter_title
        self.data_column_id = data_column_id
        self.measure = measure
        self.date_range = date_range        
        self.created_date = datetime.datetime.now()
  
# Dashboard Element Config Columns        
class Dashboard_Element_Config_Columns(db.Model):
    __tablename__ = 'tb_dashboard_element_config_columns'
    column_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    seq_id = db.Column(db.Integer, db.ForeignKey('tb_dashboard_element.seq_id'),  nullable=False)
    data_column_id = db.Column(db.Integer, db.ForeignKey('tb_dataset_column_master.column_id'),  nullable=False)
    date_column_display_name = db.Column(db.String(200), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, seq_id, data_column_id, date_column_display_name):
        self.seq_id = seq_id
        self.data_column_id = data_column_id
        self.date_column_display_name = date_column_display_name
        self.created_date = datetime.datetime.now()       
   
# Dashboard Chart
class Dashboard_Chart(db.Model):
    """Dashboard Chart Table"""
    __tablename__ = "tb_dashboard_chart"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dashboard_id = db.Column(db.Integer, db.ForeignKey("tb_dashboard_master.dashboard_id"), nullable=False)
    box_position = db.Column(db.String(200), nullable=False)
    chart_id = db.Column(db.Integer, db.ForeignKey("tb_chart_master.chart_id"), autoincrement=True)
    dataset_id = db.Column(db.Integer,  nullable=True)
    chart_title = db.Column(db.String(64), nullable=False)
    element_alignment = db.Column(db.String(64), nullable=False)
    cell_height = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, dashboard_id, chart_id, box_position, chart_title, element_alignment, cell_height, dataset_id =0):
        self.dashboard_id = dashboard_id
        self.box_position = box_position
        self.chart_id = chart_id
        self.chart_title = chart_title
        self.element_alignment = element_alignment
        self.cell_height = cell_height
        self.dataset_id = dataset_id
        self.created_date = datetime.datetime.now()

# Dashboard Chart Config
class Dashboard_Chart_Config(db.Model):
    """Dashboard Chart Config Table"""
    __tablename__ = "tb_dashboard_chart_config"
    chart_seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    seq_id = db.Column(db.Integer, db.ForeignKey("tb_dashboard_chart.seq_id"), nullable=False)
    x_axis = db.Column(db.String(64), nullable=True)
    y_axis = db.Column(db.String(64), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, seq_id, x_axis, y_axis =""):
        self.seq_id = seq_id
        self.x_axis = x_axis
        self.y_axis = y_axis
        self.created_date = datetime.datetime.now()
        
# Dataset_Column_Master
class Dataset_Column(db.Model):
    __tablename__ = 'tb_dataset_column_master'
    column_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dataset_id = db.Column(db.Integer, db.ForeignKey('tb_dataset_master.dataset_id'),  nullable=False)
    column_name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, dataset_id, column_name):       
        self.dataset_id = dataset_id
        self.column_name = column_name
        self.created_date = datetime.datetime.now()

@auth.verify_token
def verify_auth_token(token):
    """ Auth token verification """
    try:
        login_token = Login_Token.query.filter(
            and_(
                Login_Token.token == token, 
                Login_Token.status == STATUS["ACTIVE"], 
                Login_Token.is_logged_in == STATUS["YES"]
            )).first()
        
        if login_token:

            # Deactivate old session
            db.engine.execute("UPDATE tb_login_token SET status = %s WHERE user_id = %s \
                AND token != %s AND status = %s AND access_mode = %s", 
                (STATUS["DEACTIVE"], login_token.user_id, login_token.token, STATUS["ACTIVE"], login_token.access_mode))

            # Update last request date
            login_token.last_request_date = datetime.datetime.now()
            db.session.commit()
            return User.query.get(login_token.user_id)
        
    except Exception as e:
        logging.exception("verify_auth_token : exception : {}".format(e))
    return None

# Insert Login Token
def login_token_insert(user_id, access_mode="WEB"):
    token = ""
    try:
        token = uuid.uuid4()
        while Login_Token.query.get(str(token)):
            token = uuid.uuid4()

        token = str(token)
        login_token = Login_Token(token, user_id, access_mode)
        login_token.last_request_date = datetime.datetime.now()
        login_token.is_logged_in = STATUS["YES"]
        db.session.add(login_token)
        db.session.commit() 
    except Exception as e:
        logging.exception("login_token_insert - {}".format(e,))
    return token
    
# user object
def get_current_user():
    user_id = 0
    if auth.current_user():
        user_id = auth.current_user().user_id
    user = User.query.get(user_id)
    return user

# Insert and send Otp
def otp_insert(country_id, mobile):
    try:
        otp_code = generate_otp()
        otp = OTP(country_id, mobile, otp_code)
        db.session.add(otp)
        db.session.commit()

        msg = "Welcome! {} is your Safeo Verification Code to activate your account".format(otp_code)
        sms_insert(country_id,mobile,msg)
        return otp.otp_id

    except Exception as e:
        logging.exception("otp_insert - {}".format(e,))  
    return 0

# Verify Otp
def otp_verify(otp_id, otp_code):
    status = False
    try:
        otp = OTP.query.filter(and_(OTP.otp_id == str(otp_id), OTP.otp_code == str(otp_code), OTP.exp_date >= datetime.datetime.now())).first()
        if otp:
            status = True
    except Exception as e:
        logging.exception("otp_verify - {}".format(e,))
    return status

# Insert SMS
def sms_insert(country_id, mobile, message):
    try:
        sms = SMS(country_id, mobile, message)
        db.session.add(sms)
        db.session.commit() 
    except Exception as e:
        logging.exception("sms_insert - {}".format(e,))       

#Mail Insert
def mail_insert(email, subject, message):
    try:
        mail = Mail(email, subject, message)
        db.session.add(mail)
        db.session.commit() 
    except Exception as e:
        logging.exception("mail_insert - {}".format(e,))

# Return the User's Role_Type
def get_user_role_type(user):
    user_role_type = ''
    user_group = User_Group_Map.query.filter(User_Group_Map.user_id == user.user_id).first()

    if user_group:
        group_role = Employee_Group_Role_Map.query.filter(Employee_Group_Role_Map.emp_group_id == user_group.emp_group_id).first()
        if group_role:
            role = Role.query.filter(Role.role_id == group_role.role_id).first()
            user_role_type = role.role_type 
    return user_role_type

# Return Admin mobile
def get_admin_mobile(user):
    mobile = ''
    role_type = get_user_role_type(user)
    if role_type == ROLE_TYPE["CLIENT-ADMIN"]:
        country = Country.query.filter_by (country_id = user.country_id).first()
        mobile = country.country_code + user.mobile
    else:
        admin_user = User.query.filter(
            and_(
                User.business_id == user.business_id,
                User.user_id == User_Group_Map.user_id,
                User_Group_Map.emp_group_id == Employee_Group_Role_Map.emp_group_id,
                Employee_Group_Role_Map.role_id == Role.role_id,
                Role.role_type == ROLE_TYPE["CLIENT-ADMIN"])).first()
        country = Country.query.filter_by (country_id = admin_user.country_id).first()
        mobile = country.country_code + admin_user.mobile
    return mobile

#Employee Group
class Employee_Group(db.Model):
    __tablename__ = 'tb_employee_group_master'
    emp_group_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_business_master.business_id'),  nullable=True)
    emp_group_name = db.Column(db.String(128), nullable=False)
    emp_group_desc = db.Column(db.String(1000), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  emp_group_name, emp_group_desc, business_id, created_by=0):
        self.business_id = business_id
        self.emp_group_name = emp_group_name
        self.emp_group_desc = emp_group_desc
        self.created_by = created_by
        self.created_date = datetime.datetime.now()

#User Group Role Map
class User_Group_Map(db.Model):
    __tablename__ = 'tb_user_group_map'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_user_master.user_id'),  nullable=False)
    emp_group_id = db.Column(db.Integer, db.ForeignKey('tb_employee_group_master.emp_group_id'),  nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, user_id, emp_group_id, created_by=0):
        self.user_id = user_id
        self.emp_group_id = emp_group_id
        self.created_by = created_by
        self.created_date = datetime.datetime.now()

#Employee Group Role Map
class Employee_Group_Role_Map(db.Model):
    __tablename__ = 'tb_group_role_map'
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_group_id = db.Column(db.Integer, db.ForeignKey('tb_employee_group_master.emp_group_id'),  nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_role_master.role_id'),  nullable=False)
    user_id = db.Column(db.Integer,  nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=False, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self,  emp_group_id, role_id, created_by=0):
        self.emp_group_id = emp_group_id
        self.role_id = role_id
        self.created_by = created_by
        self.created_date = datetime.datetime.now()


def configuration_status(business_id, admin_mobile):
    try:
        status = "ROLE"
        roles = Role.query.filter(and_(Role.business_id == business_id,
                                        Role.status == STATUS["ACTIVE"])).all()
        if roles:
            employees = User.query.filter(and_(User.business_id == business_id,
                                        User.status != STATUS["DELETE"],
                                        User.is_employee == STATUS["YES"])).all()           
            if employees:
                groups = Employee_Group.query.filter(and_(Employee_Group.business_id == business_id,
                                        Employee_Group.status == STATUS["ACTIVE"])).all()     
                if groups:
                    cameras = Camera_Details.query.filter(Camera_Details.user_email == admin_mobile).all() 
                    if cameras:
                        configs = Module_Function_Config.query.filter(and_(Module_Function_Config.business_id == business_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"])).all()     
                        if configs:
                            status = "DASHBOARD"  
                        else:
                            status = "MODULE"
                    else:
                        status = "CAMERA"
                else:
                    status = "GROUP"   
            else:
                status = "EMPLOYEE" 
        else:
            status = "ROLE"  
    except Exception as e:
        return ""        
    return  status


def get_emp_user_functions(user):
    function_list = list()
    user_group = User_Group_Map.query.filter(User_Group_Map.user_id == user.user_id).first()
    if user_group:
        group_role = Employee_Group_Role_Map.query.filter(Employee_Group_Role_Map.emp_group_id == user_group.emp_group_id).first()
        if group_role:
            role = Role.query.filter(Role.role_id == group_role.role_id).first()
            if role:
                role_function_maps = Role_Function_Map.query.filter(
                    and_(Role_Function_Map.role_id == role.role_id, 
                        Role_Function_Map.status == STATUS["ACTIVE"])).all()
                for role_function in role_function_maps:
                    function_dict = dict()
                    parent_function = Function.query.filter(and_(Function.parent_function_id == role_function.function_id,
                                                            Function.status == STATUS["ACTIVE"])).first()
                    if not parent_function:                                        
                        function_dict["function_id"] = role_function.function_id
                        function = Function.query.get(role_function.function_id)
                        function_dict["function_name"] = function.function_desc
                        function_list.append(function_dict)
    return function_list

    
