##postgres SQL PARAMS
SQL_USER = "safeov2_dev"
SQL_PASSWORD = "_k9Bd#RP"
DATABASE = "safeov2_dev"
SQL_HOST="localhost"
 
##AIRFLOW PARAMS
AIRFLOW_URL = 'http://localhost:8989/api/v1/'
AIRFLOW_PASSWORD = 'safeo_dev'
AIRFLOW_USER = 'chennai2021'
