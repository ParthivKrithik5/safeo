-- Safeo admin database tables
-- Country Master Table
CREATE TABLE tb_country_master (
    country_id SERIAL PRIMARY KEY,
    long_name VARCHAR(100) NOT NULL,
    short_name VARCHAR(2) NOT NULL,
    country_code VARCHAR(4) NOT NULL,
    status CHAR(1) DEFAULT 'A', 
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL
);

INSERT INTO tb_country_master(long_name,short_name,country_code,created_date) VALUES ('UNITED_STATES_OF_AMERICA','US','01', now());
INSERT INTO tb_country_master(long_name,short_name,country_code,created_date) VALUES ('INDIA','IN','91', now());

-- Industry Master Table
CREATE TABLE tb_industry_master(
    industry_id SERIAl PRIMARY KEY,
    industry_name VARCHAR (64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP NULL
);

INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('INFORMATION TECHNOLOGY', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('MANUFACTURING', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('FOOD', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('HEALTHCARE', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('LOGISTICS', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('EDUCATION INSTITUTION', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('RETAIL', 1, NOW());
INSERT INTO tb_industry_master (industry_name, created_by, created_date) VALUES ('OTHERS', 1, NOW());

 -- Registration Table
create table tb_registrations(
   reg_id SERIAL PRIMARY KEY,
   name VARCHAR(120) NOT NULL,
   email VARCHAR(160) NOT NULL,
   password VARCHAR(120) NOT NULL,
   country_id INT NOT NULL,
   mobile VARCHAR(20) NOT NULL,
   business_name VARCHAR(120) NOT NULL,
   industry_id INTEGER NOT NULL,
   address VARCHAR(600) NOT NULL,
   status char(1) DEFAULT 'E',
   mobile_verified_on TIMESTAMP NULL,
   created_date TIMESTAMP NOT NULL,
   updated_date TIMESTAMP NULL,
   FOREIGN KEY(industry_id)  REFERENCES tb_industry_master(industry_id),
   FOREIGN KEY (country_id) REFERENCES tb_country_master (country_id)
);

-- Business Master Table
create table tb_business_master(
    business_id SERIAL PRIMARY KEY, 
    business_name VARCHAR(200) NOT NULL,
    industry_id INTEGER DEFAULT NULL,
    address VARCHAR(600) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NOT NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL, 
    FOREIGN KEY (industry_id) REFERENCES tb_industry_master (industry_id)
);

-- User Master Table
CREATE TABLE tb_user_master(
    user_id SERIAl PRIMARY KEY,
    emp_id VARCHAR(16) NULL,
    name VARCHAR(128) NOT NULL,
    email VARCHAR(128) NOT NULL,
    country_id INT NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    password VARCHAR(258) NOT NULL,
    designation VARCHAR(128) NOT NULL,
    is_employee CHAR(1) DEFAULT 'N',
    profile_image VARCHAR(64) DEFAULT NULL,
    default_password_changed CHAR(1) DEFAULT 'N',
    business_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (country_id) REFERENCES tb_country_master (country_id),
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id)
);

-- Function Master Table 
CREATE TABLE tb_function_master(
    function_id SERIAl PRIMARY KEY,
    function_name VARCHAR (200) NOT NULL,
    function_desc VARCHAR (1000) NOT NULL,
    parent_function_id INTEGER DEFAULT 0,
    function_url VARCHAR (1000) DEFAULT NULL,
    function_approach VARCHAR(20) DEFAULT 'NONE',
    function_icon VARCHAR(100000) DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL
);

-- Role Master Table 
CREATE TABLE tb_role_master(
    role_id SERIAl PRIMARY KEY,
    role_name VARCHAR (200) NOT NULL,
    role_desc VARCHAR (1000) NOT NULL,  
    business_id INTEGER DEFAULT NULL,
    role_type VARCHAR (64) NOT NULL DEFAULT 'CLIENT-ADMIN',  
    role_modification CHAR(1) DEFAULT 'N',
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL
);

-- Role Function Map Table
CREATE TABLE tb_role_function_map(
    seq_id SERIAl PRIMARY KEY,
    role_id INTEGER NOT NULL,
    function_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (function_id) REFERENCES tb_function_master (function_id),
    FOREIGN KEY (role_id) REFERENCES tb_role_master (role_id)
);


-- Login Token Table
create table tb_login_token (
    token UUID NOT NULL,
    access_mode VARCHAR(64) NOT NULL DEFAULT 'WEB',
    user_id INTEGER NOT NULL,
    last_request_date TIMESTAMP NULL,
    is_logged_in CHAR(1) DEFAULT 'N',
    status CHAR(1) DEFAULT 'A',
    exp_date TIMESTAMP NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(token),
    FOREIGN KEY (user_id) REFERENCES tb_user_master (user_id)
);

-- -- User Device Info Table 
-- CREATE TABLE tb_user_device_info(
--     info_id SERIAl PRIMARY KEY,
--     user_id INTEGER NOT NULL,
--     android_device_id VARCHAR (500) DEFAULT NULL,
--     ios_device_id VARCHAR (500) DEFAULT NULL,
--     created_date TIMESTAMP DEFAULT NULL,
--     updated_date TIMESTAMP DEFAULT NULL
-- );

-- OTP Master
CREATE TABLE tb_otp_txn(
    otp_id SERIAL NOT NULL,
    country_id INTEGER NOT NULL,
    mobile VARCHAR(16) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    status CHAR(1) DEFAULT 'E', 
    exp_date TIMESTAMP NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(otp_id),
    CONSTRAINT fk_tb_otp FOREIGN KEY(country_id)  REFERENCES tb_country_master(country_id)  
);

-- SMS Transaction
CREATE TABLE tb_sms_txn(
    seq_id SERIAL NOT NULL,
    country_id INTEGER NOT NULL,
    mobile VARCHAR(16) NOT NULL,
    message VARCHAR(200) NOT NULL,
    status CHAR(1) DEFAULT 'E',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(seq_id),
    CONSTRAINT fk_tb_sms_txn FOREIGN KEY(country_id)  REFERENCES tb_country_master(country_id)
);

create table tb_mail_txn(
    seq_id SERIAL NOT NULL,
    email VARCHAR(64) NOT NULL,
    subject VARCHAR(64) NOT NULL,
    message VARCHAR(20000) NOT NULL,
    status CHAR(1) DEFAULT 'E',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(seq_id)
);

-- Config SetUp Table
-- Module Master
CREATE TABLE tb_module_master(
    module_id SERIAl PRIMARY KEY,
    module_name VARCHAR(64) NOT NULL,
    module_desc VARCHAR(200) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL
);

-- Module Function
CREATE TABLE tb_module_function(
    function_id SERIAl PRIMARY KEY,
    module_id INT NOT NULL,
    function_name VARCHAR(64) NOT NULL,
    function_desc VARCHAR(200) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (module_id) REFERENCES tb_module_master (module_id)
);

-- Module Function Config
CREATE TABLE tb_module_function_config(
    config_id SERIAl PRIMARY KEY,
    business_id INT NOT NULL,
    function_id INT NOT NULL,
    config_name VARCHAR(64)  DEFAULT NULL,
    config_type VARCHAR(64)  DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id),
    FOREIGN KEY (function_id) REFERENCES tb_module_function (function_id)
);

-- Module Function Config Map
CREATE TABLE tb_module_function_config_map(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    entity_id INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Module Functin Communication Config
CREATE TABLE tb_module_function_comm_config(
    comm_config_id SERIAl PRIMARY KEY,
    config_id INT NOT NULL,
    message VARCHAR(256) NOT NULL,
    mode VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Module Functin Communication Config Map
CREATE TABLE tb_module_function_comm_config_map(
    seq_id SERIAL  PRIMARY KEY,
    comm_config_id INT NOT NULL,
    comm_employee_id INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (comm_config_id) REFERENCES tb_module_function_comm_config (comm_config_id)
);

-- Checkin Checkout Config
CREATE TABLE tb_checkin_checkout_config(
    config_id INT NOT NULL,
    checkin CHAR(1) DEFAULT 'Y',
    checkout CHAR(1) DEFAULT 'Y',
    notification_delay INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Schedule Mismatch Break Time Config
create table tb_schedule_mismatch_breaktime_config(
    config_seq_id  SERIAl PRIMARY KEY,
    config_id  INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    notification_delay INT NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

create table tb_schedule_config(
    schedule_config_seq_id SERIAl PRIMARY KEY,
    config_seq_id  INT NOT NULL,
    days VARCHAR(128) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_seq_id) REFERENCES tb_schedule_mismatch_breaktime_config (config_seq_id)
);
CREATE TABLE tb_breaktime_config(
    seq_id SERIAL PRIMARY KEY,
    schedule_config_seq_id INT NOT NULL,
    break_name VARCHAR(64) NOT NULL,
    break_time INTEGER NOT NULL,
    no_of_times INT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (schedule_config_seq_id) REFERENCES tb_schedule_config (schedule_config_seq_id)
);

-- Unauthorized Access Config
CREATE TABLE tb_unauthorized_access_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

CREATE TABLE tb_unauthorized_time_slots(
    slot_seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Mask Compliance Config
CREATE TABLE tb_mask_compliance_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Social Distancing Config
CREATE TABLE tb_social_distancing_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    is_heatmap BOOLEAN NOT NULL DEFAULT FALSE,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Safety Gear Config
CREATE TABLE tb_safety_gear_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    safety_kit VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

--Food Temperature Config
CREATE TABLE tb_food_temperature_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    low_temp VARCHAR(64) NOT NULL,
    high_temp VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

--Food Idle Time config
CREATE TABLE tb_food_idletime_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    idle_thresold INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

CREATE TABLE tb_activity_master(
    activity_id SERIAL  PRIMARY KEY,
    activity_name VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
);


CREATE TABLE tb_activity_group_config(
    activity_group_id SERIAL  PRIMARY KEY,
    activity_group_name VARCHAR(64) NOT NULL,
    activity_ids VARCHAR(64) NOT NULL,
    business_id INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id)    
);

---Activity Monitoring Config
CREATE TABLE tb_activity_config(
    config_seq_id SERIAL PRIMARY KEY,
    config_id INT NOT NULL,
    monitor_type VARCHAR(64) DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);


CREATE TABLE tb_activity_group_map(
    activity_map_id SERIAL  PRIMARY KEY,
    config_seq_id INT NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    continuous_activity_status BOOLEAN NOT NULL DEFAULT FALSE,
    continuous_activity_limit INT DEFAULT NULL,
    cumulative_activity_status BOOLEAN NOT NULL DEFAULT FALSE,
    cumulative_activity_limit INT DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_seq_id) REFERENCES tb_activity_config (config_seq_id)  
);



-- Camera Details
CREATE TABLE camera_details(
    user_email TEXT NOT NULL,
    camera_id UUID NOT NULL,
    camera_name TEXT NOT NULL,
    rtsp_link TEXT NOT NULL,
    floor_name TEXT NOT NULL,
    max_occupancy INTEGER NOT NULL,
    is_checkin_checkout BOOLEAN NOT NULL DEFAULT FALSE,
    is_exit BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY(camera_id)
);

CREATE TABLE tb_user_notifications(
	notification_id SERIAL NOT NULL,
	user_id INTEGER NOT NULL,
    title VARCHAR(64) NOT NULL,
	message VARCHAR(2000) NULL,
	status CHAR(1) DEFAULT 'A',
    read_status CHAR(1) DEFAULT 'N',   
	created_date TIMESTAMP NOT NULL,
	updated_date TIMESTAMP NULL,
	primary key(notification_id),
	CONSTRAINT fk_notification_user_id FOREIGN KEY(user_id)  REFERENCES tb_user_master(user_id)
);

--Industry Role Map Table
CREATE TABLE tb_industry_role_resp(
    seq_id SERIAL PRIMARY KEY,
    industry_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (industry_id) REFERENCES tb_industry_master (industry_id),
    FOREIGN KEY (role_id) REFERENCES tb_role_master (role_id)
);

CREATE TABLE touchless_users(
	user_email TEXT NOT NULL,
	facebank_path TEXT NOT NULL
);

CREATE TABLE tb_food_temperature_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    low_temp VARCHAR(64) NOT NULL,
    high_temp VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);


CREATE TABLE tb_food_idletime_config(
    seq_id SERIAL  PRIMARY KEY,
    config_id INT NOT NULL,
    camera_id UUID NOT NULL,
    idle_thresold INT NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (config_id) REFERENCES tb_module_function_config (config_id)
);

-- Air flow

CREATE TABLE absence(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    is_absent DEFAULT 'N'
);

CREATE TABLE unauthorized(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_mobile TEXT NOT NULL,
    camera_id UUID NOT NULL,
    is_unauthorized DEFAULT 'N'
);

CREATE TABLE social_distancing(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL
);

CREATE TABLE mask_compliance(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL
);
 
CREATE TABLE safety_gear(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_mobile TEXT NOT NULL,
    camera_id UUID NOT NULL,
    gear_name VARCHAR DEFAULT NULL,
    is_violation VARCHAR DEFAULT 'N'
);

CREATE TABLE touchless_attendance(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_mobile TEXT NOT NULL,
    camera_id UUID NOT NULL,
    attendance_status VARCHAR DEFAULT 'OUT',
    num_working_secs VARCHAR NOT NULL
);

CREATE TABLE schedule_mismatch(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_mobile TEXT NOT NULL,
    camera_id UUID NOT NULL,
    schedule_status VARCHAR DEFAULT 'OUT',
    is_violation VARCHAR DEFAULT 'N'
);

CREATE TABLE heat_map(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    camera_id UUID NOT NULL,
    no_of_people INT NOT NULL,
    is_violation VARCHAR DEFAULT 'N'
    );

CREATE TABLE break_time(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_mobile TEXT NOT NULL,
    camera_id UUID NOT NULL,
    break_status VARCHAR DEFAULT 'OUT',
    break_time_taken VARCHAR NOT NULL,
    is_violation VARCHAR DEFAULT 'N'
);    

--  Dashboard Configuration Tables not moved in dev server 

CREATE TABLE tb_element_master(
    element_id SERIAL  PRIMARY KEY,
    element_name VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP DEFAULT NULL,
    updated_date TIMESTAMP DEFAULT NULL
);

CREATE TABLE tb_chart_master(
    chart_id SERIAL  PRIMARY KEY,
    chart_name VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP DEFAULT NULL,
    updated_date TIMESTAMP DEFAULT NULL
);

CREATE TABLE tb_dataset_master(
    dataset_id  SERIAL  PRIMARY KEY,
    dataset_name VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP DEFAULT NULL,
    updated_date TIMESTAMP DEFAULT NULL
);

CREATE TABLE tb_dashboard_master(
    dashboard_id SERIAL  PRIMARY KEY,
    dashboard_name VARCHAR(64) NOT NULL,
    module_id INT NOT NULL,
    business_id INT NOT NULL,
    structure VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP DEFAULT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id),
    FOREIGN KEY (module_id) REFERENCES tb_module_master (module_id) 
);


CREATE TABLE tb_dashboard_element(
    seq_id SERIAL  PRIMARY KEY,
    dashboard_id INT NOT NULL,
    element_id INT NOT NULL,
    dataset_id  INT NULL,    
    box_position VARCHAR(200) NOT NULL,
    element_alignment VARCHAR(64)  NOT NULL,
    cell_height VARCHAR(64)  NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (dashboard_id) REFERENCES tb_dashboard_master(dashboard_id),
    FOREIGN KEY (element_id) REFERENCES tb_element_master (element_id)
);

CREATE TABLE tb_dashboard_element_config(
    element_seq_id SERIAL  PRIMARY KEY,
    seq_id  INT NOT NULL,
    highlighter_title VARCHAR(64) DEFAULT NULL,
    data_column_id  VARCHAR(64) DEFAULT NULL,
    measure  VARCHAR(64) DEFAULT NULL,
    date_range VARCHAR(64) DEFAULT NULL,  
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (seq_id) REFERENCES tb_dashboard_element (seq_id)
);

CREATE TABLE tb_dashboard_element_config_columns(
    column_seq_id SERIAL  PRIMARY KEY,
    seq_id INT NOT NULL,
    data_column_id  INT NOT NULL,
    date_column_display_name VARCHAR(200) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (data_column_id) REFERENCES tb_dataset_column_master (column_id),
    FOREIGN KEY (seq_id) REFERENCES tb_dashboard_element(seq_id)
);


CREATE TABLE tb_dashboard_chart(
    seq_id SERIAL  PRIMARY KEY,
    dashboard_id INT NOT NULL,
    box_position VARCHAR(200) NOT NULL,
    chart_id INT NOT NULL,
    chart_title VARCHAR(64) NOT NULL,
    dataset_id INT NULL,
    element_alignment VARCHAR(64)  NOT NULL,
    cell_height VARCHAR(64)  NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (dashboard_id) REFERENCES tb_dashboard_master (dashboard_id),
    FOREIGN KEY (chart_id) REFERENCES tb_chart_master (chart_id)
);

CREATE TABLE tb_dashboard_chart_config(
    chart_seq_id SERIAL  PRIMARY KEY,
    seq_id  INT NOT NULL,
    x_axis  VARCHAR(64) DEFAULT NULL,
    y_axis  VARCHAR(64) DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (seq_id) REFERENCES tb_dashboard_chart (seq_id)
);

CREATE TABLE tb_dataset_column_master(
    column_id SERIAL  PRIMARY KEY,
    dataset_id INT NOT NULL,
    column_name  VARCHAR(64) NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (dataset_id) REFERENCES tb_dataset_master (dataset_id)
);

insert into tb_chart_master(chart_name, status, created_date) values('Pie Chart' , 'A', now());
insert into tb_chart_master(chart_name, status, created_date) values('Line Chart' , 'A', now());
insert into tb_chart_master(chart_name, status, created_date) values('Bar Chart' , 'A', now());
insert into tb_chart_master(chart_name, status, created_date) values('Area Chart' , 'A', now());
insert into tb_chart_master(chart_name, status, created_date) values('Gantt Chart' , 'A', now());
insert into tb_chart_master(chart_name, status, created_date) values('Scatter Plot' , 'A', now());

insert into tb_element_master(element_name, status, created_date) values('Date Set' , 'A', now());
insert into tb_element_master(element_name, status, created_date) values('Highlighter Box' , 'A', now());
insert into tb_element_master(element_name, status, created_date) values('Table List' , 'A', now());


insert into tb_dataset_master(dataset_name, status, created_date) values('Employee' , 'A',now());


insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'name', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'email', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'country_id', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'mobile', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'designation', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'is_employee', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'profile_image', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'business_id', 'A', now());
insert into tb_dataset_column_master(dataset_id, column_name, status, created_date) values( 1, 'emp_id', 'A', now());




-- EMPLOYEE GROUP TABLE

CREATE TABLE tb_employee_group_master(
    emp_group_id SERIAL  PRIMARY KEY,
    emp_group_name VARCHAR(128) NOT NULL,
    emp_group_desc VARCHAR(1000) NOT NULL,
    business_id INTEGER DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id)
);

CREATE TABLE tb_group_role_map(
    seq_id SERIAL  PRIMARY KEY,
    emp_group_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    user_id INTEGER DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (emp_group_id) REFERENCES tb_employee_group_master (emp_group_id),
    FOREIGN KEY (role_id) REFERENCES tb_role_master (role_id)
); 

insert into tb_group_role_map(emp_group_id, role_id, status, created_date) values
(2 , 1,  'A', now());

CREATE TABLE tb_user_group_map(
    seq_id SERIAL  PRIMARY KEY,
    user_id INTEGER NOT NULL,
    emp_group_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES tb_user_master (user_id),
    FOREIGN KEY (emp_group_id) REFERENCES tb_employee_group_master (emp_group_id)
);

insert into tb_user_group_map(emp_group_id, user_id, status, created_date) values
(2 , 3,  'A', now());

select setval('tb_function_master_function_id_seq', max(function_id)) FROM tb_function_master;

-- functions
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(1,'Administration','Administration',0,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(2,'Module Configuration','Module Configuration',0,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(3,'Dashboard','Dashboard',0,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master  (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(4,'Camera Setup','Camera Setup',1,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(5,'Employee Setup','Employee Setup',1,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(6,'Group Setup','Group Setup',1,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(7,'Attendance','Attendance',2,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(8,'Mask Compliance','Mask Compliance',2,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(9,'Social Distancing','Social Distancing',2,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(10,'Schedule Mismatch & Breaktime Violation','Schedule Mismatch & Breaktime Violation',2,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(11,'Check In / Check Out','Check In / Check Out',7,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(12,'Unauthorized Access','Unauthorized Access',7,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(13,'Schedule Mismatch','Schedule Mismatch',7,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(14,'Attendance','Attendance',3,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(15,'Check In / Check Out','Check In / Check Out',14,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(16,'Role Setup','Role Setup',1,'','A',0,NOW(),0,NOW());
INSERT INTO tb_function_master (function_id, function_name,function_desc, parent_function_id, function_url, status, created_by, created_date, updated_by, updated_date) VALUES(17,'Profile Setup','Profile Setup',1,'','A',0,NOW(),0,NOW());


-- function
insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 1, 'Attendance', 'Attendance', 'A', 0, now(), 0, now());
insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 2, 'Mask Compliance', 'Mask Compliance', 'A', 0, now(), 0, now());
insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 4, 'Saftey Gear', 'Saftey Gear', 'A', 0, now(), 0, now());
insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 3, 'Social Distancing & Heat Map', 'Social Distancing & Heat Map', 'A', 0, now(), 0, now());

insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 5, 'Food Safety', 'Food Safety', 'A', 0, now(), 0, now());
insert into tb_module_master(module_id, module_name, module_desc, status, created_by, created_date, updated_by, updated_date) values( 6, 'Activity Monitoring', 'Activity Monitoring', 'A', 0, now(), 0, now());

-- sub-functions
insert into tb_module_function(function_id, module_id, function_name, function_desc, status, created_by, created_date, updated_by, updated_date) values( 9, 5, 'Food Temperature', 'Food Temperature', 'A', 0, now(), 0, now());
insert into tb_module_function(function_id, module_id, function_name, function_desc, status, created_by, created_date, updated_by, updated_date) values( 10, 5, 'Food Idle Time', 'Food Idle Time', 'A', 0, now(), 0, now());
insert into tb_module_function(function_id, module_id, function_name, function_desc, status, created_by, created_date, updated_by, updated_date) values( 11, 6, 'Activity Group', 'Activity Group', 'A', 0, now(), 0, now());
insert into tb_module_function(function_id, module_id, function_name, function_desc, status, created_by, created_date, updated_by, updated_date) values( 12, 6, 'Config Activity List & Group', 'Config Activity List & Group', 'A', 0, now(), 0, now());

insert into tb_module_function(function_id, module_id, function_name, function_desc, status, created_by, created_date, updated_by, updated_date) values( 10, 5, 'Food Idle Time', 'Food Idle Time', 'A', 0, now(), 0, now());
-- industry role map
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(1, 2, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(2, 3, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(3, 4, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(4, 5, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(5, 6, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(6, 7, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(7, 8, now(), now());
insert into tb_industry_role_resp (industry_id, role_id, created_date, updated_date) values(8, 9, now(), now());

-- default roles
insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Skoruz Admin Role' , 'Skoruz Admin Role', 'SKORUZ-ADMIN', 'N','A', now(), 0);


insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Information Technology Role' , 'IT Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Manufacturing Role' , 'MF Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('FOOD Role' , 'Food Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Healthcare Role' , 'HC Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Logistics Role' , 'Logistics Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Education Institution Role' , 'EI Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Other Role' , 'Other Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_role_master(role_name, role_desc, role_type, role_modification, status, created_date, business_id) values
('Retail' , 'Retail Role', 'CLIENT-ADMIN', 'N','A', now(), 0);

insert into tb_employee_group_master(emp_group_name, emp_group_desc, business_id, status, created_date) values
('Client-Admin' , 'CLIENT-ADMIN', '0','A', now());

--activity lists
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 1, 'Food Cutting', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 2, 'Typing', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 3, 'Sitting', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 4, 'Food Cooking', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 5, 'Eating', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 6, 'Screen Time', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 7, 'Waking', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 8, 'Floor Mopping', 'A', now(), now());
insert into tb_activity_master(activity_id, activity_name, status, created_date, updated_date) values( 9, 'Talking', 'A', now(), now());


CREATE TABLE tb_employee_group_master(
    emp_group_id SERIAL  PRIMARY KEY,
    emp_group_name VARCHAR(128) NOT NULL,
    emp_group_desc VARCHAR(1000) NOT NULL,
    business_id INTEGER DEFAULT NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0,
    created_date TIMESTAMP NOT NULL,
    updated_by INTEGER DEFAULT 0,
    updated_date TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (business_id) REFERENCES tb_business_master (business_id)
);
select setval('tb_employee_group_master_emp_group_id_seq', max(emp_group_id)) from tb_employee_group_master;
ALTER SEQUENCE tb_employee_group_master_emp_group_id_seq RESTART;


insert into tb_employee_group_master(emp_group_name, emp_group_desc, business_id, status, created_date) values
('Skoruz-Admin' , 'SKORUZ-ADMIN', '0','A', now());

ALTER TABLE tb_user_master ALTER COLUMN business_id DROP NOT NULL;



-- msg need to be changed in prod

-- update tb_user_master set password = '$pbkdf2-sha256$29000$lNLaew.hFGIMYYxxjrF2rg$dt21.xzinBLZ.PB13gZ93C1NGP3Fz.w7byPb2y4b5IU' where mobile = '8838973446';

-- $pbkdf2-sha256$29000$lNLaew.hFGIMYYxxjrF2rg$dt21.xzinBLZ.PB13gZ93C1NGP3Fz.w7byPb2y4b5IU

update tb_user_master set password = '$pbkdf2-sha256$29000$KGXMWYsxRsg5x/ifU8rZWw$.tjSJeCN.56v/mvCK4Lrp45mK/t/lk.vdObekqnxTbY' where mobile = '8667883142';
$pbkdf2-sha256$29000$KGXMWYsxRsg5x/ifU8rZWw$.tjSJeCN.56v/mvCK4Lrp45mK/t/lk.vdObekqnxTbY
