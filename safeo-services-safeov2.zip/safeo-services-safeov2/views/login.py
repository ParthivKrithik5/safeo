from flask import Blueprint, jsonify, request
from sqlalchemy import and_

from app import app, logging, auth, db
from model import *
from utils import *

# Login API Services
login_blueprint = Blueprint("login", __name__)

# Industry List
@login_blueprint.route("/api/industry-list", methods=["POST"])
def industry_list():
    """Industry List"""
    logging.debug("industry_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        industries = Industry.query.filter(Industry.status == STATUS["ACTIVE"]).order_by(Industry.industry_name.asc()).all()
        industry_list = list()
        for industry in industries:
            industry_dict = dict()
            industry_dict["industry_id"] = industry.industry_id
            industry_dict["industry_name"] = industry.industry_name.title()
            industry_list.append(industry_dict)
            
        resp_dict["status"] = True
        resp_dict["object"] = industry_list
    except Exception as e:
        logging.error("industry_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("industry_list : end")
    return jsonify(resp_dict)

# Registration
@login_blueprint.route("/api/registration", methods=["POST"])
def registration():
    """User registration"""
    logging.debug("registration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get("name")
        email = request.json.get("email")
        country_id = request.json.get("country_id")
        mobile = request.json.get("mobile")
        password = request.json.get("password")
        business_name =  request.json.get("business_name")
        industry_id = request.json.get("industry_id")
        address = request.json.get("address")
        
        # Input data validation
        input_validation = ""
        if not name:
            input_validation = "Name is required"
        elif not char_validation(name):
            input_validation = "Valid Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not email_validation(email):
            input_validation = "Valid Email Id is required"
        elif not country_id:
            input_validation = "Country Code is required"
        elif not mobile:
            input_validation = "mobile is required"
        elif not mobile_no_validation(mobile):
            input_validation = "Valid Mobile no is required"
        elif not password:
            input_validation = "Password is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry_id:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"

        strong_pass_val_msg = strong_password_validation(password)
        if strong_pass_val_msg:
            input_validation = strong_pass_val_msg
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
    
        # User duplicate validation
        user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile)).first()
        if user:
                resp_dict["msg"] = "Mobile No already registered with us"
                return jsonify(resp_dict)
        user = User.query.filter(User.email == email).first()
        if user:
            resp_dict["msg"] =  "Email already registered with us"
            return jsonify(resp_dict)   

        registration = Registration(name, email, country_id, mobile, business_name, industry_id, address)
        registration.hash_password(password)
        db.session.add(registration)
        db.session.commit()

        otp_id = otp_insert(country_id,mobile)

        resp_dict["object"] = {
                        "otp_id" : otp_id,
                        "mobile": ("xxx xxx "+mobile[6:] if mobile else "")
                    }
        resp_dict ["status"] = True
    except Exception as e:
        logging.error("registration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("registration : end")
    return jsonify(resp_dict)

# Country List
@login_blueprint.route("/api/country-list", methods=["POST"])
def country_list():
    logging.debug("country_list: start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_code_list = []
        country_list = Country.query.all()
        for country in country_list:
            country_dict = dict()
            country_dict["country_id"] = country.country_id
            country_dict["country_code"] = country.country_code
            country_code_list.append(country_dict) 

        resp_dict["status"] = True
        resp_dict["object"] = country_code_list
    except Exception as e:
        logging.exception("country_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("country_list : end")
    
    return jsonify(resp_dict)

# Resend Otp
@login_blueprint.route("/api/resend-otp", methods=["POST"])
def resend_otp():
    logging.debug("resend_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get("otp_id")
        if not otp_id:
            resp_dict["msg"] = "OTP ID is required"
            return jsonify(resp_dict)
        
        otp_obj = OTP.query.get(str(otp_id))
        if not otp_obj:
            resp_dict["msg"] = "No records found!"
            return jsonify(resp_dict)

        msg = "Welcome! {} is your Safeo Verification Code to activate your account".format(otp_obj.otp_code)
        sms_insert(otp_obj.country_id,otp_obj.mobile, msg)

        resp_dict["object"] = {
            "otp_id" : otp_id, 
            "mobile": ("xxx xxx "+otp_obj.mobile[6:] if otp_obj.mobile else "")
        } 
        resp_dict["status"] = True
    except Exception as e:
        logging.exception("resend_otp : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("resend_otp : end")

    return jsonify(resp_dict)

# Verify Otp
@login_blueprint.route("/api/verify-otp", methods = ["POST"])
def verify_otp():
    """OTP Verification"""
    logging.debug("verify_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get("otp_id")
        otp_code = request.json.get("otp_code")

        if not otp_code:
            resp_dict["msg"] = "Verification code is required "
            return jsonify(resp_dict)

        otp_status = otp_verify(otp_id,otp_code)
        otp = None
        if otp_status:
            otp = OTP.query.filter(and_(OTP.otp_id == otp_id, otp_code == otp_code)).first() 
        
        if otp:
            registration = Registration.query.filter(and_(
                    Registration.country_id == otp.country_id, Registration.mobile == otp.mobile)
                ).order_by(Registration.reg_id.desc()).first()

            if not registration:
                resp_dict["msg"] = "Mobile number is not registered with us"
                return jsonify(resp_dict)
            
            if registration.mobile_verified_on == STATUS["YES"] or registration.status != STATUS["ENTRY"]:
                resp_dict["msg"] = " Your mobile number already Verified."

            registration.mobile_verified_on = datetime.datetime.now()
            registration.updated_date = datetime.datetime.now()
            registration.status = STATUS["VERIFIED"]
            db.session.commit()

            # Save Address
            business = Business(registration.business_name, registration.industry_id, registration.address)
            db.session.add(business)
            db.session.commit()

            
            # Save User
            user = User(registration.name, registration.email, registration.country_id, registration.mobile, business.business_id)
            user.password = registration.password
            db.session.add(user)
            db.session.commit()
            
            # Get Role from Industry Role Resp
            industry_role_resp = Industry_Role_Resp.query.filter(Industry_Role_Resp.industry_id == business.industry_id).first()
            logging.info(industry_role_resp.role_id)
           # Save User Group
            emp_group_id = 1
            user_group_role = User_Group_Map(user.user_id, emp_group_id)
            db.session.add(user_group_role)
            db.session.commit()
            # Save Group Role
            emp_group_id = 1
            user_group_role = Employee_Group_Role_Map( emp_group_id, industry_role_resp.role_id)
            user_group_role.user_id = user.user_id
            db.session.add(user_group_role)
            db.session.commit()

            # Send Verified msg
            sms_insert(registration.country_id ,registration.mobile, "Mobile number verified successfully")
            resp_dict = {"status":True, "msg":"Mobile number verified successfully"}
        else:
            resp_dict["msg"] = "OTP Expired"
        
    except Exception as e:
        logging.error("verify_otp : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("verify_otp : end")
    return jsonify(resp_dict)    

# Login
@login_blueprint.route("/api/login", methods=["POST"])
def login():
    """Login authentication"""
    logging.debug("login : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get("country_id")
        mobile = request.json.get("mobile")
        password = request.json.get("password")

	# Input Validation
        input_validation = ""
        if not country_id:
            input_validation = "Country code is required"
        elif not mobile:
            input_validation = "Mobile number is required"
        elif not password:
            input_validation = "Password is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile)).first()
        if not user:
            resp_dict["msg"] = "Invalid login credentials!"
            return jsonify(resp_dict)

        # User status validation
        if user.status == STATUS["DELETE"]:
            resp_dict["msg"] = "Your active is disabled, please check with admin"
            return jsonify(resp_dict)

        # User password  verification
        if not user.verify_password(password):
            resp_dict["msg"] = "Invalid login credentials!"
            return jsonify(resp_dict)

        user_role_type = get_user_role_type(user)
       
        if user_role_type in [ ROLE_TYPE["CLIENT-ADMIN"], ROLE_TYPE["SKORUZ-ADMIN"]]:
            token = login_token_insert(user.user_id)
            if not token:
                resp_dict["msg"] = "Login authentication process failed, please try again after some time"
                return jsonify(resp_dict)
            # To get the current status of SET UP
            if user_role_type == ROLE_TYPE["CLIENT-ADMIN"]:
                admin_mobile = get_admin_mobile(user)     
                current_status = configuration_status(user.business_id, admin_mobile)
            else:
                admin_mobile = user.mobile
                current_status = "ROLE"
            profile_image = (app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"]+user.profile_image if user.profile_image else app.config["SERVER_PATH"]+app.config["DEFAULT_IMAGE"])

            resp_dict["status"] = True
            resp_dict["object"] = {
                "token":token, 
                "name":user.name,
                "default_password_changed": user.default_password_changed,
                "role_type" : user_role_type,
                "email" : user.email,
                "current_status" : current_status,
                "profile_image" : profile_image
            }
        else:
            resp_dict["msg"] = "You don't have permission to access this application"
            resp_dict["status"] = True

    except Exception as e:
        logging.error("login : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("login : end")
    return jsonify(resp_dict)

# Forgot Password
@login_blueprint.route("/api/forget-password", methods=["POST"])
def forget_password():
    """Forget password - Sending a sms with new password"""
    logging.debug("forget_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get("country_id")
        mobile = request.json.get("mobile")

	# Input Validation
        input_validation = ""
        if not country_id:
            input_validation = "Country code is required"
        elif not mobile:
            input_validation = "Mobile number is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        user = User.query.filter(User.country_id == country_id, User.mobile == mobile).first()
        if user:
            new_password = get_random_password()
            user.hash_password(new_password)
            user.default_password_changed =STATUS["YES"]
            user.updated_date = datetime.datetime.now()
            db.session.commit()

            # Send sms with new password
            msg = "Your new password is {}".format(new_password)
            sms_insert(user.country_id,user.mobile, msg)
       
        resp_dict["status"] = True
        resp_dict["msg"] = "SMS sent to you with new password"
    except Exception as e:
        logging.error("forget_password : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("forget_password : end")
    return jsonify(resp_dict)

# Change Password
@login_blueprint.route("/api/change-password", methods = ["POST"])
@auth.login_required()
def change_password():
    """
    User password change service
    """
    logging.debug("change_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        old_password = request.json.get("old_password")
        new_password = request.json.get("new_password")
        confirm_password = request.json.get("confirm_password")

        input_validation = ""
        if not old_password:
            input_validation = "old password is required"

        elif not new_password:
            input_validation = "New password is required"

        elif not confirm_password:
            input_validation = "Confirm password is required"

        elif new_password != confirm_password:
            input_validation = "New Password and Confirm Password are not matched" 

        elif old_password == new_password:
            input_validation = "Old Password and New Password should not be the same"    

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        # Strong password validation
        strong_pass_val_msg = strong_password_validation(new_password)
        if strong_pass_val_msg:
            resp_dict["msg"] = strong_pass_val_msg
            return jsonify(resp_dict)

        user = User.query.get(auth.current_user().user_id)
        
        if not user.verify_password(old_password):
            resp_dict["msg"] = "Invalid old password"
            return jsonify(resp_dict)

        # Change the temp password status
        if user.default_password_changed == STATUS["YES"]:
            user.default_password_changed = STATUS["NO"]

        user.hash_password(new_password)
        user.updated_by = auth.current_user().user_id
        user.updated_date = datetime.datetime.now()
        db.session.commit()

        resp_dict["status"] = True
        resp_dict["msg"] = "Password changed successfully"    
    except Exception as e:
        logging.exception("change_password : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("change_password : end")

    return jsonify(resp_dict)

# Logout
@login_blueprint.route("/api/logout", methods = ["POST"])
@auth.login_required()
def logout():
    """
    Skoruz-Admin logout service 
    This is only for web
    """
    logging.debug("logout : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        headers = request.headers
        bearer = headers.get("Authorization") 
        token = bearer.split()[1]

        login_token = Login_Token.query.filter(
            and_(
                Login_Token.token == token, 
                Login_Token.access_mode == "WEB"
            )).first()

        if login_token:
            # De Activate login token
            login_token.status  = STATUS["DEACTIVE"]
            login_token.is_logged_in = STATUS["NO"]
            login_token.updated_date = datetime.datetime.now()
            db.session.commit()
                    
        resp_dict["status"] = True
        resp_dict["msg"] = "Logged out successfully"
    except Exception as e:
        logging.exception("logout : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error" 
    logging.debug("logout : end")
    return jsonify(resp_dict)

# Notification
@login_blueprint.route("/api/notification-list", methods = ["POST"])
@auth.login_required()
def notification_list():
    logging.debug("notification_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try: 
        login = auth.current_user()
        notification_list = []

        notifications = Notification.query.filter(and_(
            Notification.user_id == auth.current_user().user_id,
            Notification.status != STATUS["DELETE"]
        )).order_by(Notification.notification_id.desc()).limit(20).all()
            
        for notification in notifications:
            notification_dict = dict()
            notification_dict["notification_id"] = notification.notification_id
            notification_dict["notification_title"] = notification.title
            notification_dict["message"] = notification.message
            notification_dict["read_status"] = notification.read_status
            current_datetime = datetime.datetime.now()
            difference = current_datetime - notification.created_date
            if difference.days == 0:
                seconds = difference.seconds
                hours = seconds//3600
                minutes = (seconds//60)% 60
                sec = seconds%60
                if hours == 1:
                    notification_dict["duration"] = str(hours) + ' hour ago' 
                elif hours > 1:
                    notification_dict["duration"] = str(hours) + ' hours ago' 
                elif minutes == 1:
                    notification_dict["duration"] = str(minutes) + ' min ago' 
                elif minutes > 1:
                    notification_dict["duration"] = str(minutes) + ' mins ago' 
                elif seconds > 0:
                    notification_dict["duration"] = str(sec) + ' secs ago'         

            elif difference.days == 1:
                notification_dict["duration"] = str(difference.days) + ' day ago'  
            else:
                notification_dict["duration"] = str(difference.days) + ' days ago'         
            notification_list.append(notification_dict)

        resp_dict["status"]  = True  
        resp_dict["object"] = notification_list
    except Exception as e:
        logging.exception("notification_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("notification_list : end") 
    
    return jsonify(resp_dict)

@login_blueprint.route("/api/notification-info",methods = ["POST"])
@auth.login_required()
def notification_info():
    logging.debug("notification_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try: 
        notification_id = request.json.get("notification_id")
        if not notification_id:
            resp_dict["msg"] = "Notification Id is required" 
            return jsonify(resp_dict)

        notification =  Notification.query.get(notification_id)
        if notification:
            notification_dict = dict()
            notification_dict["notification_id"] = notification.notification_id
            notification_dict["message"] = notification.message

            resp_dict["status"]  = True  
            resp_dict["object"] = notification_dict

    except Exception as e:
        logging.exception("notification_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("notification_info : end") 
    
    return jsonify(resp_dict)

@login_blueprint.route("/api/notification-status-update",methods = ["POST"])
@auth.login_required()
def notification_status_update():
    logging.debug("notification_status_update : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try: 
        notification_id = request.json.get("notification_id")
        if not notification_id:
            resp_dict["msg"] = "Notification Id is required" 
            return jsonify(resp_dict)

        notification =  Notification.query.get(notification_id)
        if notification:
            notification.read_status = STATUS["YES"]
            notification.updated_date = datetime.datetime.now()
            db.session.commit()

            resp_dict["status"]  = True  
            resp_dict["msg"] = "Notification status updated"

    except Exception as e:
        logging.exception("notification_status_update : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("notification_status_update : end") 
    
    return jsonify(resp_dict)

@login_blueprint.route("/api/notification-delete",methods = ["POST"])
@auth.login_required()
def notification_delete():
    logging.debug("notification_delete : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:        
        notification_id = request.json.get("notification_id")
        if not notification_id:
            resp_dict["msg"] = "Notification Id is required" 
            return jsonify(resp_dict)

        notification =  Notification.query.get(notification_id)
        if notification:
            notification.status = STATUS["DELETE"]
            notification.updated_date = datetime.datetime.now()
            db.session.commit()

            resp_dict["msg"] = "Notification deleted successfully"
            resp_dict["status"]  = True

    except Exception as e:
        logging.exception("notification_delete : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("notification_delete : end") 
    
    return jsonify(resp_dict)
