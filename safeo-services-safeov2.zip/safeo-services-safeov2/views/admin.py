from flask import Blueprint, jsonify, request
from sqlalchemy import cast, Date, and_, func, asc

from app import app, logging, auth, db
from model import *
from utils import *

# User API Services
admin_blueprint = Blueprint("admin", __name__)


@admin_blueprint.route("/api/admin/function-maintenance-list", methods = ["POST"])
@auth.login_required()
def function_maintenance_list():
    logging.debug("function_maintenance_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        functions = Function.query.filter(Function.status == STATUS["ACTIVE"]).order_by(Function.created_date.desc()).all()
        functions_list = list()
        for function in functions:
            function_dict = dict()
            function_dict["function_id"] = function.function_id
            function_dict["function_name"] = function.function_name
            function_dict["function_desc"] = function.function_desc
            function_dict["parent_function_name"] = ""
            parent = Function.query.filter(Function.function_id == function.parent_function_id).first()
            if parent:
                function_dict["parent_function_name"] = parent.function_name
            functions_list.append(function_dict)

        resp_dict["object"] = functions_list
        resp_dict["status"] = True 
    except Exception as e:
        logging.exception("function_maintenance_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("function_maintenance_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/role-maintenance-list", methods = ["POST"])
@auth.login_required()
def role_maintenance_list():
    logging.debug("role_maintenance_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}

    try:
        role_management_list = list()

        role_industries = Industry_Role_Resp.query.all() 
        if role_industries:
            for role_industry in role_industries:
                role = Role.query.filter(and_(Role.role_id == role_industry.role_id, 
                                    Role.status == STATUS["ACTIVE"])).first()
                if role:   
                    role_dict = dict()           
                    role_dict["role_id"] = role.role_id
                    role_dict["role_name"]=role.role_name
                    role_dict["created_date"] = role.created_date.strftime("%d/%m/%Y, %I:%M %p")
                    role_dict["function_name"] = ""
                    role_management_list.append(role_dict)

        roles = Role.query.filter(
                    and_(Role.status == STATUS["ACTIVE"],
                    Role.role_type == ROLE_TYPE["CLIENT-ADMIN"])
                ).order_by(Role.created_date.desc()).all()

        for role in roles:
            role_dict = dict()
            role_functions = Role_Function_Map.query.filter(and_(
                    Role_Function_Map.role_id == role.role_id, 
                    Role_Function_Map.status == STATUS["ACTIVE"]
                )).all()
            if role_functions:
                role_dict["role_id"] = role.role_id
                role_dict["role_name"]=role.role_name
                role_dict["created_date"] = role.created_date.strftime("%d/%m/%Y, %I:%M %p")
                role_dict["function_name"] = ""
                parnet_function_name_list = list()
                for role_function in role_functions:
                    function = Function.query.filter(and_(
                        Function.function_id == role_function.function_id, Function.parent_function_id == 0, Function.status == STATUS["ACTIVE"])
                        ).first()
                    if function:    
                        parnet_function_name_list.append(function.function_name)

                role_dict["function_name"]=",".join(parnet_function_name_list)
                role_management_list.append(role_dict)

        resp_dict["status"] = True
        resp_dict["object"] = role_management_list
    except Exception as e:
        logging.exception("role_maintenance_list : exception : {}".format(e))
    logging.debug("role_maintenance_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/user-maintenance-list", methods = ["POST"])
@auth.login_required()
def user_maintenance_list():
    logging.debug("user_maintenance_list: start")
    resp_dict={"status": False, "msg": "", "object": None}

    try:
        rows=db.session.query(
                            User.user_id,
                            User.name,
                            User.email,
                            User.mobile,
                            Role.role_name,
                            User.created_date,
                            Business.business_name
                        ).filter(and_(
                            Role.status == STATUS["ACTIVE"],
                            Role.role_type == ROLE_TYPE["CLIENT-ADMIN"],
                            Role.role_id == Employee_Group_Role_Map.role_id,
                            Employee_Group_Role_Map.status == STATUS["ACTIVE"],
                            Employee_Group_Role_Map.emp_group_id == User_Group_Map.emp_group_id,
                            Employee_Group_Role_Map.user_id == User_Group_Map.user_id,
                            User_Group_Map.user_id == User.user_id,
                            User_Group_Map.status == STATUS["ACTIVE"],
                            Business.business_id == User.business_id,
                            User.status == STATUS["ACTIVE"]  
                        )).order_by(User.created_date.desc()).all()
        user_management_list=list()
        for row in rows:
            user_dict=dict()
            user_dict["user_id"]=row[0]
            user_dict["name"]=row[1]
            user_dict["email"]=row[2]
            user_dict["mobile"]=row[3]
            user_dict["role_name"]=row[4]
            user_dict["created_date"]=row[5].strftime("%d/%m/%Y, %I:%M %p")
            user_dict["business_name"]=row[6]
            user_management_list.append(user_dict)

        resp_dict["status"]=True
        resp_dict["object"]=user_management_list
    except Exception as e:
        logging.exception("user_maintenance_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_maintenance_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/create-update-function",methods=["POST"])
@auth.login_required()
def create_update_function():
    logging.info("create_update_function: Start")
    resp_dict={"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        function_name = request.json.get("function_name")
        function_desc = request.json.get("function_desc")
        parent_function_id = request.json.get("parent_function_id")
        function_url = request.json.get("function_url")
        function_approach = request.json.get("function_approach")
        icon = request.json.get("icon")

        input_validation = ""
        if not function_name:
            input_validation = "Function Name is required"
        elif not char_validation(function_name):
            input_validation = "Valid Function Name is required"
        elif not function_desc:
            input_validation = "Function Desc is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        function_approach = (FUNCTION_TYPE["ACTIONABLE"] if function_approach in FUNCTION_TYPE["ACTIONABLE"] else FUNCTION_TYPE["NONE"])
        function_icon = (icon if icon else "")

        function = Function.query.get(function_id)
        if not function:
            function = Function(function_name, function_desc, parent_function_id, function_url, function_approach, function_icon, auth.current_user().user_id)
            db.session.add(function)
            db.session.commit()

            resp_dict["status"] = True    
            resp_dict["msg"] = "Function created successfully"
        else:
            function.function_name = function_name
            function.function_desc = function_desc
            function.parent_function_id = parent_function_id
            function.function_url = function_url
            function.updated_by = auth.current_user().user_id
            function.update_date = datetime.datetime.now()
            db.session.commit()

            resp_dict["status"] = True    
            resp_dict["msg"] = "Function updated successfully"

    except Exception as e:
        logging.exception("create_update_function : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("create_update_function : end")
    return jsonify(resp_dict)   

@admin_blueprint.route("/api/admin/function-info", methods=["POST"])
@auth.login_required()
def function_info():
    logging.debug("function_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        
        function =  Function.query.filter(and_(
            Function.function_id == function_id, 
            Function.status == STATUS["ACTIVE"])
            ).first()
        
        function_dict= dict()
        function_id_list = list()
        if function:
            function_dict["function_id"] = function.function_id
            function_dict["function_name"] = function.function_name
            function_dict["function_desc"] = function.function_desc
            function_dict["function_id_list"] = list()
            function_dict["function_url"] = function.function_url
            function_dict["function_approach"] = function.function_approach
            function_dict["icon"] = ""
            function_dict["parent_function_id"] = function.parent_function_id

            function_id_list.extend([function.function_id, function.parent_function_id])
            
            parent_id = function.parent_function_id
            while parent_id:
                function = Function.query.filter(and_(Function.function_id == parent_id, Function.status == STATUS["ACTIVE"])).first()
                                                            
                if function:
                    parent_id = function.parent_function_id
                    function_id_list.append(function.parent_function_id)
                else:
                    parent_id = ""
            function_dict["function_id_list"] = function_id_list
            resp_dict["status"] = True
            resp_dict["object"] = function_dict
        
        else:
            resp_dict["status"] = True
            resp_dict["msg"] = "Function not found"
            
    except Exception as e:
        logging.exception("function_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("function_info : end")
    return jsonify(resp_dict)
    
@admin_blueprint.route("/api/admin/function-list",methods=["POST"])
@auth.login_required()
def function_list():
    logging.debug("function_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        parent_func_list, functions_list = [], []
        fun_dict, parent_dict, child_dict = {}, {}, {}
        parent_functions = Function.query.filter(Function.status == STATUS["ACTIVE"] ).order_by(Function.parent_function_id.asc()).all()
        for parent_function in parent_functions:
            parent_func_dict = dict()
            parent_func_dict["function_id"] = parent_function.function_id
            parent_func_dict["function_name"] = parent_function.function_name
            parent_func_dict["function_desc"] = parent_function.function_desc
            parent_func_dict["parent_function_id"] = parent_function.parent_function_id 
            parent_func_dict["function_list"] = list()
            parent_func_list.append(parent_func_dict)

        for func_dict in parent_func_list:
            if func_dict["parent_function_id"] == 0:
                parent_dict = {}
                parent_dict["function_id"] = func_dict["function_id"]
                parent_dict["function_name"] = func_dict["function_name"]
                parent_dict["function_desc"] = func_dict["function_desc"]
                parent_dict["function_list"] = func_dict["function_list"]
                fun_dict[func_dict["function_id"]] = parent_dict
            else:
                child_dict = {}
                child_dict["function_id"] = func_dict["function_id"]
                child_dict["function_name"] = func_dict["function_name"]
                child_dict["function_desc"] = func_dict["function_desc"]
                child_dict["function_list"] = func_dict["function_list"]
                
                if func_dict["parent_function_id"] in fun_dict:
                    p_dict = fun_dict[func_dict["parent_function_id"]]
                    lst = p_dict["function_list"]
                    lst.append(child_dict)
                    p_dict["function_list"]=lst
                    fun_dict[func_dict["parent_function_id"]]=p_dict
                else:
                    for funcdict in fun_dict.values():
                        lst = funcdict["function_list"]
                        for lst_dict in lst:
                            if func_dict["parent_function_id"]==lst_dict["function_id"]:
                                ip_dict = lst_dict
                                ilst = ip_dict["function_list"]
                                ilst.append(child_dict)
                                ip_dict["function_list"]=ilst
                            elif len(lst_dict["function_list"])>0:
                                for lst1_dict in lst_dict["function_list"]:
                                    if func_dict["parent_function_id"]==lst1_dict["function_id"]:
                                        ip1_dict = lst1_dict
                                        ilst1 = ip1_dict["function_list"]
                                        ilst1.append(child_dict)
                                        ip1_dict["function_list"]=ilst1
        
        functions_list = list(fun_dict.values())
        if not functions_list:
            resp_dict["status"]=False
            resp_dict["msg"]="No Records Found"
        else:
            resp_dict["status"]=True
            resp_dict["object"]=functions_list        
    except Exception as e:
        logging.error("function_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("function_list : End")
    return jsonify(resp_dict)    

@admin_blueprint.route("/api/admin/create-update-role",methods=["POST"])
@auth.login_required()
def create_update_role():
    logging.debug("create_update_role : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        role_id = request.json.get("role_id")
        role_name = request.json.get("role_name")
        role_desc = request.json.get("role_desc")
        function_id_list = request.json.get("function_id_list")
        
        # Input validation
        input_validation = ""
        if not role_name:
            input_validation = "Role Name is required"
        elif not char_validation(role_name):
            input_validation = "Valid Role Name is required"
        elif not role_desc:
            input_validation = "Role Desc is required"
        elif not function_id_list:
            input_validation = "Choose at least one function"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        role = Role.query.get(role_id)
        if not role:
            role = Role(role_name, role_desc, auth.current_user().user_id)
            role.role_type = ROLE_TYPE["CLIENT-ADMIN"]
            db.session.add(role)
            db.session.commit()

            for function_id in function_id_list:
                role_function = Role_Function_Map(role.role_id, function_id)
                db.session.add(role_function)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"]="Role created successfully"
        else:
            role.role_name = role_name
            role.role_desc = role_desc
            role.updated_by = auth.current_user().user_id
            role.updated_date = datetime.datetime.now()
            db.session.commit()

            # Disable Old Function
            role_function_maps = Role_Function_Map.query.filter(Role_Function_Map.role_id == role_id).all()
            for role_function_map in role_function_maps:
                role_function_map.status = STATUS["DEACTIVE"]
                role_function_map.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New Function
            for function_id in function_id_list:
                role_function = Role_Function_Map(role.role_id, function_id)
                db.session.add(role_function)
                db.session.commit()

            resp_dict["status"] = True 
            resp_dict["msg"]="Role updated successfully"
    except Exception as e:
        logging.exception("create_update_role : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("create_update_role : end")
    return jsonify(resp_dict)    

@admin_blueprint.route("/api/admin/role-info", methods=["POST"])
@auth.login_required()
def role_info():
    logging.debug("role_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        role_id = request.json.get("role_id")

        role =  Role.query.filter(and_(
            Role.role_id == role_id,
            Role.role_type == ROLE_TYPE["CLIENT-ADMIN"], 
            Role.status == STATUS["ACTIVE"])
            ).first()
        
        role_dict= dict()
        if role:
            role_dict["role_id"] = role.role_id
            role_dict["role_name"] = role.role_name
            role_dict["role_desc"] = role.role_desc
            
            function_list = list()
            role_function_maps = Role_Function_Map.query.filter(
                    and_(
                        Role_Function_Map.role_id == role.role_id,
                        Role_Function_Map.status == STATUS["ACTIVE"]
                    )).all()

            for role_function in role_function_maps:
                function = Function.query.get(role_function.function_id)

                function_list.append(function.function_id)
                
            role_dict["role_function_list"] = function_list
            
        resp_dict["status"] = True
        resp_dict["object"] = role_dict

    except Exception as e:
        logging.exception("role_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("role_info : end")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/role-list", methods=["POST"])
@auth.login_required()
def role_list():
    logging.debug("role_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        role_list = []
        roles =  Role.query.filter(and_(
            Role.role_type == ROLE_TYPE["CLIENT-ADMIN"], Role.status == STATUS["ACTIVE"])
            ).order_by(Role.created_date.desc()).all()

        for role in roles:
            role_dict = dict()
            role_dict["role_id"] = role.role_id
            role_dict["role_name"] = role.role_name
            role_list.append(role_dict)
            
        resp_dict["status"] = True
        resp_dict["object"] = role_list

    except Exception as e:
        logging.exception("role_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("role_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/create-update-user",methods=["POST"])
@auth.login_required()
def create_update_user():
    logging.debug("create_update_user : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get("name")
        email = request.json.get("email")
        country_id = request.json.get("country_id")
        mobile = request.json.get("mobile")
        business_name = request.json.get("business_name")
        user_id = request.json.get("user_id")
        role_id = request.json.get("role_id")

        input_validation = ""
        if not name:
            input_validation = "User Name is required"
        elif not char_validation(name):
            input_validation = "Valid User Name is required"
        elif not email:
            input_validation = "Email is required"
        elif not email_validation(email):
            input_validation = "Valid Email Id is required"
        elif not country_id:
            input_validation = "Country Code is required"
        elif not mobile:
            input_validation = "Mobile is required"
        elif not business_name:
            input_validation = "Business Name is required"
       
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        user = User.query.get(user_id)
        if not user:
            user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile)).first()
            if user:
                    resp_dict["msg"] = "Mobile No already registered with us"
                    return jsonify(resp_dict)
            user = User.query.filter(User.email == email).first()
            if user:
                resp_dict["msg"] =  "Email already registered with us"
                return jsonify(resp_dict)

            business = Business(business_name, None, "", auth.current_user().user_id)
            db.session.add(business)
            db.session.commit()

            user = User( name, email, country_id, mobile, business.business_id, created_by=auth.current_user().user_id)
            user.password = ""
            db.session.add(user)
            db.session.commit()

            # Save User Group
            emp_group_id = 1
            user_group_role = User_Group_Map(user.user_id, emp_group_id)
            db.session.add(user_group_role)
            db.session.commit()
            # Save Group Role
            emp_group_id = 1
            user_group_role = Employee_Group_Role_Map( emp_group_id, role_id)
            user_group_role.user_id = user.user_id
            db.session.add(user_group_role)
            db.session.commit()

            temp_password = get_random_password()
            user.hash_password(temp_password)    
            user.default_password_changed = STATUS["YES"]
            user.updated_date = datetime.datetime.now()
            db.session.commit()

            sms_insert(country_id, mobile, "Safeo application password is {}".format(temp_password))

            resp_dict["status"]=True
            resp_dict["msg"]="Added successfully"

        else:
            user.name = name
            user.email = email
            user.updated_by = auth.current_user().user_id
            user.update_date = datetime.datetime.now()
            db.session.commit()

            business = Business.query.get(user.business_id)
            if business:
                business.business_name = business_name
                business.updated_by = auth.current_user().user_id
                business.update_date = datetime.datetime.now()
                db.session.commit()

            # Disable Old User Group
            user_groups = User_Group_Map.query.filter(and_(User_Group_Map.user_id == user.user_id,
                                       User_Group_Map.status == STATUS["ACTIVE"])).all()
            for user_group in user_groups:
                user_group.status = STATUS["DEACTIVE"]
                user_group.updated_date = datetime.datetime.now()     
                db.session.commit()          
            # Disable Group Role
            role_groups = Employee_Group_Role_Map.query.filter(and_(Employee_Group_Role_Map.emp_group_id == user_groups[0].emp_group_id,
                                       Employee_Group_Role_Map.status == STATUS["ACTIVE"],
                                       Employee_Group_Role_Map.user_id == user_groups[0].user_id)).all()
            for role_group in role_groups:
                role_group.status = STATUS["DEACTIVE"]
                role_group.updated_date = datetime.datetime.now()     
                db.session.commit()     

            # Save User Group
            emp_group_id = 1
            user_group_role = User_Group_Map(user.user_id, emp_group_id)
            db.session.add(user_group_role)
            db.session.commit()
            # Save Group Role
            emp_group_id = 1
            user_group_role = Employee_Group_Role_Map( emp_group_id, role_id)
            user_group_role.user_id = user.user_id
            db.session.add(user_group_role)
            db.session.commit()

            resp_dict["status"]=True
            resp_dict["msg"]="Updated successfully"
        
    except Exception as e:
        logging.error(" create_update_user : Exception : {}".format(e))
    logging.info("create_update_user : End")
    return jsonify(resp_dict)    

@admin_blueprint.route("/api/admin/user-info",methods=["POST"])
@auth.login_required()
def user_info():
    logging.debug("user_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user_id = request.json.get("user_id")
        if not user_id:
            resp_dict["msg"] = "User Id is required"
            return jsonify(resp_dict)

        user_dict = dict()
        user=db.session.query(
                    User.user_id,
                    User.name,
                    User.email,
                    User.country_id,
                    User.mobile,
                    Employee_Group_Role_Map.role_id,
                    Business.business_name
                ).filter(and_(
                    Role.role_type == ROLE_TYPE["CLIENT-ADMIN"],
                    Role.role_id == Employee_Group_Role_Map.role_id,
                    Employee_Group_Role_Map.status == STATUS["ACTIVE"],
                    Employee_Group_Role_Map.emp_group_id == User_Group_Map.emp_group_id,
                    Employee_Group_Role_Map.user_id == User_Group_Map.user_id,
                    User_Group_Map.user_id == User.user_id,
                    User_Group_Map.status == STATUS["ACTIVE"],
                    Business.business_id == User.business_id,
                    User.status == STATUS["ACTIVE"],
                    User. user_id == user_id
                )).first()
        if user:
            user_dict["user_id"] = user[0]
            user_dict["name"] = user[1]
            user_dict["email"] = user[2]
            user_dict["country_id"] = user[3]
            user_dict["mobile"] = user[4]
            user_dict["role_id"] = user[5]  
            user_dict["business_name"] = user[6]
           
            resp_dict["status"]=True
            resp_dict["object"]=user_dict
        else:
            resp_dict["msg"]="User not found"
        
    except Exception as e:
        logging.error(" user_info : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("user_info : End")
    return jsonify(resp_dict)

@admin_blueprint.route("/api/admin/delete-user",methods=["POST"])
@auth.login_required()
def delete_user():
    logging.debug("delete_user : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user_id = request.json.get("user_id")
        if not user_id:
            resp_dict["msg"] = "User Id is required"
            return jsonify(resp_dict)

        user = User.query.get(user_id)
        if user:
            user.status = STATUS["DEACTIVE"]   
            user.updated_date = datetime.datetime.now() 
            user.updated_by = auth.current_user().user_id
            db.session.commit() 

        resp_dict["status"] = True
        resp_dict["msg"] = "User deleted successfully"
       
    except Exception as e:
        logging.error(" delete_user : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("delete_user : End")
    return jsonify(resp_dict) 
