import datetime
import pytz
from dateutil.relativedelta import relativedelta
from sqlalchemy.sql.elements import Cast
from views.user import employee_info
from flask import Blueprint, jsonify, request, send_from_directory
from sqlalchemy import cast, Date, and_, func, asc
import json
from app import app, logging, auth, db
from model import *
from utils import *

#import saferson

# Dashboard API Services
dashboard_blueprint = Blueprint("dashboard", __name__)

def get_month_day_range(date):
    last_day = date + relativedelta(day=1, months=+1, days=-1)
    first_day = date + relativedelta(day=1)
    day = int(last_day.strftime("%d")) 
    day_list = [first_day]
    for i in range(1,day):
        day_list.append(first_day + datetime.timedelta(days=i))
    return first_day, last_day, day_list

def get_week_day_range(date):
    start = date - datetime.timedelta(days=date.weekday()) - datetime.timedelta(days=1)
    end = start + datetime.timedelta(days=7)
    day_list = [start]
    for i in range(1,7):
        day_list.append(start + datetime.timedelta(days=i))
    return start, end, day_list

# Dataset  Column List
@dashboard_blueprint.route("/api/dataset-column-list", methods = ["POST"])
@auth.login_required()
def dataset_column_list():
    logging.debug("dataset_column_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        dataset_id = request.json.get("dataset_id")
        columns = Dataset_Column.query.filter(
            and_(
                Dataset_Column.status == STATUS["ACTIVE"],
                Dataset_Column.dataset_id == dataset_id)).all()

        data_list = list()
        for column in columns:
            data_dict = dict()
            data_dict["data_column_id"]=column.column_id
            data_dict["column_name"]=column.column_name
            data_list.append(data_dict)

        resp_dict["status"] = True
        resp_dict["object"] = data_list
    except Exception as e:
        logging.exception("dataset_column_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("dataset_column_list : end")
    return jsonify(resp_dict)

# Dataset List
@dashboard_blueprint.route("/api/dataset-list", methods = ["POST"])
@auth.login_required()
def dataset_list():
    logging.debug("dataset_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:        
        datasets = Dataset.query.filter(Dataset.status == STATUS["ACTIVE"]).all()
        data_list = list()
        for dataset in datasets:
            data_dict = dict()
            data_dict["dataset_id"] = dataset.dataset_id
            data_dict["dataset_name"] = dataset.dataset_name
            data_dict["created_date"] = dataset.created_date
            data_list.append(data_dict)

        resp_dict["status"] = True
        resp_dict["object"] = data_list
    except Exception as e:
        logging.exception("dataset_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("dataset_list : end")
    return jsonify(resp_dict)

#Dashboard listing
@dashboard_blueprint.route("/api/dashboard-list",methods=["POST"])
@auth.login_required()
def dashboard_list():
    logging.debug("dashboard_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        dashboards = Dashboard.query.filter(and_(Dashboard.status == STATUS["ACTIVE"], Dashboard.business_id == auth.current_user().business_id)).all()
        dashboard_list = list()
        for dashboard in dashboards:
            dashboard_dict = dict()
            dashboard_dict["dashboard_id"] = dashboard.dashboard_id
            dashboard_dict["dashboard_name"] = dashboard.dashboard_name
            dashboard_dict["created_date"] = dashboard.created_date
            
            module = Module.query.filter(and_(Module.module_id == dashboard.module_id,Module.status == STATUS["ACTIVE"])).first()
            dashboard_dict["module_name"] = module.module_name
            dashboard_list.append(dashboard_dict)

        resp_dict["status"] = True
        resp_dict["object"] = dashboard_list
              
    except Exception as e:
        logging.error("dashboard_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("dashboard_list : End")
    return jsonify(resp_dict)

# Module List
@dashboard_blueprint.route("/api/module-list", methods=["POST"])
@auth.login_required()
def module_list():
    logging.debug("module_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        modules = Module.query.filter(Module.status == STATUS["ACTIVE"]).all()
        module_list = list()
        for module in modules: 
            module_dict = dict()
            module_dict["Module_id"] = module.module_id
            module_dict["Module_name"] = module.module_name
            module_dict["status"] = False

            module_functions = Module_Function.query.filter(Module_Function.module_id == module.module_id).all()
            for module_function in module_functions:
                module_function_config = Module_Function_Config.query.filter(and_(
                    Module_Function_Config.business_id == auth.current_user().business_id,
                    Module_Function_Config.function_id == module_function.function_id,
                    Module_Function_Config.status == STATUS["ACTIVE"]
                    )).first()
                if module_function_config:
                    module_dict["status"] = True
            module_list.append(module_dict)

        resp_dict["status"] = True
        resp_dict["object"] = module_list
        
    except Exception as e:
        logging.exception("module_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("module_list : end")
    return jsonify(resp_dict)
    
#Elements listing
@dashboard_blueprint.route("/api/element-list",methods=["POST"])
@auth.login_required()
def element_list():
    logging.debug("element_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        elements = Element.query.filter(Element.status == STATUS["ACTIVE"]).all()
        element_list = list()
        for element in elements:
            element_dict = dict()
            element_dict["element_id"] = element.element_id
            element_dict["element_name"] = element.element_name
            element_list.append(element_dict)

        resp_dict["status"] = True
        resp_dict["object"] = element_list
              
    except Exception as e:
        logging.error("element_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("element_list : End")
    return jsonify(resp_dict)  

#Charts listing
@dashboard_blueprint.route("/api/chart-list",methods=["POST"])
@auth.login_required()
def chart_list():
    logging.debug("chart_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        charts = Chart.query.filter(Chart.status == STATUS["ACTIVE"]).all()
        chart_list = list()
        for chart in charts:
            chart_dict = dict()
            chart_dict["chart_id"] = chart.chart_id
            chart_dict["chart_name"] = chart.chart_name
            chart_list.append(chart_dict)

        resp_dict["status"] = True
        resp_dict["object"] = chart_list
              
    except Exception as e:
        logging.error("chart_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("chart_list : End")
    return jsonify(resp_dict)

#Delete Element and Chart
@dashboard_blueprint.route("/api/delete-element-chart",methods=["POST"])
@auth.login_required()
def delete_element_chart():
    logging.debug("delete_element_chart : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        seq_id = request.json.get("seq_id")
        dashboard_id = request.json.get("dashboard_id")
        module_id = request.json.get("module_id")
        element_id = request.json.get("element_id")
        chart_id = request.json.get("chart_id")
        
        dashboard = Dashboard.query.filter(
            and_(
                Dashboard.dashboard_id == dashboard_id, 
                Dashboard.module_id == module_id,
                Dashboard.status == STATUS["ENTRY"])).first() 
        
        if element_id:
            dashboard_element = Dashboard_Element.query.filter(
                and_(
                    Dashboard_Element.dashboard_id == dashboard.dashboard_id,
                    Dashboard_Element.element_id == element_id, 
                    Dashboard_Element.seq_id == seq_id)).first()
            
            dashboard_element.status = STATUS["DELETE"]
            dashboard_element.updated_date = datetime.datetime.now()
            db.session.commit()
            
        if chart_id:
            dashboard_chart = Dashboard_Chart.query.filter(
                and_(
                    Dashboard_Chart.dashboard_id == dashboard.dashboard_id,
                    Dashboard_Chart.chart_id == chart_id,
                    Dashboard_Chart.seq_id == seq_id)).first()
            
            dashboard_chart.status = STATUS["DELETE"]
            dashboard_chart.updated_date = datetime.datetime.now()
            db.session.commit()
            

        resp_dict["msg"] = "Deleted sucessfully"
        resp_dict["status"] = True

    except Exception as e:
        logging.error("delete_element_chart : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("delete_element_chart : End")
    return jsonify(resp_dict)

# Dashboard Info 
@dashboard_blueprint.route("/api/element-chart-info",methods=["POST"])
@auth.login_required()
def element_chart_info():
    logging.debug("element_chart_info : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        seq_id = request.json.get("seq_id")
        dashboard_id = request.json.get("dashboard_id")
        module_id = request.json.get("module_id")
        element_id = request.json.get("element_id")
        chart_id = request.json.get("chart_id")
        
        dashboard = Dashboard.query.filter(
            and_(
                Dashboard.dashboard_id == dashboard_id,
                Dashboard.module_id == module_id,
                Dashboard.status == STATUS["ENTRY"])).first() 
        info_dict = dict()
        if dashboard:
            dashboard_element = Dashboard_Element.query.filter(
                and_(
                    Dashboard_Element.dashboard_id == dashboard.dashboard_id,
                    Dashboard_Element.element_id  == element_id,
                    Dashboard_Element.status == STATUS["ACTIVE"],
                    Dashboard_Element.seq_id == seq_id)).first()
            
            dashboard_chart = Dashboard_Chart.query.filter(
                and_(
                    Dashboard_Chart.dashboard_id == dashboard.dashboard_id,
                    Dashboard_Chart.chart_id  == chart_id,
                    Dashboard_Chart.status == STATUS["ACTIVE"],
                    Dashboard_Chart.seq_id == seq_id)).first()
            if element_id:
                if element_id == 1:               
                    if dashboard_element:
                        info_dict["dashboard_id"] = dashboard_element.dashboard_id
                        info_dict["element_id"] = dashboard_element.element_id
                        info_dict["box_position"] = dashboard_element.box_position
                        info_dict["element_alignment"] = dashboard_element.element_alignment
                        info_dict["cell_height"] = dashboard_element.cell_height
                        
                        element = Dashboard_Element_Config.query.filter(
                            and_(
                                Dashboard_Element_Config.seq_id == dashboard_element.seq_id,
                                Dashboard_Element_Config.status == STATUS["ACTIVE"])).first()
                        info_dict["date_range"] = element.date_range.split(",")
                        
                elif element_id == 2:
                    if dashboard_element:        
                        info_dict["dashboard_id"] = dashboard_element.dashboard_id
                        info_dict["element_id"] = dashboard_element.element_id
                        info_dict["box_position"] = dashboard_element.box_position
                        info_dict["element_alignment"] = dashboard_element.element_alignment
                        info_dict["cell_height"] = dashboard_element.cell_height
                        info_dict["dataset_id"] = dashboard_element.dataset_id
                        
                        element = Dashboard_Element_Config.query.filter(
                            and_(
                                Dashboard_Element_Config.seq_id == dashboard_element.seq_id,
                                Dashboard_Element_Config.status == STATUS["ACTIVE"])).first()
                        info_dict["highlighter_title"] = element.highlighter_title
                        info_dict["data_column_id"] = element.data_column_id
                        info_dict["measure"] = element.measure
                        
                elif element_id == 3:
                    if dashboard_element:        
                        info_dict["dashboard_id"] = dashboard_element.dashboard_id
                        info_dict["element_id"] = dashboard_element.element_id
                        info_dict["box_position"] = dashboard_element.box_position
                        info_dict["element_alignment"] = dashboard_element.element_alignment
                        info_dict["cell_height"] = dashboard_element.cell_height
                        info_dict["dataset_id"] = dashboard_element.dataset_id
                        
                        elements = Dashboard_Element_Config_Columns.query.filter(
                            and_(
                                Dashboard_Element_Config_Columns.seq_id == dashboard_element.seq_id,
                                Dashboard_Element_Config_Columns.status == STATUS["ACTIVE"])).all()
                        info_dict["column_id_name_list"] =list()
                        for element in elements:
                            temp_dict = dict()
                            temp_dict["data_column_id"] = element.data_column_id
                            temp_dict["display_name"] = element.date_column_display_name
                            info_dict["column_id_name_list"].append(temp_dict)
            elif chart_id:
                if chart_id == 1:
                    if dashboard_chart:
                        info_dict["dashboard_id"] = dashboard_chart.dashboard_id
                        info_dict["chart_id"] = dashboard_chart.chart_id
                        info_dict["box_position"] = dashboard_chart.box_position
                        info_dict["element_alignment"] = dashboard_chart.element_alignment
                        info_dict["cell_height"] = dashboard_chart.cell_height
                        info_dict["chart_title"] = dashboard_chart.chart_title
                        info_dict["dataset_id"] = dashboard_chart.dataset_id
                        
                        chart = Dashboard_Chart_Config.query.filter(
                            and_(
                                Dashboard_Chart_Config.seq_id == dashboard_chart.seq_id,
                                Dashboard_Chart_Config.status == STATUS["ACTIVE"])).first()
                        info_dict["x_axis"] = chart.x_axis.split(",")
                        
                elif chart_id in [ 2,3,4,5,6]:# Line Chart , Bar Chart ,Gantt Chart, Scatter Plot
                    if dashboard_chart:
                        info_dict["dashboard_id"] = dashboard_chart.dashboard_id
                        info_dict["chart_id"] = dashboard_chart.chart_id
                        info_dict["box_position"] = dashboard_chart.box_position
                        info_dict["element_alignment"] = dashboard_chart.element_alignment
                        info_dict["cell_height"] = dashboard_chart.cell_height
                        info_dict["chart_title"] = dashboard_chart.chart_title
                        info_dict["dataset_id"] = dashboard_chart.dataset_id
                        
                        chart = Dashboard_Chart_Config.query.filter(
                            and_(
                                Dashboard_Chart_Config.seq_id == dashboard_chart.seq_id,
                                Dashboard_Chart_Config.status == STATUS["ACTIVE"])).first()
                        info_dict["x_axis"] = chart.x_axis.split(",")
                        info_dict["y_axis"] = chart.y_axis.split(",")
                        
        resp_dict["status"] = True
        resp_dict["object"] = info_dict
        
    except Exception as e:
        logging.error("element_chart_info : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("element_chart_info : End")
    return jsonify(resp_dict) 
        
# Dashboard Final Save
@dashboard_blueprint.route("/api/dashboard-final-save",methods=["POST"])
@auth.login_required()
def dashboard_final_save():
    logging.debug("dashboard_final_save : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        dashboard_id = request.json.get("dashboard_id")
        module_id = request.json.get("module_id")
        structure = request.json.get("structure")
        dashboard_name = request.json.get("dashboard_name")
        
        input_validation = ""
        if not dashboard_name:
            input_validation = "Dashboard name is required"  
        elif not module_id :
            input_validation = "Please select the module"
        elif not structure:
            input_validation = "Configure atleast one element or chart "

        if input_validation:
            resp_dict["msg"] = input_validation
            return resp_dict  

        dashboard = Dashboard.query.filter(
            and_(
                Dashboard.dashboard_id == dashboard_id, 
                Dashboard.business_id == auth.current_user().business_id
                )).first()
        if dashboard:
            dashboard.module_id = module_id
            dashboard.dashboard_name = dashboard_name
            dashboard.status = STATUS["ACTIVE"]
            dashboard.structure = structure
            dashboard.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict["msg"] = "Updated Sucessfully"
            resp_dict["status"] = True
            resp_dict["object"] = {"dashboard_id":dashboard.dashboard_id}
        else:
            dashboard = Dashboard(dashboard_name,auth.current_user().business_id, module_id)
            dashboard.structure = structure
            dashboard.status = STATUS["ACTIVE"]
            db.session.add(dashboard)
            db.session.commit()
            resp_dict["msg"] = "Saved Sucessfully"
            resp_dict["status"] = True
            resp_dict["object"] = {"dashboard_id":dashboard.dashboard_id}

    except Exception as e:
        logging.error("dashboard_final_save : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("dashboard_final_save : End")
    return jsonify(resp_dict)

#Dashboard info Service
@dashboard_blueprint.route("/api/dashboard-info",methods=["POST"])
@auth.login_required()
def dashboard_info():
    logging.debug("dashboard_info : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        dashboard_id = request.json.get("dashboard_id")

        dashboard = Dashboard.query.filter(and_(Dashboard.dashboard_id == dashboard_id, 
                        Dashboard.status == STATUS["ACTIVE"],
                        Dashboard.business_id == auth.current_user().business_id)).first()
        dashboard_info = dict()
        if dashboard:
            dashboard_info["dashboard_name"] = dashboard.dashboard_name
            dashboard_info["structure"] = dashboard.structure
            dashboard_info["module_id"] = dashboard.module_id
            dashboard_info["dashboard_id"] = dashboard.dashboard_id

            resp_dict["object"] = dashboard_info
            resp_dict["status"] = True
        else:
            resp_dict["status"] = True
            resp_dict["msg"] = "Deactive"
              
    except Exception as e:
        logging.error("dashboard_info : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("dashboard_info : End")
    return jsonify(resp_dict)

#Dashboard delete
@dashboard_blueprint.route("/api/delete-dashboard",methods=["POST"])
@auth.login_required()
def delete_dashboard():
    logging.debug("delete_dashboard : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        dashboard_id = request.json.get("dashboard_id")
        dashboard = Dashboard.query.filter(and_(Dashboard.dashboard_id == dashboard_id, Dashboard.status == STATUS["ACTIVE"])).first()
        
        if dashboard:
            dashboard.status = STATUS["DELETE"]
            dashboard.updated_date = datetime.datetime.now()
            dashboard.updated_by = auth.current_user().user_id
            db.session.commit()
            
            resp_dict["status"] = True
            resp_dict["msg"] = "Dashboard Deleted Successfully"
              
    except Exception as e:
        logging.error("delete_dashboard : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("delete_dashboard : End")
    return jsonify(resp_dict)

#Save Update Chart
@dashboard_blueprint.route("/api/save-update-chart",methods=["POST"])
@auth.login_required()
def save_update_chart():
    logging.debug("save_update_chart : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        seq_id = request.json.get("seq_id")
        dashboard_id = request.json.get("dashboard_id")
        dashboard_name = request.json.get("dashboard_name") #while saving the first element or chart
        module_id = request.json.get("module_id")
        chart_id = request.json.get("chart_id")
        dataset_id = request.json.get("dataset_id")
        box_position = request.json.get("box_position")
        
        chart_title = request.json.get("chart_title")
        x_axis = request.json.get("x_axis")
        y_axis = request.json.get("y_axis")
        element_alignment = request.json.get("element_alignment")
        cell_height = request.json.get("cell_height")
        
        message = ""
        object = ""
        dashboard = []

        if dashboard_id:
            dashboard = Dashboard.query.filter(and_(Dashboard.dashboard_id == dashboard_id, Dashboard.module_id == module_id)).first()
         
        if not dashboard:
            dashboard = Dashboard(dashboard_name,auth.current_user().business_id, module_id)
            dashboard.status = STATUS["ENTRY"]
            db.session.add(dashboard)
            db.session.commit()

        if chart_id:
            dashboard_chart = Dashboard_Chart.query.filter(and_(Dashboard_Chart.dashboard_id == dashboard.dashboard_id, 
                            Dashboard_Chart.chart_id == chart_id, Dashboard_Chart.status == STATUS["ACTIVE"],
                            Dashboard_Chart.seq_id == seq_id)).first()

            if chart_id == 1: # Pie Chart
                if not dashboard_chart:
                    chart = Dashboard_Chart(dashboard.dashboard_id, chart_id, box_position, chart_title, element_alignment, cell_height, dataset_id = dataset_id)
                    db.session.add(chart)
                    db.session.commit()

                    dashboard_chart_config = Dashboard_Chart_Config( chart.seq_id, ",".join(x_axis))
                    db.session.add(dashboard_chart_config)
                    db.session.commit()
                    message =  "Saved Successfully"
                    object =  {"dashboard_id" : dashboard.dashboard_id, "seq_id": chart.seq_id, "type" : "CHART"}
                
                else:
                    dashboard_chart.box_position = box_position
                    dashboard_chart.chart_title = chart_title
                    dashboard_chart.element_alignment = element_alignment
                    dashboard_chart.cell_height = cell_height
                    dashboard_chart.dataset_id = dataset_id 
                    dashboard_chart.updated_date = datetime.datetime.now()
                    db.session.commit()
                    
                    dashboard_chart_config = Dashboard_Chart_Config.query.filter(and_(Dashboard_Chart_Config.seq_id == dashboard_chart.seq_id,
                                                                        Dashboard_Chart_Config.status == STATUS["ACTIVE"])).first()
                    
                    dashboard_chart_config.x_axis = ",".join(x_axis)
                    dashboard_chart_config.updated_date = datetime.datetime.now()
                    db.session.commit()
                    
                    message =  "Updated Successfully"
                    object = {"dashboard_id" : dashboard_id, "seq_id": dashboard_chart.seq_id, "type" : "CHART"}

            if chart_id in [2,3,4,5,6]: #[2-line chart,3-bar chart,4-area chart,5-gantt chart,6-scatter plot]
                if not dashboard_chart:
                    chart = Dashboard_Chart( dashboard.dashboard_id, chart_id, box_position, chart_title, element_alignment, cell_height, dataset_id = dataset_id )
                    db.session.add(chart)
                    db.session.commit()

                    x_axis = ",".join(x_axis)
                    y_axis = ",".join(y_axis)
                    dashboard_chart_config = Dashboard_Chart_Config( chart.seq_id, x_axis, y_axis)
                    db.session.add(dashboard_chart_config)
                    db.session.commit()

                    message =  "Saved Successfully"
                    object = {"dashboard_id" : dashboard.dashboard_id, "seq_id": chart.seq_id, "type" : "CHART"}   
                        
                else:
                    dashboard_chart.box_position = box_position
                    dashboard_chart.chart_title = chart_title
                    dashboard_chart.element_alignment = element_alignment
                    dashboard_chart.cell_height = cell_height
                    dashboard_chart.dataset_id = dataset_id 
                    dashboard_chart.updated_date = datetime.datetime.now()
                    db.session.commit()
                    
                    dashboard_chart_config = Dashboard_Chart_Config.query.filter(and_(Dashboard_Chart_Config.seq_id == dashboard_chart.seq_id,
                                                                        Dashboard_Chart_Config.status == STATUS["ACTIVE"])).first()
                    
                    dashboard_chart_config.x_axis = ",".join(x_axis)
                    dashboard_chart_config.y_axis = ",".join(y_axis)
                    dashboard_chart_config.updated_date = datetime.datetime.now()
                    db.session.commit()      

                    message =  "Updated Successfully"
                    object =  {"dashboard_id" : dashboard_id, "seq_id": dashboard_chart.seq_id, "type" : "CHART"}

        resp_dict["status"] = True
        resp_dict["msg"] = message
        resp_dict["object"] = object
    except Exception as e:
        logging.error("save_update_chart : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("save_update_chart : End")
    return jsonify(resp_dict) 
    

#Save Update Element
@dashboard_blueprint.route("/api/save-update-element",methods=["POST"])
@auth.login_required()
def save_update_element():
    logging.debug("save_update_element : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        seq_id = request.json.get("seq_id")
        dashboard_id = request.json.get("dashboard_id") 
        dashboard_name = request.json.get("dashboard_name")   #while saving the first element or chart
        module_id = request.json.get("module_id")
        element_id = request.json.get("element_id")
        dataset_id = request.json.get("dataset_id")
        box_position = request.json.get("box_position")

        date_range = request.json.get("date_range")

        highlighter_title = request.json.get("highlighter_title")
        data_column_id = request.json.get("data_column_id")
        measure = request.json.get("measure")

        column_id_name_list = request.json.get("column_id_name_list")

        element_alignment = request.json.get("element_alignment")
        cell_height = request.json.get("cell_height")
        
        message = ""
        object = ""
        dashboard = []

        if dashboard_id:
            dashboard = Dashboard.query.filter(and_(Dashboard.dashboard_id == dashboard_id, Dashboard.module_id == module_id)).first()
            dashboard.dashboard_name = dashboard_name
            db.session.commit()
         
        if not dashboard:
            dashboard = Dashboard(dashboard_name, auth.current_user().business_id, module_id)
            dashboard.status = STATUS["ENTRY"]
            db.session.add(dashboard)
            db.session.commit()
            
        if element_id:
            dashboard_element = Dashboard_Element.query.filter(and_(Dashboard_Element.dashboard_id == dashboard.dashboard_id,
                                                                Dashboard_Element.element_id  == element_id,Dashboard_Element.status == STATUS["ACTIVE"],
                                                                Dashboard_Element.seq_id == seq_id )).first()
            if element_id == 1:      # Date Set Element   
                if not dashboard_element:

                    element = Dashboard_Element( dashboard.dashboard_id, element_id, box_position, element_alignment, cell_height )
                    db.session.add(element)
                    db.session.commit()

                    date_range = ",".join(date_range)
                    dashboard_element_config = Dashboard_Element_Config( element.seq_id, date_range = date_range)
                    db.session.add(dashboard_element_config)
                    db.session.commit()

                    message =  "Saved Successfully"
                    object = {"dashboard_id" :dashboard.dashboard_id , "seq_id": element.seq_id, "type" : "ELEMENT"  }
                else:
                    dashboard_element.box_position = box_position
                    dashboard_element.element_alignment = element_alignment
                    dashboard_element.cell_height = cell_height
                    dashboard_element.updated_date = datetime.datetime.datetime.now()
                    db.session.commit()
                    
                    dashboard_element_config = Dashboard_Element_Config.query.filter(and_(Dashboard_Element_Config.seq_id == dashboard_element.seq_id
                                                                                     ,Dashboard_Element_Config.status == STATUS["ACTIVE"])).first()
                    dashboard_element_config.date_range = ",".join(date_range)
                    dashboard_element_config.updated_date = datetime.datetime.datetime.now()
                    db.session.commit()

                    message =  "Updated Successfully"
                    object =  {"dashboard_id" :dashboard_id , "seq_id": dashboard_element.seq_id, "type" : "ELEMENT"}
                    
            elif element_id == 2:     # Highlighter Box Element  
                if not dashboard_element:
                    element = Dashboard_Element( dashboard.dashboard_id, element_id, box_position, element_alignment, cell_height, dataset_id = dataset_id )
                    db.session.add(element)
                    db.session.commit()

                    dashboard_element_config = Dashboard_Element_Config(element.seq_id,  
                                                            highlighter_title= highlighter_title, data_column_id=data_column_id, measure=measure)
                    db.session.add(dashboard_element_config)
                    db.session.commit()

                    message =  "Saved Successfully"
                    object = {"dashboard_id" :dashboard.dashboard_id ,"seq_id": element.seq_id, "type" : "ELEMENT"}
                    
                else:
                    dashboard_element.box_position = box_position
                    dashboard_element.dataset_id = dataset_id
                    dashboard_element.element_alignment = element_alignment
                    dashboard_element.cell_height = cell_height
                    dashboard_element.updated_date = datetime.datetime.now()
                    db.session.commit()
                    
                    dashboard_element_config = Dashboard_Element_Config.query.filter(and_(Dashboard_Element_Config.seq_id == dashboard_element.seq_id
                                                 ,Dashboard_Element_Config.status == STATUS["ACTIVE"])).first()
                    
                    dashboard_element_config.highlighter_title = highlighter_title
                    dashboard_element_config.data_column_id = data_column_id
                    dashboard_element_config.measure = measure
                    dashboard_element_config.updated_date = datetime.datetime.now()
                    db.session.commit()

                    message =  "Updated Successfully"
                    object =  {"dashboard_id" :dashboard_id , "seq_id": dashboard_element.seq_id, "type" : "ELEMENT"}

            elif element_id == 3:  # Table List Element  
                if not dashboard_element:
                    element = Dashboard_Element( dashboard.dashboard_id, element_id, box_position, element_alignment, cell_height, dataset_id = dataset_id )
                    db.session.add(element)
                    db.session.commit()

                    for column_dict in column_id_name_list:
                        dashboard_column_config = Dashboard_Element_Config_Columns( element.seq_id, column_dict["data_column_id"], column_dict["display_name"])
                        db.session.add(dashboard_column_config)
                        db.session.commit()

                    message =  "Saved Successfully"
                    object = {"dashboard_id" :dashboard.dashboard_id ,"seq_id": element.seq_id, "type" : "ELEMENT"}
                    
                else:
                    dashboard_element.box_position = box_position
                    dashboard_element.dataset_id = dataset_id
                    dashboard_element.element_alignment = element_alignment
                    dashboard_element.cell_height = cell_height
                    dashboard_element.updated_date = datetime.datetime.now()
                    db.session.commit()
                    
                    dashboard_element_config_columns = Dashboard_Element_Config_Columns.query.filter(and_(Dashboard_Element_Config_Columns.seq_id == dashboard_element.seq_id
                                                 ,Dashboard_Element_Config.status == STATUS["ACTIVE"])).all()
                    
                    for row in dashboard_element_config_columns:
                        row.status = STATUS["DEACTIVE"]
                        row.updated_date = datetime.datetime.now()
                        db.session.commit()
                    
                    for column_dict in column_id_name_list:
                        dashboard_column_config = Dashboard_Element_Config_Columns( dashboard_element.seq_id, column_dict["data_column_id"], column_dict["display_name"])
                        db.session.add(dashboard_column_config)
                        db.session.commit()

                    message =  "Updated Successfully"
                    object =   {"dashboard_id" :dashboard_id , "seq_id": dashboard_element.seq_id, "type" : "ELEMENT"}

        resp_dict["msg"] = message
        resp_dict["object"] = object   
        resp_dict["status"] = True         

    except Exception as e:
        logging.error("save_update_element : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("save_update_element : end")
    return jsonify(resp_dict)    

    # Today Week Mont Now
@dashboard_blueprint.route("/api/preview",methods=["POST"])
@auth.login_required()
def preview():
    logging.debug("preview : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        dashboard_id = request.json.get("dashboard_id")

        dashboard = Dashboard.query.filter(and_(Dashboard.dashboard_id == dashboard_id, 
                        Dashboard.status == STATUS["ACTIVE"],
                        Dashboard.business_id == auth.current_user().business_id)).first()
        dashboard_info = dict()
        if dashboard:
            dashboard_info["dashboard_name"] = dashboard.dashboard_name
            dashboard_info["structure"] = dashboard.structure
            dashboard_info["module_id"] = dashboard.module_id
            dashboard_info["dashboard_id"] = dashboard.dashboard_id

            resp_dict["object"] = dashboard_info
            resp_dict["status"] = True
        else:
            resp_dict["status"] = True
            resp_dict["msg"] = "Deactive"
          
    except Exception as e:
        logging.error("preview : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("preview : end")
    return jsonify(resp_dict)        

#Gives the Count for the highlighter element
@dashboard_blueprint.route("/api/highlighter-box-element",methods=["POST"])
@auth.login_required()
def highlighter_box_element():
    logging.debug("highlighter_box_element : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        highlighter_title = request.json.get("highlighter_title")
        dataset_id = request.json.get("dataset_id")
        data_column_id = request.json.get("data_column_id")
        time_range = request.json.get("time_range")
        info_dict = dict()
        count = 0
        dataset_columns = Dataset_Column.query.filter(
            and_(
                Dataset_Column.dataset_id == dataset_id,
                Dataset_Column.status == STATUS["ACTIVE"])).all()
        if dataset_columns:
            if data_column_id in  ["13", 13]: # Inside Building
                logging.info(data_column_id)
                count = touchless_details(13)
                
            elif data_column_id in ["14", 14]: # outside Building
                count = touchless_details(14)

            elif data_column_id in ["15", 15]: # total Building
                count = touchless_details(15)

            elif data_column_id in [ "9", 9]: # Absence count
                count =   all_employee_info( time_range, 9) 

            elif data_column_id in  ["10", 10]: # Schedule Violation count
                count =  all_employee_info( time_range, 10)  

            elif data_column_id in ["11" ,11]: # Break Violation count
                count =   all_employee_info( time_range, 11)  

            elif data_column_id in ["12",12]: # Unauthorized Violation count
                count =  all_employee_info( time_range, 12)      

        resp_dict["status"] = True
        resp_dict["object"] = count
    except Exception as e:
        logging.error("highlighter_box_element : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("highlighter_box_element : End")
    return jsonify(resp_dict)        

#Table list element:
@dashboard_blueprint.route("/api/table-list-element",methods=["POST"])
@auth.login_required()
def table_list_element():
    logging.debug("table_list_element : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:

        column_id_name_list = request.json.get("column_id_name_list")
        dataset_id = request.json.get("dataset_id")
        time_range = request.json.get("time_range")

        display_list = list()
        user_list = list()  
        column_ids = list()
        column_display_name = list()

        for column in column_id_name_list:
            column_ids.append(column["dataset_column_id"] )       
            column_display_name.append(column["display_name"])

        dataset_columns = Dataset_Column.query.filter(
            and_(
                Dataset_Column.dataset_id == dataset_id,
                Dataset_Column.status == STATUS["ACTIVE"])).all()
        user_id_input = 3
        users = User.query.filter(
            and_(
                User.business_id == auth.current_user().business_id,
                User.is_employee == STATUS["YES"],
                User.status == STATUS["ACTIVE"])).all()      
  
        flag = 0     
        disp_dict = dict()       
        for user in users:  
            user_dict =dict()                                                                                                                 
            for column in dataset_columns:
               
                for column_id , display_column_name in zip(column_ids, column_display_name):
                    if column.column_id == column_id:
                        db_attribute = column.column_name
                        if user_id_input not in column_ids:
                            user_dict["user_id"] = user.user_id
                            if flag == 0:
                                disp_dict["user_id"] = ""

                        if column_id not in ["18", 18, "13", 13, "14", 14, "15", 15, "9", 9, "10", 10, "11", 11, "12", 12, "16", 16]:
                            user_dict["{}".format(column.column_name)] = getattr(user, db_attribute)
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name


                        if column_id in  [7, "7"]:#Profile Image
                            user_dict["{}".format(column.column_name)] =  (app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"]+getattr(user, db_attribute) if getattr(user, db_attribute) else app.config["SERVER_PATH"]+app.config["DEFAULT_IMAGE"]) 
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in ["18", 18]:#Status -- checkin checkout
                            user_dict["{}".format(column.column_name)]  =(" -- 00:00 " if time_range == "NOW" else touchless_details( user_mobile = user.mobile))
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in  ["13", 13]: # Inside Building
                            user_dict["{}".format(column.column_name)]  = touchless_details(13)
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in ["14", 14]: # outside Building
                            user_dict["{}".format(column.column_name)]  = touchless_details(14)
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in ["15", 15]: # total Building
                            user_dict["{}".format(column.column_name)]   = touchless_details(15)
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in [ "9", 9]: # Absence count
                            user_dict["{}".format(column.column_name)]  =    (0 if time_range == "NOW" else single_employee_info( user_id = user.user_id, time_range = time_range, x_axis = 9) )
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in  ["10", 10]: # Schedule Violation count
                            user_dict["{}".format(column.column_name)]   =  (0 if time_range == "NOW" else single_employee_info( user_id = user.user_id, time_range = time_range, x_axis = 10))
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in ["11" ,11]: # Break Violation count
                            user_dict["{}".format(column.column_name)]  =  (0 if time_range == "NOW" else single_employee_info( user_id = user.user_id, time_range = time_range, x_axis = 11))
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

                        elif column_id in ["12",12]: # Unauthorized Violation count
                            user_dict["{}".format(column.column_name)]  = (0 if time_range == "NOW" else single_employee_info( user_id = user.user_id, time_range = time_range, x_axis = 12))          
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name
                        elif column_id in ["16",16]: # No of Working Hours
                            user_dict["{}".format(column.column_name)]  =  ("0" if time_range == "NOW" else str(single_employee_info( user_id = user.user_id, time_range = time_range, x_axis = 16) ) )   + " hrs"
                            if flag == 0:
                                disp_dict["{}".format(column.column_name)] = display_column_name

            user_list.append(user_dict)  
            flag += 1
        # display_list =[ {"field" : i} for i in column_display_name ] 
        resp_dict["object"] = {"display_name" : disp_dict,
                                            "table_data": user_list}                                
        resp_dict["status"] = True

    except Exception as e:
        logging.error("table_list_element : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("table_list_element : End")
    return jsonify(resp_dict)        

#Pie Chart
@dashboard_blueprint.route("/api/pie-chart",methods=["POST"])
@auth.login_required()
def pie_chart():
    logging.debug("pie_chart : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        x_axis_list = request.json.get("x_axis")
        dataset_id = request.json.get("dataset_id")
        time_range = request.json.get("time_range")

        info_list = list()
        dataset_columns = Dataset_Column.query.filter(
            and_(
                Dataset_Column.dataset_id == dataset_id,
                Dataset_Column.status == STATUS["ACTIVE"])).all()
        if dataset_columns:
            for x_axis in x_axis_list:
                if x_axis in  ["13", 13]: #Inside Building count
                    info_list.append({"title":"Inside Building" , "count":  touchless_details(13)  })

                elif x_axis in ["14", 14]: #Outside Building count
                    info_list.append({"title": "Outside Building" , "count" :  touchless_details(14)  })

                elif x_axis in ["15", 15]: # Total employee count
                    info_list.append({"title" : "Total Employee" ,  "count" : touchless_details(15)  })

                elif x_axis in ["9", 9]: # Absence count
                    info_list.append({"title" : "Absence" , "count" : all_employee_info( time_range, 9)  })

                elif x_axis in ["10", 10]: # Schedule Violation count
                    info_list.append({"title" : "Schedule Violation" , "count" : all_employee_info( time_range, 10)  })

                elif x_axis in ["11", 11]: # Break Violation count
                    info_list.append({"title" : "Break Violation" , "count":  all_employee_info( time_range, 11)  })

                elif x_axis in ["12", 12]: # Unauthorized Violation count
                    info_list.append({"title" : "Unauthorized Violation" , "count" :  all_employee_info( time_range, 12)  })

        resp_dict["object"] = info_list
        resp_dict["status"] = True

    except Exception as e:
        logging.error("pie_chart : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("pie_chart : End")
    return jsonify(resp_dict)      

#Line Chart
@dashboard_blueprint.route("/api/line-chart",methods=["POST"])
@auth.login_required()
def line_chart():
    logging.debug("line_chart : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        x_axis = request.json.get("x_axis")
        y_axis_list = request.json.get("y_axis")
        time_range =  request.json.get("time_range")
        user_id = request.json.get("user_id")
        dataset_id = request.json.get("dataset_id")

        info_list = list()
        dataset_columns = Dataset_Column.query.filter(
            and_(
                Dataset_Column.dataset_id == dataset_id,
                Dataset_Column.status == STATUS["ACTIVE"])).all()
        if dataset_columns:
            for y_axis in y_axis_list:
                
                #   x_axis TIME
                if y_axis in ["9", 9]: # Absence count
                    if user_id:
                        info_list.append({"title" : "Absence" , "datas": single_employee_info(user_id, time_range, x_axis,  9)  })
                    else:    
                        info_list.append({"title" : "Absence" , "datas":   all_employee_info( time_range, x_axis,  9)  })

                elif y_axis in ["10", 10]: # Schedule Violation count
                    if user_id:
                        info_list.append({"title" : "Schedule Violation" , "datas":   single_employee_info(user_id, time_range, x_axis,  10)  })
                    else:    
                        info_list.append({"title" : "Schedule Violation" , "datas":   all_employee_info( time_range, x_axis, 10)  })

                elif y_axis in ["11", 11]: # Break Violation count
                    if user_id:
                        info_list.append({"title" : "Break Violation" , "datas":   single_employee_info(user_id, time_range, x_axis,  11)  })
                    else:    
                        info_list.append({"title" : "Break Violation" , "datas":   all_employee_info( time_range, x_axis, 11)  })

                elif y_axis  in ["12", 12]: # Unauthorized Violation count
                    if user_id:
                        info_list.append({"title" : "Unauthorized Violation" , "datas":  single_employee_info(user_id, time_range, x_axis,  12)  })
                    else:    
                        info_list.append({"title" : "Unauthorized Violation" , "datas":  all_employee_info( time_range, x_axis, 12)  })

        resp_dict["object"] = info_list
        resp_dict["status"] = True

    except Exception as e:
        logging.error("line_chart : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("line_chart : End")
    return jsonify(resp_dict)        

# no of people inside ouside the building and total no of employee
def touchless_details(dataset_column_id = 0, user_mobile = 0):
    logging.debug("touchless_details : Start")
    try:
        # Only for Now
        inside_building = 0
        outside_building = 0
        total_employees = 0

        today = datetime.datetime.now(pytz.utc)
        tomorrow = today + datetime.timedelta(days=1)
        first = today.date()
        second = tomorrow.date()
        count = 0
        #  Total employee in an organisation
        employees = User.query.filter(and_(
                            User.business_id == auth.current_user().business_id,
                            User.status == STATUS["ACTIVE"],
                            User.is_employee == STATUS["YES"],
                            User.mobile != "UNKNOWN")).all()                  
        
        for employee in employees:  
            total_employees += 1                                        
            touchless = Touchless_Attendance.query.filter(and_(
                                    Touchless_Attendance.employee_mobile == employee.mobile,
                                    Touchless_Attendance.time  >= first,
                                    Touchless_Attendance.time < second

                                )
                                ).order_by(Touchless_Attendance.time.desc()).first()
            if not touchless:
                continue            
            if touchless.attendance_status == STATUS["IN"]:
                inside_building += 1
            elif touchless.attendance_status == STATUS["OUT"]:   
                outside_building += 1
            
        if dataset_column_id ==13: # inside_building
            count =  str(inside_building)
        elif dataset_column_id ==14: # outside_building
            count =  str(outside_building)
        elif dataset_column_id ==15: # total_employee
            count =  str(total_employees)
        if not count:      
            count =  {"inside_building" : str(inside_building),
                                 "outside_building" : str(outside_building), 
                                  "total_employees" : str(total_employees)}
        if user_mobile:
            touchless = Touchless_Attendance.query.filter(and_(
                                    Touchless_Attendance.employee_mobile == user_mobile,
                                    Touchless_Attendance.time  >= first,
                                    Touchless_Attendance.time < second
                                )
                                ).order_by(Touchless_Attendance.time.desc()).first()
            count = "" 
            print("user_mobile" , user_mobile)                   
            if touchless:
                if touchless.attendance_status   == "IN":
                    count = "IN " +  touchless.time.strftime("%I:%M:%S %p")   
                elif touchless.attendance_status   == "OUT":  
                    count = "OUT " +  touchless.time.strftime("%I:%M:%S %p")   
    except Exception as e:
        logging.error("touchless_details : exception : {}".format(e))
    logging.debug("touchless_details : end")
    return count

# gives details of single employee
def single_employee_info( user_id, time_range, x_axis = 0, y_axis = 0):
    logging.debug("single_employee_info : Start")
    try:
        info_dict = dict()
        if time_range in ["NOW", "TODAY"]:
            today = datetime.datetime.now(pytz.utc)
            tomorrow = today + datetime.timedelta(days=1)
            first = today.date()
            second = tomorrow.date()
            import pandas
            day_list = pandas.date_range(first, second, freq='H')
        elif time_range == "MONTH":
            today = datetime.datetime.now(pytz.utc)
            first_day, last_day, day_list = get_month_day_range(today)
            first = first_day.date()
            second = last_day.date()  
        elif time_range == "WEEK" :
            today = datetime.datetime.now(pytz.utc)
            first_day, last_day, day_list = get_week_day_range(today)
            first = first_day.date()
            second = last_day.date()    


        user = User.query.filter(and_(User.user_id == user_id,
                                    User.business_id == auth.current_user().business_id,
                                    User.status == STATUS["ACTIVE"])).first()
        if user :     
            if time_range == "NOW":
                info_dict = now_single_attendance_functions(  time_range, user.mobile, x_axis, y_axis)
            else:
                info_dict = single_attendance_functions(first, second, user.mobile, time_range, x_axis, y_axis, day_list)      
    except Exception as e:
        logging.error("single_employee_info : exception : {}".format(e))
    logging.debug("single_employee_info : end")
    return info_dict

# return the list of dict contains x and y plots for single employee
def single_attendance_functions(  first, second, user_mobile, time_range, x_axis = 0, y_axis = 0, day_list = []):
    logging.debug("single_attendance_functions : Start")
    try:
        x_y_axis_list = list()
        attendance_functions_dict = dict()
        count = 0
        if y_axis == 9:  # Absence
            absentize = Absence.query.filter(
                                        and_(
                                            Absence.employee_mobile == user_mobile,
                                            Cast(Absence.time, Date)  >= first,
                                            Cast(Absence.time, Date) < second,
                                            Absence.is_absent == STATUS["YES"]
                                        )
                                        ).all()

            if y_axis == 9:  # Absence
                for absent in absentize:  
                    absence_dict = dict()    
                    absence_dict["x_axis"] = absent.time
                    absence_dict["y_axis"] = absent.is_absent
                    x_y_axis_list.append(absence_dict) 

        # Unauthorized Access Vioaltion
        elif x_axis == 12 or y_axis == 12 :
            if x_axis and y_axis == 12 and time_range in ["MONTH", "WEEK"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    unauthorizes = Unauthorized.query.filter(
                                and_(
                                    Unauthorized.employee_mobile == user_mobile,
                                    Cast(Unauthorized.time, Date)  >= first_day,
                                    Cast(Unauthorized.time, Date) < second_day,
                                    Unauthorized.is_unauthorized == STATUS["YES"]
                                )
                                ).all()
                    second_day = second_day + datetime.timedelta(days=1)
                    if unauthorizes:
                        count = 0
                        for unauthorize in unauthorizes:  
                            count += 1
                        unauthorized_dict = dict()    
                        unauthorized_dict["x_axis"] = first_day.strftime("%d-%b")
                        unauthorized_dict["y_axis"] = count
                        x_y_axis_list.append(unauthorized_dict)   

            elif x_axis and y_axis == 12 and time_range in ["TODAY"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    unauthorizes = Unauthorized.query.filter(
                                and_(
                                    Unauthorized.employee_mobile == user_mobile,
                                    Unauthorized.time >= first_day,
                                    Unauthorized.time < second_day,
                                    Unauthorized.is_unauthorized == STATUS["YES"]
                                )
                                ).all()
                    second_day = second_day + datetime.timedelta(hours=1)
                    if unauthorizes:
                        count = 0
                        for unauthorize in unauthorizes:  
                            count += 1
                        unauthorized_dict = dict()    
                        unauthorized_dict["x_axis"] = first_day.strftime("%I:%M %p")
                        unauthorized_dict["y_axis"] = count
                        x_y_axis_list.append(unauthorized_dict)               

            elif x_axis == 12 and not y_axis:
                unauthorizes = Unauthorized.query.filter(
                                and_(
                                    Unauthorized.employee_mobile == user_mobile,
                                    Cast(Unauthorized.time, Date)  >= first,
                                    Cast(Unauthorized.time, Date) < second,
                                    Unauthorized.is_unauthorized == STATUS["YES"]
                                )
                                ).all()
                for unauthorize in unauthorizes: 
                    count += 1                

        # Schedule Mismatch Violation: 
        elif x_axis == 10 or y_axis == 10:
            if x_axis and y_axis == 10 and time_range in [ "MONTH", "WEEK"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    schedule_mismatches = Schedule_Mismatch.query.filter(
                                and_(
                                    Schedule_Mismatch.employee_mobile == user_mobile,
                                    Cast(Schedule_Mismatch.time, Date)  >= first_day,
                                    Cast(Schedule_Mismatch.time, Date) < second_day,
                                    Schedule_Mismatch.is_violation == STATUS["YES"]
                                )
                                ).all()
                    second_day = second_day + datetime.timedelta(days=1)  
                    if schedule_mismatches:
                        count = 0
                        for schedule_mismatch in schedule_mismatches:  
                            count +=1
                        schedule_mismatches_dict = dict()    
                        schedule_mismatches_dict["x_axis"] = first_day.strftime("%d-%b")
                        schedule_mismatches_dict["y_axis"] = count
                        x_y_axis_list.append(schedule_mismatches_dict)    

            elif x_axis and y_axis == 10 and time_range in [ "TODAY"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    print("came here")
                    schedule_mismatches =  Schedule_Mismatch.query.filter(
                                and_(
                                    Schedule_Mismatch.employee_mobile == user_mobile,
                                    Schedule_Mismatch.time  >= first_day,
                                    Schedule_Mismatch.time < second_day,
                                    Schedule_Mismatch.is_violation == STATUS["YES"]
                                )
                                ).all()
                    second_day = second_day + datetime.timedelta(hours=1)  
                    print("second_day", second_day)
                    if schedule_mismatches:
                        count = 0
                        for schedule_mismatch in schedule_mismatches:  
                            count +=1
                        schedule_mismatches_dict = dict()    
                        schedule_mismatches_dict["x_axis"] = first_day.strftime("%I:%M %p")
                        schedule_mismatches_dict["y_axis"] = count
                        x_y_axis_list.append(schedule_mismatches_dict)                 

            elif x_axis == 10 and not y_axis:
                schedule_mismatches = Schedule_Mismatch.query.filter(
                                and_(
                                    Schedule_Mismatch.employee_mobile == user_mobile,
                                    Cast(Schedule_Mismatch.time, Date)  >= first,
                                    Cast(Schedule_Mismatch.time, Date) < second,
                                    Schedule_Mismatch.is_violation == STATUS["YES"]
                                )
                                ).all()
                for schedule_mismatch in schedule_mismatches:  
                    count += 1                     
  
        # Break time Violation:
        elif x_axis == 11 or y_axis == 11 :
            if x_axis and y_axis == 11 and time_range in ["MONTH", "WEEK"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    break_times = Break_Time.query.filter(
                            and_(
                                Break_Time.employee_mobile == user_mobile,
                                Cast(Break_Time.time, Date)  >= first_day,
                                Cast(Break_Time.time, Date) < second_day,
                                Break_Time.is_violation == STATUS["YES"]
                            )
                            ).all()
                    second_day = second_day + datetime.timedelta(days=1)  
                    if  break_times:   
                        count = 0 
                        for break_time in break_times:  
                            count += 1
                        break_times_dict = dict()    
                        break_times_dict["x_axis"] = first_day.strftime("%d-%b")
                        break_times_dict["y_axis"] = count
                        x_y_axis_list.append(break_times_dict)  

            elif x_axis and y_axis == 11 and time_range in ["TODAY"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    break_times = Break_Time.query.filter(
                            and_(
                                Break_Time.employee_mobile == user_mobile,
                                Break_Time.time  >= first_day,
                                Break_Time.time < second_day,
                                Break_Time.is_violation == STATUS["YES"]
                            )
                            ).all()
                    second_day = second_day + datetime.timedelta(hours=1)  
                    if  break_times:   
                        count = 0 
                        for break_time in break_times:  
                            count += 1
                        break_times_dict = dict()    
                        break_times_dict["x_axis"] = first_day.strftime("%I:%M %p")
                        break_times_dict["y_axis"] = count
                        x_y_axis_list.append(break_times_dict)              
            elif x_axis == 11 and not y_axis:
                break_times = Break_Time.query.filter(
                            and_(
                                Break_Time.employee_mobile == user_mobile,
                                Cast(Break_Time.time, Date)  >= first,
                                Cast(Break_Time.time, Date) < second,
                                Break_Time.is_violation == STATUS["YES"]
                            )
                            ).all()
                for break_time in break_times:   
                    count += 1                

        # if y_axis == 16:  # no of working hours  
        #     touchlesses = Touchless_Attendance.query.filter(and_(
        #                                 Touchless_Attendance.employee_mobile == user_mobile,
        #                                 Touchless_Attendance.time  >= first,
        #                                 Touchless_Attendance.time < second,
        #                                 Touchless_Attendance.attendance_status == STATUS["OUT"]
        #                                 )).order_by(Touchless_Attendance.time.asc()).all()  

        #     if y_axis == 16:                                          
        #         if touchlesses:
        #             for touchless in touchlesses:
        #                 touchless_dict = dict()
        #                 touchless_dict["y_axis"] = (int(touchless.num_working_secs)//60)//60
        #                 touchless_dict["x_axis"] = touchless.time
        #                 x_y_axis_list.append(touchless_dict)

        # No of working hours:
        elif x_axis == 16 or y_axis == 16 :
            if x_axis and y_axis == 16 and time_range in ["MONTH", "WEEK"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    touchlesses = Touchless_Attendance.query.filter(and_(
                                        Touchless_Attendance.employee_mobile == user_mobile,
                                        Touchless_Attendance.time  >= first_day,
                                        Touchless_Attendance.time < second_day,
                                        Touchless_Attendance.attendance_status == STATUS["OUT"]
                                        )).order_by(Touchless_Attendance.time.asc()).all()  
                    second_day = second_day + datetime.timedelta(days=1)  
                    if touchlesses:
                        touchless_dict = dict()
                        for touchless in touchlesses:
                            touchless_dict["y_axis"] += (int(touchless.num_working_secs)//60)//60
                            touchless_dict["x_axis"] = first_day.strftime("%d-%b")
                            x_y_axis_list.append(touchless_dict) 

            elif x_axis and y_axis == 16 and time_range in ["TODAY"]:
                second_day = day_list[1]
                for first_day in day_list[:-2]:
                    touchlesses = Touchless_Attendance.query.filter(and_(
                                        Touchless_Attendance.employee_mobile == user_mobile,
                                        Touchless_Attendance.time  >= first_day,
                                        Touchless_Attendance.time < second_day,
                                        Touchless_Attendance.attendance_status == STATUS["OUT"]
                                        )).order_by(Touchless_Attendance.time.asc()).all()  
                    second_day = second_day + datetime.timedelta(hours=1)  
                    if touchlesses:
                        touchless_dict = dict()
                        for touchless in touchlesses:
                            touchless_dict["y_axis"] += (int(touchless.num_working_secs)//60)//60
                            touchless_dict["x_axis"] = first_day.strftime("%I:%M %p")
                            x_y_axis_list.append(touchless_dict) 

            elif x_axis == 16 and not y_axis:
                print(first)
                touchlesses = Touchless_Attendance.query.filter(and_(
                                        Touchless_Attendance.employee_mobile == user_mobile,
                                        Cast(Touchless_Attendance.time, Date)  >= first,
                                        Cast(Touchless_Attendance.time, Date) < second,
                                        Touchless_Attendance.attendance_status == STATUS["OUT"]
                                        )).order_by(Touchless_Attendance.time.asc()).all()  
                print(user_mobile, " mobile  ", touchlesses)                        
                for touchless in touchlesses:   
                    count += (int(touchless.num_working_secs)//60)//60 


        if x_axis and y_axis:
            attendance_functions_dict = x_y_axis_list
        elif x_axis and not y_axis:
            attendance_functions_dict = count
    except Exception as e:
        logging.error("single_attendance_functions : exception : {}".format(e))
    logging.debug("single_attendance_functions : End")
    return attendance_functions_dict

# return the list of dict contains x and y plots for single employee for time range now --interval 15 sec
def now_single_attendance_functions(  time_range, user_mobile, x_axis = 0, y_axis = 0):
    logging.debug("now_single_attendance_functions : Start")
    try:
        x_y_axis_list = list()
        attendance_functions_dict = dict()
        if time_range == "NOW":
            second = datetime.datetime.now(pytz.utc)
            first = second - datetime.timedelta (seconds = 15)
            
            absentize = Absence.query.filter(
                                        and_(
                                            Absence.employee_mobile == user_mobile,
                                            Absence.time   >= first,
                                            Absence.time  < second,
                                            Absence.is_absent == STATUS["YES"]
                                        )
                                        ).all()

            if y_axis == 9: # Absence
                for absent in absentize:  
                    absence_dict = dict()    
                    absence_dict["x_axis"] = absent.time
                    absence_dict["y_axis"] = absent.is_absent
                    x_y_axis_list.append(absence_dict) 

            unauthorizes = Unauthorized.query.filter(
                                and_(
                                    Unauthorized.employee_mobile == user_mobile,
                                    Unauthorized.time   >= first,
                                    Unauthorized.time  < second,
                                    Unauthorized.is_unauthorized == STATUS["YES"]
                                )
                                ).all()

            if y_axis == 12:# Unauthorized Access
                for unauthorize in unauthorizes:  
                    unauthorized_dict = dict()    
                    unauthorized_dict["x_axis"] = unauthorize.time
                    unauthorized_dict["y_axis"] = unauthorize.is_unauthorized
                    x_y_axis_list.append(unauthorized_dict)     

            schedule_mismatches = Schedule_Mismatch.query.filter(
                                and_(
                                    Schedule_Mismatch.employee_mobile == user_mobile,
                                    Schedule_Mismatch.time   >= first,
                                    Schedule_Mismatch.time  < second,
                                    Schedule_Mismatch.is_violation == STATUS["YES"]
                                )
                                ).all()

            if y_axis == 10: # Schedule Violation
                for schedule_mismatch in schedule_mismatches:  
                    schedule_mismatches_dict = dict()    
                    schedule_mismatches_dict["x_axis"] = schedule_mismatch.time
                    schedule_mismatches_dict["y_axis"] = schedule_mismatch.is_violation
                    x_y_axis_list.append(schedule_mismatches_dict)     

            break_times = Break_Time.query.filter(
                                and_(
                                    Break_Time.employee_mobile == user_mobile,
                                    Break_Time.time   >= first,
                                    Break_Time.time  < second,
                                    Break_Time.is_violation == STATUS["YES"]
                                )
                                ).all()

            if y_axis == 11: # break Violation
                for break_time in break_times:  
                    break_times_dict = dict()    
                    break_times_dict["x_axis"] = break_time.time
                    break_times_dict["y_axis"] = break_time.is_violation
                    x_y_axis_list.append(break_times_dict)   
            
            touchlesses = Touchless_Attendance.query.filter(and_(
                                    Touchless_Attendance.employee_mobile == user_mobile,
                                    Touchless_Attendance.time  >= first,
                                    Touchless_Attendance.time < second,
                                    Touchless_Attendance.attendance_status == STATUS["OUT"]
                                    )).order_by(Touchless_Attendance.time.asc()).all()  

            if y_axis == 16:  # no of working hours                                          
                if touchlesses:
                    for touchless in touchlesses:
                        touchless_dict = dict()
                        touchless_dict["y_axis"] = (int(touchless.num_working_secs)//60)//60
                        touchless_dict["x_axis"] = touchless.time
                        x_y_axis_list.append(touchless_dict)


            attendance_functions_dict = x_y_axis_list
    except Exception as e:
        logging.error("now_single_attendance_functions : exception : {}".format(e))
    logging.debug("now_single_attendance_functions : Start")
    return attendance_functions_dict

# return the list of dict contains x and y plots for all employee
def all_employee_info( time_range, x_axis = 0, y_axis = 0):
    logging.debug("all_employee_info : Start")
    try:
        info_dict = dict()
        if time_range == "TODAY":
            today = datetime.datetime.now(pytz.utc)
            tomorrow = today + datetime.timedelta(days=1)
            first = today.date()
            second = tomorrow.date()
            import pandas
            day_list = pandas.date_range(first, second, freq='H')

        elif time_range == "MONTH":
            today = datetime.datetime.now(pytz.utc)
            first_day, last_day, day_list = get_month_day_range(today)
            first = first_day.date()
            second = last_day.date()  
        elif time_range == "WEEK" :
            today = datetime.datetime.now(pytz.utc)
            first_day, last_day, day_list = get_week_day_range(today)
            first = first_day.date()
            second = last_day.date()  

        if time_range == "NOW" and y_axis:
            info_dict = now_all_attendance_functions( time_range, x_axis, y_axis)
        elif time_range != "NOW" and y_axis:

            info_dict  = all_attendance_functions(first, second, time_range, x_axis, y_axis, day_list)            

        if time_range == "NOW" and x_axis and not y_axis:
            info_dict = now_all_attendance_functions( time_range, x_axis)
        elif time_range != "NOW" and x_axis and not y_axis:  
            info_dict = all_attendance_functions(first, second, time_range, x_axis)

    except Exception as e:
        logging.error("all_employee_info : exception : {}".format(e))
    logging.debug("all_employee_info : end")
    return info_dict

# return the list of dict contains x and y plots for all employee
def all_attendance_functions( first, second, time_range, x_axis = 0, y_axis = 0, day_list = []):
    logging.debug("all_attendance_functions : Start")
    try:
        info_dict = dict()
        count = 0
        x_y_axis_list = list()
        if time_range in ["TODAY", "WEEK", "MONTH"]:
            # Absence Count
            if x_axis == 9 or y_axis == 9:
                absentize = db.session.query(Absence.employee_mobile, Absence.time, User.business_id, User.user_id).filter(
                                    and_(
                                        User.is_employee == STATUS["YES"],
                                        User.business_id == auth.current_user().business_id,
                                        User.status == STATUS["ACTIVE"],
                                        User.mobile == Absence.employee_mobile,
                                        Cast(Absence.time, Date)  >= first,
                                        Cast(Absence.time, Date) < second,
                                        Absence.is_absent == STATUS["YES"]
                                    )
                                    ).all()

                if x_axis and y_axis == 9:
                    for absent in absentize:  
                        absence_dict = dict()    
                        absence_dict["x_axis"] = absent[1]
                        absence_dict["y_axis"] = absent[3]
                        x_y_axis_list.append(absence_dict) 
                elif x_axis == 9 and not y_axis:
                    for absent in absentize:  
                        count += 1

            # Unauthorized Access Vioaltion
            elif x_axis == 12 or y_axis == 12 :
                if x_axis and y_axis == 12 and time_range in ["MONTH", "WEEK"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        unauthorizes = db.session.query(Unauthorized.employee_mobile, Unauthorized.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Unauthorized.employee_mobile,
                                            Cast(Unauthorized.time, Date)  >= first_day,
                                            Cast(Unauthorized.time, Date) < second_day,
                                            Unauthorized.is_unauthorized == STATUS["YES"]
                                        )
                                        ).all()
                        second_day = second_day + datetime.timedelta(days=1)
                        if unauthorizes:
                            count = 0
                            for unauthorize in unauthorizes:  
                                count += 1
                            unauthorized_dict = dict()    
                            unauthorized_dict["x_axis"] = first_day.strftime("%d-%b")
                            unauthorized_dict["y_axis"] = count
                            x_y_axis_list.append(unauthorized_dict)   

                elif x_axis and y_axis == 12 and time_range in ["TODAY"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        unauthorizes = db.session.query(Unauthorized.employee_mobile, Unauthorized.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Unauthorized.employee_mobile,
                                            Unauthorized.time  >= first_day,
                                            Unauthorized.time < second_day,
                                            Unauthorized.is_unauthorized == STATUS["YES"]
                                        )
                                        ).all()
                        second_day = second_day + datetime.timedelta(hours=1)
                        if unauthorizes:
                            count = 0
                            for unauthorize in unauthorizes:  
                                count += 1
                            unauthorized_dict = dict()    
                            unauthorized_dict["x_axis"] = first_day.strftime("%I:%M %p")
                            unauthorized_dict["y_axis"] = count
                            x_y_axis_list.append(unauthorized_dict)               

                elif x_axis == 12 and not y_axis:
                    unauthorizes = db.session.query(Unauthorized.employee_mobile, Unauthorized.time, User.business_id, User.user_id).filter(
                                    and_(
                                        User.is_employee == STATUS["YES"],
                                        User.business_id == auth.current_user().business_id,
                                        User.status == STATUS["ACTIVE"],
                                        User.mobile == Unauthorized.employee_mobile,
                                        Cast(Unauthorized.time, Date)  >= first,
                                        Cast(Unauthorized.time, Date) < second,
                                        Unauthorized.is_unauthorized == STATUS["YES"]
                                    )
                                    ).all()
                    for unauthorize in unauthorizes: 
                        count += 1    

            # Schedule Mismatch Violation: 
            elif x_axis == 10 or y_axis == 10:
                if x_axis and y_axis == 10 and time_range in [ "MONTH", "WEEK"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        schedule_mismatches = db.session.query(Schedule_Mismatch.employee_mobile, Schedule_Mismatch.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Schedule_Mismatch.employee_mobile,
                                            Cast(Schedule_Mismatch.time, Date)  >= first_day,
                                            Cast(Schedule_Mismatch.time, Date) < second_day,
                                            Schedule_Mismatch.is_violation == STATUS["YES"]
                                        )
                                        ).all()
                        second_day = second_day + datetime.timedelta(days=1)  
                        if schedule_mismatches:
                            count = 0
                            for schedule_mismatch in schedule_mismatches:  
                                count +=1
                            schedule_mismatches_dict = dict()    
                            schedule_mismatches_dict["x_axis"] = first_day.strftime("%d-%b")
                            schedule_mismatches_dict["y_axis"] = count
                            x_y_axis_list.append(schedule_mismatches_dict)    

                elif x_axis and y_axis == 10 and time_range in [ "TODAY"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        print("came here")
                        schedule_mismatches = db.session.query(Schedule_Mismatch.employee_mobile, Schedule_Mismatch.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Schedule_Mismatch.employee_mobile,
                                            Schedule_Mismatch.time  >= first_day,
                                            Schedule_Mismatch.time < second_day,
                                            Schedule_Mismatch.is_violation == STATUS["YES"]
                                        )
                                        ).all()
                        second_day = second_day + datetime.timedelta(hours=1)  
                        print("second_day", second_day)
                        if schedule_mismatches:
                            count = 0
                            for schedule_mismatch in schedule_mismatches:  
                                count +=1
                            schedule_mismatches_dict = dict()    
                            schedule_mismatches_dict["x_axis"] = first_day.strftime("%I:%M %p")
                            schedule_mismatches_dict["y_axis"] = count
                            x_y_axis_list.append(schedule_mismatches_dict)                 

                elif x_axis == 10 and not y_axis:
                    schedule_mismatches = db.session.query(Schedule_Mismatch.employee_mobile, Schedule_Mismatch.time, User.business_id, User.user_id).filter(
                                    and_(
                                        User.is_employee == STATUS["YES"],
                                        User.business_id == auth.current_user().business_id,
                                        User.status == STATUS["ACTIVE"],
                                        User.mobile == Schedule_Mismatch.employee_mobile,
                                        Cast(Schedule_Mismatch.time, Date)  >= first,
                                        Cast(Schedule_Mismatch.time, Date) < second,
                                        Schedule_Mismatch.is_violation == STATUS["YES"]
                                    )
                                    ).all()
                    for schedule_mismatch in schedule_mismatches:  
                        count += 1          

            # Break time Violation:
            elif x_axis == 11 or y_axis == 11:
                if x_axis and y_axis == 11 and  time_range in ["MONTH", "WEEK"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        break_times = db.session.query(Break_Time.employee_mobile, Break_Time.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Break_Time.employee_mobile,
                                            Cast(Break_Time.time, Date)  >= first_day,
                                            Cast(Break_Time.time, Date) < second_day,
                                            Break_Time.is_violation == STATUS["YES"]
                                        )
                                        ).all()
                        second_day = second_day + datetime.timedelta(days=1)  
                        if  break_times:   
                            count = 0 
                            for break_time in break_times:  
                                count += 1
                            break_times_dict = dict()    
                            break_times_dict["x_axis"] = first_day.strftime("%d-%b")
                            break_times_dict["y_axis"] = count
                            x_y_axis_list.append(break_times_dict)  

                elif x_axis and y_axis == 11 and time_range in ["TODAY"]:
                    second_day = day_list[1]
                    for first_day in day_list[:-2]:
                        break_times = db.session.query(Break_Time.employee_mobile, Break_Time.time, User.business_id, User.user_id).filter(
                                        and_(
                                            User.is_employee == STATUS["YES"],
                                            User.business_id == auth.current_user().business_id,
                                            User.status == STATUS["ACTIVE"],
                                            User.mobile == Break_Time.employee_mobile,
                                            Break_Time.time >= first_day,
                                            Break_Time.time < second_day,
                                            Break_Time.is_violation == STATUS["YES"]
                                        )
                                        ).all()               
                        second_day = second_day + datetime.timedelta(hours=1)  
                        if  break_times:   
                            count = 0 
                            for break_time in break_times:  
                                count += 1
                            break_times_dict = dict()    
                            break_times_dict["x_axis"] = first_day.strftime("%I:%M %p")
                            break_times_dict["y_axis"] = count
                            x_y_axis_list.append(break_times_dict)              
                elif x_axis == 11 and not y_axis:
                    break_times = db.session.query(Break_Time.employee_mobile, Break_Time.time, User.business_id, User.user_id).filter(
                                    and_(
                                        User.is_employee == STATUS["YES"],
                                        User.business_id == auth.current_user().business_id,
                                        User.status == STATUS["ACTIVE"],
                                        User.mobile == Break_Time.employee_mobile,
                                        Cast(Break_Time.time, Date)  >= first,
                                        Cast(Break_Time.time, Date) < second,
                                        Break_Time.is_violation == STATUS["YES"]
                                    )
                                    ).all()
                    for break_time in break_times:   
                        count += 1            

        if x_axis and y_axis:
            info_dict = x_y_axis_list   
        else:
            info_dict = count                      

    except Exception as e:
        logging.error("all_attendance_functions : exception : {}".format(e))
    logging.debug("all_attendance_functions : end")
    return info_dict                         

# return the list of dict contains x and y plots for all employee for time range now --interval 15 sec
def now_all_attendance_functions( time_range, x_axis = 0, y_axis = 0):
    logging.debug("now_all_employee_info : Start")
    try:
        info_dict = list()
        count = 0
        x_y_axis_list = list()
        if time_range == "NOW":
            second = datetime.datetime.now(pytz.utc)
            first = second - datetime.timedelta (seconds = 15)

            absentize = db.session.query(Absence.employee_mobile, Absence.time, User.business_id, User.user_id).filter(
                                and_(
                                    User.is_employee == STATUS["YES"],
                                    User.business_id == auth.current_user().business_id,
                                    User.status == STATUS["ACTIVE"],
                                    User.mobile == Absence.employee_mobile,
                                    Absence.time  >= first,
                                    Absence.time < second,
                                    Absence.is_absent == STATUS["YES"]
                                )
                                ).all()
            if x_axis and y_axis == 9:
                for absent in absentize:  
                    absence_dict = dict()    
                    absence_dict["x_axis"] = absent[1]
                    absence_dict["y_axis"] = absent[3]
                    x_y_axis_list.append(absence_dict) 
            elif x_axis == 9 and not y_axis:  #Absence
                for absent in absentize:  
                    count += 1        

            unauthorizes = db.session.query(Unauthorized.employee_mobile, Unauthorized.time, User.business_id, User.user_id).filter(
                                and_(
                                    User.is_employee == STATUS["YES"],
                                    User.business_id == auth.current_user().business_id,
                                    User.status == STATUS["ACTIVE"],
                                    User.mobile == Unauthorized.employee_mobile,
                                    Unauthorized.time  >= first,
                                    Unauthorized.time < second,
                                    Unauthorized.is_unauthorized == STATUS["YES"]
                                )
                                ).all()

            if x_axis and y_axis == 12:
                for unauthorize in unauthorizes:  
                    unauthorized_dict = dict()    
                    unauthorized_dict["x_axis"] = unauthorize[1]
                    unauthorized_dict["y_axis"] = unauthorize[3]
                    x_y_axis_list.append(unauthorized_dict)  
            elif x_axis == 12 and not y_axis:  # Unauthorized
                for unauthorize in unauthorizes: 
                    count += 1          

            schedule_mismatches = db.session.query(Schedule_Mismatch.employee_mobile, Schedule_Mismatch.time, User.business_id, User.user_id).filter(
                                and_(
                                    User.is_employee == STATUS["YES"],
                                    User.business_id == auth.current_user().business_id,
                                    User.status == STATUS["ACTIVE"],
                                    User.mobile == Schedule_Mismatch.employee_mobile,
                                    Schedule_Mismatch.time  >= first,
                                    Schedule_Mismatch.time < second,
                                    Schedule_Mismatch.is_violation == STATUS["YES"]
                                )
                                ).all()

            if x_axis and y_axis == 10:
                for schedule_mismatch in schedule_mismatches:  
                    schedule_mismatches_dict = dict()    
                    schedule_mismatches_dict["x_axis"] = schedule_mismatch[1]
                    schedule_mismatches_dict["y_axis"] = schedule_mismatch[3]
                    x_y_axis_list.append(schedule_mismatches_dict)    
            elif x_axis == 10 and not y_axis:  # Schedule Violation
                for schedule_mismatch in schedule_mismatches:  
                    count += 1       

            break_times = db.session.query(Break_Time.employee_mobile, Break_Time.time, User.business_id, User.user_id).filter(
                                and_(
                                    User.is_employee == STATUS["YES"],
                                    User.business_id == auth.current_user().business_id,
                                    User.status == STATUS["ACTIVE"],
                                    User.mobile == Break_Time.employee_mobile,
                                    Break_Time.time  >= first,
                                    Break_Time.time < second,
                                    Break_Time.is_violation == STATUS["YES"]
                                )
                                ).all()

            if x_axis and y_axis == 11:
                for break_time in break_times:  
                    break_times_dict = dict()    
                    break_times_dict["x_axis"] = break_time[1]
                    break_times_dict["y_axis"] = break_time[3]
                    x_y_axis_list.append(break_times_dict)   
            elif x_axis == 11 and not y_axis: # break Violation
                for break_time in break_times:   
                    count += 1         
        if  x_axis and y_axis:
            info_dict = x_y_axis_list 
        elif x_axis and not y_axis:
            info_dict = count    

    except Exception as e:
        logging.error("all_attendance_functions : exception : {}".format(e))
    logging.debug("all_attendance_functions : end")
    return info_dict 


if __name__ == "__main__":
    a = all_employee_info("TODAY", 12)
    print(a)


