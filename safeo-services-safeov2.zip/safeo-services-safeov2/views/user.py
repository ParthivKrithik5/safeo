from flask import Blueprint, jsonify, request, send_from_directory
from sqlalchemy import cast, Date, and_, func, asc
import json, os, base64
from app import app, logging, auth, db
from model import *
from utils import *
import datetime

import saferson

# User API Services
user_blueprint = Blueprint("user", __name__)

# Role SetUp
# Function List
@user_blueprint.route("/api/function-list",methods=["POST"])
@auth.login_required()
def function_list():
    logging.debug("function_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        parent_func_list, functions_list = [], []
        fun_dict, parent_dict, child_dict = {}, {}, {}
        parent_functions = Function.query.filter(Function.status == STATUS["ACTIVE"] ).order_by(Function.parent_function_id.asc()).all()
        for parent_function in parent_functions:
            parent_func_dict = dict()
            parent_func_dict["function_id"] = parent_function.function_id
            parent_func_dict["function_name"] = parent_function.function_name
            parent_func_dict["function_desc"] = parent_function.function_desc
            parent_func_dict["parent_function_id"] = parent_function.parent_function_id 
            parent_func_dict["function_list"] = list()
            parent_func_list.append(parent_func_dict)

        for func_dict in parent_func_list:
            if func_dict["parent_function_id"] == 0:
                parent_dict = {}
                parent_dict["function_id"] = func_dict["function_id"]
                parent_dict["function_name"] = func_dict["function_name"]
                parent_dict["function_desc"] = func_dict["function_desc"]
                parent_dict["function_list"] = func_dict["function_list"]
                fun_dict[func_dict["function_id"]] = parent_dict
            else:
                child_dict = {}
                child_dict["function_id"] = func_dict["function_id"]
                child_dict["function_name"] = func_dict["function_name"]
                child_dict["function_desc"] = func_dict["function_desc"]
                child_dict["function_list"] = func_dict["function_list"]
                
                if func_dict["parent_function_id"] in fun_dict:
                    p_dict = fun_dict[func_dict["parent_function_id"]]
                    lst = p_dict["function_list"]
                    lst.append(child_dict)
                    p_dict["function_list"]=lst
                    fun_dict[func_dict["parent_function_id"]]=p_dict
                else:
                    for funcdict in fun_dict.values():
                        lst = funcdict["function_list"]
                        for lst_dict in lst:
                            if func_dict["parent_function_id"]==lst_dict["function_id"]:
                                ip_dict = lst_dict
                                ilst = ip_dict["function_list"]
                                ilst.append(child_dict)
                                ip_dict["function_list"]=ilst
                            elif len(lst_dict["function_list"])>0:
                                for lst1_dict in lst_dict["function_list"]:
                                    if func_dict["parent_function_id"]==lst1_dict["function_id"]:
                                        ip1_dict = lst1_dict
                                        ilst1 = ip1_dict["function_list"]
                                        ilst1.append(child_dict)
                                        ip1_dict["function_list"]=ilst1
        
        functions_list = list(fun_dict.values())
        if not functions_list:
            resp_dict["status"] = False
            resp_dict["msg"] = "No records found"
        else:
            resp_dict["status"] = True
            resp_dict["object"] = functions_list
        
    except Exception as e:
        logging.error("function_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("function_list : End")
    return jsonify(resp_dict)

# User Function Lists
@user_blueprint.route("/api/user-functions-list",methods=["POST"])
@auth.login_required()
def user_functions_list():
    logging.debug("user_functions_list : Start")
    resp_dict={"status":False,"msg":None,"object":None}
    try:
        def function_list(roleId, funcId):
            function_lists = list()
            functions = []
            if roleId > 0 and funcId > 0:
                functions = db.session.query(Role.role_id, Role.role_name, Function.function_id, Function.function_name, 
                    Function.function_url, Function.function_desc).filter(
                        and_(
                            User.user_id == User_Role_Resp.user_id,
                            Role.role_id == User_Role_Resp.role_id,
                            Role.role_id == Role_Function_Map.role_id,
                            Role_Function_Map.function_id == Function.function_id,
                            Role.role_id == roleId,
                            Function.parent_function_id == funcId,
                            User.user_id == auth.current_user().user_id                            
                        )
                    ).order_by(Role.role_id.asc(), Function.function_id.asc()).all()
            else:
                functions = db.session.query(Role.role_id, Role.role_name, Function.function_id, Function.function_name, 
                    Function.function_url, Function.function_desc).filter(
                        and_(
                            User.user_id == User_Role_Resp.user_id,
                            Role.role_id == User_Role_Resp.role_id,
                            Role.role_id == Role_Function_Map.role_id,
                            Role_Function_Map.function_id == Function.function_id,
                            Function.parent_function_id == funcId,
                            User.user_id == auth.current_user().user_id                            
                        )
                    ).order_by(Role.role_id.asc(), Function.function_id.asc()).all()

            for function in functions:
                child_function_list = function_list(function[0], function[2])
                function_dict = {
                    "role_id" : function[0],
                    "role_name" : function[1],
                    "function_id" : function[2],
                    "function_name" : function[3],
                    "function_url" : function[4],
                    "function_desc" : function[5],
                    "function_list" : child_function_list
                    }
                function_lists.append(function_dict)
                
            return function_lists
        
        resp_dict["status"] = True
        resp_dict["object"] = function_list(0, 0)
              
    except Exception as e:
        logging.error("user_functions_list : Exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_functions_list : End")
    return jsonify(resp_dict)

# Role  List
@user_blueprint.route("/api/role-list", methods = ["POST"])
@auth.login_required()
def role_list():
    logging.debug("role_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        roles = Role.query.filter(and_(Role.status == STATUS["ACTIVE"],
            Role.business_id == auth.current_user().business_id)
            ).all()

        role_list = list()
        for role in roles:
            role_dict = dict()
            role_dict["role_id"] = role.role_id
            role_dict["role_name"]=role.role_name
            role_dict["role_desc"] = role.role_desc
            role_dict["created_by"]=role.created_by
            role_list.append(role_dict)

        resp_dict["status"] = True
        resp_dict["object"] = role_list
        
    except Exception as e:
        logging.exception("role_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("role_list : end")
    return jsonify(resp_dict)

# Create and Update Role
@user_blueprint.route("/api/create-update-role",methods=["POST"])
@auth.login_required()
def create_update_role():
    logging.debug("create_update_role : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        role_id = request.json.get("role_id")
        role_name = request.json.get("role_name")
        role_desc = request.json.get("role_desc")
        function_id_list = request.json.get("function_id")
        
        # Input validation
        input_validation = ""
        if not role_name:
            input_validation = "Role Name is required"
        elif not char_validation(role_name):
            input_validation = "Valid Role Name is required"
        elif not role_desc:
            input_validation = "Role Desc is required"
        elif not function_id_list:
            input_validation = "Choose at least one function"
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        role = Role.query.get(role_id)
        if not role:
            role_name_validation = Role.query.filter(and_(Role.business_id == auth.current_user().business_id, Role.role_name == role_name )).first()
            if role_name_validation:
                resp_dict["msg"] = "Role name already Exist"
                return jsonify(resp_dict)
                
            role = Role(role_name,role_desc, auth.current_user().business_id, auth.current_user().user_id)
            role.role_type = ROLE_TYPE["CLIENT-INTERNAL"]
            db.session.add(role)
            db.session.commit()

            for function_id in function_id_list:
                role_function = Role_Function_Map(role.role_id, function_id)
                db.session.add(role_function)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"]="Role created successfully"
        else:
            role.role_name = role_name
            role.role_desc = role_desc
            role.updated_by = auth.current_user().user_id
            role.updated_date = datetime.datetime.now()
            db.session.commit()

            # Disable Old Record
            role_function_maps = Role_Function_Map.query.filter(Role_Function_Map.role_id == role.role_id).all()
            for role_function_map in role_function_maps:
                role_function_map.status = STATUS["DEACTIVE"]
                role_function_map.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New Record
            for function_id in function_id_list:
                role_function = Role_Function_Map( role_id, function_id)
                db.session.add(role_function)
                db.session.commit()
            resp_dict["status"] = True 
            resp_dict["msg"] = "Role updated successfully"
            
    except Exception as e:
        logging.exception("create_update_role : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("create_update_role : end")
    return jsonify(resp_dict) 

# Role Info
@user_blueprint.route("/api/role-info", methods = ["POST"])
@auth.login_required()
def role_info():
    logging.debug("role_info: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        role_id = request.json.get("role_id")
        
        role_info = dict()
        role = Role.query.filter(and_( Role.status == STATUS["ACTIVE"],
            Role.role_id == role_id)
            ).first()
        role_info["role_name"] = role.role_name
        role_info["role_desc"] = role.role_desc
        role_function = Role_Function_Map.query.filter(
            and_(
                Role_Function_Map.role_id == role_id,
                Role_Function_Map.status == STATUS["ACTIVE"])).all()
        
        function_id_list = list()
        for function in role_function:
            function_id_list.append(function.function_id)
        role_info["function_id"] = function_id_list
            
        resp_dict["status"] = True
        resp_dict["object"] = role_info
        
    except Exception as e:
        logging.exception("role_info: exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("role_info : end")
    return jsonify(resp_dict)

# Employee SetUp
# Add Single Employee
@user_blueprint.route("/api/add-update-employee", methods=["POST"])
@auth.login_required()
def add_update_employee():
    logging.debug("add_update_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}

    try:
        employee_name = request.json.get("employee_name")
        country_id = request.json.get("country_id")
        mobile = request.json.get("mobile")
        email = request.json.get("email")
        designation = request.json.get("designation")
        user_id = request.json.get("user_id")
      

        # Input data validation
        input_validation = ""
       
        if not employee_name:
            input_validation = "Employee Name is required"
        elif not char_validation(employee_name):
            input_validation = "Valid Employee name is required"
        elif not country_id:
            input_validation = "Country Id is required"
        elif not mobile:
            input_validation = "mobile is required"
        elif not mobile_no_validation(mobile):
            input_validation = "Valid Mobile no is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not email_validation(email):
            input_validation = "Valid Email Id is required"
        elif not designation:
            input_validation = "Designation is required"
        
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not user_id:
            # Add New Employee
            user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile, User.status != STATUS["DELETE"])).first()
            if user:
                    resp_dict["msg"] = "Employee named {} already registred with the Mobile No : {}".format(user.name, user.mobile)
                    return jsonify(resp_dict)
            user = User.query.filter(and_(User.email == email, User.status != STATUS["DELETE"])).first()
            if user:
                resp_dict["msg"] =  "Employee named {} already registred with the Email Id : {}".format(user.name, user.email)
                return jsonify(resp_dict)
            
            new_password = get_random_password()
            emp_user = User( employee_name, email, country_id, mobile, auth.current_user().business_id, STATUS["YES"], designation, auth.current_user().user_id)
            emp_user.hash_password(new_password)
            emp_user.status = STATUS["ENTRY"]
            emp_user.default_password_changed = STATUS["YES"]
            db.session.add(emp_user)
            db.session.commit()

            # Send sms with new password
            msg = "Hey {} ,Kindly click the link below to upload your photo. https://dev.safeo.ai/services/api/login Use temporary password:{}".format(emp_user.name,new_password)
            sms_insert(emp_user.country_id, emp_user.mobile, msg)
            
            # admin_mobile = get_admin_mobile(auth.current_user()) 
            # saferson.enable_face_recog(admin_mobile)
            unknown_user = User.query.filter(and_(User.mobile == "UNKNOWN", User.business_id == auth.current_user().business_id)).first()
            if not unknown_user:
                unknown_user = User( "Unknown Employee", "UNKNOWN", 1, "UNKNOWN", auth.current_user().business_id, STATUS["YES"], "UNKNOWN", auth.current_user().user_id)
                unknown_user.hash_password("UNKNOWN")
                db.session.add(unknown_user)
                db.session.commit()
            resp_dict["status"] = True
            resp_dict["msg"] = "Added successfully"
        else:
            # Update Employee
            user = User.query.get(user_id)
            old_mobile = user.mobile
            old_country_id = user.country_id
            user.name = employee_name
            user.email = email
            user.designation = designation
            user.updated_date = datetime.datetime.now()
            user.updated_by = auth.current_user().user_id
            db.session.commit()

            if old_mobile != mobile or old_country_id != country_id:
                check_user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile, User.status != STATUS["DELETE"])).first()
                if check_user:
                    resp_dict["msg"] =  "Employee named {} already registred with the Mobile number : {}".format(check_user.name, check_user.email)
                    return jsonify(resp_dict)
                new_password = get_random_password()
                new_user = User.query.get(user_id)
                new_user.mobile = mobile
                new_user.hash_password(new_password)
                new_user.status = STATUS["ENTRY"]
                new_user.default_password_changed = STATUS["YES"]
                db.session.add(new_user)
                db.session.commit()

                # Send sms with new password
                msg = "Hey {} ,Kindly click the link below to upload your photo. https://dev.safeo.ai/services/api/login Use temporary password:{}".format(new_user.name,new_password)
                sms_insert(new_user.country_id, new_user.mobile, msg)

            resp_dict["status"] = True
            resp_dict["msg"] = "Updated successfully"            

    except Exception as e:
        logging.error("add_update_employee : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("add_update_employee : end")
    return jsonify(resp_dict)

# Enable Face Recognition
@user_blueprint.route("/api/enable-face-recognition", methods=["POST"])
@auth.login_required()
def enable_face_recognition():
    """enable_face_recognition"""
    logging.debug("enable_face_recognition : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        admin_mobile = get_admin_mobile(auth.current_user()) 
        msg = saferson.enable_face_recog(admin_mobile)
        resp_dict["status"] = True
        resp_dict["msg"] = msg
    except Exception as e:
        logging.error("enable_face_recognition : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("enable_face_recognition : end")
    return jsonify(resp_dict)   


# Add List Of Employee
@user_blueprint.route("/api/add-employee-list", methods=["POST"])
@auth.login_required()
def add_employee_list():
    """Add Employee"""
    logging.debug("add_employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_list = request.json.get("employee_list")

        if not employee_list:
            resp_dict["msg"] = "Add at least one employee"
            return jsonify(resp_dict)

        for employee in employee_list:
            input_validation = ""
            if not employee["name"]:
                input_validation = "Employee Name is required"
            elif not char_validation(employee["name"]):
                input_validation = "Valid Employee name is required"
            elif not employee["country_id"]:
                input_validation = "Country Id is required for the employee {}".format(employee["name"])
            elif not employee["mobile"]:
                input_validation = "mobile is required for the employee {}".format(employee["name"])
            elif not mobile_no_validation(employee["mobile"]):
                input_validation = "Valid Mobile no is required for the employee {}".format(employee["name"])
            elif not employee["email"]:
                input_validation = "Email Address is required for the employee {}".format(employee["name"])
            elif not email_validation(employee["email"]):
                input_validation = "Valid Email Id is required for the employee {}".format(employee["name"])
            elif not employee["designation"]:
                input_validation = "Designation is required for the employee {}".format(employee["name"])

            if input_validation:
                resp_dict["msg"] = input_validation
                return jsonify(resp_dict)

            user = User.query.filter(and_(User.country_id == employee["country_id"], User.mobile == employee["mobile"],User.status != STATUS["DELETE"])).first()
            if user:
                resp_dict["msg"] = "Employee named {} already registred with the Mobile No : {}".format(user.name, user.mobile)
                return jsonify(resp_dict)
            user = User.query.filter(and_(User.email == employee["email"], User.status != STATUS["DELETE"])).first()
            if user:
                resp_dict["msg"] =  "Employee named {} already registred with the Email Id : {}".format(user.name, user.email)
                return jsonify(resp_dict)   
                    
        for employee in employee_list:
            # Save User
            new_password = get_random_password()
            emp_user = User(employee["name"], employee["email"], employee["country_id"], employee["mobile"], 
                auth.current_user().business_id, STATUS["YES"], employee["designation"], auth.current_user().user_id)
            emp_user.hash_password(new_password)
            emp_user.status = STATUS["ENTRY"]
            emp_user.default_password_changed = STATUS["YES"]
            db.session.add(emp_user)
            db.session.commit()

            unknown_user = User.query.filter(and_(User.mobile == "UNKNOWN", User.business_id == auth.current_user().business_id)).first()
            if not unknown_user:
                unknown_user = User( "Unknown Employee", "UNKNOWN", 1, "UNKNOWN", auth.current_user().business_id, STATUS["YES"], "UNKNOWN", auth.current_user().user_id)
                unknown_user.hash_password("UNKNOWN")
                db.session.add(unknown_user)
                db.session.commit()

            # Send mail with new password
            msg = "Hey {} ,Kindly click the link below to upload your photo.https://dev.safeo.ai/services/api/login Use temporary password: {}".format(emp_user.name,new_password)
            sms_insert(emp_user.country_id,emp_user.mobile, msg)
            
        admin_mobile = get_admin_mobile(auth.current_user()) 
        # saferson.enable_face_recog(admin_mobile)

        resp_dict["status"] = True
        resp_dict["msg"] = "Added Successfully"

    except Exception as e:
        logging.error("add_employee_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("add_employee_list : end")
    return jsonify(resp_dict)    

@user_blueprint.route("/api/user-function-list", methods = ["POST"])
@auth.login_required()
def user_function_list():
    logging.debug("user_function_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        user_id = request.json.get("user_id")
        user = User.query.filter(and_( User.status != STATUS["DELETE"],User.user_id == user_id,User.business_id ==auth.current_user().business_id)).first()
        if user:
            user_role_resp = User_Role_Resp.query.filter(and_(
                                                User_Role_Resp.user_id == user.user_id,
                                                User_Role_Resp.status == STATUS["ACTIVE"])).first()
            
            user_function_maps  = Role_Function_Map.query.filter(and_(
                                                Role_Function_Map.role_id == user_role_resp.role_id, 
                                                Role_Function_Map.status == STATUS["ACTIVE"])).all()
            
            function_id_list = list()
            for user_function_map in user_function_maps:
                function_id_list.append(user_function_map.function_id)
            
            resp_dict["status"] = True
            resp_dict["object"] = function_id_list
            
    except Exception as e:
        logging.exception("user_function_list: exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_function_list : end")
    return jsonify(resp_dict)

# Employee List
@user_blueprint.route("/api/employee-list", methods=["POST"])
@auth.login_required()
def employee_list():
    logging.debug("employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_list = list()
        users =  User.query.filter(and_(User.business_id == auth.current_user().business_id, User.is_employee == STATUS["YES"], User.status != STATUS["DELETE"])).all()
        for row in users :
            if row.mobile != "UNKNOWN":
                emp_dict = dict()
                emp_dict["user_id"] = row.user_id
                emp_dict["name"] = row.name
                emp_dict["country_id"] = row.country_id
                emp_dict["mobile"] = row.mobile
                emp_dict["email"] = row.email
                emp_dict["designation"] = row.designation
                emp_dict["business_id"] = row.business_id
                emp_dict["status"] = row.status
                employee_list.append(emp_dict)
    
        resp_dict["status"] = True
        resp_dict["object"] = employee_list
        
    except Exception as e:
        logging.exception("employee_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("employee_list : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/employee-info", methods = ["POST"])
@auth.login_required()
def employee_info():
    logging.debug("employee_info: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        user_id = request.json.get("user_id")

        employee = User.query.get(user_id)
        emp_dict = dict()
        if employee:
            emp_dict["name"] = employee.name
            emp_dict["country_id"] = employee.country_id
            emp_dict["mobile"] = employee.mobile
            emp_dict["email"] = employee.email
            emp_dict["designation"] = employee.designation
            emp_dict["profile_image"] = (app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"]+employee.profile_image if employee.profile_image else app.config["SERVER_PATH"]+app.config["DEFAULT_IMAGE"])

            resp_dict["status"] = True
            resp_dict["object"] = emp_dict
        else:
            resp_dict["msg"] = "Employee not found"
            
    except Exception as e:
        logging.exception("employee_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("employee_info : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/user-profile-info", methods = ["POST"])
@auth.login_required()
def user_profile_info():
    logging.debug("user_profile_info: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        user = User.query.get(auth.current_user().user_id)
        user_dict = dict()
        if user:
            user_dict["user_id"] = user.user_id
            user_dict["name"] = user.name
            
            country = Country.query.get(user.country_id)
            user_dict["mobile"] = country.country_code +" "+user.mobile
            user_dict["email"] = user.email
            user_dict["profile_image_path"] = (app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"]+user.profile_image if user.profile_image else app.config["SERVER_PATH"]+app.config["DEFAULT_IMAGE"]) 
            business = Business.query.filter(Business.business_id == user.business_id).first()
            user_dict["business_name"] = business.business_name
            user_dict["address"] = business.address
            user_dict["industry_id"]  = ""
            user_dict["industry_name"] = ""
            industry = Industry.query.get(business.industry_id)
            if industry:
                user_dict["industry_id"]  = business.industry_id
                user_dict["industry_name"] = industry.industry_name

            resp_dict["status"] = True
            resp_dict["object"] = user_dict
        else:
            resp_dict["msg"] = "Employee not found"
            
    except Exception as e:
        logging.exception("user_profile_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_profile_info : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/user-profile-update", methods = ["POST"])
@auth.login_required()
def user_profile_update():
    logging.debug("user_profile_update: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        profile_image = request.json.get("profile_image")
        user = User.query.get(auth.current_user().user_id)
        if user and profile_image:
            profile_image = profile_image.split(",")[1]
            str_time =  datetime.datetime.now().strftime('%d%m%Y%H%M%S')
            profile_image_file_name = str(user.user_id)+"_"+str_time+".jpg"
            
            with open(os.path.join(app.config["PROFILE_IMAGES"], profile_image_file_name), "wb+") as f:
                logging.info(f)
                f.write(base64.b64decode(profile_image))

            # f = open(os.path.join(app.config["PROFILE_IMAGES"], profile_image_file_name), "wb")
            # logging.info(f)
            # f.write(base64.b64decode(profile_image))

            user.profile_image = profile_image_file_name
            user.updated_date = datetime.datetime.now()
            user.status = STATUS["ACTIVE"]
            user.updated_by = auth.current_user().user_id
            db.session.commit()

            country = Country.query.filter_by (country_id = user.country_id).first()
            user_mobile =  user.mobile
            
            admin_mobile = get_admin_mobile(auth.current_user())
            # saferson.delete_employee(user_mobile, admin_mobile)

            msg = saferson.update_employee_picture(admin_mobile, user_mobile, os.path.join('/home/kathiravan/safeo-phase2', app.config["PROFILE_IMAGES"], profile_image_file_name))

            logging.info("msg")
        resp_dict["status"] = True
        resp_dict["object"] = msg
        resp_dict["msg"] = "Profile updated successfully"
    
    except Exception as e:
        logging.exception("user_profile_update : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_profile_update : end")
    return jsonify(resp_dict)

# Delete Employee
@user_blueprint.route("/api/delete-employee", methods=["POST"])
@auth.login_required()
def delete_employee():
    logging.debug("delete_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user_id = request.json.get("user_id")

        user = User.query.filter(and_(User.user_id == user_id , User.is_employee == STATUS["YES"])).first()
        if user:
            user.status = STATUS["DELETE"]
            user.updated_date = datetime.datetime.now()
            user.updated_by = auth.current_user().user_id
            db.session.commit()
            country = Country.query.filter_by (country_id = user.country_id).first()
            user_mobile = country.country_code + user.mobile
            
            admin_mobile = get_admin_mobile(auth.current_user())
            #saferson.delete_employee(user_mobile, admin_mobile)

        resp_dict["status"] = True
        resp_dict["msg"] = "Deleted successfully"

    except Exception as e:
        logging.exception("delete_employee : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("delete_employee : end")
    
    return jsonify(resp_dict)

#GROUP SETUP
#create update employee group
@user_blueprint.route("/api/create-update-employee-group", methods = ["POST"])
@auth.login_required()
def create_update_employee_group():
    logging.debug("create_update_employee_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        emp_group_name = request.json.get("emp_group_name")
        emp_group_desc = request.json.get("emp_group_desc")
        role_id_list = request.json.get("role_id_list")
        employee_id_list = request.json.get("employee_id_list")
        emp_group_id = request.json.get("emp_group_id")

         # Input data validation
        input_validation = ""
        if not emp_group_name:
            input_validation = "Employee Group name is required"
        elif not emp_group_desc:
            input_validation = "Employee Group Description is required"
        elif not role_id_list:
            input_validation = "Choose atleast one role"
        elif not employee_id_list:
            input_validation = "Choose atleast one employee"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        emp_group = Employee_Group.query.get(emp_group_id)
        if not emp_group:
            emp_group_name_validation = Employee_Group.query.filter(and_(Employee_Group.business_id == auth.current_user().business_id, Employee_Group.emp_group_name == emp_group_name,
                                                                                     Employee_Group.status == STATUS["ACTIVE"])).first()
            if emp_group_name_validation:
                resp_dict["msg"] = "Group name already Exist"
                return jsonify(resp_dict)

            emp_group = Employee_Group( emp_group_name, emp_group_desc, auth.current_user().business_id, auth.current_user().user_id)
            db.session.add(emp_group)
            db.session.commit()

            for role_id in role_id_list:
                emp_group_role_map = Employee_Group_Role_Map(emp_group.emp_group_id, role_id, auth.current_user().user_id)
                db.session.add(emp_group_role_map)
                db.session.commit()
            for emp_id in employee_id_list:
                user_group_map = User_Group_Map(emp_id, emp_group.emp_group_id, auth.current_user().user_id)
                db.session.add(user_group_map)
                db.session.commit()

            resp_dict["status"] = True 
            resp_dict["msg"] = "Employee Group created successfully"
        else:
            emp_group.emp_group_name = emp_group_name
            emp_group.emp_group_desc = emp_group_desc
            emp_group.updated_by = auth.current_user().user_id
            emp_group.updated_date = datetime.datetime.now()
            db.session.commit()

            # Disable Role Record
            emp_group_role_maps = Employee_Group_Role_Map.query.filter(and_(Employee_Group_Role_Map.emp_group_id == emp_group.emp_group_id,
                                                                Employee_Group_Role_Map.status ==STATUS["ACTIVE"])).all()
            for emp_group_role_map in emp_group_role_maps:
                emp_group_role_map.status = STATUS["DEACTIVE"]
                emp_group_role_map.updated_date = datetime.datetime.now()
                db.session.commit()
            #Disable Employee Record
            user_group_maps = User_Group_Map.query.filter(and_(User_Group_Map.emp_group_id == emp_group.emp_group_id, 
                                                        User_Group_Map.status == STATUS["ACTIVE"])).all()
            for user_group_map in user_group_maps:
                user_group_map.status = STATUS["DEACTIVE"]
                user_group_map.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New Role 
            for role_id in role_id_list:
                emp_group_role_map = Employee_Group_Role_Map(emp_group.emp_group_id, role_id, auth.current_user().user_id)
                db.session.add(emp_group_role_map)
                db.session.commit()
            # Insert New Employee
            for emp_id in employee_id_list:
                user_group_map = User_Group_Map(emp_id, emp_group.emp_group_id, auth.current_user().user_id)
                db.session.add(user_group_map)
                db.session.commit()
                db.session.commit()
            resp_dict["status"] = True 
            resp_dict["msg"] = "Employee Group updated successfully"
        
    except Exception as e:
        logging.exception("create_update_employee_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("create_update_employee_group : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/group-employee-list', methods=['POST'])
@auth.login_required()
def group_employee_list():
    """Employee List"""
    logging.info("group_employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        emp_group_id = request.json.get("emp_group_id")

        employee_list = list()   
        users  = User.query.filter(and_(User.business_id == auth.current_user().business_id,
                                   User.is_employee == STATUS["YES"],
                                   User.status != STATUS["DELETE"]) ).all()   
        if not emp_group_id:
            for user in users:  
                user_group =  User_Group_Map.query.filter(and_(
                                            User_Group_Map.user_id == user.user_id,
                                            User_Group_Map.status == STATUS["ACTIVE"],
                                            User_Group_Map.emp_group_id == Employee_Group.emp_group_id,
                                            Employee_Group.status == STATUS["ACTIVE"]
                                            ) ).first()   
                if not user_group:
                    employee_dict = dict()  
                    employee_dict["employee_id"] = user.user_id
                    employee_dict["employee_name"] = user.name
                    employee_dict["designation"] = user.designation
                    employee_list.append(employee_dict)
        else:
            for user in users:  
                employee_dict = dict()    
                users_group =  User_Group_Map.query.filter(and_(User_Group_Map.emp_group_id == emp_group_id,
                                    Employee_Group.emp_group_id == emp_group_id,
                                    Employee_Group.status == STATUS["ACTIVE"],
                                    User_Group_Map.user_id == user.user_id,
                                    User_Group_Map.status == STATUS["ACTIVE"]) ).first()   
                if users_group:
                    employee_dict = dict()   
                    employee_dict["employee_id"] = user.user_id
                    employee_dict["employee_name"] = user.name
                    employee_dict["designation"] = user.designation
                    employee_list.append(employee_dict)
                else:
                    user_group =  User_Group_Map.query.filter(and_(
                                            User_Group_Map.user_id == user.user_id,
                                            User_Group_Map.status == STATUS["ACTIVE"],
                                            User_Group_Map.emp_group_id == Employee_Group.emp_group_id,
                                            Employee_Group.status == STATUS["ACTIVE"]
                                            ) ).first()   
                    if not user_group:
                        employee_dict = dict()   
                        employee_dict["employee_id"] = user.user_id
                        employee_dict["employee_name"] = user.name
                        employee_dict["designation"] = user.designation
                        employee_list.append(employee_dict)
                        
        resp_dict["status"] = True
        resp_dict["object"] = employee_list             
    except Exception as e:
        logging.error("group_employee_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("group_employee_list : end")
    return jsonify(resp_dict)

# Role list By Group
@user_blueprint.route("/api/role-list-by-employee-group", methods = ["POST"])
@auth.login_required()
def role_list_by_employee_group():
    logging.debug("role_list_by_employee_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        emp_group_id = request.json.get("emp_group_id")

        group_role_maps = Employee_Group_Role_Map.query.filter(
                        and_(Employee_Group_Role_Map.emp_group_id == emp_group_id,
                        Employee_Group_Role_Map.status == STATUS["ACTIVE"])).all()
        role_list = list()
        for group_role_map in group_role_maps:
            role_dict = dict()
            role = Role.query.filter(
                and_(
                    Role.status == STATUS["ACTIVE"],
                    Role.role_id == group_role_map.role_id
                    )).first()

            role_dict["role_id"] = role.role_id
            role_dict["role_name"]= role.role_name
            role_list.append(role_dict)

        resp_dict["status"] = True
        resp_dict["object"] = role_list
    except Exception as e:
        logging.exception("role_list_by_employee_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("role_list_by_employee_group : end")
    return jsonify(resp_dict) 

@user_blueprint.route("/api/employee-group-info", methods = ["POST"])
@auth.login_required()
def employee_group_info():
    logging.debug("employee_group_info: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        emp_group_id = request.json.get("emp_group_id")

        emp_group = Employee_Group.query.filter(and_(Employee_Group.emp_group_id == emp_group_id, Employee_Group.status == STATUS["ACTIVE"])).first()
        emp_group_dict = dict()
        if emp_group:
            
            emp_group_dict["emp_group_name"] = emp_group.emp_group_name
            emp_group_dict["emp_group_desc"] = emp_group.emp_group_desc

            user_group_maps = User_Group_Map.query.filter(and_(User_Group_Map.emp_group_id == emp_group.emp_group_id, 
                                                            User_Group_Map.status == STATUS["ACTIVE"])).all()
            
            employee_id_list = list()
            for user_group_map in user_group_maps:
                employee_id_list.append(user_group_map.user_id)
            emp_group_dict["employee_id_list"] = employee_id_list
                
                
            emp_group_role_maps = Employee_Group_Role_Map.query.filter(and_(Employee_Group_Role_Map.emp_group_id == emp_group.emp_group_id, 
                                                                                Employee_Group_Role_Map.status == STATUS["ACTIVE"])).all()
            role_id_list = list()
            for emp_group_role_map in emp_group_role_maps:
                role_id_list.append(emp_group_role_map.role_id)
            emp_group_dict["role_id_list"] = role_id_list

            resp_dict["object"] = emp_group_dict
            resp_dict["status"] = True    
        else:
            resp_dict["msg"] = "Record not found"    
          
    except Exception as e:
        logging.exception("employee_group_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("employee_group_info : end")
    return jsonify(resp_dict)

# Delete Group
@user_blueprint.route("/api/delete-group", methods = ["POST"])
@auth.login_required()
def delete_group():
    logging.debug("delete_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        emp_group_id = request.json.get("emp_group_id")
        employee_group = Employee_Group.query.filter(
            and_(
                Employee_Group.emp_group_id == emp_group_id,
                Employee_Group.status == STATUS["ACTIVE"],
                Employee_Group.business_id == auth.current_user().business_id
                )).first()
        if employee_group:
            employee_group.status = STATUS["DELETE"]
            employee_group.updated_date = datetime.datetime.now()
            db.session.commit()
            
            resp_dict["status"] = True
            resp_dict["msg"] = "Deleted successfully"            

    except Exception as e:
        logging.error("delete_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("delete_group : end")
    return jsonify(resp_dict)    

# Group List
@user_blueprint.route("/api/group-list", methods = ["POST"])
@auth.login_required()
def group_list():
    logging.debug("group_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        employee_groups = Employee_Group.query.filter(
            and_(
                Employee_Group.status != STATUS["DELETE"],
                Employee_Group.business_id == auth.current_user().business_id
                )).order_by(Employee_Group.emp_group_name.asc()).all()

        group_list = list()
        for group in employee_groups:
            group_dict = dict()
            group_dict["emp_group_id"] = group.emp_group_id
            group_dict["emp_group_name"] = group.emp_group_name
            group_dict["status"] = (True if group.status == STATUS["ACTIVE"] else False)
            group_list.append(group_dict)

        resp_dict["status"] = True
        resp_dict["object"] = group_list
        
    except Exception as e:
        logging.exception("group_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("group_list : end")
    return jsonify(resp_dict)

# Enable group
@user_blueprint.route("/api/enable-group", methods = ["POST"])
@auth.login_required()
def enable_group():
    logging.debug("enable_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:

        emp_group_id = request.json.get("emp_group_id")

        employee_group = Employee_Group.query.filter(
            and_(
                Employee_Group.emp_group_id == emp_group_id,
                Employee_Group.status != STATUS["DELETE"],
                Employee_Group.business_id == auth.current_user().business_id
                )).first()
        if employee_group:
            employee_group.status = STATUS["ACTIVE"]  
            employee_group.updated_date == datetime.datetime.now()
            db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Activated Sucessfully"
        
    except Exception as e:
        logging.exception("enable_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("enable_group : end")
    return jsonify(resp_dict)    

# Disable group
@user_blueprint.route("/api/disable-group", methods = ["POST"])
@auth.login_required()
def disable_group():
    logging.debug("disable_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:

        emp_group_id = request.json.get("emp_group_id")

        employee_group = Employee_Group.query.filter(
            and_(
                Employee_Group.emp_group_id == emp_group_id,
                Employee_Group.status != STATUS["DELETE"],
                Employee_Group.business_id == auth.current_user().business_id
                )).first()
        if employee_group:
            employee_group.status = STATUS["DEACTIVE"]  
            employee_group.updated_date == datetime.datetime.now()
            db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Deactivated Sucessfully"
        
    except Exception as e:
        logging.exception("disable_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("disable_group : end")
    return jsonify(resp_dict)

# Camera SetUp
# Search and Return List of Camera
@user_blueprint.route("/api/camera-search", methods=["POST"])
@auth.login_required()
def camera_search():
    """Camera search"""
    logging.debug("camera_search : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        username = request.json.get("username")
        password = request.json.get("password")
        ip_address = request.json.get("ip_address")
        port_no = request.json.get("port_no")
        camera_brand = request.json.get("camera_brand")

        # Input validation
        input_validation = ""
        if not username:
            input_validation = "User Name is required"
        elif not password:
            input_validation = "password is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not ip_address:
            ip_address = None
        if not port_no:
            port_no = None
        if not camera_brand:
            camera_brand = None
        
        resp_dict["status"] = True
        resp_dict["object"] = saferson.search(username, password, ip_address, port_no, camera_brand)
        
    except Exception as e:
        logging.error("camera_search : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("camera_search : end")
    return jsonify(resp_dict)

# Add Camera to db
@user_blueprint.route("/api/add-camera", methods=["POST"])
@auth.login_required()
def add_camera():
    """Add Camera"""
    logging.debug("add_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get("camera_name")
        rtsp_link = request.json.get("rtsp_link")
        username = request.json.get("username")
        password = request.json.get("password")
        is_checkin_checkout = request.json.get("is_checkin_checkout")
        is_exit = request.json.get("is_exit")

        # Input validation
        input_validation = ""
        if not camera_name:
            input_validation = "Camera name is required"
        elif not rtsp_link:
            input_validation = "Rtsp link is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not username:
            username=None
        if not password:
            password=None
        if not is_checkin_checkout:
            is_checkin_checkout = False
        if not is_exit:
            is_exit = False
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.add_camera(admin_mobile, camera_name, rtsp_link,  username, password, is_checkin_checkout, is_exit)
            
        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Camera added successfully"
        else:
            resp_dict["msg"] = resp
            
    except Exception as e:
        logging.error("add_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("add_camera : end")
    return jsonify(resp_dict)    

# Camera List
@user_blueprint.route("/api/camera-list", methods=["POST"])
@auth.login_required()
def camera_list():
    """Camera List"""
    logging.debug("camera_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict["object"] =  saferson.get_camera_list(admin_mobile)
    except Exception as e:
        logging.error("camera_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("camera_list: end")
    return jsonify(resp_dict)

# Edit Camera Details
@user_blueprint.route("/api/update-camera", methods=["POST"])
@auth.login_required()
def update_camera():
    """Update Camera"""
    logging.debug("update_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get("camera_name")
        rtsp_link = request.json.get("rtsp_link")
        username = request.json.get("username")
        password = request.json.get("password")
        old_camera_name = request.json.get("old_camera_name")
        is_checkin_checkout = request.json.get("is_checkin_checkout")
        is_exit = request.json.get("is_exit")

        # Input validation
        input_validation = ""
        if not camera_name:
            input_validation = "Camera name is required"
        elif not rtsp_link:
            input_validation = "Rtsp Link is required"
        elif not old_camera_name:
            input_validation = "Old Camera name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not is_checkin_checkout:
            is_checkin_checkout = False
        if not is_exit:
            is_exit = False    
        
        settings_dict = {"camera_name" : camera_name, "rtsp_link" : rtsp_link, "is_checkin_checkout": is_checkin_checkout, "is_exit":is_exit}
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.update_camera_settings(admin_mobile, old_camera_name, settings_dict)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Camera updated successfully"
        else:
            resp_dict["msg"] = resp
            
    except Exception as e:
        logging.error("update_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("update_camera : end")
    return jsonify(resp_dict)

# Delete Camera
@user_blueprint.route("/api/delete-camera", methods=["POST"])
@auth.login_required()
def delete_camera():
    """Delete Camera"""
    logging.debug("delete_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get("camera_name")

        if not camera_name:
            resp_dict["msg"] = "Camera name is required"
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.delete_camera_v2(admin_mobile, camera_name)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Deleted successfully"
        else:
            resp_dict["msg"] = resp
            
    except Exception as e:
        logging.error("delete_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("delete_camera: end")
    return jsonify(resp_dict)    

# Camera Info
@user_blueprint.route("/api/camera-info", methods=["POST"])
@auth.login_required()
def camera_info():
    """Camera Info"""
    logging.debug("camera_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get("camera_name")
        if not camera_name:
            resp_dict["msg"] = "Camera name is required"
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict["object"] = saferson.get_camera_info(admin_mobile, camera_name)
    except Exception as e:
        logging.error("camera_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("camera_info : end")
    return jsonify(resp_dict)

#Return Snapshot from selected Camera
@user_blueprint.route("/api/camera-snapshot", methods=["POST"])
@auth.login_required()
def camera_snapshot():
    """Camera Snapshot"""
    logging.debug("camera_snapshot : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        ip_url = request.json.get("ip_url")

        if not ip_url:
            resp_dict["msg"] = "Ip url is required"
            return jsonify(resp_dict)

        resp_dict["status"] = True
        resp_dict["object"] = saferson.get_snapshot(ip_url)
        
    except Exception as e:
        logging.error("camera_snapshot : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("camera_snapshot : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/add-floor", methods=["POST"])
@auth.login_required()
def add_floor():
    """Add Floor"""
    logging.info("add_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_name = request.json.get("floor_name")
        camera_name_list = request.json.get("camera_name_list")

        # Input validation
        input_validation = ""
        if not floor_name:
            input_validation = "Floor name is required"
        elif not camera_name_list:
            input_validation = "Choose at lease one camera"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.add_floor(admin_mobile, camera_name_list, floor_name)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Floor saved successfully"
        else:
            resp_dict["msg"] = resp
            
    except Exception as e:
        logging.error("add_floor : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("add_floor : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/update-floor", methods=["POST"])
@auth.login_required()
def update_floor():
    """Add Floor"""
    logging.info("update_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_names = request.json.get("floor_names")
        list_camera_names = request.json.get("list_camera_names")

        input_validation = ""
        if not floor_names:
            input_validation = "Floor name is required"
        elif not list_camera_names:
            input_validation = "Choose at lease one camera"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        admin_mobile = get_admin_mobile(auth.current_user())
        for index, floor_name in enumerate(floor_names):
            camera_name_tuple =  tuple(list_camera_names[index])
            saferson.update_camera_floor(admin_mobile, camera_name_tuple, floor_name)

        resp_dict["status"] = True
        resp_dict["msg"] = "Updated successfully"
        
    except Exception as e:
        logging.error("update_floor : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("update_floor : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/floor-list", methods=["POST"])
@auth.login_required()
def floor_list():
    """Floor Listing"""
    logging.info("floor_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict["object"] = saferson.get_floor_details(admin_mobile)

    except Exception as e:
        logging.error("floor_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("floor_list : end")
    return jsonify(resp_dict)

# Model SetUp
# Module List
@user_blueprint.route("/api/module-list", methods=["POST"])
@auth.login_required()
def module_list():
    logging.debug("module_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        modules = Module.query.filter(Module.status == STATUS["ACTIVE"]).all()
        module_list = list()
        for module in modules: 
            module_dict = dict()
            module_dict["Module_id"] = module.module_id
            module_dict["Module_name"] = module.module_name
            module_dict["status"] = False

            module_functions = Module_Function.query.filter(Module_Function.module_id == module.module_id).all()
            for module_function in module_functions:
                module_function_config = Module_Function_Config.query.filter(and_(
                    Module_Function_Config.business_id == auth.current_user().business_id,
                    Module_Function_Config.function_id == module_function.function_id,
                    Module_Function_Config.status == STATUS["ACTIVE"]
                    )).first()
                if module_function_config:
                    module_dict["status"] = True

                if module_function.function_id == 11:
                    activity_group_config =  Activity_Group_Config.query.filter(and_(
                        Activity_Group_Config.business_id == auth.current_user().business_id,
                        Activity_Group_Config.status == STATUS["ACTIVE"]
                    )).first()
                    if activity_group_config:
                        module_dict["status"] = True
            module_list.append(module_dict)

        resp_dict["status"] = True
        resp_dict["object"] = module_list
        
    except Exception as e:
        logging.exception("module_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("module_list : end")
    return jsonify(resp_dict)

# Function Listings
@user_blueprint.route("/api/module-function-list", methods = ["POST"])
@auth.login_required()
def module_function_list():
    logging.debug("module_function_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        module_id = request.json.get("module_id")

        if not module_id:
            resp_dict["msg"] = "Select at least one module"
            return jsonify(resp_dict)

        functions = Module_Function.query.filter(and_(Module_Function.module_id == module_id, Module_Function.status == STATUS["ACTIVE"])).all()
        function_list = list()
        for function in functions:
            function_dict = dict()
            function_dict["function_id"] = function.function_id
            function_dict["function_name"] = function.function_name
            function_dict["status"] = False
            
            module_function_config = Module_Function_Config.query.filter(and_(
                Module_Function_Config.business_id == auth.current_user().business_id,
                Module_Function_Config.function_id == function.function_id,
                Module_Function_Config.status == STATUS["ACTIVE"]
                )).first()
            if module_function_config:
                function_dict["status"] = True

            if function.function_id == 11:
                activity_group_config =  Activity_Group_Config.query.filter(and_(
                    Activity_Group_Config.business_id == auth.current_user().business_id,
                    Activity_Group_Config.status == STATUS["ACTIVE"]
                )).first()
                if activity_group_config:
                    function_dict["status"] = True
           
            function_list.append(function_dict)

        resp_dict["status"] = True
        resp_dict["object"] = function_list
        
    except Exception as e:
        logging.exception("module_function_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("module_function_list : end")
    return jsonify(resp_dict)

# Configuration List
@user_blueprint.route("/api/config-list", methods=["POST"])
@auth.login_required()
def config_list():
    """Configuration List"""
    logging.debug("config_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")

        module_function_configs = Module_Function_Config.query.filter(
            and_(
                Module_Function_Config.function_id  == function_id,
                Module_Function_Config.business_id == auth.current_user().business_id)).all()
        config_list = list()                                            
        if module_function_configs:                                            
            for module_function_config in module_function_configs:
                config_dict = dict()
                config_dict["config_id"] = module_function_config.config_id 
                config_dict["config_name"] = module_function_config.config_name
                config_dict["status"] = module_function_config.status 
                config_list.append(config_dict) 
        resp_dict["status"] = True
        resp_dict["object"] = config_list   
    except Exception as e:
        logging.error("config_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("config_list : end")
    return jsonify(resp_dict) 

# Common Configuration Method
def configuration(function_id, config_name,  message, mode, config_type, emp_group_id = 0,  employee_ids = [], comm_employee_ids = [], config_id = 0, camera_list = []):
    logging.debug("configuration : start")
    try:
        default_config_id = 0
        error_msg = ""
        
        module_function_config = Module_Function_Config.query.filter(
            and_(
                Module_Function_Config.config_id == config_id,
                Module_Function_Config.function_id == function_id,
                Module_Function_Config.business_id == auth.current_user().business_id
                )).first()
        
        if module_function_config:
            if module_function_config.status == STATUS["DEACTIVE"]:    # Deactive Config can updated condtions
                if config_type == CONFIG_TYPE["GROUP"] and emp_group_id:
                        module_function_config_map = Module_Function_Config_Map.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config_Map.config_id != module_function_config.config_id,
                                Module_Function_Config_Map.entity_id == emp_group_id,
                                Module_Function_Config_Map.status == STATUS["ACTIVE"])).first()
                        if module_function_config_map:
                            employee_group = Employee_Group.query.get(module_function_config_map.entity_id)
                            error_msg = "{} - Group is alredy active in another config can't update.".format(employee_group.emp_group_name)
                            return default_config_id, error_msg
                            
                elif config_type == CONFIG_TYPE["EMPLOYEE"] and employee_ids:
                    for employee_id in employee_ids:
                        module_function_config_map = Module_Function_Config_Map.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                Module_Function_Config_Map.config_id != module_function_config.config_id,
                                Module_Function_Config_Map.entity_id == employee_id,
                                Module_Function_Config_Map.status == STATUS["ACTIVE"]
                            )).first()
                        if module_function_config_map:
                            employee = User.query.get(module_function_config_map.entity_id)
                            error_msg = "{} - Employee is already active in another config can't update.".format(employee.name)
                            return default_config_id, error_msg
                
                # Camera Check in use for camera_list
                if function_id in ["5" , 5]:
                    for camera_id in camera_list:
                        unauthorized_access_config = Unauthorized_Access_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Unauthorized_Access_Config.config_id,
                                Unauthorized_Access_Config.config_id != module_function_config.config_id,
                                Unauthorized_Access_Config.camera_id == camera_id,
                                Unauthorized_Access_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if unauthorized_access_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == unauthorized_access_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg
                    
                elif function_id in ["6" , 6]:
                    for camera_id in camera_list:
                        mask_compliance_config = Mask_Compliance_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Mask_Compliance_Config.config_id,
                                Mask_Compliance_Config.config_id != module_function_config.config_id,
                                Mask_Compliance_Config.camera_id == camera_id,
                                Mask_Compliance_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if mask_compliance_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == mask_compliance_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg

                elif function_id in ["7" , 7]:
                    for camera_id in camera_list:
                        social_distancing_config = Social_Distancing_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Social_Distancing_Config.config_id,
                                Social_Distancing_Config.config_id != module_function_config.config_id,
                                Social_Distancing_Config.camera_id == camera_id,
                                Social_Distancing_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if social_distancing_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == social_distancing_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg                    
                    
                elif function_id in ["8" , 8]:
                    for camera_id in camera_list:
                        safety_gear_config = Safety_Gear_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Safety_Gear_Config.config_id,
                                Safety_Gear_Config.config_id != module_function_config.config_id,
                                Safety_Gear_Config.camera_id == camera_id,
                                Safety_Gear_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if safety_gear_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg
                elif function_id in ["9" , 9]:
                    for camera_id in camera_list:
                        safety_gear_config = Food_Temperature_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Food_Temperature_Config.config_id,
                                Food_Temperature_Config.config_id != module_function_config.config_id,
                                Food_Temperature_Config.camera_id == camera_id,
                                Food_Temperature_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if safety_gear_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg
                elif function_id in ["10" , 10]:
                    for camera_id in camera_list:
                        safety_gear_config = Food_IdleTime_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.config_id == Food_IdleTime_Config.config_id,
                                Food_IdleTime_Config.config_id != module_function_config.config_id,
                                Food_IdleTime_Config.camera_id == camera_id,
                                Food_IdleTime_Config.status == STATUS["ACTIVE"]
                                )).first()
                        if safety_gear_config:
                            camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                            error_msg = "{} - Camera is already active in another config can't update.".format(camera.camera_name)
                            return default_config_id, error_msg
                                    
            module_function_config.status = STATUS["ACTIVE"]
            module_function_config.config_name = config_name
            module_function_config.config_type = config_type
            module_function_config.updated_by = auth.current_user().user_id
            module_function_config.updated_date = datetime.datetime.now()
            db.session.commit()

            default_config_id = module_function_config.config_id
            logging.info("Update : Config ID - {}".format(module_function_config.config_id))
            
            # Disable Old Config Map
            module_function_config_maps = Module_Function_Config_Map.query.filter(
                and_(
                    Module_Function_Config_Map.config_id == module_function_config.config_id,
                    Module_Function_Config_Map.status == STATUS["ACTIVE"]
                )).all()
            
            for row in module_function_config_maps:
                row.status = STATUS["DEACTIVE"]
                row.updated_date = datetime.datetime.now()
                db.session.commit()
              
            # Insert New Config Map
            if config_type == CONFIG_TYPE["GROUP"] and emp_group_id:
                module_function_config_map = Module_Function_Config_Map(module_function_config.config_id, emp_group_id)
                db.session.add(module_function_config_map)
                db.session.commit()

            elif config_type == CONFIG_TYPE["EMPLOYEE"] and employee_ids:
                for employee_id in employee_ids:
                    module_function_config_map = Module_Function_Config_Map(module_function_config.config_id, employee_id)
                    db.session.add(module_function_config_map)
                    db.session.commit()

            # Update Comm Config 
            module_function_comm_config = Module_Function_Comm_Config.query.filter(
                and_(
                    Module_Function_Comm_Config.config_id == module_function_config.config_id,
                    Module_Function_Comm_Config.status == STATUS["ACTIVE"] 
                )).first()
            modes = ",".join(mode)
            if module_function_comm_config:
                module_function_comm_config.mode = modes
                module_function_comm_config.message = message
                module_function_comm_config.updated_by = auth.current_user().user_id
                module_function_comm_config.updated_date = datetime.datetime.now()
                db.session.commit()
  
                # Disable Comm Config Map
                module_function_comm_config_maps = Module_Function_Comm_Config_Map.query.filter(
                    and_(
                        Module_Function_Comm_Config_Map.comm_config_id == module_function_comm_config.comm_config_id,
                        Module_Function_Comm_Config_Map.status == STATUS["ACTIVE"]
                    )).all()
                    
                for comm_row in module_function_comm_config_maps:
                    comm_row.status = STATUS["DEACTIVE"]
                    comm_row.updated_date = datetime.datetime.now()
                    db.session.commit()

                # Insert Comm Config Map
                if comm_employee_ids:
                    for comm_employee_id in comm_employee_ids:
                        module_function_comm_config_map = Module_Function_Comm_Config_Map(module_function_comm_config.comm_config_id, comm_employee_id)
                        db.session.add(module_function_comm_config_map)
                        db.session.commit()
        else:
            # New Function
            # Config insertion
            module_function_config = Module_Function_Config(auth.current_user().business_id, function_id, config_name, config_type, auth.current_user().user_id)
            db.session.add(module_function_config)
            db.session.commit()

            default_config_id = module_function_config.config_id
            logging.info("Insert : Config ID - {}".format(module_function_config.config_id))

            # Config Map insertion
            if config_type == CONFIG_TYPE["GROUP"] and emp_group_id:
                module_function_config_map = Module_Function_Config_Map(module_function_config.config_id, emp_group_id)
                db.session.add(module_function_config_map)
                db.session.commit()
            elif config_type == CONFIG_TYPE["EMPLOYEE"] and employee_ids:   
                for employee_id in employee_ids:
                    module_function_config_map = Module_Function_Config_Map(module_function_config.config_id, employee_id)
                    db.session.add(module_function_config_map)
                    db.session.commit()

            # Communication insertion
            modes = ",".join(mode)
            module_function_comm_config = Module_Function_Comm_Config(module_function_config.config_id, message, modes, auth.current_user().user_id)
            db.session.add(module_function_comm_config)
            db.session.commit()
            
            # Communication Map insertion
            for comm_employee_id in comm_employee_ids:
                module_function_comm_config_map = Module_Function_Comm_Config_Map(module_function_comm_config.comm_config_id, comm_employee_id)
                db.session.add(module_function_comm_config_map)
                db.session.commit()
                
    except Exception as e:
        logging.error("configuration : exception : {}".format(e))
    logging.debug("configuration : end")
    return default_config_id, error_msg

# Checkin Checkout Configuration
@user_blueprint.route("/api/checkin-checkout-configuration", methods=["POST"])
@auth.login_required()
def checkin_checkout_configuration():
    """checkin_checkout_configuration"""
    logging.debug("checkin_checkout_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        check_in = request.json.get("check_in")
        check_out = request.json.get("check_out")
        notification_delay = request.json.get("notification_delay")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        config_type = request.json.get("config_type")
        employee_ids = request.json.get("employee_ids")  
        emp_group_id = request.json.get("emp_group_id")  

        input_validation = ""
    
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not check_in and not check_out:
            input_validation = "Select atleast one Check In or Check Out"  
        elif not notification_delay:
            input_validation = "Notification delay is required"
        elif not config_name:
            input_validation = "Configuration Name is required"    

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        if not config_type:
            resp_dict["msg"] = "Config Type is required"
            return jsonify(resp_dict)

        if config_type == CONFIG_TYPE["EMPLOYEE"]:
            if not employee_ids:
                resp_dict["msg"] = "Choose atleast one Employee"
                return jsonify(resp_dict)
        if config_type == CONFIG_TYPE["GROUP"]:
            if not emp_group_id:
                resp_dict["msg"] = "Group is required"
                return jsonify(resp_dict)        

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee Id"
            return jsonify(resp_dict)
        
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)
                
        check_in = (STATUS["YES"] if check_in else STATUS["NO"])
        check_out = (STATUS["YES"] if check_out else STATUS["NO"])
        camera_list = []

        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
        
        checkin_checkout_config = Checkin_Checkout_Config.query.filter(Checkin_Checkout_Config.config_id == get_config_id).first()
        if checkin_checkout_config:
            checkin_checkout_config.checkin = check_in
            checkin_checkout_config.checkout = check_out
            checkin_checkout_config.notification_delay = notification_delay
            checkin_checkout_config.updated_date = datetime.datetime.now()
            db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            checkin_checkout_config = Checkin_Checkout_Config(get_config_id, check_in, check_out, notification_delay)
            db.session.add(checkin_checkout_config)
            db.session.commit()
        
            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("checkin_checkout_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("checkin_checkout_configuration : end")
    return jsonify(resp_dict)  

# Unauthorized Access Configuration
@user_blueprint.route("/api/unauthorized-access-configuration", methods=["POST"])
@auth.login_required()
def unauthorized_access_configuration():
    """unauthorized-access"""
    logging.debug("unauthorized_access_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        employee_ids = request.json.get("employee_ids")
        camera_id_list = request.json.get("camera_id_list")
        comm_employee_ids = request.json.get("comm_employee_ids")
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        config_type = request.json.get("config_type")
        emp_group_id = request.json.get("emp_group_id")
        time_slot_status  =  request.json.get("time_slot_status")
        slots_list = request.json.get("slots_list")

        input_validation = ""
    
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"        
        elif not camera_id_list:
            input_validation = "Choose at least one camera"
                    
        elif not config_name:
            input_validation = "Configuration Name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if config_type == CONFIG_TYPE["EMPLOYEE"]:
            if not employee_ids:
                resp_dict["msg"] = "Choose atleast one Employee"
                return jsonify(resp_dict)
        if config_type == CONFIG_TYPE["GROUP"]:
            if not emp_group_id:
                resp_dict["msg"] = "Group is required"
                return jsonify(resp_dict) 

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)    
            
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)

        if time_slot_status:
            if not slots_list:
                resp_dict["msg"] = "Atleast one Time solt is required"
                return jsonify(resp_dict)
            if slots_list:
                for slot in slots_list:
                    if not slot["start_time"]:
                        resp_dict["msg"] = "Start time is required"
                        return jsonify(resp_dict)
                    elif not slot["end_time"]:
                        resp_dict["msg"] = "End time is required"
                        return jsonify(resp_dict)
        
        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id,employee_ids, comm_employee_ids, config_id, camera_id_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)

        unauthorized_access_configs = Unauthorized_Access_Config.query.filter(
            and_(
                Unauthorized_Access_Config.config_id == get_config_id,
                Unauthorized_Access_Config.status == STATUS["ACTIVE"])).all()
        if unauthorized_access_configs:

            # Disable Old
            for unauthorized_access_config in unauthorized_access_configs:
                unauthorized_access_config.status = STATUS["DEACTIVE"]
                unauthorized_access_config.updated_date = datetime.datetime.now()
                db.session.commit()
            
            time_solts = Unauthorized_Timeslot.query.filter(
                and_(
                    Unauthorized_Timeslot.config_id == get_config_id,
                    Unauthorized_Timeslot.status == STATUS["ACTIVE"]) ).all()
            if time_solts:
                for slot in time_solts:
                    slot.status = STATUS["DEACTIVE"]  
                    slot.updated_date = datetime.datetime.now()
                    db.session.commit()

            # Insert New
            for camera_id in camera_id_list:
                unauthorized_access_config = Unauthorized_Access_Config(get_config_id, camera_id)
                unauthorized_access_config.is_time_slot = time_slot_status
                db.session.add(unauthorized_access_config)
                db.session.commit()

            for slot in slots_list:    
                time_slot = Unauthorized_Timeslot( get_config_id, slot["start_time"], slot["end_time"])
                db.session.add(time_slot)
                db.session.commit()    

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            # Insert New
            for camera_id in camera_id_list:
                unauthorized_access_config = Unauthorized_Access_Config(get_config_id, camera_id)
                unauthorized_access_config.is_time_slot = time_slot_status
                db.session.add(unauthorized_access_config)
                db.session.commit()

            for slot in slots_list:    
                time_slot = Unauthorized_Timeslot( get_config_id, slot["start_time"], slot["end_time"])
                db.session.add(time_slot)
                db.session.commit()   
            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("unauthorized_access_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("unauthorized_access_configuration: end")
    return jsonify(resp_dict)

# Mask Complaince Configuration
@user_blueprint.route("/api/mask-compliance-configuration", methods=["POST"])
@auth.login_required()
def mask_compliance_configuration():
    """mask_compliance_configuration"""
    logging.debug("mask_compliance_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        # employee_ids = request.json.get("employee_ids")
        camera_id_list = request.json.get("camera_id_list")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        # config_type = request.json.get("config_type")
        # emp_group_id = request.json.get("emp_group_id")
        
        input_validation = ""
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not camera_id_list:
            input_validation = "Choose at least one camera"
        elif not config_name:
            input_validation = "Configuration Name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        # if config_type == CONFIG_TYPE["EMPLOYEE"]:
        #     if not employee_ids:
        #         resp_dict["msg"] = "Choose atleast one Employee"
        #         return jsonify(resp_dict)
        # if config_type == CONFIG_TYPE["GROUP"]:
        #     if not emp_group_id:
        #         resp_dict["msg"] = "Group is required"
        #         return jsonify(resp_dict) 
        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)

        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_id_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
       
        mask_complaince_configs = Mask_Compliance_Config.query.filter(
            and_(
                Mask_Compliance_Config.config_id == get_config_id,
                Mask_Compliance_Config.status == STATUS["ACTIVE"])).all()
        if mask_complaince_configs:
            # Disbale Old
            for mask_complaince_config in mask_complaince_configs:
                mask_complaince_config.status = STATUS["DEACTIVE"]
                mask_complaince_config.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New
            for camera_id in camera_id_list:
                mask_complaince_config = Mask_Compliance_Config(get_config_id, camera_id)
                db.session.add(mask_complaince_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            # Insert New
            for camera_id in camera_id_list:
                mask_complaince_config = Mask_Compliance_Config(get_config_id, camera_id)
                db.session.add(mask_complaince_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("mask_compliance_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("mask_compliance_configuration: end")
    return jsonify(resp_dict)

# Safety Gear Configuration
@user_blueprint.route("/api/safety-gear-configuration", methods=["POST"])
@auth.login_required()
def safety_gear_configuration():
    """safety-gear-Config"""
    logging.debug("safety_gear_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        employee_ids = request.json.get("employee_ids")
        camera_id_list = request.json.get("camera_id_list")
        safety_kit_list = request.json.get("safety_kit_list")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        config_type = request.json.get("config_type")
        emp_group_id = request.json.get("emp_group_id")
        input_validation = ""
    
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not camera_id_list:
            input_validation  = "Choose at least one camera"    
        elif not safety_kit_list:
            input_validation  = "Choode at lease one safety kit"

        elif not config_name:
            input_validation = "Configuration Name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if config_type == CONFIG_TYPE["EMPLOYEE"]:
            if not employee_ids:
                resp_dict["msg"] = "Choose atleast one Employee"
                return jsonify(resp_dict)
        if config_type == CONFIG_TYPE["GROUP"]:
            if not emp_group_id:
                resp_dict["msg"] = "Group is required"
                return jsonify(resp_dict) 

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)    
            
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)
        
        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id,employee_ids, comm_employee_ids, config_id, camera_id_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
        
        safety_gear_configs = Safety_Gear_Config.query.filter(
            and_(
                Safety_Gear_Config.config_id == get_config_id,
                Safety_Gear_Config.status == STATUS["ACTIVE"])).all()
        if safety_gear_configs:
            # Disable Old
            for safety_gear_config in safety_gear_configs:
                safety_gear_config.status = STATUS["DEACTIVE"]
                safety_gear_config.updated_date = datetime.datetime.now()
                db.session.commit()
            # Insert New
            for camera_id in camera_id_list:
                safety_gear_config = Safety_Gear_Config(get_config_id, camera_id,",".join(safety_kit_list))
                db.session.add(safety_gear_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            # New Insertion
            for camera_id in camera_id_list:
                safety_gear_config = Safety_Gear_Config(get_config_id, camera_id,",".join(safety_kit_list))
                db.session.add(safety_gear_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("safety_gear_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("safety_gear_configuration : end")
    return jsonify(resp_dict)

# Schedule Mismatch Breaktime  Configuration
@user_blueprint.route("/api/schedule-mismatch-breaktime-configuration", methods=["POST"])
@auth.login_required()
def schedule_mismatch_breaktime_configuration():
    """schedule_mismatch_breaktime_configuration"""
    logging.debug("schedule_mismatch_breaktime_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        employee_ids = request.json.get("employee_ids")
        weeks_list = request.json.get("weeks_list")
        comm_employee_ids = request.json.get("comm_employee_ids")
        message = request.json.get("message")
        modes = request.json.get("mode")
        notification_delay = request.json.get("notification_delay")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        config_type = request.json.get("config_type")
        emp_group_id = request.json.get("emp_group_id")
        input_validation = ""
    
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not notification_delay:
            input_validation = "Notification Delay is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        if config_type == CONFIG_TYPE["EMPLOYEE"]:
            if not employee_ids:
                resp_dict["msg"] = "Choose atleast one Employee"
                return jsonify(resp_dict)
        if config_type == CONFIG_TYPE["GROUP"]:
            if not emp_group_id:
                resp_dict["msg"] = "Group is required"
                return jsonify(resp_dict) 

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)    
        
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)
        
        camera_list = []
        
        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
       
        schedule_mismatch_configs = Schedule_Mismatch_Breaktime_Config.query.filter(
            and_(
                Schedule_Mismatch_Breaktime_Config.config_id == get_config_id,
                Schedule_Mismatch_Breaktime_Config.status == STATUS["ACTIVE"])).all()
        if schedule_mismatch_configs:
            # Disable Old
            for schedule_mismatch_config in schedule_mismatch_configs:
                schedule_mismatch_config.status = STATUS["DEACTIVE"]
                schedule_mismatch_config.updated_date = datetime.datetime.now()
                db.session.commit()

                schedules = Schedule_Config.query.filter(Schedule_Config.config_seq_id == schedule_mismatch_config.config_seq_id).all()
                for schedule in schedules:
                    schedule.status = STATUS["DEACTIVE"]
                    schedule.updated_date = datetime.datetime.now()
                    db.session.commit()

                    breaks = Breaktime_Config.query.filter(Breaktime_Config.schedule_config_seq_id == schedule.schedule_config_seq_id).all()
                    for break_c in breaks:
                        break_c.updated_date = datetime.datetime.now()
                        break_c.status = STATUS["DEACTIVE"]
                        db.session.commit()

            # Insert New
            for week in weeks_list:
                schedule_mismatch_config = Schedule_Mismatch_Breaktime_Config(get_config_id, week["start_date"], (week["end_date"] if week["end_date"] else None), notification_delay)
                db.session.add(schedule_mismatch_config)
                db.session.commit()

                for schedule in week["schedules"]:
                    schedule_config = Schedule_Config(schedule_mismatch_config.config_seq_id, ",".join(schedule["days"]), schedule["start_time"], schedule["end_time"])
                    db.session.add(schedule_config)
                    db.session.commit()

                    for break_time in schedule["break_time_config"]:
                        f_start_time = (None if (break_time["f_start_time"][0:5] == "00:00" or not break_time["time_frame_status"]) else break_time["f_start_time"])
                        f_end_time = (None if (break_time["f_end_time"][0:5] == "00:00" or not break_time["time_frame_status"]) else break_time["f_end_time"] )
                        breaktime_config = Breaktime_Config(schedule_config.schedule_config_seq_id, break_time["break_name"], break_time["duration"], 
                                                            break_time["no_of_times"], f_start_time, f_end_time)
                        db.session.add(breaktime_config)
                        db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"

        else:
            for week in weeks_list:
                schedule_mismatch_config = Schedule_Mismatch_Breaktime_Config(get_config_id, week["start_date"],  (week["end_date"] if week["end_date"] else None), notification_delay)
                db.session.add(schedule_mismatch_config)
                db.session.commit()

                for schedule in week["schedules"]:
                    schedule_config = Schedule_Config(schedule_mismatch_config.config_seq_id, ",".join(schedule["days"]), schedule["start_time"], schedule["end_time"])
                    db.session.add(schedule_config)
                    db.session.commit()

                    for break_time in schedule["break_time_config"]:
                        f_start_time = (None if (break_time["f_start_time"][0:5] == "00:00" or not break_time["time_frame_status"]) else break_time["f_start_time"])
                        f_end_time = (None if (break_time["f_end_time"][0:5] == "00:00" or not break_time["time_frame_status"]) else break_time["f_end_time"] )
                        breaktime_config = Breaktime_Config(schedule_config.schedule_config_seq_id, break_time["break_name"], break_time["duration"],
                                                            break_time["no_of_times"], f_start_time, f_end_time)
                        db.session.add(breaktime_config)
                        db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("schedule_mismatch_breaktime_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("schedule_mismatch_breaktime_configuration : end")
    return jsonify(resp_dict)

# Food Temperature Configuration
@user_blueprint.route("/api/food-temperature-configuration", methods=["POST"])
@auth.login_required()
def food_temperature_configuration():
    """food_temperature_configuration"""
    logging.debug("food_temperature_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        camera_id_list = request.json.get("camera_id_list")
        low_temp = request.json.get("low_temp")
        high_temp = request.json.get("high_temp")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        
        
        input_validation = ""
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not camera_id_list:
            input_validation = "Choose at least one camera"
        elif not config_name:
            input_validation = "Configuration Name is required"
        elif not low_temp:
            input_validation = "Unsafe Food Temperature Low is required"
        elif not high_temp:
            input_validation = "Unsafe Food Temperature High is required"
        elif not temperature_validation(low_temp):
            input_validation = "Valid Low Temperature is required"
        elif not temperature_validation(high_temp):
            input_validation = "Valid High Temperature is required"   

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)
                
        employee_ids = []
        config_type = ""
        emp_group_id = 0
        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_id_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
       
        food_temp_configs = Food_Temperature_Config.query.filter(
            and_(
                Food_Temperature_Config.config_id == get_config_id,
                Food_Temperature_Config.status == STATUS["ACTIVE"])).all()
        if food_temp_configs:
            # Disbale Old
            for food_temp in food_temp_configs:
                food_temp.status = STATUS["DEACTIVE"]
                food_temp.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New
            for camera_id in camera_id_list:
                food_temp_config = Food_Temperature_Config(get_config_id, camera_id, low_temp, high_temp)
                db.session.add(food_temp_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            # Insert New
            for camera_id in camera_id_list:
                food_temp_config = Food_Temperature_Config(get_config_id, camera_id, low_temp, high_temp)
                db.session.add(food_temp_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("food_temperature_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("food_temperature_configuration: end")
    return jsonify(resp_dict)

# Food Idel Time Configuration
@user_blueprint.route("/api/food-idletime-configuration", methods=["POST"])
@auth.login_required()
def food_idletime_configuration():
    """food_idletime_configuration"""
    logging.debug("food_idletime_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        camera_id_list = request.json.get("camera_id_list")
        idle_thresold = request.json.get("idle_thresold")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
    
        
        input_validation = ""
    
        if not function_id:
            input_validation = "Function Id is required"
        elif not idle_thresold:
            input_validation = "Food Tray Idle Time Thresold is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not camera_id_list:
            input_validation = "Choose at least one camera"
        elif not config_name:
            input_validation = "Configuration Name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee "
            return jsonify(resp_dict)
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)

        employee_ids = []
        config_type = ""
        emp_group_id = 0

        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_id_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
       
        food_idletime_configs = Food_IdleTime_Config.query.filter(
            and_(
                Food_IdleTime_Config.config_id == get_config_id,
                Food_IdleTime_Config.status == STATUS["ACTIVE"])).all()
        if food_idletime_configs:
            # Disbale Old
            for food_idletime_config in food_idletime_configs:
                food_idletime_config.status = STATUS["DEACTIVE"]
                food_idletime_config.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New
            for camera_id in camera_id_list:
                food_idletime_config = Food_IdleTime_Config(get_config_id, camera_id, idle_thresold)
                db.session.add(food_idletime_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
        else:
            # Insert New
            for camera_id in camera_id_list:
                food_idletime_config = Food_IdleTime_Config(get_config_id, camera_id, idle_thresold)
                db.session.add(food_idletime_config)
                db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("food_idletime_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("food_idletime_configuration: end")
    return jsonify(resp_dict)

#Activity Group- User activity List
@user_blueprint.route("/api/user-activity-list", methods=["POST"])
@auth.login_required()
def user_activity_list():
    logging.debug("user_activity_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activities = Activity_Master.query.filter(Activity_Master.status == STATUS["ACTIVE"]).all()
        activity_list = list()
        for activity in activities:
            activity_dict = dict()
            activity_dict["activity_id"] = str(activity.activity_id)
            activity_dict["activity_name"] = activity.activity_name
            activity_list.append(activity_dict)

        resp_dict["status"] = True
        resp_dict["object"] = activity_list
          
    except Exception as e:
        logging.error("user_activity_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("user_activity_list: end")
    return jsonify(resp_dict)

#Activity Group Configuration
@user_blueprint.route("/api/activity-group-config", methods=["POST"])
@auth.login_required()
def activity_group_config():
    logging.debug("activity_group_config : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_group_id = request.json.get("activity_group_id")
        activity_group_name = request.json.get("activity_group_name")
        activity_ids= request.json.get("activity_ids")
        
        input_validation = ""
        if not activity_group_name:
            input_validation = "Activity Group Name is required"
        elif not activity_ids:
            input_validation = "Choose atlease one Activity"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        activity = Activity_Group_Config.query.get(activity_group_id)
        if not activity:
            group_activity = Activity_Group_Config(activity_group_name, ",".join(activity_ids), auth.current_user().business_id)
            db.session.add(group_activity)
            db.session.commit()
            resp_dict["status"] = True
            resp_dict["msg"] = "Activity Group saved successfully"
            
        else:
            activity.activity_group_name = activity_group_name
            activity.activity_ids = ",".join(activity_ids)
            activity.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict["status"] = True
            resp_dict["msg"] = "Activity Group updated successfully"
          
    except Exception as e:
        logging.error("activity_group_config : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("activity_group_config: end")
    return jsonify(resp_dict)

#Activity Group Configuration list
@user_blueprint.route("/api/activity-group-config-list", methods=["POST"])
@auth.login_required()
def activity_group_config_list():
    logging.debug("activity_group_config_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_groups = Activity_Group_Config.query.filter(Activity_Group_Config.business_id == auth.current_user().business_id).all()
        activity_group_list = list()
        for activity_group in activity_groups:
            activity_group_dict = dict()
            activity_group_dict["activity_group_id"] = activity_group.activity_group_id
            activity_group_dict["activity_group_name"] = activity_group.activity_group_name
            activity_group_dict["status"] = activity_group.status
            activity_group_list.append(activity_group_dict)

        resp_dict["status"] = True
        resp_dict["object"] = activity_group_list
        
    except Exception as e:
        logging.error("activity_group_config_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("activity_group_config_list: end")
    return jsonify(resp_dict)
    
@user_blueprint.route("/api/activity-group-list", methods=["POST"])
@auth.login_required()
def activity_group_list():
    logging.debug("activity_group_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_groups = Activity_Group_Config.query.filter(
            and_(
                Activity_Group_Config.business_id == auth.current_user().business_id,
                Activity_Group_Config.status == STATUS["ACTIVE"])).all()
        activity_group_list = list()
        for activity_group in activity_groups:
            activity_group_dict = dict()
            activity_group_dict["activity_group_id"] = activity_group.activity_group_id
            activity_group_dict["activity_group_name"] = activity_group.activity_group_name
            activity_group_list.append(activity_group_dict)

        resp_dict["status"] = True
        resp_dict["object"] = activity_group_list
        
    except Exception as e:
        logging.error("activity_group_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("activity_group_list: end")
    return jsonify(resp_dict)

#Disable Activity Group
@user_blueprint.route("/api/disable-activity-group", methods=["POST"])
@auth.login_required()
def disable_activity_group():
    logging.debug("disable_activity_group : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_group_id = request.json.get("activity_group_id")
        
        activity_group = Activity_Group_Config.query.get(activity_group_id)
        if activity_group:
            activity_group.status = STATUS["DEACTIVE"]
            activity_group.updated_date = datetime.datetime.now()
            db.session.commit()
        
        resp_dict["status"] = True
        resp_dict["msg"] = "Activity Group disabled successfully"
            
    except Exception as e:
        logging.error("disable_activity_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("disable_activity_group: end")
    return jsonify(resp_dict)

#Enable Activity Group
@user_blueprint.route("/api/enable-activity-group", methods=["POST"])
@auth.login_required()
def enable_activity_group():
    logging.debug("enable_activity_group : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_group_id = request.json.get("activity_group_id")
        
        activity_group = Activity_Group_Config.query.get(activity_group_id)
        if activity_group:
            activity_group.status = STATUS["ACTIVE"]
            activity_group.updated_date = datetime.datetime.now()
            db.session.commit()
        
        resp_dict["status"] = True
        resp_dict["msg"] = "Activity Group enabled successfully"
            
    except Exception as e:
        logging.error("enable_activity_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("enable_activity_group: end")
    return jsonify(resp_dict)

#Activity Group Configuration Info
@user_blueprint.route("/api/activity-group-config-info", methods=["POST"])
@auth.login_required()
def activity_group_config_info():
    logging.debug("activity_group_config_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        activity_group_id = request.json.get("activity_group_id")
        
        activity_group = Activity_Group_Config.query.filter(Activity_Group_Config.activity_group_id == activity_group_id).first()
        activity_group_dict = dict()
        if activity_group:
            activity_group_dict["activity_group_id"] = activity_group.activity_group_id
            activity_group_dict["activity_group_name"] = activity_group.activity_group_name
            activity_group_dict["activity_ids"] = (activity_group.activity_ids).split(",")

            resp_dict["status"] = True

        resp_dict["object"] = activity_group_dict
          
    except Exception as e:
        logging.error("activity_group_config_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("activity_group_config_info: end")
    return jsonify(resp_dict)

# Activity Monitoring Configuration
@user_blueprint.route("/api/activity-monitoring-configuration", methods=["POST"])
@auth.login_required()
def activity_monitoring_configuration():
    """activity_monitoring_configuration"""
    logging.debug("activity_monitoring_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        monitor_type = request.json.get("monitor_type")
        user_activity_list = request.json.get("user_activity_list")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode")
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")
        config_type = request.json.get("config_type")
        employee_ids = request.json.get("employee_ids")  
        emp_group_id = request.json.get("emp_group_id")  

        input_validation = ""
        if not function_id:
            input_validation = "Function Id is required"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"
        elif not config_name:
            input_validation = "Configuration Name is required"    

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        if not config_type:
            resp_dict["msg"] = "Config Type is required"
            return jsonify(resp_dict)

        if config_type == CONFIG_TYPE["EMPLOYEE"]:
            if not employee_ids:
                resp_dict["msg"] = "Choose atleast one Employee"
                return jsonify(resp_dict)
        if config_type == CONFIG_TYPE["GROUP"]:
            if not emp_group_id:
                resp_dict["msg"] = "Group is required"
                return jsonify(resp_dict)        

        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee Id"
            return jsonify(resp_dict)
        
        if modes: 
            for mode in modes:
                if mode not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)
                
        camera_list = []

        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)
        activity_monitoring_config = Activity_Monitoring_Config.query.filter(
                and_(
                    Activity_Monitoring_Config.config_id == get_config_id,
                    Activity_Monitoring_Config.status == STATUS["ACTIVE"])).first()
        if activity_monitoring_config:
            # Disable Old
            activity_monitoring_config.status = STATUS["DEACTIVE"]
            activity_monitoring_config.updated_date = datetime.datetime.now()
            db.session.commit()
            activities = Activity_Group_Map.query.filter(Activity_Group_Map.config_seq_id == activity_monitoring_config.config_seq_id).all()
            for activity in activities:
                activity.status = STATUS["DEACTIVE"]
                activity.updated_date = datetime.datetime.now()
                db.session.commit()

            # Insert New
            activity_config = Activity_Monitoring_Config(get_config_id, monitor_type)
            db.session.add(activity_config)
            db.session.commit()
            
            for activity in user_activity_list:
                if monitor_type == MONITOR_TYPE["GROUP"] and activity["activity_group_id"]:
                    activity_config = Activity_Group_Map(activity_config.config_seq_id, activity["activity_group_id"],activity["continuous_activity_status"],
                    activity["continuous_activity_limit"],activity["cumulative_activity_status"],activity["cumulative_activity_limit"])
                    db.session.add(activity_config)
                    db.session.commit()

                elif monitor_type == MONITOR_TYPE["ACTIVITY"] and activity["activity_ids"]:
                    activity_config = Activity_Group_Map(activity_config.config_seq_id,",".join(activity["activity_ids"]),activity["continuous_activity_status"],
                        activity["continuous_activity_limit"],activity["cumulative_activity_status"],activity["cumulative_activity_limit"])
                    db.session.add(activity_config)
                    db.session.commit()

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"

        else:
            activity_config = Activity_Monitoring_Config(get_config_id, monitor_type)
            db.session.add(activity_config)
            db.session.commit()
            
            for activity in user_activity_list:
                if monitor_type == MONITOR_TYPE["GROUP"] and activity["activity_group_id"]:
                    activity_config = Activity_Group_Map(activity_config.config_seq_id, activity["activity_group_id"],activity["continuous_activity_status"],
                    activity["continuous_activity_limit"],activity["cumulative_activity_status"],activity["cumulative_activity_limit"])
                    db.session.add(activity_config)
                    db.session.commit()

                elif monitor_type == MONITOR_TYPE["ACTIVITY"] and activity["activity_ids"]:
                    activity_config = Activity_Group_Map(activity_config.config_seq_id,",".join(activity["activity_ids"]),activity["continuous_activity_status"],
                        activity["continuous_activity_limit"],activity["cumulative_activity_status"],activity["cumulative_activity_limit"])
                    db.session.add(activity_config)
                    db.session.commit()
            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"
        
    except Exception as e:
        logging.error("activity_monitoring_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("activity_monitoring_configuration : end")
    return jsonify(resp_dict)

# Disable Module
@user_blueprint.route("/api/disable-module", methods=["POST"])
@auth.login_required()
def disable_module():
    """Disable Module"""
    logging.debug("disable_module : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        module_id = request.json.get("module_id")

        module_functions = Module_Function.query.filter(Module_Function.module_id == module_id).all()
        for module_function in module_functions:
            module_function_configs = Module_Function_Config.query.filter(and_(
                    Module_Function_Config.business_id == auth.current_user().business_id,
                    Module_Function_Config.function_id == module_function.function_id,
                    Module_Function_Config.status == STATUS["ACTIVE"]
                )).all()
            for module_function_config in module_function_configs:
                module_function_config.status = STATUS["DEACTIVE"]   
                module_function_config.updated_date = datetime.datetime.now() 
                db.session.commit()

            if module_function.function_id == 11:
                activity_group_configs =  Activity_Group_Config.query.filter(
                    and_(
                        Activity_Group_Config.business_id == auth.current_user().business_id,
                        Activity_Group_Config.status == STATUS["ACTIVE"]
                        )).all()
                for activity_group_config in activity_group_configs:
                    activity_group_config.status = STATUS["DEACTIVE"]   
                    activity_group_config.updated_date = datetime.datetime.now() 
                    db.session.commit()

        resp_dict["status"] = True
        resp_dict["msg"] = "Module disabled successfully"
    
    except Exception as e:
        logging.error("disable_module : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("disable_module : end")
    return jsonify(resp_dict)             

# Disable Function
@user_blueprint.route("/api/disable-function", methods=["POST"])
@auth.login_required()
def disable_function():
    """Disable Function"""
    logging.debug("disable_function : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")

        module_function_configs = Module_Function_Config.query.filter(and_(
                    Module_Function_Config.business_id == auth.current_user().business_id,
                    Module_Function_Config.function_id == function_id,
                    Module_Function_Config.status == STATUS["ACTIVE"]
                )).all()
        for module_function_config in module_function_configs:
            module_function_config.status = STATUS["DEACTIVE"]   
            module_function_config.updated_date = datetime.datetime.now() 
            db.session.commit()
  
        resp_dict["status"] = True
        resp_dict["msg"] = "Function disabled successfully"
    
    except Exception as e:
        logging.error("disable_function : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("disable_function : end")
    return jsonify(resp_dict)        

# Disable Config
@user_blueprint.route("/api/disable-config", methods=["POST"])
@auth.login_required()
def disable_config():
    """Disable Config"""
    logging.debug("disable_config : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        config_id = request.json.get("config_id")
        function_id = request.json.get("function_id")
        
        module_function = Module_Function_Config.query.filter(
            and_(
                Module_Function_Config.function_id == function_id,
                Module_Function_Config.business_id == auth.current_user().business_id,
                Module_Function_Config.status == STATUS["ACTIVE"],
                Module_Function_Config.config_id == config_id)).first()
        
        if module_function:
            module_function.status = STATUS["DEACTIVE"]   
            module_function.updated_date = datetime.datetime.now() 
            module_function.updated_by = auth.current_user().user_id
            db.session.commit()
    
        resp_dict["status"] = True
        resp_dict["msg"] = "Config disabled successfully"

    except Exception as e:
        logging.error("disable_config : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("disable_config : end")
    return jsonify(resp_dict) 

# Enable Config
@user_blueprint.route("/api/enable-config", methods=["POST"])
@auth.login_required()
def enable_config():
    """Enable Config"""
    logging.debug("enable_config : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        config_id = request.json.get("config_id")
        function_id = request.json.get("function_id")
        admin_mobile = get_admin_mobile(auth.current_user())
  
        module_function = Module_Function_Config.query.filter(
            and_(
                Module_Function_Config.function_id == function_id,
                Module_Function_Config.business_id == auth.current_user().business_id,
                Module_Function_Config.status == STATUS["DEACTIVE"],
                Module_Function_Config.config_id == config_id)).first()
        
        if module_function:
            if module_function.config_type == CONFIG_TYPE["EMPLOYEE"]:
                module_function_config_maps = Module_Function_Config_Map.query.filter(
                    and_(
                        Module_Function_Config_Map.config_id == module_function.config_id,
                        Module_Function_Config_Map.status == STATUS["ACTIVE"]
                    )).all()
                for config_map in module_function_config_maps:
                    module_function_config_map = Module_Function_Config_Map.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id,
                        Module_Function_Config_Map.entity_id == config_map.entity_id,
                        Module_Function_Config_Map.config_id == Module_Function_Config.config_id,
                        Module_Function_Config_Map.status == STATUS["ACTIVE"]
                    )).first()
                    if module_function_config_map:
                        employee = User.query.get(module_function_config_map.entity_id)
                        resp_dict["msg"] = "{} - Employee is already active in another config can't update.".format(employee.name)
                        return jsonify(resp_dict)
                                    
            elif module_function.config_type == CONFIG_TYPE["GROUP"]:
                module_function_config_maps = Module_Function_Config_Map.query.filter(
                    and_(
                        Module_Function_Config_Map.config_id == module_function.config_id,
                        Module_Function_Config_Map.status == STATUS["ACTIVE"]
                    )).first()
                if module_function_config_maps:
                    module_function_config_map = Module_Function_Config_Map.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.business_id == auth.current_user().business_id,
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config_Map.entity_id == module_function_config_maps.entity_id,
                        Module_Function_Config_Map.config_id == Module_Function_Config.config_id,
                        Module_Function_Config_Map.status == STATUS["ACTIVE"]
                    )).first()
                    if module_function_config_map:
                        employee_group = Employee_Group.query.get(module_function_config_map.entity_id)
                        resp_dict["msg"] = "{} - Group is already active in another config can't enable.".format(employee_group.emp_group_name)
                        return jsonify(resp_dict)
            
            # Check Cameras
            if function_id in [5, "5"]:
                old_cameras = db.session.query(Unauthorized_Access_Config.camera_id).filter(
                                    and_(
                                        Unauthorized_Access_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                    
                for camera in used_cameras:
                    unauthorized_access_config = Unauthorized_Access_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Unauthorized_Access_Config.config_id,
                                Unauthorized_Access_Config.config_id != config_id,
                                Unauthorized_Access_Config.camera_id == camera.camera_id,
                                Unauthorized_Access_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if unauthorized_access_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == unauthorized_access_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)
            
            elif function_id in [6, "6"]:
                old_cameras = db.session.query(Mask_Compliance_Config.camera_id).filter(
                                    and_(
                                        Mask_Compliance_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                
                for camera in used_cameras:
                    mask_compliance_config = Mask_Compliance_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Mask_Compliance_Config.config_id,
                                Mask_Compliance_Config.config_id != config_id,
                                Mask_Compliance_Config.camera_id == camera.camera_id,
                                Mask_Compliance_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if mask_compliance_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == mask_compliance_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)

            elif function_id in [7, "7"]:
                old_cameras = db.session.query(Social_Distancing_Config.camera_id).filter(
                                    and_(
                                        Social_Distancing_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                #used cameras
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                for camera in used_cameras:
                    social_distancing_config = Social_Distancing_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Social_Distancing_Config.config_id,
                                Social_Distancing_Config.config_id != config_id,
                                Social_Distancing_Config.camera_id == camera.camera_id,
                                Social_Distancing_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if social_distancing_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == social_distancing_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)
            
            elif function_id in [ 8, "8"]:
                old_cameras = db.session.query(Safety_Gear_Config.camera_id).filter(
                                    and_(
                                        Safety_Gear_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                #used cameras
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                
                for camera in used_cameras:
                    safety_gear_config = Safety_Gear_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Safety_Gear_Config.config_id,
                                Safety_Gear_Config.config_id != config_id,
                                Safety_Gear_Config.camera_id == camera.camera_id,
                                Safety_Gear_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if safety_gear_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)

            elif function_id in [ 9, "9"]:
                old_cameras = db.session.query(Food_Temperature_Config.camera_id).filter(
                                    and_(
                                        Food_Temperature_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                #used cameras
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                
                for camera in used_cameras:
                    safety_gear_config = Food_Temperature_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Food_Temperature_Config.config_id,
                                Food_Temperature_Config.config_id != config_id,
                                Food_Temperature_Config.camera_id == camera.camera_id,
                                Food_Temperature_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if safety_gear_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)
            elif function_id in [ 10, "10"]:
                old_cameras = db.session.query(Food_IdleTime_Config.camera_id).filter(
                                    and_(
                                        Food_IdleTime_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id,
                                    )).distinct().all()
                old_cameras = [camera[0] for camera in old_cameras]
                #used cameras
                used_cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile,
                                    Camera_Details.camera_id.in_(old_cameras)
                                )).all()
                
                for camera in used_cameras:
                    safety_gear_config = Food_IdleTime_Config.query.filter(
                            and_(
                                Module_Function_Config.function_id == function_id,
                                Module_Function_Config.business_id == auth.current_user().business_id,
                                Module_Function_Config.status == STATUS["ACTIVE"],
                                Module_Function_Config.config_id == Food_IdleTime_Config.config_id,
                                Food_IdleTime_Config.config_id != config_id,
                                Food_IdleTime_Config.camera_id == camera.camera_id,
                                Food_IdleTime_Config.status == STATUS["ACTIVE"]
                                )).first()
                    if safety_gear_config:
                        camera = Camera_Details.query.filter(Camera_Details.camera_id == safety_gear_config.camera_id).first()
                        resp_dict["msg"] = "{} - Camera is already active in another config can't enable.".format(camera.camera_name)
                        return jsonify(resp_dict)

            module_function.status = STATUS["ACTIVE"]   
            module_function.updated_date = datetime.datetime.now() 
            module_function.updated_by = auth.current_user().user_id
            db.session.commit()
    
        resp_dict["status"] = True
        resp_dict["msg"] = "Config enabled successfully"

    except Exception as e:
        logging.error("enable_config : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("enable_config : end")
    return jsonify(resp_dict)

@user_blueprint.route("/api/config-info", methods=["POST"])
@auth.login_required()
def config_info():
    """config_info"""
    logging.debug("config_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        config_id = request.json.get("config_id")
        function_id = request.json.get("function_id")

        config_info = configuration_info(config_id)
        
        if config_info:
            
            if function_id == 1:	# Schedule Mismatch & Break-Time
                schedule_mismatch_config = Schedule_Mismatch_Breaktime_Config.query.filter(and_(
                                Schedule_Mismatch_Breaktime_Config.config_id == config_info["config_id"],
                                Schedule_Mismatch_Breaktime_Config.status == STATUS["ACTIVE"])).order_by(asc(Schedule_Mismatch_Breaktime_Config.config_seq_id)).all()

                config_info["notification_delay"] = schedule_mismatch_config[0].notification_delay
                weeks_list = list()
                for schedule_mismatch in schedule_mismatch_config:
                    schedule_info = dict()
                    schedule_info["start_date"] = schedule_mismatch.start_date.strftime("%Y-%m-%d")
                    schedule_info["end_date"] = (schedule_mismatch.end_date.strftime("%Y-%m-%d") if schedule_mismatch.end_date else "")
                    
                    schedule_config = Schedule_Config.query.filter(
                       Schedule_Config.config_seq_id == schedule_mismatch.config_seq_id).order_by(asc(Schedule_Config.schedule_config_seq_id)).all()
                    schedule_info["schedules"] = list()
                    for schedule in schedule_config:
                        schedule_dict = dict()
                        schedule_dict["days"] = schedule.days.split(",")
                        schedule_dict["start_time"] = schedule.start_time.strftime("%I:%M:%S %p")
                        schedule_dict["end_time"] = schedule.end_time.strftime("%I:%M:%S %p")

                        breaktime_config = Breaktime_Config.query.filter(
                                        Breaktime_Config.schedule_config_seq_id == schedule.schedule_config_seq_id).order_by(asc(Breaktime_Config.seq_id)).all()
                        
                        schedule_dict["break_time_config"] = list()
                        for breaktime in breaktime_config:
                            break_time = dict()
                            break_time["break_name"] = breaktime.break_name
                            break_time["duration"] = breaktime.break_time
                            break_time["no_of_times"] = breaktime.no_of_times
                            break_time["f_start_time"] = ("" if breaktime.start_time == None else breaktime.start_time.strftime("%I:%M:%S %p"))
                            break_time["f_end_time"] = ("" if  breaktime.end_time == None else breaktime.end_time.strftime("%I:%M:%S %p"))
                            break_time["time_frame_status"] = (False if breaktime.start_time == None or breaktime.end_time == None else True)
                            schedule_dict["break_time_config"] .append(break_time)

                        schedule_info["schedules"].append(schedule_dict)
                    weeks_list.append(schedule_info)
                    
                config_info["weeks_list"] = weeks_list

            elif function_id ==  3:   # Absence Notification
                pass
            
            elif function_id ==  4:   # Check in / Check out
                checkin_checkout_config = Checkin_Checkout_Config.query.filter(
                    and_(
                        Checkin_Checkout_Config.config_id == config_info["config_id"],
                        Checkin_Checkout_Config.status == STATUS["ACTIVE"]
                        )).first()
                config_info["check_in"] = (True if checkin_checkout_config.checkin == STATUS["YES"] else False)
                config_info["check_out"] = (True if checkin_checkout_config.checkout == STATUS["YES"] else False)
                config_info["notification_delay"] = checkin_checkout_config.notification_delay
            
            elif function_id ==  5:   # Unauthorized Access
                unauthorized_access_configs = Unauthorized_Access_Config.query.filter(
                    and_(
                        Unauthorized_Access_Config.config_id == config_info["config_id"],
                        Unauthorized_Access_Config.status == STATUS["ACTIVE"]
                        )).all()
                config_info["camera_id_list"] = [unauthorized_access_config.camera_id for unauthorized_access_config in unauthorized_access_configs]
                config_info["slots_list"] = []
                config_info["time_slot_status"] = False
                if unauthorized_access_configs[0].is_time_slot:
                    time_solts = Unauthorized_Timeslot.query.filter(and_(Unauthorized_Timeslot.config_id == config_info["config_id"],
                                                        Unauthorized_Timeslot.status == STATUS["ACTIVE"])).all()
                    for time_solt in time_solts:       
                        slot = dict()     
                        slot["start_time"] = time_solt.start_time.strftime("%I:%M:%S %p")
                        slot["end_time"] = time_solt.end_time.strftime("%I:%M:%S %p")
                        config_info["slots_list"].append(slot)
                    config_info["time_slot_status"] = unauthorized_access_configs[0].is_time_slot    


            elif function_id ==  6:     # Mask Compliance
                mask_compliance_configs = Mask_Compliance_Config.query.filter(
                    and_(
                        Mask_Compliance_Config.config_id == config_info["config_id"],
                        Mask_Compliance_Config.status == STATUS["ACTIVE"]
                        )).all()
                config_info["camera_id_list"] = [mask_compliance_config.camera_id for mask_compliance_config in mask_compliance_configs]

            elif function_id == 7:  # Social Distancing
                social_distancing_configs = Social_Distancing_Config.query.filter(
                    and_(
                        Social_Distancing_Config.config_id == config_info["config_id"],
                        Social_Distancing_Config.status == STATUS["ACTIVE"]
                        )).all()
                
                camera_occupancy_list = list()
                for social_distancing_config in social_distancing_configs:
                    config_info["is_heatmap"] = (True if social_distancing_config.is_heatmap else False)
                    camera_occupancy_dict = dict()
                    camera_occupancy_dict["camera_id"] = social_distancing_config.camera_id
                    
                    camera = Camera_Details.query.get(social_distancing_config.camera_id)
                    camera_occupancy_dict["max_occupancy"] = (camera.max_occupancy if camera.max_occupancy else 0)
                    camera_occupancy_list.append(camera_occupancy_dict)
                
                config_info["camera_occupancy_list"] = camera_occupancy_list

            elif function_id ==  8:     # Safety Gears
                safety_gear_configs = Safety_Gear_Config.query.filter(
                    and_(
                        Safety_Gear_Config.config_id == config_info["config_id"],
                        Safety_Gear_Config.status == STATUS["ACTIVE"]
                        )).all()
                config_info["camera_id_list"] = [safety_gear_config.camera_id for safety_gear_config in safety_gear_configs]
                config_info["safety_kit_list"] = safety_gear_configs[0].safety_kit.split(",")

            elif function_id ==  9:     # Food Temperature
                food_temp_configs = Food_Temperature_Config.query.filter(
                    and_(
                        Food_Temperature_Config.config_id == config_info["config_id"],
                        Food_Temperature_Config.status == STATUS["ACTIVE"]
                        )).all()
                config_info["camera_id_list"] = [food_temp_config.camera_id for food_temp_config in food_temp_configs]
                config_info["low_temp"] = ""
                config_info["high_temp"] = ""
                for food_temp_config in food_temp_configs:
                    config_info["low_temp"] = food_temp_config.low_temp
                    config_info["high_temp"] = food_temp_config.high_temp
                    
            elif function_id ==  10:     # Food Idle Time
                food_idletime_configs = Food_IdleTime_Config.query.filter(
                    and_(
                        Food_IdleTime_Config.config_id == config_info["config_id"],
                        Food_IdleTime_Config.status == STATUS["ACTIVE"]
                        )).all()
                config_info["camera_id_list"] = [food_idletime_config.camera_id for food_idletime_config in food_idletime_configs]
                config_info["idle_thresold"] = ""
                for food_idletime_configs in food_idletime_configs:
                    config_info["idle_thresold"] = food_idletime_configs.idle_thresold
            elif function_id == 12:	# Activitiy Group List Monitoring
                acitivity_monitoring_config = Activity_Monitoring_Config.query.filter(and_(
                                Activity_Monitoring_Config.config_id == config_info["config_id"],
                                Activity_Monitoring_Config.status == STATUS["ACTIVE"])).first()

                config_info["monitor_type"] = acitivity_monitoring_config.monitor_type
                user_activity_list = list()
                activity_group_maps = Activity_Group_Map.query.filter(and_(Activity_Group_Map.config_seq_id == acitivity_monitoring_config.config_seq_id,
                                    Activity_Group_Map.status == STATUS["ACTIVE"])).order_by(asc(Activity_Group_Map.activity_map_id)).all()
                if activity_group_maps:
                    for activity_group_map in activity_group_maps:
                        activity_group_info = dict()
                        if config_info["monitor_type"] == MONITOR_TYPE["GROUP"]:
                            activity_group_info["acitvity_group_id"] = activity_group_map.entity_id
                        
                        elif config_info["monitor_type"] == MONITOR_TYPE["ACTIVITY"]:
                            activity_group_info["activity_ids"] = (activity_group_map.entity_id).split(",")
                        activity_group_info["continuous_activity_status"] = activity_group_map.continuous_activity_status 
                        activity_group_info["continuous_activity_limit"] = (activity_group_map.continuous_activity_limit if activity_group_map.continuous_activity_limit else 0)
                        activity_group_info["cumulative_activity_status"]= activity_group_map.cumulative_activity_status
                        activity_group_info["cumulative_activity_limit"] = (activity_group_map.cumulative_activity_limit if activity_group_map.cumulative_activity_limit else 0)
                        user_activity_list.append(activity_group_info)
 
                config_info["user_activity_list"] = user_activity_list
            resp_dict["status"] = True
            resp_dict["object"] = config_info
        else:
            resp_dict["msg"] = "Configuration not found"
            
    except Exception as e:
        logging.error("config_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("config_info : end")
    return jsonify(resp_dict)

def configuration_info(config_id):
    logging.debug("configuration_info : start")
    config_info = dict()
    try:
        # Config 
        module_function_config = Module_Function_Config.query.filter(
            and_(
                Module_Function_Config.business_id == auth.current_user().business_id,
                Module_Function_Config.config_id == config_id
            )).first()


        if module_function_config:
            config_info["config_id"] = module_function_config.config_id
            config_info["config_name"] = module_function_config.config_name
            config_info["config_type"] = module_function_config.config_type
            module_function_config_map = Module_Function_Config_Map.query.filter(
                and_(
                    Module_Function_Config_Map.config_id == module_function_config.config_id,
                    Module_Function_Config_Map.status == STATUS["ACTIVE"]
                    )).first()

            # Config Map
            if module_function_config_map:
                rows = Module_Function_Config_Map.query.filter(
                    and_(
                        Module_Function_Config_Map.config_id == module_function_config_map.config_id,
                        Module_Function_Config_Map.status == STATUS["ACTIVE"]
                        )).all()
                if module_function_config.config_type == CONFIG_TYPE["GROUP"]:
                    config_info["emp_group_id"] = rows[0].entity_id
                else:    
                    config_info["employee_ids"] = [row.entity_id for row in rows]

            # Config Comm 
            module_function_comm_config = Module_Function_Comm_Config.query.filter(
                and_(
                    Module_Function_Comm_Config.config_id == module_function_config.config_id,
                    Module_Function_Comm_Config.status == STATUS["ACTIVE"]
                    )).first()
                    
            if module_function_comm_config:
                config_info["message"] = module_function_comm_config.message
                config_info["mode"] = module_function_comm_config.mode.split(",")

                # Config Comm Map
                module_function_comm_config_maps = Module_Function_Comm_Config_Map.query.filter(
                        and_(
                            Module_Function_Comm_Config_Map.comm_config_id == module_function_comm_config.comm_config_id,
                            Module_Function_Comm_Config_Map.status == STATUS["ACTIVE"]
                            )).all()

                config_info["comm_employee_ids"] = [module_function_comm_config_map.comm_employee_id for module_function_comm_config_map in module_function_comm_config_maps]
            
    except Exception as e:
        logging.error("configuration_info : exception : {}".format(e))
    logging.debug("configuration_info : end")
    return config_info

# Social distancing config save/update
@user_blueprint.route("/api/social-distancing-configuration", methods=["POST"])
@auth.login_required()
def social_distancing_configuration():
    """social_distancing_configuration"""
    logging.debug("social_distancing_configuration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        camera_occupancy_list = request.json.get("camera_occupancy_list")
        is_heatmap = request.json.get("is_heatmap")
        comm_employee_ids = request.json.get("comm_employee_ids") 
        message = request.json.get("message")
        modes = request.json.get("mode") 
        config_id = request.json.get("config_id")
        config_name = request.json.get("config_name")

        input_validation = ""
        if not function_id:
            input_validation = "Function Id is required"
        elif not camera_occupancy_list:
            input_validation = "Choose at least one camera"
        elif not message:
            input_validation = "Message is required"
        elif not modes:
            input_validation = "Mode is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        if not comm_employee_ids:
            resp_dict["msg"] = "Choose atleast one Communication Employee Id"
            return jsonify(resp_dict)
        
        if modes: 
            for m in modes:
                if m not in ["SMS", "EMAIL", "PUSH"]:
                    resp_dict["msg"] = "Valid mode is required"
                    return jsonify(resp_dict)

        employee_ids = []
        config_type = ""
        emp_group_id = 0
        camera_list = [camera["camera_id"] for camera in camera_occupancy_list]

        get_config_id, error_msg = configuration(function_id, config_name, message, modes, config_type, emp_group_id, employee_ids, comm_employee_ids, config_id, camera_list)
        if error_msg:
            resp_dict["msg"] = error_msg
            return jsonify(resp_dict)

        social_distancing_configurations = Social_Distancing_Config.query.filter(
                    and_(Social_Distancing_Config.config_id == get_config_id,
                        Social_Distancing_Config.status == STATUS["ACTIVE"])).all()

        if not social_distancing_configurations:
            # Insert New
            for camera_occupancy in camera_occupancy_list:
                social_distancing_config = Social_Distancing_Config(get_config_id, camera_occupancy["camera_id"],is_heatmap)
                db.session.add(social_distancing_config)
                db.session.commit()

                admin_mobile = get_admin_mobile(auth.current_user())
                saferson.update_max_occupancy_by_id(admin_mobile, camera_occupancy["camera_id"],camera_occupancy["max_occupancy"])
                
            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration saved successfully"

        else:
                # Deactivate Old
            for social_distancing in  social_distancing_configurations:
                social_distancing.status = STATUS["DEACTIVE"]    
                social_distancing.updated_date = datetime.datetime.now()
                db.session.commit() 

            # Insert New
            for camera_occupancy in camera_occupancy_list:
                social_distancing_config = Social_Distancing_Config(config_id, camera_occupancy["camera_id"],is_heatmap)
                db.session.add(social_distancing_config)
                db.session.commit()
                
                admin_mobile = get_admin_mobile(auth.current_user())
                saferson.update_max_occupancy_by_id(admin_mobile, camera_occupancy["camera_id"], camera_occupancy["max_occupancy"])     

            resp_dict["status"] = True
            resp_dict["msg"] = "Configuration updated successfully"
            
    except Exception as e:
        logging.error("social_distancing_configuration : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("social_distancing_configuration: end")
    return jsonify(resp_dict)

#config camera list
@user_blueprint.route("/api/config-camera-list", methods=["POST"])
@auth.login_required()
def config_camera_list():
    """Camera List"""
    logging.debug("config_camera_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        function_id = request.json.get("function_id")
        config_id = request.json.get("config_id")

        admin_mobile = get_admin_mobile(auth.current_user())        
        camera_list = list()
        cameras = []
        # Select the camera for given config Id
        if config_id:
            if function_id == 5:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Unauthorized_Access_Config.camera_id).filter(
                                    and_(
                                        Unauthorized_Access_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                   
                    unused_cameras = db.session.query(Unauthorized_Access_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        (Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    )).all()
    
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
                        
            elif function_id == 6:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Mask_Compliance_Config.camera_id).filter(
                                    and_(Mask_Compliance_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                     
                    #unused cameras   
                   
                    unused_cameras = db.session.query(Mask_Compliance_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    ).all()
                    
                    #unused cameras   
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
                        
            elif function_id == 7:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Social_Distancing_Config.camera_id).filter(
                                    and_(
                                        Social_Distancing_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                   
                    unused_cameras = db.session.query(Social_Distancing_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    ).all()
                    
                    #unused cameras   
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
                        
            elif function_id == 8:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Safety_Gear_Config.camera_id).filter(
                                    and_(
                                        Safety_Gear_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                
                    unused_cameras = db.session.query(Safety_Gear_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    ).all()
                    
                    #unused cameras   
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
            elif function_id == 9:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Food_Temperature_Config.camera_id).filter(
                                    and_(
                                        Food_Temperature_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                   
                    unused_cameras = db.session.query(Food_Temperature_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    ).all()
                    
                    #unused cameras   
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
            elif function_id == 10:
                module_function_configs = Module_Function_Config.query.filter(
                    and_(
                        Module_Function_Config.status == STATUS["ACTIVE"],
                        Module_Function_Config.function_id == function_id,
                        Module_Function_Config.business_id == auth.current_user().business_id
                    )).all()
                
                if module_function_configs:
                    used_cameras = db.session.query(Food_IdleTime_Config.camera_id).filter(
                                    and_(
                                        Food_IdleTime_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.config_id == config_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    used_cameras1 = [camera[0] for camera in used_cameras]
                   
                    unused_cameras = db.session.query(Food_IdleTime_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    unused_cameras1 = [camera[0] for camera in unused_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(unused_cameras1)|
                                        Camera_Details.camera_id.in_(used_cameras1))
                                    ).all()
                    
                    #unused cameras   
                    for camera in cameras:
                        camera_dict = dict()
                        camera_dict["camera_id"] = camera.camera_id 
                        camera_dict["camera_name"] = camera.camera_name
                        camera_list.append(camera_dict)
       
        else:
            cameras = Camera_Details.query.filter(
                                and_(
                                    Camera_Details.user_email == admin_mobile
                                )).all()
            if function_id == 5:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Unauthorized_Access_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.status == STATUS["ACTIVE"],
                                        Unauthorized_Access_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()
            if function_id == 6:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Mask_Compliance_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.status == STATUS["ACTIVE"],
                                        Mask_Compliance_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()
            if function_id == 7:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Social_Distancing_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.status == STATUS["ACTIVE"],
                                        Social_Distancing_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]

                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()

            if function_id == 8:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Safety_Gear_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.status == STATUS["ACTIVE"],
                                        Safety_Gear_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()
            if function_id == 9:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Food_Temperature_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.status == STATUS["ACTIVE"],
                                        Food_Temperature_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()
            if function_id == 10:
                module_function_configs = Module_Function_Config.query.filter(
                        and_(
                            Module_Function_Config.function_id == function_id,
                            Module_Function_Config.business_id == auth.current_user().business_id
                        )).all()
                    
                if module_function_configs:
                    old_cameras = db.session.query(Food_IdleTime_Config.camera_id).filter(
                                    and_(
                                        Module_Function_Config.function_id == function_id,
                                        Module_Function_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.status == STATUS["ACTIVE"],
                                        Food_IdleTime_Config.config_id == Module_Function_Config.config_id,
                                        Module_Function_Config.business_id == auth.current_user().business_id
                                    )).distinct().all()
                    old_cameras = [camera[0] for camera in old_cameras]
                                    
                    cameras = Camera_Details.query.filter(
                                    and_(
                                        Camera_Details.user_email == admin_mobile,
                                        Camera_Details.camera_id.notin_(old_cameras)
                                    )).all()
                   
            #unused cameras   
            for camera in cameras:
                camera_dict = dict()
                camera_dict["camera_id"] = camera.camera_id 
                camera_dict["camera_name"] = camera.camera_name
                camera_list.append(camera_dict)                                                             
        
        resp_dict["status"] = True
        resp_dict["object"] =  camera_list
    except Exception as e:
        logging.error("config_camera_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("config_camera_list: end")
    return jsonify(resp_dict)

# config-group-employee-list -- By Group
@user_blueprint.route("/api/config-group-list", methods = ["POST"])
@auth.login_required()
def config_group_list():
    logging.debug("config_group_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        function_id = request.json.get("function_id")
        config_id = request.json.get("config_id")
        employee_groups = Employee_Group.query.filter(and_(Employee_Group.business_id == auth.current_user().business_id,
                                                            Employee_Group.status == STATUS["ACTIVE"])).order_by(asc(Employee_Group.emp_group_name)).all()
        config_group_list = list()                                                    
        for employee_group in employee_groups:
            config_group_dict = dict()
            if config_id:
                config = Module_Function_Config_Map.query.filter(and_(Module_Function_Config.function_id == function_id,
                                                Module_Function_Config.config_id == config_id,
                                                Module_Function_Config.config_type == CONFIG_TYPE["GROUP"],
                                                Module_Function_Config_Map.config_id == Module_Function_Config.config_id,
                                                Module_Function_Config_Map.entity_id == employee_group.emp_group_id,
                                                Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()

                if config:
                    config_group_dict["emp_group_id"] = employee_group.emp_group_id
                    config_group_dict["group_name"] = employee_group.emp_group_name
                    config_group_list.append(config_group_dict)
                else:
                    check_group_config = Module_Function_Config_Map.query.filter(and_( Module_Function_Config.function_id == function_id,
                                            Module_Function_Config.status == STATUS["ACTIVE"],
                                            Module_Function_Config.config_type == CONFIG_TYPE["GROUP"],
                                            Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                            Module_Function_Config_Map.entity_id == employee_group.emp_group_id,
                                            Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()
                
                    if not check_group_config:
                        config_group_dict["emp_group_id"] = employee_group.emp_group_id
                        config_group_dict["group_name"] = employee_group.emp_group_name
                        config_group_list.append(config_group_dict)

            if not config_id: 
                check_group_config = Module_Function_Config_Map.query.filter(and_( Module_Function_Config.function_id == function_id,
                                            Module_Function_Config.status == STATUS["ACTIVE"],
                                            Module_Function_Config.config_type == CONFIG_TYPE["GROUP"],
                                            Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                            Module_Function_Config_Map.entity_id == employee_group.emp_group_id,
                                            Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()
                
                if not check_group_config:
                    config_group_dict["emp_group_id"] = employee_group.emp_group_id
                    config_group_dict["group_name"] = employee_group.emp_group_name
                    config_group_list.append(config_group_dict)


        resp_dict["status"] = True
        resp_dict["object"] =  config_group_list
    except Exception as e:
        logging.exception("config_group_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("config_group_list : end")
    return jsonify(resp_dict)

# config-employee-list -- By Employee
@user_blueprint.route("/api/config-employee-list", methods = ["POST"])
@auth.login_required()
def config_employee_list():
    logging.debug("config_employee_list: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        function_id = request.json.get("function_id")
        config_id = request.json.get("config_id")

        config_employee_list = list()                                                    

        emp_users = User.query.filter(
            and_(
                User.status != STATUS["DELETE"],
                User.business_id == auth.current_user().business_id,
                User.is_employee == STATUS["YES"]
                )).all()
        for user in emp_users:
            if config_id:
                config = Module_Function_Config_Map.query.filter(and_(Module_Function_Config.function_id == function_id,
                                                Module_Function_Config.config_id == config_id,
                                                Module_Function_Config.config_type == CONFIG_TYPE["EMPLOYEE"],
                                                Module_Function_Config_Map.config_id == Module_Function_Config.config_id,
                                                Module_Function_Config_Map.entity_id == user.user_id,
                                                Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()
                if config:
                    config_employee_dict = dict()
                    config_employee_dict["employee_id"] = user.user_id
                    config_employee_dict["name"] = user.name
                    config_employee_list.append(config_employee_dict)

                else:
                    check_emp_config = Module_Function_Config_Map.query.filter(and_( Module_Function_Config.function_id == function_id,
                                            Module_Function_Config.status == STATUS["ACTIVE"],
                                            Module_Function_Config.config_type == CONFIG_TYPE["EMPLOYEE"],
                                            Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                            Module_Function_Config_Map.entity_id == user.user_id,
                                            Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()
                
                    if not check_emp_config:
                        config_employee_dict = dict()
                        config_employee_dict["employee_id"] = user.user_id
                        config_employee_dict["name"] = user.name
                        config_employee_list.append(config_employee_dict)


            if not config_id: 
                check_emp_config = Module_Function_Config_Map.query.filter(and_( Module_Function_Config.function_id == function_id,
                                            Module_Function_Config.status == STATUS["ACTIVE"],
                                            Module_Function_Config.config_type == CONFIG_TYPE["EMPLOYEE"],
                                            Module_Function_Config.config_id == Module_Function_Config_Map.config_id,
                                            Module_Function_Config_Map.entity_id == user.user_id,
                                            Module_Function_Config_Map.status == STATUS["ACTIVE"] )).first()
                
                if not check_emp_config:
                    config_employee_dict = dict()
                    config_employee_dict["employee_id"] = user.user_id
                    config_employee_dict["name"] = user.name
                    config_employee_list.append(config_employee_dict)
                  

        resp_dict["status"] = True
        resp_dict["object"] =  config_employee_list
    except Exception as e:
        logging.exception("config_employee_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("config_employee_list : end")
    return jsonify(resp_dict)

# Employee list By Group -- Comm Group Employee
@user_blueprint.route("/api/comm-employee-list-by-employee-group", methods = ["POST"])
@auth.login_required()
def comm_employee_list_by_employee_group():
    logging.debug("comm_employee_list_by_employee_group: start")
    resp_dict = {"status": False, "msg": "", "object": None}
    try:
        employee_groups = Employee_Group.query.filter(and_(Employee_Group.business_id == auth.current_user().business_id,
                                                            Employee_Group.status == STATUS["ACTIVE"])).order_by(asc(Employee_Group.emp_group_name)).all()
        group_employee_list = list()                                                    
        for employee_group in employee_groups:
            group_dict = dict()
            if employee_group.emp_group_desc != "UNKNOWN GROUP":
                group_dict["emp_group_id"] = employee_group.emp_group_id
                group_dict["group_name"] = employee_group.emp_group_name
                user_group_maps = db.session.query(User_Group_Map.user_id).filter(
                            and_(User_Group_Map.emp_group_id == employee_group.emp_group_id,
                            User_Group_Map.status == STATUS["ACTIVE"])).group_by(User_Group_Map.user_id).all()
                group_dict["employee_list"] = list()                         
                if user_group_maps:          
                    for user_group_map in user_group_maps:
                        emp_user_dict = dict()
                        emp_user = User.query.filter(
                            and_(
                                User.status != STATUS["DELETE"],
                                User.user_id == user_group_map.user_id,
                                User.is_employee == STATUS["YES"]
                                )).first()
                        if emp_user:
                            emp_user_dict["employee_id"] = emp_user.user_id
                            emp_user_dict["employee_name"]= emp_user.name
                            group_dict["employee_list"].append(emp_user_dict)   
                                    
                    group_employee_list.append(group_dict)   
                else:
                    group_employee_list.append(group_dict)   

        resp_dict["status"] = True
        resp_dict["object"] =  group_employee_list
    except Exception as e:
        logging.exception("comm_employee_list_by_employee_group : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("comm_employee_list_by_employee_group : end")
    return jsonify(resp_dict)

# Checkin Checkout Camera -- For Nikhil
@user_blueprint.route("/api/checkin-checkout-camera", methods = ["POST"])
@auth.login_required()
def checkin_checkout_camera():
    logging.debug("checkin_checkout_camera: start")
    resp_dict = {"status": False, "msg": "", "object": {"is_checkin_checkout" : None}}
    try:
        camera_id = request.json.get("camera_id")
        if not camera_id:
            resp_dict["msg"] = "Camera Id is required"
            return resp_dict
        
        admin_mobile = get_admin_mobile(auth.current_user())    
        camera = Camera_Details.query.filter(and_(Camera_Details.user_email == admin_mobile,
                                Camera_Details.camera_id == camera_id)).first()    
        if not camera:
            resp_dict["msg"] = "Not Found"
            return resp_dict
        else:
            if camera.is_checkin_checkout:
                resp_dict["object"]["is_checkin_checkout"] = True
                resp_dict["status"] = True
                resp_dict["msg"] = "success"
            else:
                resp_dict["object"]["is_checkin_checkout"] = False
                resp_dict["status"] = True
                resp_dict["msg"] = "success"

    except Exception as e:
        logging.error("checkin_checkout_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("checkin_checkout_camera : end")
    return jsonify(resp_dict)                           

# ------------------------------- Mobile App API Services ---------------------------------------
@user_blueprint.route("/api/mobile/industry-list", methods=["POST"])
def mobile_industry_list():
    """Industry List"""
    logging.debug("mobile_industry_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        industries = Industry.query.filter(Industry.status == STATUS["ACTIVE"]).order_by(Industry.industry_name.asc()).all()
        industry_list = list()
        for industry in industries:
            industry_dict = dict()
            industry_dict["industry_id"] = industry.industry_id
            industry_dict["industry_name"] = industry.industry_name.title()
            industry_list.append(industry_dict)
            
        resp_dict["status"] = True
        resp_dict["object"] = industry_list
    except Exception as e:
        logging.error("mobile_industry_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("mobile_industry_list : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/registration', methods=['POST'])
def registration():
    """User registration"""
    logging.info("registration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get('name')
        email = request.json.get('email')
        country_id = request.json.get('country_id')
        mobile = request.json.get('phone')
        password = request.json.get('password')
        business_name =  request.json.get('business_name')
        industry_id = request.json.get('industry_id')
        address = request.json.get('address')
    

        # Input data validation
        input_validation = ""
        if not name:
            input_validation = "Name is required"
        elif not char_validation(name):
            input_validation = "Valid Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not email_validation(email):
            input_validation = "Valid Email Id is required"
        elif not country_id:
            input_validation = "Country Code is required"
        elif not mobile:
            input_validation = "mobile is required"
        elif not mobile_no_validation(mobile):
            input_validation = "Valid Mobile no is required"
        elif not password:
            input_validation = "Password is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry_id:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"

        strong_pass_val_msg = strong_password_validation(password)
        if strong_pass_val_msg:
            input_validation = strong_pass_val_msg
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
    
        # User duplicate validation
        user = User.query.filter(and_(User.country_id == country_id, User.mobile == mobile)).first()
        if user:
                resp_dict["msg"] = "Mobile No already registered with us"
                return jsonify(resp_dict)
        user = User.query.filter(User.email == email).first()
        if user:
            resp_dict["msg"] =  "Email already registered with us"
            return jsonify(resp_dict)   

        registration = Registration(name, email, country_id, mobile, business_name, industry_id, address)
        registration.hash_password(password)
        db.session.add(registration)
        db.session.commit()

        otp_id = otp_insert(country_id,mobile)

        resp_dict["object"] = {
                        "otp_id" : otp_id,
                        "phone": ("xxx xxx "+mobile[6:] if mobile else "")
                    }
        resp_dict ['status'] = True
    except Exception as e:
        logging.error("registration : exception : {}".format(e))
    logging.info("registration : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/country-list', methods=["POST"])
def country_list():
    logging.debug("country_list: start")
    resp_dict = {"status":False, "msg":"", "object":None}
    
    try:
        country_code_list = []
        country_list = Country.query.all()
        for country in country_list:
            country_code_list.append({'country_id': country.country_id,'country_code': country.country_code}) 

        resp_dict['status'] = True
        resp_dict['object'] = {
            'country_code_list': country_code_list
        }   
    except Exception as e:
        logging.exception("country_list : exception : {}".format(e))
    logging.debug("country_list : end")
    
    return jsonify(resp_dict)

@user_blueprint.route("/api/mobile/resend-otp", methods=["POST"])
def resend_otp():
    logging.debug("resend_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get("otp_id")
        if not otp_id:
            resp_dict["msg"] = "OTP ID is required"
            return jsonify(resp_dict)
        
        otp_obj = OTP.query.get(str(otp_id))
        if not otp_obj:
            resp_dict["msg"] = "No records found!"
            return jsonify(resp_dict)

        msg = "Welcome! {} is your Safeo Verification Code to activate your account".format(otp_obj.otp_code)
        sms_insert(otp_obj.country_id,otp_obj.mobile, msg)

        resp_dict["object"] = {
            "otp_id" : otp_id, 
            "phone": ("xxx xxx "+otp_obj.mobile[6:] if otp_obj.mobile else "")
        } 
        resp_dict["status"] = True
    except Exception as e:
        logging.exception("resend_otp : exception : {}".format(e))
    logging.debug("resend_otp : end")

    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/verify-otp', methods = ['POST'])
def verify_otp():
    """OTP Verification"""
    logging.info("verify_otp : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        otp_id = request.json.get('otp_id')
        otp_code = request.json.get('otp_code')
        if not otp_code:
            resp_dict["msg"] = "Verification code is required "
            return jsonify(resp_dict)

        otp_status = otp_verify(otp_id,otp_code)
        otp = None
        if otp_status:
            otp = OTP.query.filter(and_(OTP.otp_id == otp_id, otp_code == otp_code)).first() 
        
        if otp:
            registration = Registration.query.filter(and_(
                    Registration.country_id == otp.country_id, Registration.mobile == otp.mobile)
                ).order_by(Registration.reg_id.desc()).first()

            if not registration:
                resp_dict['msg'] = 'phone number is not registered with us'
                return jsonify(resp_dict)
            
            if registration.mobile_verified_on == STATUS["YES"] or registration.status != STATUS["ENTRY"]:
                resp_dict["msg"] = " Your phone number already Verified."

            registration.mobile_verified_on = datetime.datetime.now()
            registration.updated_date = datetime.datetime.now()
            registration.status = STATUS["VERIFIED"]
            db.session.commit()

            # Save Address
            business = Business(registration.business_name, registration.industry_id, registration.address)
            db.session.add(business)
            db.session.commit()
            
            # Save User
            user = User(registration.name, registration.email, registration.country_id, registration.mobile, business.business_id)
            user.password = registration.password
            db.session.add(user)
            db.session.commit()
            
            # Get Role from Industry Role Resp
            industry_role_resp = Industry_Role_Resp.query.filter(Industry_Role_Resp.industry_id == business.industry_id).first()
            logging.info(industry_role_resp.role_id)
           # Save User Group
            emp_group_id = 1
            user_group_role = User_Group_Map(user.user_id, emp_group_id)
            db.session.add(user_group_role)
            db.session.commit()
            # Save Group Role
            emp_group_id = 1
            user_group_role = Employee_Group_Role_Map( emp_group_id, industry_role_resp.role_id)
            db.session.add(user_group_role)
            db.session.commit()
            # Send Verified msg
            sms_insert(registration.country_id ,registration.mobile, "Phone number verified successfully")
            resp_dict = {"status":True, "msg":"Phone number verified successfully"}
        else:
            resp_dict["msg"] = "OTP Expired"
        
    except Exception as e:
        logging.error("verify_otp : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("verify_otp : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/login', methods=['POST'])
def login():
    """Login authentication"""
    logging.info("login : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        password = request.json.get('password')

        if not phone or not password:
            resp_dict['msg'] = 'phone number & password required!'
            return jsonify(resp_dict)

        user = User.query.filter(and_(User.country_id == country_id,User.mobile==phone)).first()
        if not user:
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        # User status validation
        if user.status == STATUS['DELETE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        # User password  verification
        if not user.verify_password(password):
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        token = login_token_insert(user.user_id)
        user_role_type = get_user_role_type(user)
        if user_role_type not in [ ROLE_TYPE["CLIENT-ADMIN"], ROLE_TYPE["SKORUZ-ADMIN"]]:
            count = 0

            email = get_admin_mobile(user)
            cameras = Camera_Details.query.filter(Camera_Details.user_email == email).all()
            if cameras:
                for camera in cameras:
                    count += 1
            resp_dict['status'] = True
            resp_dict['object'] = \
                {'token':token, 
                'name':user.name,
                'role':user_role_type,
                "email" : user.email,
                'function_list': get_emp_user_functions(user),
                'default_password_changed': user.default_password_changed,
                'camera_count': count,
                'profile_status' : user.status
                }
        else:
            resp_dict["msg"] = "You don't have permission to access this application"
            resp_dict["status"] = True
    except Exception as e:
        logging.error("login : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("login : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/login-data', methods=['POST'])
@auth.login_required()
def login_data():
    """Login Data"""
    logging.info("login_data : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            country = Country.query.filter(Country.country_id == user.country_id).first()
            phone = country.country_code + user.mobile

            user_role_type = get_user_role_type(user)
            count = 0

            email = get_admin_mobile(user)
            cameras = Camera_Details.query.filter(Camera_Details.user_email == email).all()
            if cameras:
                for camera in cameras:
                    count += 1
            resp_dict['status'] = True 
            resp_dict['object'] = {
                'user_id':user.user_id,
                'name':user.name, 
                'phone':phone,
                'email' :user.email,
                'role':user_role_type,
                'function_list': get_emp_user_functions(user),
                'default_password_changed': user.default_password_changed,
                'camera_count' : count,
                'profile_status' : user.status
            }
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("login_data : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("login_data : end")
    return jsonify(resp_dict)

# Change Password
@user_blueprint.route("/api/mobile/change-password", methods = ["POST"])
@auth.login_required()
def change_password():
    """
    User password change service
    """
    logging.debug("change_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        old_password = request.json.get("old_password")
        new_password = request.json.get("new_password")
        confirm_password = request.json.get("confirm_password")

        input_validation = ""
        if not old_password:
            input_validation = "old password is required"

        elif not new_password:
            input_validation = "New password is required"

        elif not confirm_password:
            input_validation = "Confirm password is required"

        elif new_password != confirm_password:
            input_validation = "New Password and Confirm Password are not matched" 

        elif old_password == new_password:
            input_validation = "Old Password and New Password should not be the same"    

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        # Strong password validation
        strong_pass_val_msg = strong_password_validation(new_password)
        if strong_pass_val_msg:
            resp_dict["msg"] = strong_pass_val_msg
            return jsonify(resp_dict)

        user = User.query.get(auth.current_user().user_id)
        
        if not user.verify_password(old_password):
            resp_dict["msg"] = "Invalid old password"
            return jsonify(resp_dict)

        # Change the temp password status
        if user.default_password_changed == STATUS["YES"]:
            user.default_password_changed = STATUS["NO"]

        user.hash_password(new_password)
        user.updated_by = auth.current_user().user_id
        user.updated_date = datetime.datetime.now()
        db.session.commit()

        resp_dict["status"] = True
        resp_dict["msg"] = "Password changed successfully"    
    except Exception as e:
        logging.exception("change_password : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.debug("change_password : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/forget-password', methods=['POST'])
def forget_password():
    """Forget password - Sending a sms with new password"""
    logging.info("forget_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        country_id = request.json.get('country_id')
        mobile = request.json.get('phone')
        
        # Input Validation
        input_validation = ""
        if not country_id:
            input_validation = "Country code is required"
        elif not mobile:
            input_validation = "Mobile number is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        user = User.query.filter(User.country_id == country_id, User.mobile == mobile).first()
        if user:
            new_password = get_random_password()
            user.hash_password(new_password)
            user.default_password_changed =STATUS["YES"]
            user.updated_date = datetime.datetime.now()
            db.session.commit()

            # Send sms with new password
            msg = "Your new password is {}".format(new_password)
            sms_insert(user.country_id,user.mobile, msg)
       
        resp_dict["status"] = True
        resp_dict["msg"] = "SMS sent to you with new password"
    except Exception as e:
        logging.error("forget_password : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("forget_password : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/add-camera', methods=['POST'])
@auth.login_required()
def mobile_add_camera():
    """Add Camera"""
    logging.info("mobile_add_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        is_checkin_checkout = request.json.get("is_checkin_checkout")
        is_exit = request.json.get("is_exit")

        input_validation = ""
        if not camera_name:
            input_validation = "Camera name is required"
        elif not rtsp_link:
            input_validation = "Rtsp link is required"
        
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not username:
            username=None
        if not is_checkin_checkout:
            is_checkin_checkout = False
        if not is_exit:
            is_exit = False

        password = None
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.add_camera(admin_mobile, camera_name, rtsp_link,  username, password, is_checkin_checkout, is_exit)
            
        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Camera added successfully"
        else:
            resp_dict["msg"] = resp
    except Exception as e:
        logging.error("mobile_add_camera : exception : {}".format(e))
    logging.info("mobile_add_camera : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/camera-search', methods=['POST'])
@auth.login_required()
def mobile_camera_search():
    """Camera search"""
    logging.info("mobile_camera_search : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        username = request.json.get('username')
        password = request.json.get('password')
        ip_address = request.json.get('ip_address')
        port_no = request.json.get('port_no')
        camera_brand = request.json.get('camera_brand')
        
        # Input validation
        input_validation = ""
        if not username:
            input_validation = "User Name is required"
        elif not password:
            input_validation = "password is required"
        
        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        if not ip_address:
            ip_address = None
        if not port_no:
            port_no = None
        if not camera_brand:
            camera_brand = None
        
        resp_dict["status"] = True
        resp_dict["object"] = saferson.search(username, password, ip_address, port_no, camera_brand)
    except Exception as e:
        logging.error("mobile_camera_search : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_camera_search : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/camera-snapshot', methods=['POST'])
@auth.login_required()
def mobile_camera_snapshot():
    """Camera Snapshot"""
    logging.info("mobile_camera_snapshot : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        ip_url = request.json.get('ip_url')
        
        if not ip_url:
            resp_dict["msg"] = "Ip url is required"
            return jsonify(resp_dict)

        resp_dict["status"] = True
        resp_dict["object"] = saferson.get_snapshot(ip_url)
    except Exception as e:
        logging.error("mobile_camera_snapshot : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_camera_snapshot : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/camera-info', methods=['POST'])
@auth.login_required()
def mobile_camera_info():
    """Camera Info"""
    logging.info("mobile_camera_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        
        if not camera_name:
            resp_dict["msg"] = "Camera name is required"
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict['object'] = saferson.get_camera_settings(admin_mobile, camera_name)
    except Exception as e:
        logging.error("mobile_camera_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_camera_info : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/update-camera', methods=['POST'])
@auth.login_required()
def mobile_update_camera():
    """Update Camera"""
    logging.info("mobile_update_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        password = request.json.get('password')
        old_camera_name = request.json.get('old_camera_name')
        is_checkin_checkout = request.json.get("is_checkin_checkout")
        is_exit = request.json.get("is_exit")
        
        
        # Input validation
        input_validation = ""
        if not camera_name:
            input_validation = "Camera name is required"
        elif not rtsp_link:
            input_validation = "Rtsp Link is required"
        elif not old_camera_name:
            input_validation = "Old Camera name is required"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        if not is_checkin_checkout:
            is_checkin_checkout = False
        if not is_exit:
            is_exit = False    
        
        settings_dict = {"camera_name" : camera_name, "rtsp_link" : rtsp_link, "is_checkin_checkout": is_checkin_checkout, "is_exit":is_exit}
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.update_camera_settings(admin_mobile, old_camera_name, settings_dict)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Camera updated successfully"
        else:
            resp_dict["msg"] = resp
            
    except Exception as e:
        logging.error("mobile_update_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_update_camera : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/update-camera-max-capacity', methods=['POST'])
@auth.login_required()
def update_camera_max_capacity():
    """Updated Camera Maximum Allowed Capacity"""
    logging.info("update_camera_max_capacity : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        max_capacity = request.json.get('max_capacity')
        
        admin_mobile = get_admin_mobile(auth.current_user())
        saferson.update_max_occupancy(admin_mobile, camera_name, max_capacity)
        resp_dict['status'] = True
        resp_dict['msg'] = 'Capacity Updated'        
    except Exception as e:
        logging.error("update_camera_max_capacity : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("update_camera_max_capacity : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/camera-list', methods=['POST'])
@auth.login_required()
def mobile_camera_list():
    """Camera List"""
    logging.info("mobile_camera_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict["object"] =  saferson.get_camera_names(admin_mobile)

    except Exception as e:
        logging.error("mobile_camera_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_camera_list: end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/delete-camera', methods=['POST'])
@auth.login_required()
def mobile_delete_camera():
    """Delete Camera"""
    logging.info("mobile_delete_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        
        
        if not camera_name:
            resp_dict["msg"] = "Camera name is required"
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.delete_camera_v2(admin_mobile, camera_name)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Deleted successfully"
        else:
            resp_dict["msg"] = resp
        
    except Exception as e:
        logging.error("mobile_delete_camera : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("mobile_delete_camera: end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/add-floor', methods=['POST'])
@auth.login_required()
def mobile_add_floor():
    """Add Floor"""
    logging.info("mobile_add_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_name = request.json.get('floor_name')
        camera_name_list = request.json.get('camera_name_list')
        
        # Input validation
        input_validation = ""
        if not floor_name:
            input_validation = "Floor name is required"
        elif not camera_name_list:
            input_validation = "Choose at lease one camera"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp = saferson.add_floor(admin_mobile, camera_name_list, floor_name)

        if resp == "success":
            resp_dict["status"] = True
            resp_dict["msg"] = "Floor saved successfully"
        else:
            resp_dict["msg"] = resp
        
    except Exception as e:
        logging.error("mobile_add_floor : exception : {}".format(e))
    logging.info("mobile_add_floor : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/update-floor', methods=['POST'])
@auth.login_required()
def mobile_update_floor():
    """Add Floor"""
    logging.info("mobile_update_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_names = request.json.get('floor_names')
        list_camera_names = request.json.get('list_camera_names')
        
        input_validation = ""
        if not floor_names:
            input_validation = "Floor name is required"
        elif not list_camera_names:
            input_validation = "Choose at lease one camera"

        if input_validation:
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        admin_mobile = get_admin_mobile(auth.current_user())
        for index, floor_name in enumerate(floor_names):
            camera_name_tuple =  tuple(list_camera_names[index])
            saferson.update_camera_floor(admin_mobile, camera_name_tuple, floor_name)

        resp_dict["status"] = True
        resp_dict["msg"] = "Updated successfully"
        
    except Exception as e:
        logging.error("mobile_update_floor : exception : {}".format(e))
    logging.info("mobile_update_floor : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/floor-list', methods=['POST'])
@auth.login_required()
def mobile_floor_list():
    """Floor Listing"""
    logging.info("mobile_floor_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        admin_mobile = get_admin_mobile(auth.current_user())
        resp_dict["status"] = True
        resp_dict["object"] = saferson.get_floor_details(admin_mobile)
    
    except Exception as e:
        logging.error("mobile_floor_list : exception : {}".format(e))
    logging.info("mobile_floor_list : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/add-employee', methods=['POST'])
@auth.login_required()
def add_employee():
    """Add Employee"""
    logging.info("add_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        mobile_list = request.json.get('phone_list')

        # Input data validation
        input_validation = ""
        if not mobile_list:
            input_validation = "Mobile No is required"
            resp_dict["msg"] = input_validation
            return jsonify(resp_dict)

        # Add New Employee
        for mobile in mobile_list:
            user = User.query.filter(and_(User.country_id == mobile["country_id"], User.mobile == mobile["phone"], User.status != STATUS["DELETE"])).first()
            if user:
                    resp_dict["msg"] = "Employee named {} already registred with the Mobile No : {}".format(user.name, user.mobile)
                    return jsonify(resp_dict)

        for mobile in mobile_list:
            # Save User
            new_password = get_random_password()
            emp_user = User( "", "", mobile['country_id'], mobile["phone"], auth.current_user().business_id, STATUS["YES"], "", auth.current_user().user_id)
            emp_user.hash_password(new_password)
            emp_user.status = STATUS["ENTRY"]
            emp_user.default_password_changed = STATUS["YES"]
            db.session.add(emp_user)
            db.session.commit()

            # Send sms with new password
            msg = "Kindly click the link below to upload your photo. https://dev.safeo.ai/services/api/login Use temporary password:{}".format( new_password)
            sms_insert(emp_user.country_id, emp_user.mobile, msg)

            admin_mobile = get_admin_mobile(auth.current_user()) 
            # saferson.enable_face_recog(admin_mobile)
        
        resp_dict['status'] = True
        resp_dict['msg'] = "Added Successfully"

    except Exception as e:
        logging.error("add_employee : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("add_employee : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/employee-list', methods=['POST'])
@auth.login_required()
def mobile_employee_list():
    """Employee List"""
    logging.info("employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_info_dict = dict()
        users = db.session.query(User.mobile, User.name, User.designation, User.country_id).filter(and_(
                User.business_id == auth.current_user().business_id,
                User.is_employee == STATUS["YES"],
                User.status != STATUS["DELETE"],
                User.mobile != "UNKNOWN"
                )).order_by(User.created_date.desc()).all()  
        users = list(zip(*users))
        if len(users) > 0:
            mobile_list = list(users[0])
            name_list = list(users[1])
            designation_list = list(users[2])
            country_id_list = list(users[3])
        else:
            mobile_list, name_list, designation_list, country_id_list = [], [], [], []

        employee_info_dict = dict()
        employee_info_dict["mobile"] = mobile_list
        employee_info_dict["name"] = name_list
        employee_info_dict["designation"] = designation_list
        employee_info_dict["country_id"] = country_id_list     

        resp_dict['status'] = True
        resp_dict['object'] = employee_info_dict
    except Exception as e:
        logging.error("employee_list : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("employee_list : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/employee-info', methods=['POST'])
@auth.login_required()
def mobile_employee_info():
    """Fetching Employee Info"""
    logging.info("employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone')
        user = User.query.filter(and_(User.country_id == country_id, User.mobile == employee_phone, User.status != STATUS["DELETE"])).first()
        user_dict = dict()
        if user:
            user_dict["user_id"] = user.user_id
            user_dict["name"] = user.name
            
            country = Country.query.get(user.country_id)
            user_dict["mobile"] = country.country_code +" "+user.mobile
            user_dict["email"] = (user.email if user.email else "")
            user_dict["designation"] = (user.designation if user.designation else "")
            user_dict["emp_id"] = (user.emp_id if user.emp_id else "")
            user_dict["profile_image_path"] = (app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"]+user.profile_image if user.profile_image else app.config["SERVER_PATH"]+app.config["DEFAULT_IMAGE"]) 

            resp_dict["status"] = True
            resp_dict["object"] = user_dict
    except Exception as e:
        logging.error("employee_info : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("employee_info : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/update-employee', methods=['POST'])
@auth.login_required()
def mobile_update_employee():
    """Employee Info Update"""
    logging.info("update_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone')
        employee_name = request.json.get('employee_name')
        email = request.json.get("email")
        designation = request.json.get("designation")
        profile_image = request.json.get('profile_image_data')

        user =  User.query.filter(and_(User.country_id == country_id, User.mobile == employee_phone)).first()
        current_user = auth.current_user()
        if current_user.user_id == user.user_id:
            if not profile_image:
                resp_dict["msg"] = "Profile image is required"
                return resp_dict
            profile_image = profile_image.split(",")[1]
            str_time =  datetime.datetime.now().strftime('%d%m%Y%H%M%S')
            profile_image_file_name = str(user.user_id)+"_"+str_time+".jpg"
            
            with open(os.path.join(app.config["PROFILE_IMAGES"], profile_image_file_name), "wb+") as f:
                logging.info(f)
                f.write(base64.b64decode(profile_image))
            # f = open(os.path.join(app.config["PROFILE_IMAGES"], profile_image_file_name), "wb")
            # logging.info(f)
            # f.write(base64.b64decode(profile_image))

            user.name = employee_name
            user.email = email
            user.designation = designation
            user.profile_image = profile_image_file_name
            user.updated_date = datetime.datetime.now()
            user.status = STATUS["ACTIVE"]
            user.updated_by = auth.current_user().user_id
            db.session.commit()

            if user.is_employee == STATUS["YES"]:
                profile_image_file_name = os.path.abspath(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name))
                employee_info_dict = {
                    'id': user.emp_id,
                    'name': user.name,
                    'pic_path': profile_image_file_name    
                }
                country = Country.query.filter_by (country_id = user.country_id).first()
                user_mobile =  user.mobile

                admin_mobile = get_admin_mobile(auth.current_user())
                # saferson.update_employee_info(user_mobile, admin_mobile, employee_info_dict)
                msg = saferson.update_employee_picture(admin_mobile, user_mobile, os.path.join('/home/kathiravan/safeo-phase2', app.config["PROFILE_IMAGES"], profile_image_file_name))
                    
        elif current_user.user_id != user.user_id:
            user.name = employee_name
            user.email = email
            user.designation = designation
            user.updated_date = datetime.datetime.now()
            user.status = STATUS["ACTIVE"]
            user.updated_by = auth.current_user().user_id
            db.session.commit()

            if user.is_employee == STATUS["YES"]:
                profile_image_file_name = (user.profile_image if user.profile_image else "")
                employee_info_dict = {
                    'id': user.emp_id,
                    'name': user.name,
                    'pic_path': profile_image_file_name    
                }
                country = Country.query.filter_by (country_id = user.country_id).first()
                user_mobile = country.country_code + user.mobile

                admin_mobile = get_admin_mobile(auth.current_user())
                # saferson.update_employee_info(user_mobile, admin_mobile, employee_info_dict)

        resp_dict["status"] = True
        resp_dict["msg"] = "Profile updated successfully"
    except Exception as e:
        logging.error("update_employee : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("update_employee : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/delete-employee', methods=['POST'])
@auth.login_required()
def mobile_delete_employee():
    """Delete Employee"""
    logging.info("delete_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_mobile = request.json.get('employee_phone')
        emp = User.query.filter(User.country_id == country_id, User.mobile == employee_mobile).first()
        if emp :
            emp.status = STATUS["DELETE"]
            db.session.commit()

            country = Country.query.filter_by (country_id = emp.country_id).first()
            user_mobile = country.country_code + emp.mobile
            
            admin_mobile = get_admin_mobile(auth.current_user())
            #saferson.delete_employee(user_mobile, admin_mobile)
            resp_dict['status'] = True
            resp_dict['msg'] = "Deleted Successfully"
        else:
            resp_dict['msg'] = "Employee data not found!"
    except Exception as e:
        logging.error("delete_employee : exception : {}".format(e))
        resp_dict["msg"] = "Internal Server Error"
    logging.info("delete_employee : end")
    return jsonify(resp_dict)  
 #touchless check in
@user_blueprint.route('/api/mobile/touchless-checkin', methods=['POST'])

@auth.login_required()
def touchless_checkin():
    """Touch Less Checkin"""
    logging.info("touchless_checkin : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        filter_cond = request.json.get('filter_cond')        
        user = get_current_user()
        
        time_zone = saferson.get_timezone(request)

        resp = None
        if freq in  ['day', 'week', 'month']:
            resp = saferson.touchless_dashboard(user.mobile, freq=freq, filter_cond=filter_cond, time_zone=time_zone)
        else:
            resp = saferson.touchless_dashboard(user.mobile, \
                start_date_str=start_date, end_date_str=end_date, filter_cond=filter_cond, time_zone=time_zone)
        if resp and resp['attendance_table']:
            for emp in resp['attendance_table']: 
                emp['employee_pic_path'] = app.config["SERVER_PATH"]+"/"+app.config["PROFILE_IMAGES"] + emp['employee_pic_path']
        resp_dict['status'] = True
        resp_dict['object'] = resp
    
    except Exception as e:
        logging.error("touchless_checkin : exception : {}".format(e))
        
    logging.info("touchless_checkin : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/touchless-checkin-employee-info', methods=['POST'])
@auth.login_required()
def touchless_checkin_employee_info():
    """Touch Less Checkin Employee Info"""
    logging.info("touchless_checkin_employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_country_id = request.json.get('employee_country_id')
        employee_mobile = request.json.get('employee_mobile')
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        time_zone = saferson.get_timezone(request)    


        if freq in ['day', 'week', 'month']:
            resp_dict['object'] = saferson.get_employee_attendance(employee_mobile, freq=freq, time_zone=time_zone)
        else:
            resp_dict['object'] = saferson.get_employee_attendance(employee_mobile, \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)    
        resp_dict['status'] = True
    except Exception as e:
        logging.error("touchless_checkin_employee_info : exception : {}".format(e))
        
    logging.info("touchless_checkin_employee_info : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/mobile/dashboard-list', methods=['POST'])
@auth.login_required()
def dashboard_list():
    """Dashboard List"""
    logging.info("dashboard_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        dashboard_dict = {"camera_setup" : False, "employee_setup": False, "touchless_checkin" : False}
        user = auth.current_user()
        functions = get_emp_user_functions(user)
        if functions:
            for function in functions: 
                if (function["function_id"] == 4 or function["function_id"] == 5) and function["function_name"] == 'Camera Setup':
                    dashboard_dict["camera_setup"] = True
                elif (function["function_id"] == 5 or function["function_id"] == 6) and function["function_name"] == 'Employee Setup':
                    dashboard_dict["employee_setup"] = True
                elif  (function["function_id"] == 15 or function["function_id"] == 10) and function["function_name"] == 'Check In / Check Out' : 
                    dashboard_dict["touchless_checkin"] = True

        resp_dict["status"] = True
        resp_dict["object"] = dashboard_dict
          
    except Exception as e:
        logging.error("dashboard_list : exception : {}".format(e))
        
    logging.info("dashboard_list : end")
    return jsonify(resp_dict)             



