#TODO BETTER WAY TO RUN BACKGROUND THREADS
#TODO BETTER WAY TO TERMINATE BACKGROUND THREADS
#TODO CUDA OUT OF MEMORY - check memory usage and if everything is released properly
#TODO FIX TIME ZONE CONVERSION - RN, assume that everything is in utc same time zone
#TODO IMPLEMENT STREAMING TASK QUEUE AND MESSAGE BROKER (SCALABLE)
#TODO IMPLEMENT DYNAMIC BATCH PROCESSING IN QUEUE MECHANISM
#TODO SET FPS LIMIT FOR CAMS
#TODO CONVERT MODELS TO TENSOR RT
#TODO CREATE REST API TO COMMUNICATE WITH MODEL
#TODO CONTAINERIZE EVERYTHING
#TODO CHANGE SCORING MECHANISM - (how heatmap factors into overall score)
#TODO OPTIMIZE DATABASE

#TODO When delete camera, check in queue processing
#TODO add weakref directly to db
#TODO delete user
#TODO check uniqueness of rtsp link ?
#TODO rethink handling of max occupancy in heatmap
#TODO rethink some settings functions maybe ?

import os
import numpy as np
import cv2
import shutil
from datetime import datetime, timedelta, timezone
import psycopg2
from psycopg2 import pool
from psycopg2 import sql
import uuid
import weakref
from threading import Thread
import threading
from multiprocessing import Queue
import base64

import socket
import concurrent.futures
import requests
import time
import sys
import re

import psycopg2.extras

#importing module 
import logging 

#Create and configure logger 
logging.basicConfig(filename="saferson.log", 
                    format='%(asctime)s %(message)s', 
                    filemode='w')

logger=logging.getLogger() 
  
#Setting the threshold of logger to DEBUG 
logger.setLevel(logging.DEBUG)

import pandas as pd

try:
    df = pd.read_csv('url.csv')
except:
    logger.exception('Exception in reading url.csv')
    df = pd.DataFrame()

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()

import config

from face_recognition.recog_inference import FaceRecogInference

from stream_reader import VideoStreamReader
from maskerson import Maskerson
from social_distance import SD
from heat_mapperson import HeatMapperson
from scoreson import Scoreson
from facerson import Facerson
# from safety_gears import SafetyGear

from reidmct.create_tracker import UserTrackerMapper, FrameDistributer
from reidmct.attendance_triggers import AttendanceEventTrigger

#to Get timezone info from IP
from geolite2 import geolite2
import pytz 

##FACE Detection for user image validation
from face_detection.run_inference import RetinaFaceInference

##FACE recognition
from face_recognition.recog_inference import FaceRecogInference
BASE_FACEBANK_PATH = "./facebank"
# BASE_FACEBANK_PATH =  "/home/kathiravan/safeo-phase2/facebank"
#Default image path for employee with no profile picture
DEFAULT_PIC_PATH = "./default.png"

#camera_objects_dict = weakref.WeakValueDictionary()

db_connection_pool = psycopg2.pool.SimpleConnectionPool(
                        minconn=1, 
                        maxconn=20,
                        user="sfsktusr01",
                        password="_k9Bd#RP",
                        host="localhost",
                        database="safeov2_dev")

mask_queue = Queue()
sd_queue = Queue()
heatmap_queue = Queue()
score_queue = Queue()
# safety_queue = Queue()
attendance_trigger_queue = Queue()

sd_obj = SD(in_data_queue=sd_queue, out_data_queue=mask_queue)
sd_thread = Thread(target=sd_obj.run, args=())
sd_thread.daemon = False
sd_thread.start()

# sf_obj = SafetyGear(in_data_queue=safety_queue, out_data_queue=mask_queue)
# sf_thread = Thread(target=sf_obj.run, args=())
# sf_thread.daemon = False
# sf_thread.start()

# mask_obj = Maskerson(in_data_queue=mask_queue, out_data_queue=heatmap_queue)
# mask_thread = Thread(target=mask_obj.run, args=())
# mask_thread.daemon = False
# mask_thread.start()

# map_obj = HeatMapperson(in_data_queue=heatmap_queue, out_data_queue=score_queue)
# map_thread = Thread(target=map_obj.run, args=())
# map_thread.daemon = False
# map_thread.start()


attendance_trigger = AttendanceEventTrigger(in_queue=attendance_trigger_queue,
                                            url=config.AIRFLOW_URL,
                                            user=config.AIRFLOW_USER,
                                            password = config.AIRFLOW_PASSWORD)

user_attendance_mapper = UserTrackerMapper(attendance_trigger)

distributer_obj = FrameDistributer(in_queue=sd_queue, user_attendance_mapper=user_attendance_mapper)
distributer_obj.run_as_thread()

# score_obj = Scoreson(in_data_queue=score_queue)
# score_thread = Thread(target=score_obj.run, args=())
# score_thread.daemon = False
# score_thread.start()

# face_obj = Facerson()
# face_thread = Thread(target=face_obj.run, args=())
# face_thread.daemon = False
# face_thread.start()

def update_employee_picture(user_id, employee_id, employee_pic_path):
    try:
        # enable_face_recog(user_id)
        print("user_id:   " ,user_id, " employee_id  :  ", employee_id, "    employee_pic_path:   ", employee_pic_path)
        img = cv2.imread(employee_pic_path)
        tracker = user_attendance_mapper.get_user_tracker(user_id)
        tracker.facer.add_individual(employee_id, [img])
        print("success")
        return "success"
    except Exception as e:
        # print(e)
        return e.__repr__()

def get_camera_object_dict():
    '''A function to initialize camera object dict. If server restarts then camera objects are reconnected else
    empty camera object dictionary is created.
    '''
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id, rtsp_link \
                            FROM camera_details")
        
        camera_data = cursor.fetchall()
        cursor.close()    
        db_connection_pool.putconn(connection)

        if len(camera_data) == 0:
            return weakref.WeakValueDictionary()

        camera_object_dict = weakref.WeakValueDictionary()

        for camera_id,link in camera_data:
            camera = VideoStreamReader(camera_id=camera_id, rtsp_link=link, data_queue=sd_queue)
            if camera.get_connection_status():
                camera_object_dict[camera_id] = camera
                camera.start()
        return camera_object_dict
    except:
        logger.exception("Exception in get_camera_object_dict")
        return weakref.WeakValueDictionary()

#camera_objects_dict = get_camera_object_dict()
camera_objects_dict = weakref.WeakValueDictionary()

def create_sql_function():
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("CREATE OR REPLACE FUNCTION attend(ftime timestamptz, fstatus boolean, fnum_sec float, ltime timestamptz,lstatus boolean, lnum float8, tnum_secs float8, start timestamptz, end_time timestamptz)\
                        returns float8\
                        language plpgsql\
                        as\
                        $$\
                            BEGIN\
                                IF FSTATUS = FALSE THEN\
                                    tnum_secs := tnum_secs - fnum_sec;\
                                    tnum_secs := tnum_secs + extract(epoch from ftime at time zone 'utc'-start at time zone 'utc');\
                                END IF;\
                                IF LSTATUS THEN\
                                    tnum_secs := tnum_secs + extract(epoch from end_time at time zone 'utc' - ltime at time zone 'utc');\
                                END IF;\
                                return tnum_secs;\
                            END;\
                        $$;")


        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.error("Error in create_sql_function()",exc_info=True)
        raise

create_sql_function()

def delete_camera_v2(user_email, camera_name):
    try:
        camera_id = get_camera_id(user_email, camera_name)
       
        if camera_id in camera_objects_dict.keys():
            camera_objects_dict[camera_id].remove_stream_reader()
            #del camera_objects_dict[camera_id]
            logger.info(camera_objects_dict.keys())
            logger.info(camera_id)
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
    
        cursor.execute("DELETE FROM tb_unauthorized_access_config \
                                         WHERE camera_id = %s", (camera_id, ))

        cursor.execute("DELETE FROM tb_mask_compliance_config \
                                        WHERE camera_id = %s", (camera_id, ))
                         
        cursor.execute("DELETE FROM tb_social_distancing_config \
                                        WHERE camera_id = %s", (camera_id, ))
                                 
        cursor.execute("DELETE FROM tb_safety_gear_config \
                                        WHERE camera_id = %s", (camera_id, ))
                                         
        cursor.execute("DELETE FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in delete camera_v2")
        return 'faliure'
        
def update_max_occupancy_by_id(user_email, camera_id, max_occupancy):
    logging.debug("update_max_occupancy_by_id : Start")
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("UPDATE camera_details \
                        SET max_occupancy = %s \
                        WHERE user_email = %s AND camera_id = %s",(max_occupancy, user_email, camera_id))
        connection.commit()
        cursor.close()
        return 'success'
    except Exception as e:
        logging.exception("Exception : update_max_occupancy_by_id : ",e)
        return 'failure'

def get_max_occupancy(user_email, camera_id):
    logging.debug("get_max_occupancy : Start")
    try:
        max_occupancy = 0
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT max_occupancy WHERE user_email = %s AND camera_id = %s",(user_email, camera_id))
        row = cursor.fetchone()
        if row:
            max_occupancy = row[0]
    except Exception as e:
        logging.exception("Exception : get_max_occupancy : ",e)
    logging.debug("get_max_occupancy : End")
    return max_occupancy

def add_camera(user_email, camera_name, rtsp_link, username=None, password=None, is_checkin_checkout = False, is_exit = False):
    try:
        max_occupancy = 10
        floor_name = 'ground floor'

        _, camera_name_list, _, _ = get_camera_details(user_email)
        if camera_name in camera_name_list:
            return "This camera name already exists"

        camera_id = uuid.uuid4()
        camera = VideoStreamReader(camera_id=camera_id, rtsp_link=rtsp_link, data_queue=sd_queue)
        
        if camera.get_connection_status():
            camera_objects_dict[camera_id] = camera

            connection = db_connection_pool.getconn()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO camera_details (user_email, camera_id, camera_name, rtsp_link, floor_name, max_occupancy, is_checkin_checkout, is_exit) \
                            VALUES (%s, %s, %s, %s, %s, %s, %s,%s)", (user_email, camera_id, camera_name, str(rtsp_link), floor_name, max_occupancy, is_checkin_checkout, is_exit))
            connection.commit()
            cursor.close()
            db_connection_pool.putconn(connection)

            camera.start()

            return 'success'
        else:
            return 'failure'
    except:
        logger.exception("exception occured in add_camera")
        return 'failure'

def get_camera_details(user_email):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id, camera_name, floor_name, max_occupancy \
                        FROM camera_details \
                        WHERE user_email = %s \
                        ORDER BY floor_name ASC", (user_email, ))
        
        camera_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(camera_data) > 0:
            camera_id_list, camera_name_list, floor_name_list, max_occupancy_list =  map(list,zip(*camera_data))
        else:
            camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = [], [], [], []

        return (camera_id_list, camera_name_list, floor_name_list, max_occupancy_list)
    except:
        logger.exception('exception occured in get_camera details')
        return ([],[],[],[])

def update_camera_details(user_email, camera_name, col_name, col_value):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute(sql.SQL("UPDATE camera_details \
                        SET {} = %s \
                        WHERE user_email = %s AND camera_name = %s").format(sql.Identifier(col_name)), [col_value, user_email, camera_name])

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.exception('Exception occured in update_camera_details')

def update_camera_floor(user_email, camera_name_tuple, floor_name):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("UPDATE camera_details \
                        SET floor_name = %s \
                        WHERE user_email = %s AND camera_name IN %s", (floor_name, user_email, camera_name_tuple))
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.exception("Exception in update_camera_floor")

def update_camera_settings(user_email, camera_name, settings_dict):
    try:
        curr_settings_dict = get_camera_settings(user_email, camera_name)

        res = 'success'

        if curr_settings_dict['camera_name'] != settings_dict['camera_name']:
            res = update_camera_name(user_email, camera_name, settings_dict['camera_name'])
            if res != 'success':
                return res

        if curr_settings_dict['rtsp_link'] != settings_dict['rtsp_link']:
            res = update_rtsp_link(user_email, camera_name, settings_dict['rtsp_link'])

        # update is_checin_checkout:
        update_camera_details(user_email, camera_name, 'is_checkin_checkout', settings_dict['is_checkin_checkout'])
        
        # update is_exit:
        update_camera_details(user_email, camera_name, 'is_exit', settings_dict['is_exit'])
        
        return res
    except:
        logger.exception('Exception in update_camera_settings')
        return 'faliure'

def update_floor(user_email, floor_dict):
    try:
        floor_name_list = floor_dict['floor_name']
        camera_name_list = floor_dict['camera_name_list']

        for i, floor_name in enumerate(floor_name_list):
            curr_camera_list = camera_name_list[i]
            update_camera_floor(user_email, tuple(curr_camera_list), floor_name)

        return 'success'
    except:
        logger.exception("Exception in update floor")
        return 'failure'

def add_floor(user_email, camera_name_list, floor_name):
    try:
        _, _, floor_name_list, _ = get_camera_details(user_email)

        if floor_name in floor_name_list:
            return 'This floor name already exists'
        else:
            update_camera_floor(user_email, tuple(camera_name_list), floor_name)
            return 'success'
    except:
        logger.exception("Exception in add_floor")
        return 'faliure'

def get_floor_details(user_email):
    try:
        _, camera_name_list, floor_name_list, _ = get_camera_details(user_email)

        floor_dict = dict()

        for i, camera_name in enumerate(camera_name_list):
            floor_name = floor_name_list[i]
            if floor_name in floor_dict:
                floor_dict[floor_name].append(camera_name)
            else:
                floor_dict[floor_name] = [camera_name]

        location_dict = dict()
        location_dict['floor_name'] = list(floor_dict.keys())
        location_dict['camera_name_list'] = list(floor_dict.values())
        
        return location_dict
    except:
        logger.exception("Exception in get_floor_details")
        return {'floor_name':[],'camera_name_list':[]}

def update_max_occupancy(user_email, camera_name, max_occupancy):
    try:
        update_camera_details(user_email, camera_name, 'max_occupancy', max_occupancy)
        return 'success'
    except:
        logger.exception("Exception in update_max_occupancy")
        return 'failure'

def update_camera_name(user_email, camera_name, new_camera_name):
    try:
        _, camera_name_list, _, _ = get_camera_details(user_email)

        if new_camera_name in camera_name_list:
            return 'This camera name already exists'
        else:
            update_camera_details(user_email, camera_name, 'camera_name', new_camera_name)
            return 'success'
    except:
        logger.exception("Exception in update_camera_name")
        return 'failure'

def update_rtsp_link(user_email, camera_name, rtsp_link):
    try:
        camera_id = get_camera_id(user_email, camera_name)

        camera = VideoStreamReader(camera_id=camera_id, rtsp_link=rtsp_link, data_queue=sd_queue)
        
        if camera.get_connection_status():
            camera_objects_dict[camera_id].remove_stream_reader()

            camera_objects_dict[camera_id] = camera

            camera.start()

            update_camera_details(user_email, camera_name, 'rtsp_link', rtsp_link)

            return 'success'
        else:
            return 'failure'
    except:
        logger.exception("Exception in update_rtsp_link")
        return 'failure'

def delete_camera(user_email, camera_name):
    try:
        camera_id = get_camera_id(user_email, camera_name)
       
        if camera_id in camera_objects_dict.keys():
            camera_objects_dict[camera_id].remove_stream_reader()
            #del camera_objects_dict[camera_id]
            logger.info(camera_objects_dict.keys())
            logger.info(camera_id)

     
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        
        
        cursor.execute("DELETE FROM mask \
                                         WHERE camera_id = %s", (camera_id, ))

        cursor.execute("DELETE FROM social_distance \
                                        WHERE camera_id = %s", (camera_id, ))
                         
        cursor.execute("DELETE FROM heatmap \
                                        WHERE camera_id = %s", (camera_id, ))
                                 
        cursor.execute("DELETE FROM violation \
                                        WHERE camera_id = %s", (camera_id, ))
                                         
        cursor.execute("DELETE FROM score \
                                        WHERE camera_id = %s", (camera_id, ))
        cursor.execute("DELETE FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in delete camera")
        return 'faliure'

def get_camera_id(user_email, camera_name):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id \
                        FROM camera_details \
                        WHERE user_email = %s and camera_name = %s", (user_email, camera_name))
        
        camera_id_data = cursor.fetchall()
        
        cursor.close()
        db_connection_pool.putconn(connection)
        
        camera_id = list(zip(*camera_id_data))[0][0]

        return camera_id
    except:
        logger.exception("Exception in get_camera_id")
        return uuid.uuid4()
    
def get_camera_names(user_email):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_name \
                        FROM camera_details \
                        WHERE user_email = %s \
                        ORDER BY camera_name ASC", (user_email, ))
        
        camera_name_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(camera_name_data) > 0:
            camera_name_list = list(list(zip(*camera_name_data))[0])
        else:
            camera_name_list = []

        return camera_name_list
    except:
        logger.exception("Exceptionn in get_camera_names")
        return []
    
# get_camera_names replace get_camera_list
def get_camera_list(user_email):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id, camera_name \
                        FROM camera_details \
                        WHERE user_email = %s \
                        ORDER BY camera_name ASC", (user_email, ))
        camera_lists = cursor.fetchall()

        if len(camera_lists) > 0:
            camera_list = [{"camera_id":row[0], "camera_name":row[1]} for row in camera_lists]
        else:
            camera_list = []
        
        cursor.close()
        db_connection_pool.putconn(connection)

        return camera_list
    except Exception as e:
        logger.exception("Exceptionn in get_camera_list : ",e)
        return []

def get_camera_settings(user_email, camera_name):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT rtsp_link \
                        FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))
        
        settings_data = cursor.fetchall()
        settings_list = list(zip(*settings_data))[0]

        cursor.close()
        db_connection_pool.putconn(connection)

        rtsp_link = settings_list[0]

        settings_dict = dict()
        settings_dict['camera_name'] = camera_name
        settings_dict['rtsp_link'] = rtsp_link

        return settings_dict
    except:
        logger.exception("Exception in get_camera_settings")
        return {'camera_name':None,'rtsp_link':None}

# get_camera_settings replace get_camera_info
def get_camera_info(user_email, camera_name):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_id,  rtsp_link , camera_name, is_checkin_checkout, is_exit, max_occupancy\
                        FROM camera_details \
                        WHERE user_email = %s AND camera_name = %s", (user_email, camera_name))
        camera_data = cursor.fetchone()
        camera_dict = dict()
        if camera_data:
            camera_dict["camera_id"] = camera_data[0]
            camera_dict["rtsp_link"] = camera_data[1]
            camera_dict["camera_name"] = camera_data[2]
            camera_dict["is_checkin_checkout"] = camera_data[3]
            camera_dict["is_exit"] = camera_data[4]
            camera_dict["max_occupancy"] = camera_data[5]
        
        cursor.close()
        db_connection_pool.putconn(connection)

        return camera_dict
    except:
        logger.exception("get_camera_info")
        return {}

def get_risk_status(score):
    if score > 80:
        return 'unsafe'
    elif score > 20:
        return 'cautious'
    else:
        return 'safe'

def get_safety_status(score):
    if score >= 80:
        return 'safe'
    elif score >= 20:
        return 'cautious'
    else:
        return 'unsafe'

def str_to_date(date_str):
    date = datetime.strptime(date_str, '%Y-%m-%d').date()
    return date

# def get_start_date(end_date, freq):
#     start_date = end_date
#     if freq == 'day':
#         start_date = end_date
#     elif freq == 'week':
#         curr_week_day = end_date.weekday()
#         start_date = end_date - timedelta(days=curr_week_day)
#     elif freq == 'month':
#         start_date = end_date.replace(day=1)
    
#     return start_date

# def get_date_frame(end_date):
#     try:
#         date_frame = {}

#         for freq in ['now','day', 'week', 'month']:
#             if freq == 'now':
#                 curr_str = end_date.strftime('%H:%M')
#             if freq == 'day':
#                 curr_str = end_date.strftime('%b %-d, %Y')

#             elif freq == 'week':
#                 start_date = get_start_date(end_date, freq)
#                 start_day = start_date.strftime('%-d')
#                 start_month = start_date.strftime('%b')
#                 end_day = end_date.strftime('%-d')
#                 end_month = end_date.strftime('%b')

#                 if start_month == end_month:
#                     curr_str =  start_month + ' ' + start_day + ' to ' + end_day
#                 else:
#                     curr_str = start_month + ' ' + start_day + ' to ' + end_month + ' ' + end_day
            
#             elif freq == 'month':
#                 curr_str = end_date.strftime('%b 1 to %-d')
            
#             date_frame[freq] = curr_str

#         return date_frame
#     except:
#         logger.exception("Exception in get_date_frame")
#         return {}

def get_safety_score(module_name, camera_id_tuple, start_date, end_date):
    try:
        metric_name = module_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp AND \
                                        time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s AND {} >= 0").format(sql.Identifier(metric_name),sql.Identifier(metric_name)), [start_date, end_date, camera_id_tuple])
            risk_data = cursor.fetchall()
        else:
            risk_data = []
        
        cursor.close()
        db_connection_pool.putconn(connection)

        if len(risk_data) > 0:
            risk_score = risk_data[0][0]
            if risk_score is None:
                safety_score = 1
            else:
                safety_score = 1 - risk_score
        else:
            safety_score = 1
        return safety_score
    except:
        logger.exception("Exception in get_safety_score")
        return -1

def get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision='day',time_zone='UTC'):
    try:
        precision_str = '1 ' + precision

        if precision == 'hour':
            date_format_str = 'HH12 am'
        else:
            date_format_str = 'Mon DD'
        
        metric_name = dashboard_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT to_char(grouped_time, %s), avg \
                            FROM \
                                (SELECT time_bucket(%s, time AT TIME ZONE %s) AS grouped_time, avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp  \
                                        AND time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s AND {} > 0 \
                                    GROUP BY grouped_time \
                                    ORDER BY grouped_time ASC) AS temp_table").format(sql.Identifier(metric_name),sql.Identifier(metric_name)), [date_format_str, precision_str, time_zone, start_date, end_date, camera_id_tuple])

            data = cursor.fetchall()
        
        else:
            data = []

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) > 0:
            x_arr, y_arr = map(list,zip(*data))
        else:
            x_arr, y_arr = [], []

        return (x_arr, y_arr)
    except:
        logger.exception("Exception in get_risk_score_data")
        return 

def get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date):
    try:
        metric_name = dashboard_name + "_risk_score"

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT camera_id, avg({}) \
                                    FROM score \
                                    WHERE time > %s::timestamp AND \
                                            time < (SELECT %s::timestamp + interval '1 day') AND \
                                            camera_id IN %s \
                                    GROUP BY camera_id").format(sql.Identifier(metric_name)), [start_date, end_date, camera_id_tuple])
            data = cursor.fetchall()

        else:
            data = []
        
        cursor.close()
        db_connection_pool.putconn(connection)

        camera_score_dict = dict(data)

        return camera_score_dict
    except:
        logger.exception("Exception in get_camera_risk_score")
        return {}

# def get_date_range(start_date_str=None, end_date_str=None, freq='day'):
#     try:
#         if start_date_str and end_date_str:
#             if start_date_str == end_date_str:
#                 precision = 'hour'
#             else:
#                 precision = 'day'
            
#             start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
#             end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()

#         else:
#             if freq == 'day':
#                 precision = 'hour'
#             else:
#                 precision = 'day'
            
#             end_date = datetime.now(timezone.utc).date()
#             start_date = get_start_date(end_date, freq)
        
#         return (start_date, end_date, precision)
#     except:
#         logger.exception("Exception inn get_date_range")
#         return (datetime.min,datetime.max,'hour')

def get_camera_risk_score_now(dashboard_name, camera_id_tuple):

    dashboard_name += "_risk_score"
    connection = db_connection_pool.getconn()
    cursor = connection.cursor()
    if len(camera_id_tuple) > 0:
        cursor.execute(sql.SQL("SELECT cid,lst,lst-prev as diff, (lst-prev)/(prev+0.001) as pct FROM\
                            ( SELECT camera_id as cid,last({},time) as lst, (SELECT lead({}) over (order by time desc) FROM SCORE limit 1) as prev \
                                FROM score\
                                    WHERE camera_id in %s\
                                    GROUP BY camera_id)as temp").format(sql.Identifier(dashboard_name),sql.Identifier(dashboard_name)),[camera_id_tuple])
        data = cursor.fetchall()

    else:
        data = []
    
    cursor.close()
    db_connection_pool.putconn(connection)

    if len(data) < 1:
        # cursor.close()
        # db_connection_pool.putconn(connection)
        return  {'risk_score':0,'risk_status':None,'delta':0,'pct_delta':0,'change':'increases'}

    #camera_score_dict = {}
    average_score = 0
    average_change = 0
    average_pct_change = 0
    for i in  data:
        #risk_score = int(i[1]*100)
        #if i[2] < 0:
        #    change = 'decrease'
        #elif i[2]==0:
        #    change = 'increase'
        #camera_score_dict[i[0]] = {'risk_score':risk_score,'risk_status':get_risk_status(risk_score),'delta':int(i[2]*100),'pct_delta':round(i[3]*100,2),'change':change}
        average_score +=i[1]
        average_change+=i[2]
        average_pct_change+=i[3]

    average_score /=len(data)
    average_change/= len(data)
    average_pct_change /= len(data)
    if average_change >=0:
        change='increase'
    else:
        change = 'decrease'  

    return {'risk_score':round(average_score),'delta':average_change,'pct_delta':average_change*100,'change':change}

def get_dashboard_data_now(user_email,dashboard_name):

    try:
        dashboard_name += "_risk_score"
        camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        if len(camera_id_tuple) > 0:
            cursor.execute(sql.SQL("SELECT cid,lst,lst-prev as diff, (lst-prev)/(prev+0.1) as pct FROM\
                                ( SELECT camera_id as cid,last({},time) as lst, (SELECT lead({}) over (order by time desc) FROM SCORE limit 1) as prev \
                                    FROM score\
                                        WHERE camera_id in %s\
                                        GROUP BY camera_id)as temp").format(sql.Identifier(dashboard_name),sql.Identifier(dashboard_name)),[camera_id_tuple])
            data = cursor.fetchall()
    
        else:
            data = []

        if len(data) < 1:
            cursor.close()
            db_connection_pool.putconn(connection)
            return {'floor_names':[],'camera_data':[],'OveraOverall_average':[],'Overall_change':[],'Overall_percent_change':[],'date_frame':[]}

        camera_score_dict = {}
        average_score = 0
        average_change = 0
        average_pct_change = 0
        for i in  data:
            risk_score = int(i[1]*100)
            if i[2] < 0:
                change = 'decrease'
            else:
                change = 'increase'
            uuid_index = camera_id_list.index(i[0])
            name = camera_name_list[uuid_index]    
            camera_score_dict[name] = {'name':name,'risk_score':risk_score,'risk_status':get_risk_status(risk_score),'delta':int(i[2]*100),'pct_delta':round(i[3]*100,2),'change':change}
            if dashboard_name == "heatmap_risk_score":
                camera_score_dict[name]['max_occupancy'] = max_occupancy_list[uuid_index]
            average_score +=i[1]
            average_change+=i[2]
            average_pct_change+=i[3]

        average_score /=len(data)
        average_change/= len(data)
        average_pct_change /= len(data)
        
            

        floor_dict = dict()
        logger.info(f'Camera_id_list = {camera_id_list}')
        for i, camera_id in enumerate(camera_id_list):
            camera_floor = floor_name_list[i]
            uuid_index = camera_id_list.index(camera_id)
            name = camera_name_list[uuid_index]  
            if name in camera_score_dict:
                if camera_floor in floor_dict:
                    floor_dict[camera_floor].append(camera_score_dict[name])
                else:
                    floor_dict[camera_floor] = [camera_score_dict[name]] 
        
        camera_dict = dict()
        camera_dict['floor_names'] = list(floor_dict.keys())
        camera_dict['camera_data'] = list(floor_dict.values())
        
        logger.info(f'camera_dict = {camera_dict}')

        dashboard_dict = dict()
        dashboard_dict['location_data'] = camera_dict
        dashboard_dict['Overall_average'] = abs(int(average_score*100))
        
        overall_change = 'No'
        if average_change >= 0:
            overall_change = 'increase'
        else:
            overall_change = 'decrease'

        dashboard_dict['Overall_change'] = overall_change
        dashboard_dict['Overall_percent_change'] = round(average_pct_change*100,2)
        
        date_frame = get_date_frame(datetime.now())
        dashboard_dict['date_frame'] = date_frame

        cursor.close()
        db_connection_pool.putconn(connection)
        
        return dashboard_dict

    except:
        logger.exception("Exception in get_dashboard_data_now")
        return {'floor_names':[],'camera_data':[],'OveraOverall_average':[],'Overall_change':[],'Overall_percent_change':[],'date_frame':[]}

def get_dashboard_data(user_email, dashboard_name, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
    try:
        if dashboard_name not in ['mask', 'heatmap', 'sd']:
            return get_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision=freq,time_zone=time_zone)

        if freq == 'now':
            return get_dashboard_data_now(user_email,dashboard_name)
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        date_frame = get_date_frame(end_date)
        
        camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        x_arr, y_arr = get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone=time_zone)
        scaled_y_arr = list(np.array(y_arr) * 100)
        graph_dict = dict()
        graph_dict['x'] = x_arr
        graph_dict['y'] = scaled_y_arr

        camera_score_dict = get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date) 

        floor_dict = dict()

        for i, camera_id in enumerate(camera_id_list):
            curr_dict = dict()

            if camera_id in camera_score_dict:
                camera_risk_score = int(camera_score_dict[camera_id] * 100)
            else:
                camera_risk_score = int(0)
            
            camera_risk_status = get_risk_status(camera_risk_score)

            curr_dict['name'] = camera_name_list[i]
            curr_dict['risk_score'] = camera_risk_score
            curr_dict['risk_status'] = camera_risk_status

            if dashboard_name == 'heatmap':
                curr_dict['max_occupancy'] = max_occupancy_list[i]

            camera_floor = floor_name_list[i]

            if camera_floor in floor_dict:
                floor_dict[camera_floor].append(curr_dict)
            else:
                floor_dict[camera_floor] = [curr_dict] 
        
        camera_dict = dict()
        camera_dict['floor_names'] = list(floor_dict.keys())
        camera_dict['camera_data'] = list(floor_dict.values())

        dashboard_dict = dict()
        dashboard_dict['date_frame'] = date_frame
        dashboard_dict['graph_data'] = graph_dict
        dashboard_dict['location_data'] = camera_dict


        get_safety_score(dashboard_name, camera_id_tuple, start_date, end_date)

        return dashboard_dict
    except:
        logger.exception("Exception in get_dashboard_data")
        return {'date_frame':[],'floor_names':[],'camera_data':[],'graph_data':[],'location_data':[]}

######## CHECK if this is faster
def get_dashboard_graph(user_email, dashboard_name, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
    try:
        if freq == 'now':
            return get_dashboard_data_now(user_email,dashboard_name)
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        date_frame = get_date_frame(end_date)
        
        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        x_arr, y_arr = get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone=time_zone)
        scaled_y_arr = list(np.array(y_arr) * 100)
        graph_dict = dict()
        graph_dict['x'] = x_arr
        graph_dict['y'] = scaled_y_arr

        # camera_score_dict = get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date) 

        # floor_dict = dict()

        # for i, camera_id in enumerate(camera_id_list):
        #     curr_dict = dict()

        #     if camera_id in camera_score_dict:
        #         camera_risk_score = int(camera_score_dict[camera_id] * 100)
        #     else:
        #         camera_risk_score = int(0)
            
        #     camera_risk_status = get_risk_status(camera_risk_score)

        #     curr_dict['name'] = camera_name_list[i]
        #     curr_dict['risk_score'] = camera_risk_score
        #     curr_dict['risk_status'] = camera_risk_status

        #     if dashboard_name == 'heatmap':
        #         curr_dict['max_occupancy'] = max_occupancy_list[i]

        #     camera_floor = floor_name_list[i]

        #     if camera_floor in floor_dict:
        #         floor_dict[camera_floor].append(curr_dict)
        #     else:
        #         floor_dict[camera_floor] = [curr_dict] 
        
        # camera_dict = dict()
        # camera_dict['floor_names'] = list(floor_dict.keys())
        # camera_dict['camera_data'] = list(floor_dict.values())

        dashboard_graph_dict = dict()
        dashboard_graph_dict['date_frame'] = date_frame
        dashboard_graph_dict['graph_data'] = graph_dict
        # dashboard_dict['location_data'] = camera_dict


        # get_safety_score(dashboard_name, camera_id_tuple, start_date, end_date)

        return dashboard_graph_dict
    except:
        logger.exception("Exception in get_dashboard_data")
        return {'date_frame':[],'graph_data':[]}

##############CHECK if this is faster
def get_dashboard_camera(user_email, dashboard_name, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
    try:
        if freq == 'now':
            return get_dashboard_data_now(user_email,dashboard_name)
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        # date_frame = get_date_frame(end_date)
        
        camera_id_list, camera_name_list, floor_name_list, max_occupancy_list = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        # x_arr, y_arr = get_risk_score_data(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone=time_zone)
        # scaled_y_arr = list(np.array(y_arr) * 100)
        # graph_dict = dict()
        # graph_dict['x'] = x_arr
        # graph_dict['y'] = scaled_y_arr

        camera_score_dict = get_camera_risk_score(dashboard_name, camera_id_tuple, start_date, end_date) 

        floor_dict = dict()

        for i, camera_id in enumerate(camera_id_list):
            curr_dict = dict()

            if camera_id in camera_score_dict:
                camera_risk_score = int(camera_score_dict[camera_id] * 100)
            else:
                camera_risk_score = int(0)
            
            camera_risk_status = get_risk_status(camera_risk_score)

            curr_dict['name'] = camera_name_list[i]
            curr_dict['risk_score'] = camera_risk_score
            curr_dict['risk_status'] = camera_risk_status

            if dashboard_name == 'heatmap':
                curr_dict['max_occupancy'] = max_occupancy_list[i]

            camera_floor = floor_name_list[i]

            if camera_floor in floor_dict:
                floor_dict[camera_floor].append(curr_dict)
            else:
                floor_dict[camera_floor] = [curr_dict] 
        
        camera_dict = dict()
        camera_dict['floor_names'] = list(floor_dict.keys())
        camera_dict['camera_data'] = list(floor_dict.values())

        dashboard_camera_dict = dict()
        # dashboard_graph_dict['date_frame'] = date_frame
        # dashboard_graph_dict['graph_data'] = graph_dict
        dashboard_camera_dict['location_data'] = camera_dict


        # get_safety_score(dashboard_name, camera_id_tuple, start_date, end_date)

        return dashboard_camera_dict
    except:
        logger.exception("Exception in get_dashboard_data")
        return {'location_data':[]}

def get_score_change(score):

    if score < 0:
        return 'decrease'
    else:
        return 'increase'

def get_safety_insights_now(user_email):

    try:

        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        if len(camera_id_list) < 1:
            return  {"safety_score":[],'safety_status':[]}

        #dasb_dict = get_camera_risk_score_now('overall', camera_id_tuple)
        dashboard_dict = dict()
        #overall_score = 100 - dasb_dict['risk_score']
        dashboard_dict['overall_safety_insight'] = 100#overall_average
        dashboard_dict['overall_safety_status'] = get_safety_status(100)#overall_average
        dashboard_dict['overall_safety_insight_pct_chagne'] = 0#-1 * dasb_dict['pct_delta'] #overll_oct_avg
        dashboard_dict['overall_safety_insight_chagne'] = get_score_change(0) #overll_oct_avg
        module_dict = get_user_dashboard_list(user_email)
        #module_list = [key for key,value in module_dict if value == 1]
        module_list = []
        for key,value in module_dict.items():
            if key == 'safety_gear' and value == 1:
                module_list += get_safety_dashboards(user_email)
            elif key != 'safety_gear' and value == 1:
                module_list.append(key) 

        overall_score_list = []
        overall_pct_change = []
        for module in module_list:
            curr_dict = dict()
            if module not in ['mask','heatmap','sd']:
                module_safety_score, module_change , module_safaety_change  = get_safety_gear_score_now(module,camera_id_tuple)
                module_change_status = get_score_change(module_change)
            else:
                d_dict = get_camera_risk_score_now(module, camera_id_tuple)
                module_safety_score = 100 - d_dict['risk_score']
                module_change =  dashboard_dict['overall_safety_insight_pct_chagne']
                module_change_status = get_score_change(module_change)
            
            module_safety_status = get_safety_status(module_safety_score)
            
            #overall
            overall_score_list.append(module_safety_score)
            overall_pct_change.append(module_change)
            
            curr_dict['safety_score'] = module_safety_score
            curr_dict['pct_change'] = module_change 
            curr_dict['safety_status'] = module_safety_status
            curr_dict['change'] = module_change

            dashboard_dict[module + '_data'] = curr_dict


        ######
        #update dashboard_dict here
        dashboard_dict['overall_safety_insight'] = round(np.mean(overall_score_list),2)
        dashboard_dict['overall_safety_status'] = get_safety_status(dashboard_dict['overall_safety_insight'])
        dashboard_dict['overall_safety_insight_pct_chagne'] = round(np.mean(overall_pct_change),2)
        dashboard_dict['overall_safety_insight_chagne'] = get_score_change(dashboard_dict['overall_safety_insight_pct_chagne'])

        date_frame = get_date_frame(datetime.now())
        dashboard_dict['date_frame'] = date_frame
            
        return dashboard_dict
    except:
        logger.exception("Exception in get_safety_insights_now")
        return {"safety_score":[],'safety_status':[]}

def get_safety_insights(user_email, start_date_str=None, end_date_str=None, freq='day'):

    try:

        if freq=='now':
            return get_safety_insights_now(user_email)


        dashboard_dict = dict()

        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        date_frame = get_date_frame(end_date)
        dashboard_dict['date_frame'] = date_frame
        
        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        if len(camera_id_list) < 1:
            return  {"safety_score":[],'safety_status':[]}

        x_arr, risk_y_arr = get_risk_score_data('overall', camera_id_tuple, start_date, end_date, precision)
        scaled_safe_y_arr = list( (1 - np.array(risk_y_arr)) * 100)
        graph_dict = dict()
        graph_dict['x'] = x_arr
        graph_dict['y'] = scaled_safe_y_arr
        dashboard_dict['graph_data'] = graph_dict

        module_dict = get_user_dashboard_list(user_email)
        #module_list = [key for key,value in module_dict if value == 1]
        module_list = []
        for key,value in module_dict.items():
            if key == 'safety_gear' and value == 1:
                module_list += get_safety_dashboards(user_email)
            elif key != 'safety_gear' and value == 1:
                module_list.append(key)

        for module in module_list:
            curr_dict = dict()
            if module not in ["mask","heatmap","sd"]:
                module_safety_score = get_safety_gear_score(module, camera_id_tuple, start_date, end_date)
            else:
                module_safety_score = int(get_safety_score(module, camera_id_tuple, start_date, end_date) * 100)
            curr_dict['safety_score'] = module_safety_score 

            module_safety_status = get_safety_status(module_safety_score)
            curr_dict['safety_status'] = module_safety_status

            dashboard_dict[module + '_data'] = curr_dict
        
        return dashboard_dict
    except:
        logger.exception("Exception in get_safety_insights")
        return {"safety_score":[],'safety_status':[]}

def get_overall_safety_score(user_email):
    try:
        start_date, end_date, _ = get_date_range(freq='day')

        camera_id_list, _, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        overall_safety_score = int(get_safety_score('overall', camera_id_tuple, start_date, end_date) * 100)
        overall_safety_status = get_safety_status(overall_safety_score)

        dashboard_dict = dict()
        dashboard_dict['safety_score'] = overall_safety_score
        dashboard_dict['safety_status'] = overall_safety_status
        return dashboard_dict
    except:
        logger.exception("Exception in get_overall_safety_score")
        return {'safety_score':[],'safety_status':[]}

def add_employee_email(user_email, employee_email_list):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT employee_email FROM employee_info\
                        WHERE user_email = %s", (user_email, ))

        data = cursor.fetchall()

        # unpack list of single tuple
        if len(data) > 0:
            existing_employees = list(list(zip(*data))[0]) 

            # filter out existing emails
            new_employee_emails = [x for x in employee_email_list if x not in existing_employees] 
        
        else:
            new_employee_emails = employee_email_list

        if len(new_employee_emails) > 0:
            number_employees = len(new_employee_emails)
            insert_cols = zip(new_employee_emails, [user_email]*number_employees, [False]* number_employees,
                            [None]*number_employees, [None]*number_employees, [None]*number_employees)
            
            insert_cols_srt = ','.join(cursor.mogrify("(%s, %s, %s, %s, %s, %s)", x).decode('utf-8') for x in insert_cols)
            cursor.execute("INSERT INTO employee_info VALUES " + insert_cols_srt) 
            
            connection.commit()

            insert_cols = zip(new_employee_emails, [user_email]*number_employees, [False]* number_employees,
                            [None]*number_employees, [None]*number_employees)

            insert_cols_srt = ','.join(cursor.mogrify("(%s, %s, %s, %s, %s)", x).decode('utf-8') for x in insert_cols)
            cursor.execute("INSERT INTO employee_job_info VALUES " + insert_cols_srt) 
            connection.commit()

        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in add_employee_email")
        return 'failure'

def update_employee_info(employee_email, admin_email, info_dict, mode=''):
    try:
        employee_name = info_dict["name"]
        employee_id = info_dict["id"]


        connection = db_connection_pool.getconn()
        
        cursor = connection.cursor()

        if mode != 'QR':
            employee_pic_path = info_dict["pic_path"]


            cursor.execute("SELECT facebank_path FROM touchless_users \
                                    WHERE user_email = %s", (admin_email, ))

            fb_data  = cursor.fetchall()
            fb_path = fb_data[0][0]

            img = cv2.imread(employee_pic_path)

            frec = FaceRecogInference(face_bank_path=fb_path)
            frec.add_individual(name=employee_email, img_arr=[img])
        else:
            employee_pic_path  = DEFAULT_PIC_PATH
        
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
    except:
        logger.exception("Exception in update_employee_info")
        return 'faliure'

def enable_face_recog(user_email):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email \
                        FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        data = cursor.fetchall()
        data=[]
        if len(data) > 0:
            cursor.close()
            db_connection_pool.putconn(connection)
            return "Face Recog is already enabled for user"

        # curr_facebank_path = os.path.join(BASE_FACEBANK_PATH, user_email)
        user_attendance_mapper.create_and_start(user_id=user_email, facebank_path=BASE_FACEBANK_PATH)

        curr_facebank_path = BASE_FACEBANK_PATH
        if not os.path.exists(curr_facebank_path):
            os.mkdir(curr_facebank_path)
        unknown_identity_path = os.path.join(BASE_FACEBANK_PATH, 'unknown')
        if not os.path.exists(unknown_identity_path):
            os.mkdir(unknown_identity_path)

        cursor.execute("INSERT INTO touchless_users (user_email, facebank_path) \
                        VALUES (%s, %s)", (user_email, curr_facebank_path))
        connection.commit()
        
        cursor.close()
        db_connection_pool.putconn(connection)
        
        return "success"
    except:
        logger.exception("Exception in enable_face_recog")
        return "failure"

def disable_face_recog(user_email):
    try:
        
        user_attendance_mapper.disable_and_destroy(user_id=user_email)

        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email \
                        FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        data = cursor.fetchall()

        if len(data) <= 0:
            cursor.close()
            db_connection_pool.putconn(connection)
            return "Face Recog is already disabled for user"

        # curr_facebank_path = os.path.join(BASE_FACEBANK_PATH, user_email)
        # shutil.rmtree(curr_facebank_path)   

        cursor.execute("SELECT employee_email \
                        FROM employee_info \
                        WHERE user_email = %s", (user_email, ))
        employee_data = cursor.fetchall()

        if len(employee_data) > 0:
            employee_email_list = list(zip(*employee_data))[0]
            cursor.execute("DELETE FROM touchless_attendance \
                        WHERE employee_email IN %s", (employee_email_list, ))
            connection.commit()

            cursor.execute("DELETE FROM employee_info \
                            WHERE user_email = %s", (user_email, ))
            connection.commit()

        cursor.execute("DELETE FROM touchless_users \
                        WHERE user_email = %s", (user_email, ))
        connection.commit()

        cursor.close()
        db_connection_pool.putconn(connection)

        return "success"
    except:
        logger.exception("Exception in disable_face_recog")
        return "failure"
    
def get_employee_info_list(user_email):
    try:
        connection = db_connection_pool.getconn()
        
        
        cursor = connection.cursor()
    
        cursor.execute("SELECT employee_email, employee_name, employee_id FROM employee_info \
                                WHERE user_email = %s AND \
                                info_uploaded = %s", (user_email, True))

        data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        data = list(zip(*data))
        if len(data) > 0:
            email_list = list(data[0])
            name_list = list(data[1])
            id_list = list(data[2])
        else:
            email_list, name_list, id_list = [], [], []

        employee_info_dict = dict()
        employee_info_dict["email"] = email_list
        employee_info_dict["name"] = name_list
        employee_info_dict["id"] = id_list

        return employee_info_dict
    except:
        logger.exception("Exception in get_employee_info_list")
        return "failure"

def get_employee_info(employee_email):
    # you can get this info from the employee_info table
    # return {"name" : emp_name, "id" : emp_id, "pic_path" : }
    try:
        connection = db_connection_pool.getconn()
        
        cursor = connection.cursor()
    
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path FROM employee_info \
                                WHERE employee_email = %s and info_uploaded = True",(employee_email, ))

        data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) > 0:

            email, name, eid, pic_path =  map(list,zip(*data))

            return {'email':email,'name':name,'id':eid,'pic_path':pic_path}
        else:

            return {'email':[],'name':[],'id':[],'pic_path':[]}

    except:
        logger.exception("Exception in get_employee_info")
        return {'email':[],'name':[],'id':[],'pic_path':[]}

def delete_employee(employee_email, admin_email):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT facebank_path \
                        FROM touchless_users \
                        WHERE user_email = %s", (admin_email, ))

        data = cursor.fetchall()
        facebank_path = data[0][0]

        cursor.close()
        db_connection_pool.putconn(connection)

        employee_pic_dir = os.path.join(facebank_path, employee_email)
        shutil.rmtree(employee_pic_dir)

        face_recognizer = FaceRecogInference(face_bank_path=facebank_path)
        face_recognizer.prepare_facebank()

        return "success"
    except:
        logger.exception("Exception in delete_employee")
        return "failure"

def get_formatted_attendance(row, start_datetime, end_datetime):
    try:
        final_working_secs = row['total_working_secs']
        if row["first_status"] == False:
            first_time = row['first_time'].to_pydatetime()
            first_time = first_time.replace(tzinfo=timezone.utc)
            top_time_elapsed = (first_time - start_datetime).total_seconds()
            final_working_secs = final_working_secs + top_time_elapsed
        if row['last_status'] == True:
            last_time = row['last_time'].to_pydatetime()
            last_time = last_time.replace(tzinfo=timezone.utc)
            bottom_time_elapsed = (end_datetime - last_time).total_seconds()
            final_working_secs = final_working_secs + bottom_time_elapsed
        
        final_working_hours = final_working_secs / 3600
        final_working_hours = round(final_working_hours, 1)

        curr_status = row['last_time'].strftime("%I:%M%p")
        if row['last_status'] == True:
            curr_status = "IN " + curr_status
        else:
            curr_status = "OUT " + curr_status

        return final_working_hours, curr_status
    except:
        logger.exception("Exception in get_formatted_attendance")
        return 0,''

# def daily_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
#     try:
#         connection = db_connection_pool.getconn()
#         cursor = connection.cursor()   

#         # query to all employees_emails,name,id,pic_path, for the user from employee_info
#         cursor.execute("SELECT employee_email\
#                         FROM employee_info \
#                         WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

#         employee_data = cursor.fetchall() 


#         if len(employee_data) <= 0:
#             overall_dict = dict()
#             overall_dict['overall_stats'] = None
#             overall_dict['attendance_table'] = None
#             cursor.close()
#             db_connection_pool.putconn(connection)
#             return overall_dict
#         else:
#             email_list = tuple([x[0] for x in employee_data])

#         min_time = datetime.min.time()
#         start_date_time = datetime.combine(start_date, min_time)
#         #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
#         start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
#         now = datetime.now(timezone.utc)
#         now = now.replace(tzinfo=pytz.timezone(time_zone))
#         if (start_date == now.date()) and (start_date == end_date):
#             end_date_time = now
#         else:
#             max_time = datetime.max.time()
#             end_date_time = datetime.combine(end_date, max_time)
#             #end_date_time = end_date_time.replace(tzinfo=timezone.utc)
#             end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))

#         cursor.execute("WITH PRE_TABLE AS  (SELECT employee_email, \
#                         first(time AT TIME ZONE %s, time) as first_time, \
#                         first(attendance_status, time) as first_status, \
#                         first(num_working_secs, time) as first_working_secs, \
#                         last(time AT TIME ZONE %s, time) as last_time, \
#                         last(attendance_status, time) as last_status, \
#                         last(num_working_secs, time) as last_working_secs, \
#                         sum(num_working_secs) as total_working_secs \
#                             FROM (SELECT * FROM touchless_attendance \
#                             WHERE employee_email IN %s AND \
#                             time > %s::timestamp AND \
#                             time < %s::timestamp + interval '1 day' \
#                             ORDER BY time ASC) AS filter_table\
#                         GROUP BY employee_email)\
#                         SELECT info.employee_email as employee_email,\
#                             info.employee_name as employee_name, \
#                             info.employee_id as employee_id,\
#                             info.employee_pic_path as employee_pic_path,\
#                             (CASE When pt.last_status IS FALSE then 'OUT' When pt.last_status is TRUE Then 'IN' ELSE 'ABSENT' end) as status,\
#                             FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int as num_working_hrs\
#                             FROM PRE_TABLE as pt RIGHT JOIN (SELECT employee_email,employee_name,employee_id,employee_pic_path from employee_info where user_email = %s AND info_uploaded = %s) as info ON\
#                             pt.employee_email = info.employee_email",(time_zone, time_zone, email_list, start_date, end_date,start_date_time,end_date_time,user_email,True))
#         attendance_data = cursor.fetchall() 
#         attendance_df_col_list = [desc[0] for desc in cursor.description]
#         attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_df_col_list)

#         cursor.close()
#         db_connection_pool.putconn(connection)



#         num_employees_in = sum(attendance_data_df['status'] == 'IN')
#         num_employees_out = sum(attendance_data_df['status'] == 'OUT')
#         num_employees_total = attendance_data_df.shape[0]
#         num_employees_absent = num_employees_total - (num_employees_in + num_employees_out) 

#         overall_stats_dict = dict()
#         overall_stats_dict['Total'] = num_employees_total
#         overall_stats_dict['IN'] = num_employees_in
#         overall_stats_dict['OUT'] = num_employees_out
#         overall_stats_dict['Absent'] = num_employees_absent


#         overall_dict = dict()
#         overall_dict['overall_stats'] = overall_stats_dict
#         overall_dict['attendance_table'] = list(attendance_data_df.to_dict(orient='index').values())

#         return overall_dict
#     except:
#         logger.exception("Exception in daily_touchless_attendance")
#         return {}

# def agg_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
#     try:
#         connection = db_connection_pool.getconn()
#         cursor = connection.cursor()   
#         # query to all employees_emails,name,id,pic_path, for the user from employee_info
#         cursor.execute("SELECT employee_email\
#                 FROM employee_info \
#                 WHERE user_email = %s AND info_uploaded = %s", (user_email, True))
        
#         employee_data = cursor.fetchall() 

#         if len(employee_data) <= 0:
#             overall_dict = dict()
#             overall_dict['overall_stats'] = None
#             overall_dict['attendance_table'] = None
#             cursor.close()
#             db_connection_pool.putconn(connection)
#             return overall_dict
#         else:
#             email_list = tuple([x[0] for x in employee_data])

#         cursor.execute("SELECT time AT TIME ZONE %s AS day, employee_email, attendance_status, num_working_secs FROM touchless_attendance \
#                     WHERE employee_email IN %s AND time > %s::timestamp \
#                         AND time < %s::timestamp + interval '1 day' ORDER BY time ASC\
#                         ", (time_zone,email_list, start_date, end_date))

#         attendance_data = cursor.fetchall()
#         attendance_dict_col_list = [desc[0] for desc in cursor.description]
#         attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_dict_col_list)
#         attendance_data_df['day'] = pd.to_datetime(attendance_data_df['day']).dt.strftime('%b %-d')

#         two_way_table = pd.crosstab(attendance_data_df.day, attendance_data_df.employee_email)
#         two_way_table[two_way_table > 0] = 1

#         num_total_employees = len(email_list)

#         daily_absences_data = two_way_table.sum(axis=1)
#         daily_absences_list = (num_total_employees - daily_absences_data.values).tolist()
#         daily_absences_dates = list(daily_absences_data.index.tolist())

#         absences_graph_dict = dict()
#         absences_graph_dict['x'] = daily_absences_dates
#         absences_graph_dict['y'] = daily_absences_list

#         total_number_days = (end_date - start_date).days + 1

#         employee_absences_data = total_number_days - two_way_table.sum(axis=0)



#         min_time = datetime.min.time()
#         start_date_time = datetime.combine(start_date, min_time)
#         #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
#         start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
#         now = datetime.now(timezone.utc)
#         now = now.replace(tzinfo=pytz.timezone(time_zone))
#         if (start_date == now.date()) and (start_date == end_date):
#             end_date_time = now
#         else:
#             max_time = datetime.max.time()
#             end_date_time = datetime.combine(end_date, max_time)
#             #end_date_time = end_date_time.replace(tzinfo=timezone.utc)
#             end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))

#         cursor.execute("WITH PRE_TABLE AS  (SELECT employee_email, \
#                 first(time AT TIME ZONE %s, time) as first_time, \
#                 first(attendance_status, time) as first_status, \
#                 first(num_working_secs, time) as first_working_secs, \
#                 last(time AT TIME ZONE %s, time) as last_time, \
#                 last(attendance_status, time) as last_status, \
#                 last(num_working_secs, time) as last_working_secs, \
#                 sum(num_working_secs) as total_working_secs \
#                     FROM (SELECT * FROM touchless_attendance \
#                     WHERE employee_email IN %s AND \
#                     time > %s::timestamp AND \
#                     time < %s::timestamp + interval '1 day' \
#                     ORDER BY time ASC) AS filter_table\
#                 GROUP BY employee_email)\
#                 SELECT info.employee_email as employee_email,\
#                     info.employee_name as employee_name, \
#                     info.employee_id as employee_id,\
#                     info.employee_pic_path as employee_pic_path,\
#                     SUM(CASE When pt.last_status IS FALSE then 0 When pt.last_status is TRUE Then 0 ELSE 1 end) as num_absent,\
#                     SUM(FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int) as num_working_hrs\
#                     FROM PRE_TABLE as pt RIGHT JOIN (SELECT employee_email,employee_name,employee_id,employee_pic_path from employee_info where user_email = %s and info_uploaded = %s) as info ON\
#                     pt.employee_email = info.employee_email\
#                     GROUP BY info.employee_email, info.employee_name, info.employee_id, info.employee_pic_path",(time_zone, time_zone, email_list, start_date, end_date,start_date_time,end_date_time,user_email,True))
        
#         attendance_data = cursor.fetchall() 
        
#         attendance_df_col_list = [desc[0] for desc in cursor.description]
#         attendance_data_df = pd.DataFrame(attendance_data, columns=attendance_df_col_list)

#         cursor.close()
#         db_connection_pool.putconn(connection)

#         num_absent_employees = attendance_data_df['num_absent'].sum()
#         avg_working_hrs = round(attendance_data_df['num_working_hrs'].sum()/(num_total_employees * total_number_days), 2)
    
#         overall_stats_dict = dict()
#         overall_stats_dict['Total'] = int(num_total_employees)
#         overall_stats_dict['Absent'] = int(num_absent_employees)
#         overall_stats_dict['avg_working_hrs'] = avg_working_hrs

#         attendance_table_dict = list(attendance_data_df.to_dict(orient='index').values())

#         overall_dict = dict()
#         overall_dict['overall_stats'] = overall_stats_dict
#         overall_dict['graph_data'] = absences_graph_dict
#         overall_dict['attendance_table'] = attendance_table_dict

#         return overall_dict
#     except:
#         logger.exception("Exception in agg_touchless_dashboard")
#         return {}

# def touchless_dashboard(user_email, start_date_str=None, end_date_str=None, freq='day', filter_cond='Total',time_zone='UTC'):
#     try:
#         # get start and end dates
#         start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

#         if start_date == end_date:
#             overall_dict = daily_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)
#         else:
#             overall_dict = agg_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)

#         date_frame = get_date_frame(end_date)
#         overall_dict['date_frame'] = date_frame
        
#         return overall_dict
#     except:
#         logger.exception("Exception in touchless_dashboard")
#         return {}

# def agg_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
#     try:
#         connection = db_connection_pool.getconn()
#         cursor = connection.cursor()

#         min_time = datetime.min.time()
#         start_date_time = datetime.combine(start_date, min_time)
#         #start_date_time = start_date_time.replace(tzinfo=timezone.utc)
#         start_date_time = start_date_time.replace(tzinfo=pytz.timezone(time_zone))
#         max_time = datetime.max.time()
#         end_date_time = datetime.combine(end_date, max_time)
#         end_date_time = end_date_time.replace(tzinfo=pytz.timezone(time_zone))



#         cursor.execute("WITH agg_emp AS (SELECT time_bucket('1 day', time AT TIME ZONE %s) AS grouped_day, \
#                         sum(num_working_secs) AS total_working_secs, \
#                         first(attendance_status, time) AS first_status, \
#                         first(time AT TIME ZONE %s, time) AS first_time, \
#                         first(num_working_secs, time) AS first_working_secs, \
#                         last(attendance_status, time) AS last_status, \
#                         last(time  AT TIME ZONE %s, time) AS last_time, \
#                         last(num_working_secs, time) AS last_working_secs \
#                         FROM touchless_attendance \
#                         WHERE employee_email = %s AND \
#                         time > %s::timestamp AND \
#                         time < %s::timestamp + interval '1 day' \
#                         GROUP BY grouped_day \
#                         ORDER BY grouped_day ASC)\
#                         SELECT  to_char(grouped_day, 'MON DD') as x,\
#                         FLOOR(coalesce(attend(pt.first_time , pt.first_status, pt.first_working_secs, pt.last_time, pt.last_status, pt.last_working_secs, pt.total_working_secs, %s, %s),0)/3600)::int as y\
#                         FROM agg_emp as pt", (time_zone, time_zone, time_zone, employee_email, start_date, end_date,  start_date_time, end_date_time))
        
#         attendance_data = cursor.fetchall()

#         if len(attendance_data) == 0:
#             cursor.close()
#             db_connection_pool.putconn(connection)
#             return {}
        
#         x,y= map(list,zip(*attendance_data))

#         cursor.close()
#         db_connection_pool.putconn(connection)

#         graph_data_dict = dict()
#         graph_data_dict['x'] =x
#         graph_data_dict['y'] = y

#         return graph_data_dict
#     except:
#         logger.exception("Exception in agg_employee_attendance")
#         return {}

# def daily_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
#     try:
#         connection = db_connection_pool.getconn()
#         cursor = connection.cursor()

#         # cursor.execute("SELECT to_char(day,'HH:MM') as start_hour, LEAD(to_char(day,'HH:MM')) over(order by time) as end_hour, attendance_status FROM (SELECT time,time AT TIME ZONE %s AS day, attendance_status \
#         #                 FROM touchless_attendance \
#         #                 WHERE employee_email = %s AND \
#         #                 time > %s::timestamp AND \
#         #                 time < %s::timestamp + interval '1 day' \
#         #                 ORDER BY time ASC)as p", (time_zone, employee_email, start_date, end_date))

#         cursor.execute("SELECT to_char(time at time zone %s,'HH24:MI') as start_hour FROM touchless_attendance WHERE employee_email = %s AND time >%s::timestamp AND time< %s::timestamp + interval '1 day'\
#                         AND attendance_status = true\
#                             ORDER BY time ASC",(time_zone, employee_email,start_date, end_date))
        
#         in_times = cursor.fetchall()
#         if len(in_times) ==0:
#             cursor.close()
#             db_connection_pool.putconn(connection)
#             return [{'start_hour':'None'}]

#         in_times=  [i[0] for i in in_times]
        
#         cursor.execute("SELECT to_char(time at time zone %s,'HH24:MI') as start_hour FROM touchless_attendance WHERE employee_email = %s AND time >%s::timestamp AND time< %s::timestamp + interval '1 day'\
#                         AND attendance_status = False\
#                             ORDER BY time ASC",(time_zone, employee_email,start_date, end_date))
        
#         out_times = cursor.fetchall()
        
        
        
#         if len(out_times) ==0:
#             cursor.close()
#             db_connection_pool.putconn(connection)
#             return [{'start_hours':in_times[0],'end_hour':datetime.now().replace(tzinfo=pytz.timezone(time_zone)).strftime('%H:%M')}]

#         out_times = [i[0] for i in out_times]

        
#         #if int(in_times[0][:2]) > int(out_times[0][:2]) and out_times[-2:]:

        

#         graph_data_dict = {}
#         graph_data_dict['end_hour'] = out_times
#         graph_data_dict['start_hour'] = in_times
#         # graph_data_dict['status'] = att[:-1]
#         data=[]
#         if len(in_times) >= len(out_times):
#             out_times.append(datetime.now().replace(tzinfo=pytz.timezone(time_zone)).strftime('%H:%M'))
#             for idx,val in enumerate(in_times):
#                 data.append({'start_hour':val,'end_hours':out_times[idx],'staus':'IN'})
#                 if idx == len(in_times)-1:
#                     break
#                 data.append({'start_hour':out_times[idx],'end_hours':in_times[idx+1],'staus':'OUT'})
#         else:
#             print('else')
#             in_times = ['00:00 AM'] + in_times + [datetime.now().replace(tzinfo=pytz.timezone(time_zone)).strftime('%H:%M')]
#             print(in_times)
#             for idx,val in enumerate(out_times):
#                 data.append({'start_hour':in_times[idx],'end_hours':val,'staus':'IN'})
#                 if idx == len(in_times)-1:
#                     break
#                 data.append({'start_hour':val,'end_hours':in_times[idx+1],'staus':'OUT'})
#         graph_data_dict['gantt_data'] = data

#         cursor.close()
#         db_connection_pool.putconn(connection)

#         return graph_data_dict
#     except:
#         logger.exception("Exception in daily_employee_attendace")
#         return {'gantt_data':[]}

# def get_employee_attendance(employee_email, start_date_str=None, end_date_str=None, freq='day', time_zone='UTC'):
#     # get start and end dates
#     try:
#         start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
#         if start_date == end_date:
#             graph_data_dict = daily_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
#         else:
#             graph_data_dict = agg_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
        
#         return graph_data_dict
#     except:
#         logger.exception("Exception in get_employee_attendance")
#         return {}

def daily_temperature_dashboard(user_email, start_date, end_date, filter_cond):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path \
                        FROM employee_info \
                        WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

        employee_data = cursor.fetchall() 
        employee_df_col_list = [desc[0] for desc in cursor.description]
        employee_data_df = pd.DataFrame(employee_data, columns=employee_df_col_list)


        email_list = tuple(employee_data_df["employee_email"].tolist())
        if len(email_list) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['temperature_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict

        cursor.execute("WITH temp AS (SELECT employee_email, \
                        last(temperature, time) as temperature, \
                        last(temperature_status, time) as temperature_status \
                        FROM (SELECT * FROM employee_temperature \
                            WHERE employee_email IN %s AND \
                            time > %s::timestamp AND \
                            time < %s::timestamp + interval '1 day' \
                            ORDER BY time ASC) AS filter_table\
                        GROUP BY employee_email)\
                        SELECT info.employee_email, info.employee_name, info.employee_id, info.employee_pic_path, temp.temperature, coalesce(temp.temperature_status,'Absent') as temperature_status FROM\
                            temp RIGHT JOIN (SELECT employee_email, employee_name, employee_id, employee_pic_path \
                                                FROM employee_info \
                                                WHERE user_email = %s AND info_uploaded = %s) as info on temp.employee_email = info.employee_email", (email_list, start_date, end_date,user_email, True))
        temperature_data = cursor.fetchall()

        temperature_df_col_list = [desc[0] for desc in cursor.description]
        temperature_data_df = pd.DataFrame(temperature_data, columns=temperature_df_col_list)

        
        
        cursor.close()
        db_connection_pool.putconn(connection)

        #final_employee_data_df = employee_data_df.merge(temperature_data_df, on='employee_email', how='left')
        temperature_data_df['temperature'].fillna("Absent", inplace=True)
        #final_employee_data_df = final_employee_data_df[ employee_df_col_list + ["temperature", "temperature_status"] ]


        num_total_employees = len(email_list)
        num_high_temp_employees = sum(temperature_data_df['temperature_status'] == 'high')

        #if filter_cond != "Total":
        #    final_employee_data_df = final_employee_data_df.loc[final_employee_data_df['temperature_status'] == filter_cond]
        
        
        overall_stats_dict = dict()
        overall_stats_dict['total'] = num_total_employees
        overall_stats_dict['high'] = num_high_temp_employees

        temperature_table_dict = list(temperature_data_df.to_dict(orient='index').values()) 

        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['temperature_table'] = temperature_table_dict

        return overall_dict
    except:
        logger.exception("Exception in daily_temperature_dashboard")
        return {}

def agg_temperature_dashboard(user_email, start_date, end_date, filter_cond, time_zone='UTC'):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path \
                        FROM employee_info \
                        WHERE user_email = %s AND info_uploaded = %s", (user_email, True))

        employee_data = cursor.fetchall() 
        employee_df_col_list = [desc[0] for desc in cursor.description]
        employee_data_df = pd.DataFrame(employee_data, columns=employee_df_col_list)


        email_list = tuple(employee_data_df["employee_email"].tolist())
        if len(email_list) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['temperature_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict

        cursor.execute("SELECT DISTINCT temp.employee_email, \
                        temp.temperature, temp.temperature_status \
                        FROM (SELECT employee_email, MAX(temperature) AS max_temperature \
                                FROM employee_temperature \
                                WHERE employee_email IN %s AND \
                                time > %s::timestamp AND \
                                time < %s::timestamp + interval '1 day' \
                                GROUP BY employee_email) AS max_table \
                        INNER JOIN employee_temperature AS temp \
                        ON temp.employee_email = max_table.employee_email AND \
                        temp.temperature = max_table.max_temperature", (email_list, start_date, end_date))
        
        temperature_data = cursor.fetchall()
        temperature_df_col_list = [desc[0] for desc in cursor.description]
        temperature_data_df = pd.DataFrame(temperature_data, columns=temperature_df_col_list)

        final_employee_data_df = employee_data_df.merge(temperature_data_df, on='employee_email', how='left')
        final_employee_data_df['temperature'].fillna("Absent", inplace=True)
        final_employee_data_df['temperature_status'].fillna("Absent", inplace=True)
        final_employee_data_df = final_employee_data_df[ employee_df_col_list + ["temperature", "temperature_status"] ]

        num_total_employees = len(email_list)
        num_high_temp_employees = sum(final_employee_data_df['temperature_status'] == 'high')

        if filter_cond != "Total":
            final_employee_data_df = final_employee_data_df.loc[final_employee_data_df['temperature_status'] == filter_cond]
        
        overall_stats_dict = dict()
        overall_stats_dict['total'] = num_total_employees
        overall_stats_dict['high'] = num_high_temp_employees

        temperature_table_dict = list(final_employee_data_df.to_dict(orient='index').values())

        cursor.execute("SELECT to_char(temp.date, 'MON DD') AS date, temp.temperature_count \
                        FROM (SELECT time_bucket('1 day', time AT TIME ZONE %s) AS date, \
                            COUNT(temperature_status) AS temperature_count \
                            FROM employee_temperature \
                            WHERE employee_email IN %s AND \
                            time > %s::timestamp AND \
                            time < %s::timestamp + interval '1 day' AND\
                            temperature_status = 'high' \
                            GROUP BY date \
                            ORDER BY date ASC) AS temp", (time_zone, email_list, start_date, end_date))
        temperature_graph_data = cursor.fetchall()
        temperature_graph_df_col_list = [desc[0] for desc in cursor.description]
        temperature_graph_data_df = pd.DataFrame(temperature_graph_data, columns=temperature_graph_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)

        temperature_graph_data_dict = dict()
        temperature_graph_data_dict['x'] = list(temperature_graph_data_df['date'])
        temperature_graph_data_dict['y'] = list(temperature_graph_data_df['temperature_count'])

        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['temperature_table'] = temperature_table_dict
        overall_dict['graph_data'] = temperature_graph_data_dict

        return overall_dict
    except:
        logger.exception("Exception in agg_temperature_dashboard")
        return {}

def temperature_dashboard(user_email, start_date_str=None, end_date_str=None, freq='day', filter_cond='Total', time_zone= "UTC"):
    # get start and end dates
    try:
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)

        if start_date == end_date:
            overall_dict = daily_temperature_dashboard(user_email, start_date, end_date, filter_cond)
        else:
            overall_dict = agg_temperature_dashboard(user_email, start_date, end_date, filter_cond, time_zone=time_zone)

        date_frame = get_date_frame(end_date)
        overall_dict['date_frame'] = date_frame
        
        return overall_dict
    except:
        logger.exception("Exception in temperature_dashboard")
        return {}

def daily_employee_temperature(employee_email, start_date, end_date, time_zone='UTC'):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT to_char(time AT TIME ZONE %s, 'HH12:MI am') AS time, temperature, temperature_status \
                        FROM employee_temperature \
                        WHERE employee_email = %s AND \
                        time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        ORDER BY time ASC", (time_zone, employee_email, start_date, end_date))
        
        temperature_graph_data = cursor.fetchall()
        temperature_graph_df_col_list = [desc[0] for desc in cursor.description]
        temperature_graph_data_df = pd.DataFrame(temperature_graph_data, columns=temperature_graph_df_col_list)

        cursor.close()
        db_connection_pool.putconn(connection)

        graph_data_dict = dict()
        graph_data_dict['x'] = list(temperature_graph_data_df['time'])
        graph_data_dict['y'] = list(temperature_graph_data_df['temperature'])
        graph_data_dict['status'] = list(temperature_graph_data_df[['temperature', 'temperature_status']].to_dict(orient='index').values())

        return graph_data_dict
    except:
        logger.exception("Exception in daily_employee_temperature")
        return {}

def agg_employee_temperature(employee_email, start_date, end_date, time_zone='UTC'):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
    
        cursor.execute("SELECT DISTINCT to_char(temp.date, 'MON DD'), temp.temperature \
                        FROM (SELECT time_bucket('1 DAY', time AT TIME ZONE %s) + '0.5 day' AS date, max(temperature) as temperature \
                        FROM employee_temperature \
                        WHERE employee_email = %s \
                        AND time > %s::timestamp AND \
                        time < %s::timestamp + interval '1 day' \
                        GROUP BY date \
                        ORDER BY date ASC) AS temp", (time_zone, employee_email, start_date, end_date))

        data = cursor.fetchall()
        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) > 0:
            data = list(zip(*data))
            date = list(data[0])
            max_temp = list(data[1])
        else:
            date,max_temp = [], []

        status = []
        for x in max_temp:
            if x >100:
                status.append({'temperature':x,'temperature_status':'high'})
            else:
                status.append({'temperature':x,'temperature_status':'normal'})

        graph_data_dict = dict()
        graph_data_dict['x'] = date
        graph_data_dict['y'] = max_temp
        graph_data_dict['status'] = status

        return graph_data_dict
    except:
        logger.exception("exception in agg_employee_temperature")
        return {}

def get_employee_temperature(employee_email, start_date_str=None, end_date_str=None, freq='day',time_zone='UTC'):
    # get start and end dates
    try:
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
        if start_date == end_date:
            graph_data_dict = daily_employee_temperature(employee_email, start_date, end_date, time_zone=time_zone)
        else:
            graph_data_dict = agg_employee_temperature(employee_email, start_date, end_date, time_zone=time_zone)
        
        return graph_data_dict
    except:
        logger.exception("Exception in get_employee_temperature")
        return {}

def validate_image(image):
    '''Function to validate the image (if image is a valid face) 
    uploaded by the user. A valid images is a image of a single face.
    This function calls the RetinaFaceInference module to detect face.
    If no face or multiple face are detected then it returns False.
    It also validates the image after alignemnt.
    params := img - base64 encoded image
    returns Boolean 
    '''
    try:
        detector = RetinaFaceInference()

        decoded_data = base64.b64decode(image)
        np_data = np.fromstring(decoded_data,np.uint8)
        img = cv2.imdecode(np_data,cv2.IMREAD_UNCHANGED)

        img = np.array(img)
        _,landmarks = detector.detect_faces(img)

        
        if landmarks.shape[0]>0:# or h<w:
            aligned = detector.align(img)
            _,aligned_marks = detector.detect_faces(aligned)
            if aligned_marks.shape[0]>0:
                return True
            else:
                return False    
        else:
            return False
    except:
        logger.exception("Exception in validate_image")
        return False

def update_qr_attendace(employee_email):
    try:
        curr_time = datetime.now(timezone.utc)
        
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT time, attendance_status \
                                        FROM touchless_attendance \
                                        WHERE employee_email = %s \
                                        ORDER BY time \
                                        DESC LIMIT 1", (employee_email, ) )
        status_data = cursor.fetchall()
        if len(status_data) > 0:
            last_time, prev_status = status_data[0][0], status_data[0][1]
            time_elapsed = (curr_time - last_time).total_seconds()
        else:
            time_elapsed = sys.maxsize
            prev_status = False

        if time_elapsed > 60:
            curr_status = not prev_status
            if curr_status == True:
                num_working_secs = 0
            else:
                num_working_secs = time_elapsed

            cursor.execute("INSERT INTO touchless_attendance (time , employee_email, attendance_status, num_working_secs) \
                            VALUES (%s, %s, %s, %s)", (curr_time, employee_email, curr_status, num_working_secs))
            
            connection.commit()

            cursor.close()
            db_connection_pool.putconn(connection)

        return 'success',not prev_status
    except:
        logger.exception("exception in update_qr_attendance")
        return 'failure',None

# def get_timezone(IP):
#     ''' Requires maxminddb (pip install maxminddb-geolite2)
#         input - IP address String
#     '''
#     reader = geolite2.reader()
#     try:
#         r =reader.get(IP)
#         return r['location']['time_zone']
#     except:
#         logger.warning('Time zone not found in location')
#         return 'UTC'
#     geolite2.close()
#     return 'UTC'

def make_url(prefix,user,password,ip,port,url):
    # helper
    url = url.lstrip('/')
    if 'CHANNEL' in url:
        url = url.replace('[CHANNEL]','1')
    if 'WIDTH' in url:
        url = url.replace('[WIDTH]','416')
    if 'HEIGHT' in url:
        url = url.replace('[HEIGHT]','416')
    if 'USERNAME' in url:
        url = url.replace('[USERNAME]',user)
        url = url.replace('[PASSWORD]',password)
        return prefix+ip+'/'+url
    return prefix+user+':'+password+'@'+ip+':'+str(port)+'/'+url

def get_urls(username,password,ip,port=None,br=None):
    #helper
    all_urls = []
    new_df = df.copy()
    if br:
        if br in df['brand'].unique():
            new_df = new_df.query('brand ==@br')
    for idx,i in new_df.iterrows():
        if port==None:
            if i['port'] == -1:
                if i['prefix'] == 'rtsp://':
                    all_urls.append(make_url(i['prefix'],username,password,ip,554,i['url']))
                    all_urls.append(make_url(i['prefix'],username,password,ip,5544,i['url']))
                else:
                    all_urls.append(make_url(i['prefix'],username,password,ip,80,i['url']))
                    all_urls.append(make_url(i['prefix'],username,password,ip,8000,i['url']))
            else:
                all_urls.append(make_url(i['prefix'],username,password,ip,i['port'],i['url']))
        else:
            all_urls.append(make_url(i['prefix'],username,password,ip,port,i['url']))
    del new_df
    return all_urls

def get_ip_from_url(url):
    #helper
    ip,port = url.split('@')[1].split('/')[0].split(':')
    return ip,int(port)

def load_url(url, timeout):
    #helper
    if url.startswith('http://'):
        ans = requests.head(url,timeout=timeout)
        if ans.status_code < 400:
            if ans.headers['Content-type'] in ['image/jpeg','video/mp4']:
                return url
            else:
                return None
    else:
        if check_rtsp(url,timeout=timeout):
          return url
    return None

# def try_channels(link_format):
#     #helper
#     ch=False
#     if "ch" in link_format:
#       ch=True
#     channels = [link_format]
#     for i in range(2,9):
#         if ch:
#           new_link = re.sub('ch01',f'ch0{i}',link_format)
#         else:
#            new_link = re.sub('/1',f'/{i}',link_format)
#         if new_link.startswith('http://'):
#             try:
#                 resp = requests.head(new_link,timeout=0.3)
#                 if resp.status_code < 400 and resp.headers['Content-type'] in ['image/jpeg','video/mp4']:#check for stream
#                     channels.append(new_link)
#             except requests.exceptions.Timeout:
#                 continue
#         else:
#           if check_rtsp(new_link):
#             channels.append(new_link)
#     return channels

# Check the usrl is rtsp or not
# def check_rtsp(url,timeout=5):
#   #check if port is open before checking if rtsp link is valid. Saves time
#   ip,port = get_ip_from_url(url)
#   if check_open(ip,port):
#     #if port is open check if rtsp link is valid
#     cap = cv2.VideoCapture(url)
#     conn, _ = cap.read()
#     # print(frame)
#     cap.release()
#     return conn
#   return False

def check_open(ip,port,timeout=5):
  sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  sock.settimeout(timeout)
  result = sock.connect_ex((ip,554))
  # result = 0 means port is open
  sock.close()
  return not result

def search(username,password,ip,port=None,brand=None):
    # returns list of string of available camera
    try:
        all_urls= get_urls(username,password,ip,port=port,br=brand)
        
        cameras = []
        CONNECTIONS = 150
        TIMEOUT = 1
        #data=None
        c=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=CONNECTIONS) as executor:
            future_to_url = (executor.submit(load_url,url, TIMEOUT) for url in all_urls)
            time1 = time.time()
            for future in concurrent.futures.as_completed(future_to_url):
                try:
                    data = future.result()
                except Exception as exc:
                    #data = str(type(exc))
                    data=None
                finally:
                    if data:
                        cameras.append(data)
                    c+=1
                    

            time2 = time.time()
            
        if cameras:
            cameras = try_channels(cameras[0])
        
        return cameras
    except:
        logger.exception("Exception in serach")
        return []

def get_snapshot(ip_url):
    #returns a sample image
    try:
        if ip_url.endswith('.jpg') or ip_url.endswith('.jpeg'):
            resp = requests.get(ip_url)
            #image = np.asarray(bytearray(resp.content),dtype="uint8")
            #image = cv2.imdecode(image, cv2.IMREAD_COLOR)
            reply = resp.content
        else:
            stream = cv2.VideoCapture(ip_url)
            retval, image = stream.read()
            retval, buffer = cv2.imencode('.jpg', image)
            reply = base64.b64encode(buffer).decode()

            stream.release()
        # reply = 'data:image/jpeg;base64,'+ str(base64.b64encode(reply).decode())
        return reply
    except Exception as e:
        #logger.exception("Exception in get_snapshot")
        print(e)
        return ""

def employee_checkin_status(user_email):
    employee_dict = dict()
    connection = db_connection_pool.getconn()
    cursor = connection.cursor()
   
    cursor.execute("SELECT employee_email, employee_name, employee_id, employee_pic_path FROM employee_info WHERE user_email = %s", (user_email, ))
    employees = cursor.fetchall()
    for employee in employees:
        cursor.execute("SELECT time FROM touchless_attendance WHERE employee_email = %s ORDER BY time DESC LIMIT 1", (employee[0], ))
        time = cursor.fetchall()
        for t in time:
            current_time = datetime.now(timezone.utc)
            d = (current_time - t[0]).total_seconds()
            if d <= 5:
                employee_dict['employee_name'] = employee[1]
                employee_dict['employee_id'] = employee[2]
                employee_dict['employee_pic_path'] = employee[3]
                employee_dict['checkin_time'] = t[0]
    cursor.close()
    db_connection_pool.putconn(connection)
    return employee_dict

def add_user_dashboard(user_email,mask=True,sd=True,heatmap=True,safety_gear=False):
    """
        Description : A function used to add user dashboard details to the database.
        Parameters  : user_email (string), mask (bool), sd(bool) , heatmap(bool), safety_gear(bool).
        Returns     : Returns 'success' or 'failure' as a message
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO user_dashboard (user_email, mask, sd, heatmap, safety_gear) \
                                    VALUES (%s, %s, %s, %s, %s)", (user_email, mask, sd, heatmap, safety_gear))
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'

    except:
        logger.exception("exception occured in add user safety gears dashboard")
        return 'failure'

def update_user_dashboard(user_email,col_name,col_value):
    """
        Description : A function used to update user dashboard details.
        Parameters  : col_name (string), col_value (bool).
        Returns     : Returns 'success' or 'failure' as a message
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute(sql.SQL("UPDATE user_dashboard \
                        SET {} = %s \
                        WHERE user_email = %s").format(sql.Identifier(col_name)), [col_value, user_email])

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
        
    except:
        logger.exception("exception occured in update user safety gears dashboard")
        return 'failure'

def get_user_dashboard_list(user_email):
    """
        Description : A function used to get user dashboard details.
        Parameters  : user_email (string).
        Returns     : Returns user dashboard details.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email, mask, sd, heatmap, safety_gear \
                        FROM user_dashboard \
                        WHERE user_email = %s ", (user_email,))
        
        user_dashboard_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(user_dashboard_data) > 0:
            user_email = user_dashboard_data[0][0]
            mask = user_dashboard_data[0][1]
            sd = user_dashboard_data[0][2]
            heatmap = user_dashboard_data[0][3]
            safety_gear = user_dashboard_data[0][4]
           
            # print(mask,sd,heatmap,safety_gear)
        
            return  {'mask' : mask, 'sd' : sd, 'heatmap' : heatmap, 'safety_gear' : safety_gear}
        
        else:

            return {'mask' : None, 'sd' : None, 'heatmap' : None, 'safety_gear' : None}

    except:
        logger.exception('exception occured in get user dashboard list')
        return {}

def add_safety_gear_code(name,gear_code):
    """
        Description : A function used to add safety gear code details.
        Parameters  : name (string), gear_code (string) .
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO safety_gear_code (name, gear_code) \
                                    VALUES (%s, %s)", (name, gear_code))
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'

    except:
        logger.exception("exception occured in adding safety gear codes")
        return 'failure'
  
def get_names(codes=None):
    """
        Description : A function used to get names of safety gears.
        Returns     : Returns safety gears names as a list.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        if(codes):
            code_tuple = tuple([i for i in codes])
            cursor.execute("SELECT name FROM safety_gear_code where gear_code IN %s ",(code_tuple,))
        else :
            cursor.execute("SELECT name \
                        FROM safety_gear_code ")
        
        names_data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(names_data) > 0:
            names_data_list = list(list(zip(*names_data))[0])
        else:
            names_data_list = []

        return names_data_list
    except:
        logger.exception("Exceptionn in get gear name")
        return []

def get_safety_codes(gear_names):
    """
        Description : A function used to get safety gear code details.
        Parameters  : gear_names (list) .
        Returns     : Returns gear code.
    """
    try:
        gear_codes = ''
        gear_names.sort()
        for gear_name in gear_names:
            # get code for all the gear names

            connection = db_connection_pool.getconn()
            cursor = connection.cursor()

            cursor.execute("SELECT gear_code \
                            FROM safety_gear_code \
                            WHERE name = %s ", (gear_name,))
            
            gear_code = cursor.fetchall()

            cursor.close()
            db_connection_pool.putconn(connection)

            if len(gear_code) > 0:
                code = gear_code[0][0]
            else:

                raise Exception('gear name " {} " not found'.format(gear_name))
            
            gear_codes+=code

        return gear_codes
    except:
        logger.exception("Exceptionn in get gear code")
        return None

def add_job_list(job,industry,safety_gears_list):
    """
        Description : A function used to add job list details.
        Parameters  : job (string), industry(string), safety_gear_list (string) .
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        gear_code = get_safety_codes(safety_gears_list)
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO job_list (job,industry,gear_code) \
                                    VALUES (%s, %s, %s)", (job,industry,gear_code))
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'

    except:
        logger.exception("exception occured in adding job list")
        return 'failure'

def get_job_list():
    """
        Description : A function used to get job list.
        Returns     : Returns job list.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT job \
                        FROM job_list ")
        
        job_list = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(job_list) > 0:
            job_list = list(list(zip(*job_list))[0])
        else:
            job_list = []

        requirement_dict = {}
        for i in job_list:
            requirement_dict[i] = ["hard_hat"]

        return {"job_list":job_list,"requirements":requirement_dict}
    except:
        logger.exception("Exceptionn in get job list")
        return []

def add_safety_gear_settings(user_email,mode ,safety_gears_list=None):
    """
        Description : A function used to add safety gear settings.
        Parameters  : user_email (string), mode(bool), safety_gears_list (list) .
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        if safety_gears_list:
            gear_code = get_safety_codes(safety_gears_list)
        else:
            gear_code= None
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO safety_gear_settings (user_email,mode,gear_code) \
                                    VALUES (%s, %s, %s)", (user_email,mode,gear_code))
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'

    except:
        logger.exception("exception occured in adding safety gear settings")
        return 'failure'

def get_safety_gear_settings(user_email):
    """
        Description : A function used to get user's safety gear settings.
        Parameters  : user_email (string).
        Returns     : Returns safety gears settings.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT user_email, mode, gear_code \
                        FROM safety_gear_settings \
                        WHERE user_email = %s ", (user_email,))
        
        safety_gear_settings = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        if len(safety_gear_settings) > 0:
           
            user_email = safety_gear_settings[0][0]
            mode = safety_gear_settings[0][1]
            gear_code = safety_gear_settings[0][2]
           
            # print(user_email,mode,gear_code)
        
            return  {'user_email' : user_email, 'mode' : mode, 'gear_code' : gear_code}
        
        else:

            return {'user_email' : None, 'mode' : None, 'gear_code' : None}

    except:
        logger.exception('exception occured in get safety gear settings')
        return {}

def update_safety_gear_settings(user_email,col_name,col_value):
    """
        Description : A function used to update user's safety gear settings.
        Parameters  : user_email (string), col_name (string), col_value (bool).
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute(sql.SQL("UPDATE safety_gear_settings \
                        SET {} = %s \
                        WHERE user_email = %s").format(sql.Identifier(col_name)), [col_value, user_email])

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
    except:
        logger.exception("exception occured in update user safety gear settings")
   
def update_safety_gear_code(user_email,safety_gears_list):
    """
        Description : A function used to update safety gear code.
        Parameters  : user_email (string), safety_gear_list (list).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        new_gear_code = get_safety_codes(safety_gears_list)
        update_safety_gear_settings(user_email,"gear_code",new_gear_code)
        return 'success'
    except:
        logger.exception("Exception in update safety gear codes")
        return 'failure'

def update_safety_gear_mode(user_email,new_mode_value):
    """
        Description : A function used to update safety gear mode.
        Parameters  : user_email (string), new_mode_value (bool).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        update_safety_gear_settings(user_email,'mode',new_mode_value)
        return 'success'
    except:
        logger.exception("Exception in update safety mode")
        return 'failure'

def add_employees(employee_email,user_email,info_uploaded,job_type,safety_gears_list):
    """
        Description : A function used to add employee job info details.
        Parameters  : employee_email (string), user_email (string), info_uploaded (bool),job_type (string), safety_gears_list (list).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        gear_code = None
        if(safety_gears_list):
            gear_code = get_safety_codes(safety_gears_list)
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO employee_job_info (employee_email,user_email, info_uploaded,job_type,gear_code) \
                                    VALUES (%s, %s, %s, %s, %s)", (employee_email, user_email, info_uploaded, job_type, gear_code))
        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'

    except:
        logger.exception("exception occured in add employee job info")
        return 'failure'

def update_employee_job_details(employee_email, col_name, col_value):
    """
        Description : A function used to update employee job info details.
        Parameters  : user_email (string), col_name (string), col_value (string).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute(sql.SQL("UPDATE employee_job_info \
                        SET {} = %s \
                        WHERE employee_email = %s").format(sql.Identifier(col_name)), [col_value, employee_email])

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)

        return 'success'
        
    except:
        logger.exception("exception occured in update employee job info")
        return 'failure'

def update_employee_job_type(employee_email,new_job_type):
    """
        Description : A function used to update employee job type.
        Parameters  : user_email (string), new_job_type (string).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        # update_employee_job_details(user_email,'job_type',new_job_type)
        return update_employee_job_details(employee_email,'job_type',new_job_type)
    except:
        logger.exception("Exception in update employee job type")
        return 'failure'

def update_employee_gear_code(employee_email,safety_gears_list):
    """
        Description : A function used to update employee gear code.
        Parameters  : employee_email (string), safety_gears_list (list).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        gear_code = get_safety_codes(safety_gears_list)
        # update_employee_job_details(employee_email,'gear_code',gear_code)
        return update_employee_job_details(employee_email,'gear_code',gear_code)
    except:
        logger.exception("Exception in update employee gear code")
        return 'failure'

def update_employee_info_uploaded(employee_email,info_uploaded):
    """
        Description : A function used to update employee info uploaded.
        Parameters  : employee_email (string), info_uploaded (bool).
        Returns     : Returns 'success' or 'failure' as a message.
    """
    try:
        update_employee_job_details(employee_email,'info_uploaded',info_uploaded)
        return 'success'
    except:
        logger.exception("Exception in update employee info uploaded")
        return 'failure'

def is_complete(employee_email):
    """
        Description : A function used to check employee info's uploaded or not.
        Returns     : Returns 'True' or 'False'.
    """
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT info_uploaded \
                        FROM employee_job_info \
                        WHERE employee_email = %s ", (employee_email,))
        
        employee_info_uploaded = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)

        info_uploaded = employee_info_uploaded[0][0]

        if(info_uploaded):
            return True
        else:
            return False

    except:
        logger.exception('exception occured in is complete')
        return 'failure'

def str_to_date(date_str):
    """
        Description : A function used to convert date string to date.
        Parameters  : date_str (string).
        Returns     : Returns date .
    """
    date = datetime.strptime(date_str, '%Y-%m-%d').date()
    return date

def get_violation_graph(dashboard_name, camera_id_tuple,start_date, end_date, precision='day',time_zone='UTC'):
    """
        Description : A function used to get normal violations graph between given date range.
        Parameters  : dashboard_name (string), camera_id_tuple (tuple),start_date (string), end_date (string), precision (string),time_zone (string).
        Returns     : Returns date, violations .
    """
    try:
        code = get_safety_codes([dashboard_name])
        if precision == 'hour':
            date_format_str = 'HH12 am'
        elif precision == 'now' :
            date_format_str  = 'HH : MM'
        else:
            date_format_str = 'Mon DD'

        precision = '1 ' + precision
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
       
        cursor.execute("SELECT to_char(grouped_time, %s), count \
                            FROM \
                                (SELECT time_bucket(%s, time AT TIME ZONE %s) AS grouped_time, COUNT(gear_code) AS count \
                                    FROM violation \
                                    WHERE time > %s::timestamp  \
                                        AND time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s AND gear_code ~ %s \
                                    GROUP BY grouped_time \
                                    ORDER BY grouped_time) as gear_table ",(date_format_str,precision,time_zone, start_date, end_date,camera_id_tuple,code))
        data = cursor.fetchall()
        #print(data,code,camera_id_tuple)
        cursor.close()
        db_connection_pool.putconn(connection)
    
        if len(data) > 0:
            date,violations = map(list,zip(*data))

        else:
            date,violations = [], []
        
        return (date,violations)
    
    except:
        logger.exception("Exception in get normal violations")
        return ([],[])

def get_violations_now(dashboard_name, camera_id, time_zone='UTC'):
    """
        Description : A function used to get normal violations right now.
        Parameters  : dashboard_name (string), camera_id (uuid),time_zone (string).
        Returns     : Returns date, violations .
    """
    try:
        code = get_safety_codes([dashboard_name])
        # if precision == 'hour':
        #     date_format_str = 'HH12 am'
        # else:
        #     date_format_str = 'Mon DD'
        date_format_str = 'MI SS'
        precision = '1 seconds'
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
       
        cursor.execute("SELECT to_char(grouped_time, %s), count \
                            FROM \
                                (SELECT time_bucket(%s, time AT TIME ZONE %s) AS grouped_time, COUNT(gear_code) AS count \
                                    FROM violation WHERE \
                                        camera_id = %s AND gear_code ~ %s \
                                    GROUP BY grouped_time \
                                    ORDER BY grouped_time LIMIT 2) as gear_table ",(date_format_str,precision,time_zone,camera_id,code))
        data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)
        
        if len(data) > 0:
            _,violations = map(list,zip(*data))
            current = violations[0]
            last = violations[-1]
            if last == 0:
                last = 1
            percent_change = round(100*(current - last)/(last*1.),3)
            change = 'increase'
            if current - last < 0:
                change = 'decrease' 

        else:
            current, percent_change, change = 0, 0, 'increase'
        
        return {"current": current, "percent_change": percent_change, "change": change}
    
    except:
        logger.exception("Exception in get normal violations")
        return  {"current": 0, "percent_change": 0, "change": 'increase'}

def get_dashboard_violations_now(dashboard_name, camera_id_tuple, time_zone = 'UTC'):
    """
        Description : A function used to get dashboard for specific gear for now tab
        Parameters  : dashboard_name (string), camera_id_tuple (tuple),start_date (string), end_date (string), precision (string),time_zone (string).
        Returns     : Returns camera_name , violations as a dict .
    """
    try:
        code = get_safety_codes([dashboard_name])
    
        
        camera_id_violation_dict = {}
        all_current=[]
        all_change =[]

        for camera_id in camera_id_tuple:
            v = get_violations_now(dashboard_name,camera_id, time_zone= time_zone)
            camera_id_violation_dict[camera_id] = v
            all_current.append(v['current'])
            all_change.append(v['percent_change'])
            
        avg_current = int(sum(all_current)/len(all_current))
        avg_change = sum(all_change)/len(all_change)
        change = 'increase'
        if avg_change < 0:
            change = 'decrease'
        
        

        return {"overall_current":avg_current, "overall_pct_change":avg_change, "overall_change":change,"camera_violations":camera_id_violation_dict}

    except:
        logger.exception("Exception in get camera violations")
        return {"overall_current":0, "overall_pct_change":0, "overall_change":'increase',"camera_violations":{}}

def get_camera_violations(dashboard_name, camera_id_tuple,start_date,end_date):
    """
        Description : A function used to get camera violations between given date range.
        Parameters  : dashboard_name (string), camera_id_tuple (tuple),start_date (string), end_date (string), precision (string),time_zone (string).
        Returns     : Returns camera_name , violations as a dict .
    """
    try:
        code = get_safety_codes([dashboard_name])
    
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()

        cursor.execute("SELECT camera_name AS camera , COUNT(gear_code) AS count \
                                    FROM violation \
                                    INNER JOIN camera_details USING(camera_id) \
                                    WHERE time > %s::timestamp  \
                                        AND time < (SELECT %s::timestamp + interval '1 day') AND \
                                        camera_id IN %s AND gear_code ~ %s \
                                    GROUP BY camera_name ",(start_date, end_date,camera_id_tuple,code))
        data = cursor.fetchall()

        cursor.close()
        db_connection_pool.putconn(connection)
    
        if len(data) > 0:
    
            cam_dict =  dict(data)

        else:
            cam_dict = {}
        
        return cam_dict

    except:
        logger.exception("Exception in get camera violations")
        return {}
    
def get_normal_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision='day',time_zone='UTC'):
    """
        Description : A function used to get graph and camera violations between given date range.
        Parameters  : user_email (string), dashboard_name (string), start_date_str (string), end_date_str (string), precision (string),time_zone (string).
        Returns     : Returns x_data , y_data and camera_data as a dict .
    """
    try:

        camera_id_list, camera_name_list, floor_name_list, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)
        
        if len(camera_id_list) <1:
            return {}
        
        date_frame = get_date_frame(datetime.now())

        # violations_dict = dict()
        if precision == 'now':
            # c_dict = {i:j for i,j in zip(camera_id_list,camera_name)}
            violations_dict = get_dashboard_violations_now(dashboard_name, camera_id_tuple, time_zone = 'UTC')
            # returns  {"overall_current":0, "overall_pct_change":0, "overall_change":'increase',\
            # "camera_violations":{"id":{"current": current, "percent_change": percent_change, "change": change}}}
            camera_data = {}
            floor_dict ={}
           
            for i, camera_id in enumerate(camera_id_list):
                curr_dict = dict()

                if camera_id in  violations_dict['camera_violations']:
                    camera_risk_score = int(violations_dict['camera_violations'][camera_id]["current"])
                    delta = 0
                    pct_delta = violations_dict['camera_violations'][camera_id]["percent_change"]
                    change =  violations_dict['camera_violations'][camera_id]["change"]
                else:
                    camera_risk_score = int(0)
                    delta = 0
                    pct_delta = 0
                    change = "increase"
                
                camera_risk_status = get_risk_status(camera_risk_score)

                curr_dict['name'] = camera_name_list[i]
                curr_dict['risk_score'] = camera_risk_score
                curr_dict['risk_status'] = camera_risk_status
                curr_dict['delta'] = delta
                curr_dict['pct_delta'] = pct_delta
                curr_dict['change'] = change

                camera_floor = floor_name_list[i]

                if camera_floor in floor_dict:
                    floor_dict[camera_floor].append(curr_dict)
                else:
                    floor_dict[camera_floor] = [curr_dict]
            
            camera_dict = dict()
            camera_dict['floor_names'] = list(floor_dict.keys())
            camera_dict['camera_data'] = list(floor_dict.values())

            dashboard_dict = dict()
            dashboard_dict['date_frame'] = date_frame
            dashboard_dict['Overall_average'] = int(violations_dict['overall_current'])
            dashboard_dict['Overall_change'] = violations_dict['overall_change']
            dashboard_dict['Overall_percent_change'] = violations_dict['overall_pct_change']
            dashboard_dict['location_data'] = camera_dict
             

        else:
            start_date, end_date, precision = get_date_range(start_date_str, end_date_str,freq = precision)
            date_frame = get_date_frame(end_date)
            
            date,violations = get_violation_graph(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone)

            camera_violation_dict = get_camera_violations(dashboard_name,camera_id_tuple,start_date,end_date)
            #return dict{"name":gear_count}
            
            # violations_dict['x_data'] = date
            # violations_dict['y_data'] = violations
            # violations_dict['graph_data'] = {'x':date,'y':violations}
            # violations_dict['camera_data'] = camera_dict
            
            floor_dict = {}
            
            for i, camera_name in enumerate(camera_name_list):
                curr_dict = dict()

                if camera_name in camera_violation_dict:
                    camera_risk_score = int(camera_violation_dict[camera_name])
                else:
                    camera_risk_score = int(0)
                
                camera_risk_status = get_risk_status(camera_risk_score)

                curr_dict['name'] = camera_name_list[i]
                curr_dict['risk_score'] = camera_risk_score
                curr_dict['risk_status'] = camera_risk_status


                camera_floor = floor_name_list[i]

                if camera_floor in floor_dict:
                    floor_dict[camera_floor].append(curr_dict)
                else:
                    floor_dict[camera_floor] = [curr_dict] 
        
            camera_dict = dict()
            camera_dict['floor_names'] = list(floor_dict.keys())
            camera_dict['camera_data'] = list(floor_dict.values())

            dashboard_dict = dict()
            dashboard_dict['date_frame'] = date_frame
            dashboard_dict['graph_data'] = {'x':date,'y':violations}
            dashboard_dict['location_data'] = camera_dict
        

        return dashboard_dict
    
    except:
        logger.exception("Exception in get normal safety dashboard")
        return {"x_arr":['8 am', '9 am', '10 am'], "y_arr":[5, 6, 7],"camera_data":{"Cam1":5,"Cam2":4}}
    
def get_employee_job_info(employee_email):
    """
        Description : A function used to return employee_job_info_dashboard.
        Parameters  : employee_email (string).
        Returns     : dict
    """
    try:

        employee_info_dict = get_employee_info(employee_email)

        employee_name = employee_info_dict['name'][0]
        employee_id = employee_info_dict['id'][0]
        employee_pic_path = employee_info_dict['pic_path'][0]
        
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("SELECT job_type, gear_code FROM employee_job_info WHERE employee_email = %s AND info_uploaded = TRUE", (employee_email,))
        
        data = cursor.fetchall()

        connection.commit()
        cursor.close()
        db_connection_pool.putconn(connection)
        
        if len(data) > 0:

            job_type , gear_code = map(list,zip(*data))
            job_type = job_type[0]
            gears = get_names(gear_code[0])
           
            
        else:
            gears = []
            job_type = None

        employee_job_info_dict = dict()
        employee_job_info_dict["job_type"] = job_type
        employee_job_info_dict["gears"] = gears

        employee_job_info_dict['pic_path'] = employee_pic_path
        employee_job_info_dict['employee_name'] = employee_name
        employee_job_info_dict['id'] = employee_id

        return employee_job_info_dict
    
    except:
        logger.exception("Exception in get_employee_job_info")
        return "failure"

def get_advanced_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision='day',time_zone='UTC'):
    """This function combines returns data for advanced mode. Advacned mode includes graph and empoloyee wise violations
    should return {x_data:time,y_data:violations,employee_data:[{}]}
    """
    try:

        #call camera_details functions
        camera_id_list, camera_name, _, _ = get_camera_details(user_email)
        camera_id_tuple = tuple(camera_id_list)

        if len(camera_id_list) < 1:
            return {}

        original_precision = precision

        start_date, end_date, precision = get_date_range(start_date_str, end_date_str,freq = original_precision) #now violations not applicable for list of employee
        date_frame  = get_date_frame(end_date)

        employee_violation_list = get_employee_violations(user_email, dashboard_name, start_date, end_date, precision, time_zone)

        if original_precision == 'now':
            violations_dict = get_dashboard_violations_now(dashboard_name, camera_id_tuple, time_zone = 'UTC')
            avg_current, avg_change,change = int(violations_dict['overall_current']),violations_dict['overall_pct_change'] ,violations_dict['overall_change']
            date_frame = get_date_frame(datetime.now())
            return {"Overall_average":avg_current, "Overall_percent_change":avg_change, "Overall_change":change,"employee_data":employee_violation_list,'date_frame':date_frame}
        else:
            start_date, end_date, precision = get_date_range(start_date_str, end_date_str,original_precision)
            time,violations =get_violation_graph(dashboard_name, camera_id_tuple, start_date, end_date, precision, time_zone)

        

            return {'graph_data':{"x":time, "y":violations}, "employee_data":employee_violation_list,"date_frame":date_frame}
    except:
        logger.exception("exception occured in fetching get_advanced_dashboard")
        mock = {'employee_name':"Unkown", 'employee_email':"NA", "employee_pic_path":"./default.png" , "employee_id":"01", "violations": 5, "job_type": "Operator"}
        return {'graph_data':{"x":['8 am', '9 am', '10 am'], "y":[5, 6, 7] }, "employee_data":[mock]} 

def get_employee_violations(user_email, dashboard_name, start_date, end_date, precision='day', time_zone = 'UTC'):
    try:
        #get code
        code = get_safety_codes([dashboard_name])

        #get employee_list
        emp_info = get_employee_info_list(user_email)

        #query
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
       
        cursor.execute("SELECT info.employee_email,info.employee_name,info.employee_id,info.employee_pic_path,emp_table.gc FROM ( SELECT employee_id, COUNT(gear_code) AS gc FROM violation \
                        WHERE time > %s::timestamp AND \
                             time < %s::timestamp + interval '1 day' \
                                 AND gear_code ~ %s \
                                and employee_id in %s \
                                     GROUP BY employee_id \
                                         ORDER BY gc ) as emp_table \
                            JOIN employee_info AS info USING(employee_id)",(start_date, end_date, code, tuple(emp_info['id'])))
        data = cursor.fetchall()
        cursor.close()
        db_connection_pool.putconn(connection)

        if len(data) < 1:
            return []

        employee_email,employee_name,employee_id,employee_pic_path,gear_code = map(list,zip(*data))
        result_list = []
        for i in data:
            connection = db_connection_pool.getconn()
            cursor = connection.cursor()
            cursor.execute('SELECT job_type FROM employee_job_info WHERE info_uploaded = TRUE AND employee_email = %s',(i[0],))
            job = cursor.fetchall()
            cursor.close()
            db_connection_pool.putconn(connection)
            if len(job) > 0:
                job_type = job[0][0]
            else:
                job_type = None

            result_list.append({'employee_name':i[1], 'employee_email':i[0], "employee_pic_path":i[3] , "employee_id":i[2], "violations": i[4], "job_type": job_type})

        return result_list

    except:
         logger.exception("exception occured in fetching get_employee_violations")
         return [{'employee_name':"Unkown", 'employee_email':"NA", "employee_pic_path":"./default.png" , "employee_id":"01", "violations": 5, "job_type": "Operator"}]

def get_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision='day',time_zone='UTC'):
    """Main function for the service
    if dashboard_name not in ['mask','heatmap','sd']
        get_safety_dashboard
        else
    """
    try:
        mode = get_safety_gear_settings(user_email)['mode']
        
        if mode:
            data = get_advanced_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision=precision,time_zone=time_zone)
        else:
            data = get_normal_safety_dashboard(user_email, dashboard_name, start_date_str,end_date_str,precision=precision,time_zone=time_zone)

        return data
    except:
        logger.exception("exception occured in fetching get_safety_dashboard")
        return 'failure'#return sample data

def get_employee_safety_violation(emp_id,employee_email):
    '''TESTED
    '''
    try:
        # get violations
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        cursor.execute("SELECT gear_code FROM violation WHERE employee_id = %s", (emp_id,))
        data = cursor.fetchall()

        #get employee gear 
        cursor.execute("SELECT gear_code FROM employee_job_info WHERE employee_email =%s",(employee_email,))
        requirements = cursor.fetchall()
        
        cursor.close()
        db_connection_pool.putconn(connection)

        print(requirements)

        gear_names = get_names(requirements[0][0])
        # gear_names = ''
        vio_codes = {i:0 for i in requirements[0][0]}
        print(vio_codes)
        
        if len(data) > 0:
            for codes in data:
                # print(codes)
                for code in codes[0]:
                    if code in vio_codes.keys():
                        vio_codes[code]+=1
                    else:
                        continue

            final_vio = dict()

            for key,value in vio_codes.items():

                name = get_names(codes=key)[0]
                final_vio[name] = value

            return {'violations':final_vio,'requirements':gear_names}

        else:
            return {'violations':{},'requirements':[]}

        return
    except:
        logger.exception("exception occured in fetching get_employee_safety_violation")
        return {'violations':{},'requirements':[]}

def get_safety_gear_score(module_name, camera_id_tuple, start_date, end_date):
    '''
    Function used for retuurning the value for safety_gear_dashboard in the overall_safety_score screen
    '''
    try:
        _, violations = get_violation_graph(module_name, camera_id_tuple, start_date, end_date)
        if len(violations) > 0:
            risk_score = sum(violations)/(len(violations)*100)
        else:
            risk_score = 0

        if risk_score is None:
            safety_score = 1
        else:
            safety_score = 1 - risk_score
        return safety_score
    except:
        logger.exception("Exception in get_safety_score")
        return -1

def get_safety_gear_score_now(module_name, camera_id_tuple):
    '''
    Function used for retuurning the value for safety_gear_dashboard in the overall_safety_score screen
    '''
    try:
        violation_dict = get_dashboard_violations_now(module_name, camera_id_tuple, time_zone = 'UTC')
        #_, violations = get_violation_graph(module_name, camera_id_tuple, start_date, end_date,precision='now')
        #risk_score = sum(violations)/(len(violations)*100)
        risk_score = violation_dict['overall_current']

        if risk_score is None:
            safety_score = 100
        else:
            safety_score = 100 - risk_score
        return safety_score, violation_dict['overall_pct_change'], violation_dict['overall_change']
    except:
        logger.exception("Exception in get_safety_score")
        return -1

def serve_safety_gear_settings(user_email):
    """
    """
    settings = {'safety_gear':False,'normal':False, "advanced":False, "safety_list":[]}
    sg = get_user_dashboard_list(user_email)['safety_gear']
    if sg == True:
        settings['safety_gear'] = True
        usr_sets = get_safety_gear_settings(user_email)
        mode = usr_sets['mode']
        
        # True Means Advanced -- False means Normal
        if mode == True:
            settings['advanced'] = True
        elif mode ==False:
            settings['normal'] = True
            gear_code = usr_sets['gear_code']
            if gear_code:
                names = get_names(gear_code)
            else:
                names = []
            settings['safety_list'] = names

    return settings    

def get_safety_dashboards(user_email):
    """ Internal function to get all safety gear dashboards for user
    """
    try:
        usr_sets = get_safety_gear_settings(user_email)
        mode = usr_sets['mode']
        if mode:
            connection = db_connection_pool.getconn()
            cursor = connection.cursor()

            cursor.execute('select gear_code from employee_job_info \
                    where length(gear_code) = (select max(length(gear_code)) from employee_job_info where user_email = %s)',(user_email,))

            data = cursor.fetchall()

            # connection = db_connection_pool.getconn()
                
            # cursor = connection.cursor()

            cursor.close()
            db_connection_pool.putconn(connection)

            if len(data[0]) < 1:
                return []

            return get_names(codes=data[0][0])
        else:
            gear_code = usr_sets['gear_code']
            return get_names(gear_code) 
    except:
        return get_names()      

def flush_queue(q):
    while True:
        try:
            if q.qsize() > 0:
                q.get()
            else:
                break
        except:
            print('Exception occured')
            break

def join_queue(q):
    q.close()
    q.join_thread()

def kill_saferson():
    for streamer in camera_objects_dict.values():
        streamer.remove_stream_reader()

    flush_queue(mask_queue)
    flush_queue(sd_queue)
    flush_queue(heatmap_queue)
    flush_queue(score_queue)
    flush_queue(safety_queue)

    mask_obj.stop()
    mask_thread.join()

    sd_obj.stop()
    sd_thread.join()

    # sf_obj.stop()
    # sf_obj.join()

    map_obj.stop()
    map_thread.join()

    score_obj.stop()
    score_thread.join()

    face_obj.stop()
    face_thread.join()

    join_queue(mask_queue)
    join_queue(sd_queue)
    join_queue(heatmap_queue)
    join_queue(score_queue)

    db_connection_pool.closeall()

def restart():
    main_thread = threading.current_thread()
    for thr in threading.enumerate():
        if thr is main_thread:
            continue
        else:
            print('Killing')
            thr.join() 
# -------------------------------------Dashboard_changes----------------------------

def get_timezone(IP):
    ''' Requires maxminddb (pip install maxminddb-geolite2)
        input - IP address String
    '''
    reader = geolite2.reader()
    try:
        r =reader.get(IP)
        return r['location']['time_zone']
    except:
        logger.warning('Time zone not found in location')
        return 'UTC'
    geolite2.close()
    return 'UTC'

def get_date_frame(end_date):
    try:
        date_frame = {}

        for freq in ['now','day', 'week', 'month']:
            if freq == 'now':
                curr_str = end_date.strftime('%H:%M')
            if freq == 'day':
                curr_str = end_date.strftime('%b %d, %Y')
                

            elif freq == 'week':
                start_date = get_start_date(end_date, freq)
                start_day = start_date.strftime('%d')
                start_month = start_date.strftime('%b')
                end_day = end_date.strftime('%d')
                end_month = end_date.strftime('%b')

                if start_month == end_month:
                    curr_str =  start_month + ' ' + start_day + ' to ' + end_day
                else:
                    curr_str = start_month + ' ' + start_day + ' to ' + end_month + ' ' + end_day
            
            elif freq == 'month':
                curr_str = end_date.strftime('%b %d')
            
            date_frame[freq] = curr_str

        return date_frame
    except:
        logger.exception("Exception in get_date_frame")
        return {}

def get_start_date(end_date, freq):
    start_date = end_date
    if freq == 'day':
        start_date = end_date
    elif freq == 'week':
        curr_week_day = end_date.weekday()
        start_date = end_date - timedelta(days=curr_week_day)
    elif freq == 'month':
        start_date = end_date.replace(day=1)
    
    return start_date

def daily_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   

        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        # cursor.execute("SELECT employee_email\
        #                 FROM employee_info \
        #                 WHERE user_email = %s AND info_uploaded = %s", (user_email, True))
        cursor.execute("SELECT business_id FROM tb_user_master where mobile= %s",(user_email, ) )
        business_id = cursor.fetchone()[0]

        cursor.execute("SELECT email , name , emp_id, profile_image, status\
                        FROM tb_user_master\
                        WHERE business_id = %s AND is_employee = %s AND profile_image != %s", (business_id, "Y",""))
         
        attendance_datas = cursor.fetchall()
        
        if len(attendance_datas) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['attendance_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict
        else:
            final_list = list()
            for attendance_data in attendance_datas:
                temp_dict = dict()
                temp_dict["employee_email"] = attendance_data[0]
                temp_dict["employee_name"] = attendance_data[1]
                temp_dict["employee_id"] = attendance_data[2]
                temp_dict["employee_pic_path"] = attendance_data[3]
                temp_dict["status"] = ""
                final_list.append(temp_dict)
            logging.info(final_list)
       

            overall_stats_dict = dict()
            overall_stats_dict['Total'] = len(attendance_datas)
            overall_stats_dict['IN'] = 0
            overall_stats_dict['OUT'] = 0
            
            

            overall_dict = dict()
            overall_dict['overall_stats'] = overall_stats_dict
            overall_dict['attendance_table'] = final_list

            return overall_dict
    except:
        logger.exception("Exception in daily_touchless_attendance")
        return {}

def agg_touchless_dashboard(user_email, start_date, end_date, filter_cond,time_zone='UTC'):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()   
        # query to all employees_emails,name,id,pic_path, for the user from employee_info
        cursor.execute("SELECT business_id FROM tb_user_master where mobile= %s",(user_email, ) )
        business_id = cursor.fetchone()[0]

        cursor.execute("SELECT email , name , emp_id, profile_image, status\
                        FROM tb_user_master\
                        WHERE business_id = %s AND is_employee = %s AND profile_image != %s", (business_id, "Y",""))
        
         
        attendance_datas = cursor.fetchall()
        
        if len(attendance_datas) <= 0:
            overall_dict = dict()
            overall_dict['overall_stats'] = None
            overall_dict['attendance_table'] = None
            cursor.close()
            db_connection_pool.putconn(connection)
            return overall_dict
        else:
            final_list = list()
            for attendance_data in attendance_datas:
                temp_dict = dict()
                temp_dict["employee_email"] = attendance_data[0]
                temp_dict["employee_name"] = attendance_data[1]
                temp_dict["employee_id"] = attendance_data[2]
                temp_dict["employee_pic_path"] = attendance_data[3]
                temp_dict["status"] = ""
                final_list.append(temp_dict)


        absences_graph_dict = dict()
        absences_graph_dict['x'] = []
        absences_graph_dict['y'] = []
    
        overall_stats_dict = dict()
        overall_stats_dict['Total'] = len(attendance_datas)
        overall_stats_dict['Absent'] = 0
        overall_stats_dict['avg_working_hrs'] = 0


        overall_dict = dict()
        overall_dict['overall_stats'] = overall_stats_dict
        overall_dict['graph_data'] = absences_graph_dict
        overall_dict['attendance_table'] = final_list

        return overall_dict
    except:
        logger.exception("Exception in agg_touchless_dashboard")
        return {}

def touchless_dashboard(user_email, start_date_str=None, end_date_str=None, freq='day', filter_cond='Total',time_zone='UTC'):
    try:
        # get start and end dates
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
       
        if start_date == end_date:
            overall_dict = daily_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)
        else:
            overall_dict = agg_touchless_dashboard(user_email, start_date, end_date, filter_cond, time_zone)

        date_frame = get_date_frame(end_date)
        overall_dict['date_frame'] = date_frame
        
        return overall_dict
    except:
        logger.exception("Exception in touchless_dashboard")
        return {}

def agg_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
    try:
       
        
        graph_data_dict = dict()
        graph_data_dict['x'] = []
        graph_data_dict['y'] = []

        return graph_data_dict
    except:
        logger.exception("Exception in agg_employee_attendance")
        return {}

def daily_employee_attendance(employee_email, start_date, end_date, time_zone='UTC'):
    try:
       
        graph_data_dict = {}
        graph_data_dict['end_hour'] = 0
        graph_data_dict['start_hour'] = 0
        # graph_data_dict['status'] = att[:-1]
        graph_data_dict['gantt_data'] = []
        return graph_data_dict
    except:
        logger.exception("Exception in daily_employee_attendace")
        return {'gantt_data':[]}

def get_employee_attendance(employee_email, start_date_str=None, end_date_str=None, freq='day', time_zone='UTC'):
    # get start and end dates
    try:
        start_date, end_date, precision = get_date_range(start_date_str, end_date_str, freq)
        logging.info(start_date, end_date, precision)
        if start_date == end_date:
            graph_data_dict = daily_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
        else:
            graph_data_dict = agg_employee_attendance(employee_email, start_date, end_date, time_zone=time_zone)
        
        return graph_data_dict
    except:
        logger.exception("Exception in get_employee_attendance")
        return {}

def get_date_range(start_date_str=None, end_date_str=None, freq='day'):
    try:
        if start_date_str and end_date_str:
            if start_date_str == end_date_str:
                precision = 'hour'
            else:
                precision = 'day'
            
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()

        else:
            if freq == 'day':
                precision = 'hour'
            else:
                precision = 'day'
            
            end_date = datetime.now(timezone.utc).date()
            start_date = get_start_date(end_date, freq)
        logging.info(start_date, end_date, precision)
        return (start_date, end_date, precision)
    except:
        logger.exception("Exception inn get_date_range")
        return (datetime.min,datetime.max,'hour')


def check_rtsp(url,timeout=5):
  #check if port is open before checking if rtsp link is valid. Saves time
  # ip,port = get_ip_from_url(url)
  # if check_open(ip,port):
    #if port is open check if rtsp link is valid
  cap = cv2.VideoCapture(url)
  conn, _ = cap.read()
    # print(frame)
  cap.release()
  return conn
  # return False

def try_channels(link_format):
    #helper
    ch=False
    if "ch" in link_format:
      ch=True
    channels = [link_format]
    for i in range(2,9):
        if ch:
          new_link = re.sub('ch01',f'ch0{i}',link_format)
        elif 'Stream1' in link_format:
          new_link = re.sub('Stream1',f'Stream{i}',link_format)
        else:
           new_link = re.sub('/1',f'/{i}',link_format)
        if new_link.startswith('http://'):
            try:
                resp = requests.head(new_link,timeout=0.3)
                if resp.status_code < 400 and resp.headers['Content-type'] in ['image/jpeg','video/mp4']:#check for stream
                    channels.append(new_link)
            except requests.exceptions.Timeout:
                continue
        else:
          if check_rtsp(new_link):
            channels.append(new_link)
    return channels

def checkin_checkout(camera_id):
    try:
        connection = db_connection_pool.getconn()
        cursor = connection.cursor()
        message = ""
        cursor.execute("SELECT is_checkin_checkout FROM  camera_details WHERE camera_id = %s",(camera_id,))
        camera = cursor.fetchone()
        if not camera:
            message = "Not Found"
        else:
            if camera[0]:
                message =  True
            else:
                message = False
    except:
        return "Failure"       
    return message  

    
