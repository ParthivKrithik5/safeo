import logging, random, string, base64

from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_httpauth import HTTPTokenAuth

import psycopg2.extras

# Flask App
app = Flask(__name__)
cors = CORS(app)

# App log configuration
logging.basicConfig(filename="safeov2_api.log", level=logging.DEBUG, format="%(asctime)s  %(name)s  %(levelname)s: %(message)s")

# Postgres database connection
db_url = 'postgresql://sfsktusr01:_k9Bd#RP@localhost:5432/safeov2_dev'
app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_POOL_SIZE"] = 10
db = SQLAlchemy(app)

# Code Configuration 
app.config["OTP_VALID_MINUTES"] = 5
app.config["PROFILE_IMAGES"] = "static/profile-images/"
app.config["DEFAULT_IMAGE"] = "/static/profile-images/default_pic.jpeg"
app.config["SERVER_PATH"] = "https://dev.safeo.ai/services"

# Authentication
auth = HTTPTokenAuth("Bearer")

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()
