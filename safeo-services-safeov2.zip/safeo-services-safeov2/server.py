from app import app
from views import login, user, admin, dashboard

from flask import request, render_template

# SME Portal API Services..

app.register_blueprint(login.login_blueprint)
app.register_blueprint(user.user_blueprint)
app.register_blueprint(admin.admin_blueprint)
app.register_blueprint(dashboard.dashboard_blueprint)

@app.route("/")
@app.route("/api")
def home():
   """ API Home """
   return "Safeo Portal API Services.."

if __name__ == "__main__":
   app.run(debug=True, host="0.0.0.0",port=5001)
