from app import app, logging
import random, math, string, re

from email_validator import validate_email, EmailNotValidError

from dateutil.relativedelta import relativedelta
import datetime

OTP_VALID_MINUTES = 3

# Role Type
ROLE_TYPE = {
    "SKORUZ-ADMIN": "SKORUZ-ADMIN",
    "CLIENT-ADMIN": "CLIENT-ADMIN",
    "ADMIN": "ADMIN",
    "CLIENT-INTERNAL": "CLIENT-INTERNAL"
}

# Role Modification status
ROLE_MODIFICATION = {
    "YES": "Y",
    "NO": "N"
}

# Config Type
CONFIG_TYPE = {
    "ROLE" : "ROLE",
    "EMPLOYEE" : "EMPLOYEE",
    "GROUP" : "GROUP"
}

# Monitor Type
MONITOR_TYPE = {
    "ACTIVITY" : "ACTIVITY",
    "GROUP" : "GROUP"
}


# Status 
STATUS = {
    "ACTIVE" : "A",
    "DEACTIVE" : "D",
    "DELETE" : "C",
    "YES" : "Y",
    "NO" : "N",
    "VERIFIED" : "V",
    "ENTRY" : "E",
    "OUT" : "OUT",
    "IN" : "IN",
    "SAVED" : "S"
}

# Function Approach Type using Function Creation
FUNCTION_TYPE = {
    "NONE" : "NONE",
    "ACTIONABLE" : "ACTIONABLE"    
}

#Email_validation
def email_validation(email):
    email = email.strip()
    try:
        validate_email(email)
        return True
    except EmailNotValidError as e:
        return False

#mobile_no validation
def mobile_no_validation(number):
    number = str(number)
    number = number.strip()
    if number.isnumeric() and len(number) <= 16 and len(number) > 6 :
        return True
    else:
        return False 

#char_validation
def char_validation(string):
    string = string.strip()
    regex = re.compile("[@_!#.,$%^&*()<>?/\|}{~:0-9]")
    if regex.search(string)==None and len(string) <= 64 :
        return True
    else:
        return False    

# Strong Password Valiadation
def strong_password_validation(password): 
    message = ""
    try:
        if len(password) < 8:
            message = "Password should be at least 8 characters : 8-16"
        elif len(password) > 16:
            message = "Password should not exceed 15 characters : 8-16"
        elif not re.search("[a-z]", password):
            message = "Password should contain at least one lowercase : a-z"
        elif not re.search("[A-Z]", password):
            message = "Password should contain at least one uppercase : A-Z"
        elif not re.search("[0-9]", password):
            message = "Password should contain at least one digit : 0-9"
        elif not re.search("[$#@!%^&*()]", password):
            message = "Password should contain at least one character : $#@!%^&*()"
    except Exception as e:
        logging.error("strong_password_validation : exception : {}".format(e))
        message = ""
    return message    

# Generate OTP
def generate_otp():
    digits = "0123456789"
    otp = "" 
    for i in range(6) : 
        otp += digits[math.floor(random.random() * 10)]
    return str(123456) #str(otp)             

# Generate Random Password
def get_random_password():
    letters = string.ascii_lowercase
    result_str = "".join(random.choice(letters) for i in range(10))
    return result_str

# Generate 3 digit Random Number using to Emp_id in CLIENT-ADMIN Only
def get_random_no():
    digits = "0123456789"
    no = ""
    for i in range(3):
        no += digits[math.floor(random.random() * 10)]
    return no

def get_month_day_range(date):
    last_day = date + relativedelta(day=1, months=+1, days=-1)
    first_day = date + relativedelta(day=1)
    return first_day, last_day

def get_week_day_range(date):
    start = date - datetime.timedelta(days=date.weekday()) - datetime.timedelta(days=1)
    end = start + datetime.timedelta(days=7)
    return start, end

def temperature_validation(n): 
    if re.search("^(?=.)([+-]?([0-9]*)(\.([0-9]+))?)$",n): 
        return True
    else: 
        return False    
