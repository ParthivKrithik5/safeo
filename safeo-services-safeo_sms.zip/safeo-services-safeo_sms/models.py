import datetime, math, random

from app import app, db, auth, logging
from constants import STATUS, MONTHLY,READ_STATUS, SMS_STATUS, OTP_VALID_MINUTES

from sqlalchemy import and_

# Password Hashing Import
from passlib.hash import pbkdf2_sha256
from itsdangerous import (TimedJSONWebSignatureSerializer as Serializer, BadSignature, SignatureExpired)


# Safeo Model Class

# Function Model
class Function(db.Model):
    """ Function maintenance table """
    __tablename__ = 'tb_functions'
    function_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    function_name = db.Column(db.String(200), nullable=False)
    function_desc = db.Column(db.String(200), nullable=True)
    parent_function_id = db.Column(db.Integer, nullable=True, default=0)
    function_url = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)


# Business Model
class Business(db.Model):
    """ Business maintenance table """
    __tablename__ = 'tb_businesses'
    business_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_name = db.Column(db.String(200), nullable=False)
    industry = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(600), nullable=False)
    selected_plan = db.Column(db.String(60), nullable=True)
    selected_plan_span = db.Column(db.String(20), default='')
    active_users = db.Column(db.Integer, nullable=True, default=0)
    plan_exp_date = db.Column(db.DateTime, nullable=True)
    touchless_checkin_option =  db.Column(db.String(60), default='THERMAL')
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_name, industry, address):
        self.business_name = business_name
        self.industry = industry
        self.address = address
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Payment Cards Model
class PaymentCard(db.Model):
    """Payment card maintenance table """
    __tablename__ = 'tb_payment_cards'
    card_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    customer_profile_id = db.Column(db.String(60), nullable=True)
    customer_payment_profile_id = db.Column(db.String(60), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_id, customer_profile_id, customer_payment_profile_id):
        self.business_id = business_id
        self.customer_profile_id = customer_profile_id
        self.customer_payment_profile_id = customer_payment_profile_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Invoice Model
class Invoice(db.Model):
    """Invoice maintenance table """
    __tablename__ = 'tb_invoices'
    invoice_no = db.Column(db.Integer, primary_key=True, autoincrement=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    card_id = db.Column(db.Integer, db.ForeignKey('tb_payment_cards.card_id'), nullable=False)
    invoice_sub_total_amount = db.Column(db.Float, nullable=True)
    invoice_tax = db.Column(db.Float, nullable=True)
    invoice_total_amount = db.Column(db.Float, nullable=True)
    invoice_date = db.Column(db.DateTime, nullable=False)
    invoice_paid_amount = db.Column(db.Float, nullable=False)
    transcation_id = db.Column(db.String(20), nullable=True)
    remarks = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=True)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, business_id, card_id, invoice_sub_total_amount, invoice_tax, invoice_total_amount,
                 invoice_paid_amount):
        self.business_id = business_id
        self.card_id = card_id
        self.invoice_sub_total_amount = invoice_sub_total_amount
        self.invoice_tax = invoice_tax
        self.invoice_total_amount = invoice_total_amount
        self.invoice_paid_amount = invoice_paid_amount
        self.invoice_date = datetime.datetime.now()
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Role Model
class Role(db.Model):
    """ Role maintenance table """
    __tablename__ = 'tb_roles'
    role_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    role_name = db.Column(db.String(200), nullable=False)
    role_desc = db.Column(db.String(1000), nullable=True)
    business_id = db.Column(db.Integer, db.ForeignKey('tb_businesses.business_id'), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, role_name, role_desc, business_id):
        self.role_name = role_name
        self.role_desc = role_desc
        self.business_id = business_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()


# Role & Function Map
class Role_Function_Map(db.Model):
    """Function & Role Mapping table """
    __tablename__ = 'tb_role_function_map'
    __table_args__ = (db.PrimaryKeyConstraint('role_id', 'function_id'),)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_roles.role_id'), nullable=False)
    function_id = db.Column(db.Integer, db.ForeignKey('tb_functions.function_id'), nullable=False)

    def __init__(self, role_id, function_id):
        self.role_id = role_id
        self.function_id = function_id

# Registration Model
class Registration(db.Model):
    """ Registration maintenance table  """
    __tablename__ = 'tb_registrations'
    reg_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    password = db.Column(db.String(64), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country.country_id'),nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    business_name = db.Column(db.String(120), nullable=False)
    industry = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(600), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    sms_verified_on = db.Column(db.DateTime, nullable=True)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def __init__(self, name,email, country_id,phone, business_name, industry, address):
        self.name = name
        self.email = email
        self.country_id = country_id
        self.phone = phone
        self.business_name = business_name
        self.industry = industry
        self.address = address
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

# User Model
class User(db.Model):
    """ User maintenance table  """
    __tablename__ = 'tb_users'
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    password = db.Column(db.String(64), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country.country_id'),nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    terms_conditions_agreement = db.Column(db.String(1), nullable=False, default=STATUS['YES'])
    default_password_changed = db.Column(db.String(1), nullable=False, default=STATUS['NO'])
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_by = db.Column(db.Integer, nullable=True, default=0)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_by = db.Column(db.Integer, nullable=True, default=0)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, name, email, password, country_id ,phone):
        self.name = name
        self.email = email
        self.password = password
        self.country_id = country_id
        self.phone = phone
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

    def hash_password(self, password):
        """ Password hasing using passlib package"""
        self.password = pbkdf2_sha256.hash(password)

    def verify_password(self, password):
        """ Password verification """
        return pbkdf2_sha256.verify(password, self.password)

    def generate_auth_token(self):
        """ Generate authentication token with expiration time """
        s = Serializer(app.config['SECRET_KEY'], expires_in=app.config['TOKEN_EXPIRATION'])
        return s.dumps({'user_id': self.user_id})


# User & Role Map
class User_Role_Map(db.Model):
    """ User & Role Mapping table """
    __tablename__ = 'tb_user_role_map'
    __table_args__ = (db.PrimaryKeyConstraint('user_id', 'role_id'),)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('tb_roles.role_id'), nullable=False)

    def __init__(self, user_id, role_id):
        self.user_id = user_id
        self.role_id = role_id


# Enquiry Model
class Enquiry(db.Model):
    """ User maintenance table  """
    __tablename__ = 'tb_enquires'
    enquiry_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120), nullable=False)
    company = db.Column(db.String(160), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country.country_id'),nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(60), nullable=False)
    message = db.Column(db.String(600), nullable=False)
    enquiry_type = db.Column(db.String(20), nullable=False, default=STATUS['DEMO'])
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, name, company, email, country_id,phone, country, message, enquiry_type):
        self.name = name
        self.company = company
        self.email = email
        self.country_id = country_id
        self.phone = phone
        self.country = country
        self.message = message
        self.enquiry_type = enquiry_type
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

# Complaince Tables
class Compliance_List(db.Model):
    """ Compliance list maintenance table  """
    __tablename__ = 'compliance_list'
    compliance_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

class Compliance_Check_List(db.Model):
    """ Compliance Check list maintenance table  """
    __tablename__ = 'compliance_check_list'
    check_list_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    compliance_id = db.Column(db.Integer, db.ForeignKey('compliance_list.compliance_id'), nullable=False)
    check_list_name = db.Column(db.String(1000), nullable=False)
    check_list_desc = db.Column(db.String(1000), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

class Compliance_Check_List_User(db.Model):
    """ Compliance Check List & User Mapping table """
    __tablename__ = 'compliance_check_list_user'
    __table_args__ = (db.PrimaryKeyConstraint('compliance_id', 'check_list_id','user_id'),)
    compliance_id = db.Column(db.Integer, db.ForeignKey('compliance_list.compliance_id'), nullable=False)
    check_list_id = db.Column(db.Integer, db.ForeignKey('compliance_check_list.check_list_id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    checked_status = db.Column(db.String(1), nullable=False, default=STATUS['NO'])

    def __init__(self, compliance_id, check_list_id, user_id, checked_status):
        self.compliance_id = compliance_id
        self.check_list_id = check_list_id
        self.user_id = user_id
        self.checked_status = checked_status

# Thermal Tables
class Thermal_Camera_Details(db.Model):
    """ Thermal camera details maintenance table  """
    __tablename__ = 'thermal_camera_details'
    camera_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    camera_name = db.Column(db.String(60), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ACTIVE'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, camera_name, user_id):
        self.camera_name = camera_name
        self.user_id = user_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

class Thermal_Camera_Images(db.Model):
    """ Thermal camera image maintenance table  """
    __tablename__ = 'thermal_camera_images'
    image_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('thermal_camera_details.camera_id'), nullable=False)
    thermal_image_file_name = db.Column(db.String(60), nullable=False)
    normal_image_file_name = db.Column(db.String(60), nullable=False)
    temperature_image_file_name = db.Column(db.String(60), nullable=False)
    inserted_datetime = db.Column(db.DateTime, nullable=False)

    def __init__(self, camera_id, thermal_image_file_name, normal_image_file_name, temperature_image_file_name):
        self.camera_id = camera_id
        self.thermal_image_file_name = thermal_image_file_name
        self.normal_image_file_name = normal_image_file_name
        self.temperature_image_file_name = temperature_image_file_name
        self.inserted_datetime = datetime.datetime.now()

class User_Device_Info(db.Model):
    """ User device info maintenance table  """
    __tablename__ = 'tb_user_device_info'
    info_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    android_device_id = db.Column(db.String(500), nullable=False)
    ios_device_id = db.Column(db.String(500), nullable=False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, user_id):
        self.user_id = user_id
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

class User_Notification(db.Model):
    """ User Notification maintenance table  """
    __tablename__ = 'tb_user_notifications'
    notification_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('tb_users.user_id'), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS['ENTRY'])
    read_status = db.Column(db.String(1), nullable=False, default=READ_STATUS['UNREAD'])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)

    def __init__(self, user_id, message):
        self.user_id = user_id
        self.message =  message
        self.created_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()

class Plan_Details(db.Model):
    """ Plan details maintenance table  """
    __tablename__ = 'tb_plan_details'
    plan_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    plan_name = db.Column(db.String(100), nullable=False)
    plan_desc = db.Column(db.String(500), nullable=False)
    plan_price = db.Column(db.Float, nullable=False)
    total_span = db.Column(db.String(20), nullable=False, default=MONTHLY)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=False)


# SMS Master Model
class SMS(db.Model):
    """ SMS Txn table  """
    __tablename__ = "tb_sms_txn"
    seq_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country.country_id'),nullable=False)
    phone = db.Column(db.String(16), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=SMS_STATUS["ENTRY"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, country_id,phone,message):
        self.country_id = country_id
        self.phone = phone
        self.message = message
        self.created_date = datetime.datetime.now()

# OTP Model
class OTP(db.Model):
    """ OTP Table """
    __tablename__ = "tb_otp"
    otp_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    country_id = db.Column(db.Integer, db.ForeignKey('tb_country.country_id'),nullable=False)
    phone = db.Column(db.String(16), nullable=False)
    otp_code = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ENTRY"])
    exp_date = db.Column(db.DateTime, nullable=False)
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)

    def __init__(self, country_id,phone, otp_code):
        self.country_id = country_id
        self.phone =  phone
        self.otp_code = otp_code
        # OTP Code will be valid for 3 minutes
        self.exp_date = datetime.datetime.now() + datetime.timedelta(minutes = OTP_VALID_MINUTES)
        self.created_date = datetime.datetime.now()

# Country Code
class Country(db.Model):
    """Country Table """
    __tablename__ = "tb_country"
    country_id =    db.Column(db.Integer, primary_key=True, autoincrement=True)
    long_name = db.Column(db.String(160), nullable=False)
    short_name = db.Column(db.String(120), nullable=False)
    country_code = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(1), nullable=False, default=STATUS["ACTIVE"])
    created_date = db.Column(db.DateTime, nullable=False)
    updated_date = db.Column(db.DateTime, nullable=True)


@auth.verify_token
def verify_auth_token(token):
    """ Auth token verification """
    s = Serializer(app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except SignatureExpired:
        return None  # valid token, but expired
    except BadSignature:
        return None  # invalid token
    user = User.query.get(data['user_id'])
    return user


def get_current_user():
    user_id = 0
    if auth.current_user():
        user_id = auth.current_user().user_id
    user = User.query.get(user_id)
    return user


def get_business(user):
    business = None
    user_role_map = User_Role_Map.query.filter(User_Role_Map.user_id == user.user_id).first()
    if user_role_map:
        role = Role.query.filter(Role.role_id == user_role_map.role_id).first()
        if role:
            business = Business.query.filter(Business.business_id == role.business_id).first()
    return business


def get_payment_card(business_id):
    return PaymentCard.query.filter(
        (PaymentCard.business_id == business_id) and (PaymentCard.status == STATUS['ACTIVE'])).first()


def get_invoices(business_id):
    return Invoice.query.filter((Invoice.business_id == business_id) and (Invoice.status == STATUS['COMPLETED'])).all()


def get_invoice_by_no(invoice_no):
    return Invoice.query.filter((Invoice.invoice_no == invoice_no) and (Invoice.status == STATUS['COMPLETED'])).first()


def get_user_role(user):
    user_role = ''
    user_role_map = User_Role_Map.query.filter(User_Role_Map.user_id == user.user_id).first()
    if user_role_map:
        role = Role.query.filter(Role.role_id == user_role_map.role_id).first()
        user_role = role.role_desc #role_name.split('_')[1]
    return user_role


def get_admin_user(business, admin_type='ADMIN'):
    country_id,phone = 0,''
    role_name = str(business.business_id) + '_' +  admin_type
    role = Role.query.filter((Role.role_name == role_name)).first()
    if role:
        user_role_map = User_Role_Map.query.filter(User_Role_Map.role_id == role.role_id).first()
        if user_role_map:
            user = User.query.filter(User.user_id == user_role_map.user_id).first()
            if user:
                country_id = user.country_id
                phone = user.phone
    return country_id,phone


def get_safety_regulations_score(user, result):
    compliance_dict_list = []
    heatmap_percentage = result['heatmap_data']['safety_score']
    mask_percentage = result['mask_data']['safety_score']
    sd_percentage = result['sd_data']['safety_score']

    compliance_id_list = Compliance_Check_List_User.query.with_entities(Compliance_Check_List_User.compliance_id) \
        .filter(Compliance_Check_List_User.user_id==user.user_id).distinct().all()
    compliance_id_list =[id[0] for id in compliance_id_list]

    for compliance_id in compliance_id_list:
        compliance_list = Compliance_List.query.filter(Compliance_List.compliance_id == compliance_id).first()
        checked_count= Compliance_Check_List_User.query.filter((Compliance_Check_List_User.user_id==user.user_id) & \
                (Compliance_Check_List_User.compliance_id == compliance_id) & \
                (Compliance_Check_List_User.checked_status == STATUS['YES'])).count()
        total_count= Compliance_Check_List_User.query.filter((Compliance_Check_List_User.user_id==user.user_id) & \
                (Compliance_Check_List_User.compliance_id == compliance_id) ).count()

        compliance_score = ( checked_count / total_count ) * 100
        safety_score = (heatmap_percentage+mask_percentage+sd_percentage+compliance_score)/4
        
        safety_status = ''
        if safety_score >= 80:
            safety_status = 'safe'
        elif safety_score >= 20:
            safety_status = 'cautious'
        else:
            safety_status = 'unsafe'
        
        compliance_dict_list.append({
            'compliance_id':compliance_id, 'name':compliance_list.name, 'safety_score':safety_score, 'safety_status':safety_status})
    return compliance_dict_list

def add_notification_message(country_id, phone, message):
    try:
        user = User.query.filter_by(country_id = country_id, phone = phone).first()
        if user:
            db.session.add(User_Notification(user.user_id, message))
            db.session.commit()
    except Exception as e:
        logging.error('add_notification_message : exception : {}'.format(e))
    return 'success'
    
def get_pro_plan_price(plan_name):
    plan_details = Plan_Details.query.filter(Plan_Details.plan_name == plan_name).first()
    if plan_details:
        return plan_details.plan_price
    else:
        return 0


def sms_insert(country_id, phone, message):
    try:
        sms = SMS(country_id,phone, message)
        db.session.add(sms)
        db.session.commit() 
    except Exception as e:
        logging.exception("sms_insert - {}".format(e,))

def generate_otp():
    digits = "0123456789"
    otp = ""
    for i in range(6) :
        otp += digits[math.floor(random.random() * 10)]
    otp='123456'
    return str(otp)

def otp_insert(country_id,phone):
    try:
        otp_code = generate_otp()
        otp = OTP(country_id,phone, otp_code)
        db.session.add(otp)
        db.session.commit()
        msg = "Welcome! {} is your Safeo Verification Code to activate your account".format(otp_code)
        sms_insert(country_id,phone,msg)
        return otp.otp_id
    except Exception as e:
        logging.exception("otp_insert - {}".format(e,))  
    return 0

def otp_verify(otp_id, otp_code):
    status = False
    try:
        otp = OTP.query.filter(and_ (OTP.otp_id == str(otp_id), OTP.otp_code == str(otp_code), OTP.exp_date >= datetime.datetime.now())).first()
        logging.debug(otp)
        if otp is not None:
            status = True
    except Exception as e:
        logging.exception("otp_verify - {}".format(e,))
    return status
