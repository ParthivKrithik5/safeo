import os, json, datetime, base64

from flask import Blueprint, abort, jsonify, request

from app import auth, logging, db, app
from models import User, Business,Country, get_current_user, get_business, Thermal_Camera_Details, \
    Thermal_Camera_Images, get_safety_regulations_score, get_user_role, get_admin_user
import constants

import saferson

# Data Science API Service

datascience_blueprint = Blueprint('datascience', __name__)

@datascience_blueprint.route('/api/add-camera', methods=['POST'])
@auth.login_required()
def add_camera():
    """Add Camera"""
    logging.info("add_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        if not username:
            username=None
        password = request.json.get('password')
        if not password:
            password=None

        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp = saferson.add_camera(phone, camera_name, rtsp_link, username, password)
        if resp == 'success':
            resp_dict['status'] = True
            resp_dict['msg'] = 'Camera Added Successfully'
        else:
            resp_dict['msg'] = resp
    except Exception as e:
        logging.error("add_camera : exception : {}".format(e))
        abort(500)
    logging.info("add_camera : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/camera-search', methods=['POST'])
@auth.login_required()
def camera_search():
    """Camera search"""
    logging.info("camera_search : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        username = request.json.get('username')
        password = request.json.get('password')
        ip_address = request.json.get('ip_address')
        port_no = request.json.get('port_no')
        if not port_no:
            port_no=None
        camera_brand = request.json.get('camera_brand')
        if not camera_brand:
            camera_brand = None
        
        user = get_current_user()
        resp_dict['status'] = True
        resp_dict['object'] = saferson.search(username,password,ip_address,port_no,camera_brand)
    except Exception as e:
        logging.error("camera_search : exception : {}".format(e))
        abort(500)
    logging.info("camera_search : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/camera-snapshot', methods=['POST'])
@auth.login_required()
def camera_snapshot():
    """Camera Snapshot"""
    logging.info("camera_snapshot : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        
        ip_url = request.json.get('ip_url')
        user = get_current_user()
        resp_dict['status'] = True
        resp_dict['object'] = saferson.get_snapshot(ip_url)
    except Exception as e:
        logging.error("camera_snapshot : exception : {}".format(e))
        abort(500)
    logging.info("camera_snapshot : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/camera-info', methods=['POST'])
@auth.login_required()
def camera_info():
    """Camera Info"""
    logging.info("camera_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp_dict['status'] = True
        resp_dict['object'] = saferson.get_camera_settings(phone, camera_name)
    except Exception as e:
        logging.error("camera_info : exception : {}".format(e))
        abort(500)
    logging.info("camera_info : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-camera', methods=['POST'])
@auth.login_required()
def update_camera():
    """Update Camera"""
    logging.info("update_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        rtsp_link = request.json.get('rtsp_link')
        username = request.json.get('username')
        password = request.json.get('password')
        old_camera_name = request.json.get('old_camera_name')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        settings_dict = {'camera_name' : camera_name, 'rtsp_link' : rtsp_link}
        resp = saferson.update_camera_settings(phone, old_camera_name, settings_dict)
        if resp == 'success':
            resp_dict['status'] = True
            resp_dict['msg'] = 'Camera updated successfully'
        else:
            resp_dict['msg'] = resp
    except Exception as e:
        logging.error("update_camera : exception : {}".format(e))
        abort(500)
    logging.info("update_camera : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-camera-max-capacity', methods=['POST'])
@auth.login_required()
def update_camera_max_capacity():
    """Updated Camera Maximum Allowed Capacity"""
    logging.info("update_camera_max_capacity : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        max_capacity = request.json.get('max_capacity')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        saferson.update_max_occupancy(phone, camera_name, max_capacity)
        resp_dict['status'] = True
        resp_dict['msg'] = 'Capacity Updated'        
    except Exception as e:
        logging.error("update_camera_max_capacity : exception : {}".format(e))
        abort(500)
    logging.info("update_camera_max_capacity : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/office-surveillance', methods=['GET'])
@auth.login_required()
def office_surveillance():
    """Office Surveillance"""
    logging.info("office_surveillance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_list = []
        user = get_current_user()
        resp_dict['status'] = True
        resp_dict['object'] =  []
    except Exception as e:
        logging.error("office_surveillance : exception : {}".format(e))
        abort(500)
    logging.info("office_surveillance: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/camera-list', methods=['GET'])
@auth.login_required()
def camera_list():
    """Camera List"""
    logging.info("camera_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp_dict['status'] = True
        resp_dict['object'] =  saferson.get_camera_names(phone)
    except Exception as e:
        logging.error("camera_list : exception : {}".format(e))
        abort(500)
    logging.info("camera_list: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/add-camera-availability', methods=['GET'])
@auth.login_required()
def add_camera_availability():
    """Add Camera Availability"""
    logging.info("add_camera_availability : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        camera_count = len(saferson.get_camera_names(phone))
        business = get_business(user)
        result_dict =  dict()
        result_dict['camera_allowed_status'] = constants.STATUS['YES']
        if business.selected_plan == constants.FREEMIUM and camera_count == constants.FREEMIUM_MAX_ALLOWD_CAMERAS :
            result_dict['camera_allowed_status'] = constants.STATUS['NO']
            result_dict['selected_plan'] = constants.PRO
        if business.selected_plan == constants.PRO and camera_count == constants.PRO_MAX_ALLOWD_CAMERAS: 
            result_dict['camera_allowed_status'] = constants.STATUS['NO']
            result_dict['selected_plan'] = constants.ENTERPRISE
            result_dict['max_allowed_cameras'] = constants.PRO_MAX_ALLOWD_CAMERAS
        resp_dict['status'] = True
        resp_dict['object'] =  result_dict
    except Exception as e:
        logging.error("add_camera_availability : exception : {}".format(e))
        abort(500)
    logging.info("add_camera_availability: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/delete-camera', methods=['POST'])
@auth.login_required()
def delete_camera():
    """Delete Camera"""
    logging.info("delete_camera : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        camera_name = request.json.get('camera_name')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        saferson.delete_camera(phone, camera_name)
        resp_dict['status'] = True
        resp_dict['msg'] = "Deleted Successfully"
    except Exception as e:
        logging.error("delete_camera : exception : {}".format(e))
        abort(500)
    logging.info("delete_camera: end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/add-floor', methods=['POST'])
@auth.login_required()
def add_floor():
    """Add Floor"""
    logging.info("add_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_name = request.json.get('floor_name')
        camera_name_list = request.json.get('camera_name_list')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp = saferson.add_floor(phone, camera_name_list, floor_name)
        if resp == 'success':
            resp_dict['status'] = True
            resp_dict['msg'] = 'Floor saved successfully'
        else:
            resp_dict['msg'] = resp
    except Exception as e:
        logging.error("add_floor : exception : {}".format(e))
        abort(500)
    logging.info("add_floor : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/update-floor', methods=['POST'])
@auth.login_required()
def update_floor():
    """Add Floor"""
    logging.info("update_floor : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        floor_names = request.json.get('floor_names')
        list_camera_names = request.json.get('list_camera_names')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        for index, floor_name in enumerate(floor_names):
            camera_name_tuple =  tuple(list_camera_names[index])
            saferson.update_camera_floor(phone, camera_name_tuple, floor_name)
        resp_dict['status'] = True
        resp_dict['msg'] = 'Updated successfully'
    except Exception as e:
        logging.error("update_floor : exception : {}".format(e))
        abort(500)
    logging.info("update_floor : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/floor-list', methods=['GET'])
@auth.login_required()
def floor_list():
    """Floor Listing"""
    logging.info("floor_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp_dict['status'] = True
        resp_dict['object'] = saferson.get_floor_details(phone)
    except Exception as e:
        logging.error("floor_list : exception : {}".format(e))
        abort(500)
    logging.info("floor_list : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/overall-safety-score', methods=['POST'])
@auth.login_required()
def overall_safety_score():
    """Overall Safety Score"""
    logging.info("overall_safety_score : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        resp_dict['status'] = True
        resp_dict['object'] = saferson.get_overall_safety_score(phone)
    except Exception as e:
        logging.error("overall_safety_score : exception : {}".format(e))
        abort(500)
    logging.info("overall_safety_score : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/safety-insights', methods=['POST'])
@auth.login_required()
def safety_insights():
    """Safety Insights"""
    logging.info("safety_insights : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date') 
        freq = request.json.get('freq')
        user = get_current_user()
        
        #if freq in ['day', 'week', 'month']:
        #    resp_dict['object'] = saferson.get_safety_insights(user.email,freq=freq)
        #else: 
        #    resp_dict['object'] = saferson.get_safety_insights(user.email, start_date_str=start_date, end_date_str=end_date)
        
        compliance_dict_list = []
        user = get_current_user()

        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        
        result = saferson.get_safety_insights(phone, freq)
        compliance_dict_list = get_safety_regulations_score(user, result)
        
        safety_regulations_score = 0
        safety_regulations_score = sum(compliance['safety_score'] for compliance in compliance_dict_list)
        if compliance_dict_list:
            safety_regulations_score = round((safety_regulations_score / len(compliance_dict_list)), 2)

        safety_regulations_status = ''
        if safety_regulations_score >= 80:
            safety_regulations_status = 'safe'
        elif safety_regulations_score >= 20:
            safety_regulations_status = 'cautious'
        else:
            safety_regulations_status = 'unsafe'

        safety_regulation_data = {
            'safety_score': safety_regulations_score,
            'safety_status' :safety_regulations_status
        }
        result['safety_regulations_data'] = safety_regulation_data

        resp_dict['object'] = result
        resp_dict['status'] = True
    except Exception as e:
        logging.error("safety_insights : exception : {}".format(e))
        abort(500)
    logging.info("safety_insights : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/mask-compliance', methods=['POST'])
@auth.login_required()
def mask_compliance():
    """Mask Compliance"""
    logging.info("mask_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        time_zone = get_time_zone(request)

        if freq in ['now']:
             resp_dict['object'] = saferson.get_dashboard_data(phone, 'mask', freq=freq, time_zone=time_zone)
        elif  freq in ['day', 'week', 'month']:
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'mask', freq=freq, time_zone=time_zone)
        else: 
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'mask', \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)
        resp_dict['status'] = True
    except Exception as e:
        logging.error("mask_compliance : exception : {}".format(e))
        abort(500)
    logging.info("mask_compliance : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/social-distancing-compliance', methods=['POST'])
@auth.login_required()
def social_distancing_compliance():
    """Social Distancing Compliance"""
    logging.info("social_distancing_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date') 
        freq = request.json.get('freq')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        time_zone = get_time_zone(request)

        if freq in ['now', 'day', 'week', 'month']:
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'sd', freq=freq, time_zone=time_zone)
        else: 
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'sd', \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)
        resp_dict['status'] = True
    except Exception as e:
        logging.error("social_distancing_compliance : exception : {}".format(e))
        abort(500)
    logging.info("social_distancing_compliance : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/heatmap-sanitization', methods=['POST'])
@auth.login_required()
def heatmap_sanitization():
    """Heatmap Sanitization"""
    logging.info("heatmap_sanitization : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        time_zone = get_time_zone(request)

        if freq in ['now', 'day', 'week', 'month']:
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'heatmap', freq=freq, time_zone=time_zone)
        else: 
            resp_dict['object'] = saferson.get_dashboard_data(phone, 'heatmap', \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)
        resp_dict['status'] = True
    except Exception as e:
        logging.error("heatmap_sanitization : exception : {}".format(e))
        abort(500)
    logging.info("heatmap_sanitization : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/enable-face-recog')
@auth.login_required()
def enable_face_recog():
    """Heatmap Sanitization"""
    logging.info("enable_face_recog : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        saferson.enable_face_recog(phone)
        resp_dict['status'] = True
        resp_dict['msg'] = "Enabled Successfully"
    except Exception as e:
        logging.error("enable_face_recog : exception : {}".format(e))
        abort(500)
    logging.info("enable_face_recog : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/touchless-checkin', methods=['POST'])
@auth.login_required()
def touchless_checkin():
    """Touch Less Checkin"""
    logging.info("touchless_checkin : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        filter_cond = request.json.get('filter_cond')        
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        time_zone = get_time_zone(request)

        resp = None
        if freq in  ['day', 'week', 'month']:
            resp = saferson.touchless_dashboard(phone, freq=freq, filter_cond=filter_cond, time_zone=time_zone)
        else:
            resp = saferson.touchless_dashboard(phone, \
                start_date_str=start_date, end_date_str=end_date, filter_cond=filter_cond, time_zone=time_zone)
        if resp and resp['attendance_table']:
            for emp in resp['attendance_table']:
                profile_file_name = os.path.basename(emp['employee_pic_path'])
                emp['employee_pic_path'] = app.config['SERVER_PATH']+'/api/profile-image/'+profile_file_name
        resp_dict['status'] = True
        resp_dict['object'] = resp
    
    except Exception as e:
        logging.error("touchless_checkin : exception : {}".format(e))
        abort(500)
    logging.info("touchless_checkin : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/touchless-checkin-employee-info', methods=['POST'])
@auth.login_required()
def touchless_checkin_employee_info():
    """Touch Less Checkin Employee Info"""
    logging.info("touchless_checkin_employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        employee_country_id = request.json.get('employee_country_id')
        employee_phone = request.json.get('employee_phone')
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        time_zone = get_time_zone(request)    

        country = Country.query.filter_by (country_id = employee_country_id).first()
        emp_phone = country.country_code+employee_phone

        if freq in ['day', 'week', 'month']:
            resp_dict['object'] = saferson.get_employee_attendance(emp_phone, freq=freq, time_zone=time_zone)
        else:
            resp_dict['object'] = saferson.get_employee_attendance(emp_phone, \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)    
        resp_dict['status'] = True
    except Exception as e:
        logging.error("touchless_checkin_employee_info : exception : {}".format(e))
        abort(500)
    logging.info("touchless_checkin_employee_info : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/temperature', methods=['POST'])
@auth.login_required()
def temperature_dashboard():
    """Temperature Dashboard"""
    logging.info("temperature_dashboard : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        filter_cond = request.json.get('filter_cond') 
        user = get_current_user()
        country = Country.query.filter_by (country_id = user.country_id).first()
        phone = country.country_code + user.phone
        time_zone = get_time_zone(request)

        resp = None
        if freq in  ['day', 'week', 'month']:
            resp = saferson.temperature_dashboard(phone, freq=freq, filter_cond=filter_cond, time_zone=time_zone)
        else:
            resp = saferson.temperature_dashboard(phone, start_date_str=start_date, end_date_str=end_date, filter_cond=filter_cond, time_zone=time_zone)
        if resp and resp['temperature_table']:
            for emp in resp['temperature_table']:
                profile_file_name = os.path.basename(emp['employee_pic_path'])
                emp['employee_pic_path'] = app.config['SERVER_PATH']+'/api/profile-image/'+profile_file_name
        resp_dict['status'] = True
        resp_dict['object'] = resp
    except Exception as e:
        logging.error("temperature_dashboard : exception : {}".format(e))
        abort(500)
    logging.info("temperature_dashboard : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/temperature-employee-info', methods=['POST'])
@auth.login_required()
def temperature_employee_info():
    """Temperature Employee Info"""
    logging.info("temperature_employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone')
        start_date = request.json.get('start_date')
        end_date = request.json.get('end_date')
        freq = request.json.get('freq')
        user = get_current_user()
        country = Country.query.filter_by (country_id = country_id).first()
        phone = country.country_code + employee_phone
        time_zone = get_time_zone(request)

        if freq in  ['day', 'week', 'month']:
            resp_dict['object'] = saferson.get_employee_temperature(phone, freq=freq, time_zone=time_zone)
        else:
            resp_dict['object'] = saferson.get_employee_temperature(phone, \
                start_date_str=start_date, end_date_str=end_date, time_zone=time_zone)
        resp_dict['status'] = True
    except Exception as e:
        logging.error("temperature_employee_info : exception : {}".format(e))
        abort(500)
    logging.info("temperature_employee_info : end")
    return jsonify(resp_dict)

# Thermal 
@datascience_blueprint.route('/api/thermal-image-upload', methods=['POST'])
def thermal_image_upload():
    """Thermal image upload"""
    logging.info("thermal_image_upload : start")
    resp_dict = {"status":False}
    try:
        country_id = request.json.get('country_id')
        phone = request.json.get('phone')
        camera_name = request.json.get('camera_name')
        thermal_temperature_data = request.json.get('thermal_temperature_data')
        thermal_image_data = request.json.get('thermal_image_data')
        normal_image_data = request.json.get('normal_image_data')

        user_id = 0
        camera_id  = 0
        user = User.query.filter_by(country_id = country_id, phone = phone).first()
        if user:
            business = get_business(user)
            countryId,admin_phone = get_admin_user(business)
            admin_user = User.query.filter_by(country_id = countryId, phone=admin_phone).first()
            user_id = admin_user.user_id
            thermal_camera_details = Thermal_Camera_Details.query.filter(
                (Thermal_Camera_Details.user_id == user_id) & (Thermal_Camera_Details.camera_name == camera_name)).first()
            if thermal_camera_details:
                camera_id = thermal_camera_details.camera_id

        if not user_id or not camera_id:
            logging.info('Invalid Phone or Camera name')
            return jsonify(resp_dict)

        thermal_img_name = ''
        normal_img_name = ''
        temperature_img_name = ''
        if thermal_image_data and normal_image_data and thermal_temperature_data:
            dt = str(datetime.datetime.now().strftime("%d%m%Y_%H%M%S"))
            thermal_img_name = '{}_{}_TI.jpg'.format(str(camera_id),str(dt))
            normal_img_name = '{}_{}_NI.jpg'.format(str(camera_id),str(dt))
            temperature_img_name = '{}_{}_TD.jpg'.format(str(camera_id),str(dt))

            thermal_image_data = thermal_image_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], thermal_img_name), 'wb') as f:
                f.write(base64.b64decode(thermal_image_data))

            normal_image_data = normal_image_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], normal_img_name), 'wb') as f:
                f.write(base64.b64decode(normal_image_data))

            thermal_temperature_data = thermal_temperature_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], temperature_img_name), 'wb') as f:
                f.write(base64.b64decode(thermal_temperature_data))

            thermal_camera_images = Thermal_Camera_Images(camera_id, thermal_img_name, normal_img_name, temperature_img_name)
            db.session.add(thermal_camera_images)
            db.session.commit()
            logging.info('Thermal Image Saved')  
            resp_dict['status'] = True
        else:
            logging.info('Input file not found')
    except Exception as e:
        logging.error("thermal_image_upload : exception : {}".format(e))
        abort(500)
    logging.info("thermal_image_upload : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/thermal-image-upload1', methods=['POST'])
@auth.login_required()
def thermal_image_upload1():
    """Thermal image upload"""
    logging.info("thermal_image_upload1 : start")
    resp_dict = {"status":False}
    try:
        thermal_temperature_data = request.json.get('thermal_temperature_data')
        thermal_image_data = request.json.get('thermal_image_data')
        normal_image_data = request.json.get('normal_image_data')
        camera_name = 'cone'
        
        user_id = 0
        camera_id  = 0
        user = get_current_user()
        if user:
            business = get_business(user)
            country_id,admin_phone = get_admin_user(business)
            admin_user = User.query.filter_by(country_id=country_id,phone=admin_phone).first()
            user_id = admin_user.user_id
            thermal_camera_details = Thermal_Camera_Details.query.filter(
                (Thermal_Camera_Details.user_id == user_id) & (Thermal_Camera_Details.camera_name == camera_name)).first()
            if thermal_camera_details:
                camera_id = thermal_camera_details.camera_id
            else:
                thermal_camera_details = Thermal_Camera_Details(camera_name, user_id)
                db.session.add(thermal_camera_details)
                db.session.commit()
                camera_id = thermal_camera_details.camera_id

        if not user_id or not camera_id:
            logging.info('Invalid Phone or Camera name')
            return jsonify(resp_dict)

        thermal_img_name = ''
        normal_img_name = ''
        temperature_img_name = ''
        if thermal_image_data and normal_image_data and thermal_temperature_data:
            dt = str(datetime.datetime.now().strftime("%d%m%Y_%H%M%S%f"))
            thermal_img_name = '{}_{}_TI.jpg'.format(str(camera_id),str(dt))
            normal_img_name = '{}_{}_NI.jpg'.format(str(camera_id),str(dt))
            temperature_img_name = '{}_{}_TD.jpg'.format(str(camera_id),str(dt))

            thermal_image_data = thermal_image_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], thermal_img_name), 'wb') as f:
                f.write(base64.b64decode(thermal_image_data))

            normal_image_data = normal_image_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], normal_img_name), 'wb') as f:
                f.write(base64.b64decode(normal_image_data))

            thermal_temperature_data = thermal_temperature_data.split(',')[1]
            with open(os.path.join(app.config['THERMAL_IMAGES'], temperature_img_name), 'wb') as f:
                f.write(base64.b64decode(thermal_temperature_data))

            thermal_camera_images = Thermal_Camera_Images(camera_id, thermal_img_name, normal_img_name, temperature_img_name)
            db.session.add(thermal_camera_images)
            db.session.commit()
            logging.info('Thermal Image Saved')  
            resp_dict['status'] = True
        else:
            logging.info('Input file not found')
    except Exception as e:
        logging.error("thermal_image_upload1 : exception : {}".format(e))
        abort(500)
    logging.info("thermal_image_upload1 : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/add-thermal-camera-details', methods=['POST'])
@auth.login_required()
def add_thermal_camera_details():
    """Add thermal camera details"""
    logging.info("add_thermal_camera_details : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        thermal_camera_name = request.json.get('thermal_camera_name')

        if Thermal_Camera_Details.query.filter(Thermal_Camera_Details.camera_name == thermal_camera_name).first():
            resp_dict['msg'] = 'Camera name is already added, please try other name'
            return jsonify(resp_dict)
        
        user = get_current_user()
        thermal_camera_details = Thermal_Camera_Details(thermal_camera_name, user.user_id)
        db.session.add(thermal_camera_details)
        db.session.commit()
        resp_dict['status'] = True
        resp_dict['msg'] = "Added Successfully"
    except Exception as e:
        logging.error("add_thermal_camera_details : exception : {}".format(e))
        abort(500)
    logging.info("add_thermal_camera_details : end")
    return jsonify(resp_dict)

@datascience_blueprint.route('/api/touchless-employee-checkin')
@auth.login_required()
def touchless_employee_checkin():
    """Touchless Employee Checkin"""
    logging.info("touchless_employee_checkin : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            country_id,admin_phone = get_admin_user(business)
            country = Country.query.filter_by (country_id = country_id).first()
            resp = saferson.employee_checkin_status(country.country_code+admin_phone)
            if resp and resp.get('employee_pic_path'):
                profile_file_name = os.path.basename(resp.get('employee_pic_path'))
                resp['employee_pic_path'] = app.config['SERVER_PATH']+'/api/profile-image/'+profile_file_name
                resp_dict['status'] = True
                resp_dict['object'] = resp
    except Exception as e:
        logging.error("touchless_employee_checkin : exception : {}".format(e))
        abort(500)
    logging.info("touchless_employee_checkin : end")
    return jsonify(resp_dict)

def get_time_zone(request):
    ip = ''
    time_zone = 'UTC'
    try:
        if not request.environ.get('HTTP_X_FORWARDED_FOR'):
            ip = request.environ['REMOTE_ADDR']
        else:
            ip = request.environ['HTTP_X_FORWARDED_FOR']
        
        if ip.startswith('127.0.0') or ip == 'localhost':
            ip = ''
        logging.info('IP Address - {}'.format(ip))

        time_zone = saferson.get_timezone(ip) if ip else 'UTC'
        logging.info('Time Zone - {}'.format(time_zone))
    except Exception as e:
        logging.error("get_ip_address : exception : {}".format(e))
    return time_zone
