import os, json, datetime, base64, qrcode, cv2
from views.user import country_list
from io import BytesIO
import psycopg2

from flask import Blueprint, abort, jsonify, send_from_directory, request
from werkzeug.utils import secure_filename

from app import app, auth, db, logging, db_url
from models import Role, User, User_Role_Map, Business, Country, get_current_user, get_business,User_Device_Info,sms_insert
from utils import get_random_string, forgot_password_mail, allowed_file
import constants

import saferson

# Employee API Services

employee_blueprint = Blueprint('employee', __name__)

@employee_blueprint.route('/api/terms-conditions-agreement', methods=['POST'])
@auth.login_required()
def terms_conditions_agreement():
    """Terms & Conditions Agreement accepting status update"""
    logging.info("terms_conditions_agreement : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            user.terms_conditions_agreement = constants.STATUS['YES']
            user.updated_date = datetime.datetime.now()
            user.updated_by = user.user_id
            db.session.commit()
            resp_dict['status'] = True
            resp_dict['msg'] = 'Terms & Conditions accept status updated'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("terms_conditions_agreement : exception : {}".format(e))
        abort(500)
    logging.info("terms_conditions_agreement : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/add-employee', methods=['POST'])
@auth.login_required()
def add_employee():
    """Add Employee"""
    logging.info("add_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        phone_list = request.json.get('phone_list')
        phone_obj_list = []
        for phone in phone_list:
            user = User.query.filter_by(country_id = phone['country_id'],phone=phone['phone']).first()
            if user:
                country = Country.query.filter_by(country_id=user.country_id).first()
                phone_obj = country.country_code + user.phone
                resp_dict['msg'] = '+'+phone_obj+' number is already added, please remove it from phone list'
                return jsonify(resp_dict)

        user = get_current_user()
        if user:
            business = get_business(user)
            role_name = str(business.business_id)+'_EMPLOYEE'
            role = Role.query.filter(Role.role_name == role_name).first()
            if not role:
                # Save Role
                role_desc = 'EMPLOYEE'
                role = Role(role_name, role_desc, business.business_id)
                db.session.add(role)
                db.session.commit()

            for phone in phone_list:
                # Save User
                new_password = get_random_string()
                emp_user = User('','', '',phone['country_id'], phone['phone'])
                emp_user.hash_password(new_password)
                emp_user.terms_conditions_agreement = constants.STATUS['NO']
                emp_user.created_by = user.user_id
                db.session.add(emp_user)
                db.session.commit()

                country = Country.query.filter_by(country_id=emp_user.country_id).first()
                phone_obj_1 = country.country_code + emp_user.phone
                phone_obj_list.append(phone_obj_1)
                logging.debug(phone_obj_list)

                # User & Role Mapping
                user_role_map = User_Role_Map(emp_user.user_id, role.role_id)
                db.session.add(user_role_map)
                db.session.commit()
    
                # Send mail with new password
                msg = "Your new password is {}".format(new_password)
                sms_insert(emp_user.country_id,emp_user.phone, msg)

            business.active_users = (business.active_users+len(phone_obj_list))
            business.updated_date = datetime.datetime.now()
            business.updated_by = user.user_id
            db.session.commit()

            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone

            saferson.add_employee_email(phone, phone_obj_list)
            
            resp_dict['status'] = True
            resp_dict['msg'] = "Added Successfully"
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("add_employee : exception : {}".format(e))
        abort(500)
    logging.info("add_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/employee-list', methods=['GET'])
@auth.login_required()
def employee_list():
    """Employee List"""
    logging.info("employee_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        emp_list = []
        user = get_current_user()
        if user:
            country = Country.query.filter_by (country_id =user.country_id).first()
            phone = country.country_code + user.phone
            resp_dict['status'] = True
            resp_dict['object'] = saferson.get_employee_info_list(phone)
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("employee_list : exception : {}".format(e))
        abort(500)
    logging.info("employee_list : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/employee-count', methods=['GET'])
@auth.login_required()
def employee_count():
    """Employee Count"""
    logging.info("employee_count : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user_id_list = []
        user = get_current_user()
        if user:
            connection = psycopg2.connect(db_url)
            cursor = connection.cursor()
            country = Country.query.filter_by(country_id=user.country_id).first()
            phone = country.country_code + user.phone
            cursor.execute("SELECT employee_email  FROM employee_info WHERE user_email = %s ", (phone,))
            data = cursor.fetchall()
            employee_count = len(data)
            cursor.close()
            connection.close()
            
            resp_dict['status'] = True
            resp_dict['object'] = employee_count
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("employee_count : exception : {}".format(e))
        abort(500)
    logging.info("employee_count : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/employee-info', methods=['POST'])
@auth.login_required()
def employee_info():
    """Fetching Employee Info"""
    logging.info("employee_info : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone') 
        user = User.query.filter_by(country_id = country_id, phone = employee_phone).first()
        if user:
            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone
            resp = saferson.get_employee_info(phone)
            if resp:
                if resp['pic_path']:
                    pic_path = os.path.basename(resp['pic_path'])
                    resp['pic_path'] = app.config['SERVER_PATH']+'/api/profile-image/'+pic_path  
                else:
                    resp['pic_path'] = ''

                if not resp['name']:
                    resp['name'] = ''

                if not resp['id']:
                    resp['id'] = ''
                     
                resp_dict['status'] = True
                resp_dict['object'] = resp
        else:
            resp_dict['msg'] = 'Employee phone not found'
    except Exception as e:
        logging.error("employee_info : exception : {}".format(e))
        abort(500)
    logging.info("employee_info : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/update-employee', methods=['POST'])
@auth.login_required()
def update_employee():
    """Employee Info Update"""
    logging.info("update_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone')
        employee_name = request.json.get('employee_name')
        employee_id = request.json.get('employee_id')
        checkin_mode = request.json.get('checkin_mode')
        profile_image_data = request.json.get('profile_image_data')
        
        user = User.query.filter_by(country_id = country_id, phone = employee_phone).first()
        if user:
            country = Country.query.filter_by (country_id = user.country_id).first()
            phone = country.country_code + user.phone
            if (not checkin_mode) or checkin_mode != 'QR':
                profile_image_file_name = ''
                if profile_image_data:
                    profile_image_data = profile_image_data.split(',')[1]
                    profile_image_file_name = str(user.user_id)+'_profile.jpg'
                    profile_image_file_name_temp = str(user.user_id)+'_profile_temp.jpg'
                    with open(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name_temp), 'wb') as f:
                        f.write(base64.b64decode(profile_image_data))

                    img = cv2.imread(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name_temp))
                    string = base64.b64encode(cv2.imencode('.jpg', img)[1]).decode()
                    if not saferson.validate_image(string):
                        os.remove(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name_temp))
                        resp_dict['msg'] = 'Please upload a photo of yourself that clealy shows your face'
                        return jsonify(resp_dict)
                    
                    os.rename(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name_temp), 
                        os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name)) 
                    logging.info('Profile Image Saved {}'.format(profile_image_file_name)) 
                    profile_image_file_name = os.path.abspath(os.path.join(app.config['PROFILE_IMAGES'], profile_image_file_name))
                else:
                    resp = saferson.get_employee_info(phone)
                    profile_image_file_name = resp['pic_path']
                
                user.name = employee_name
                user.updated_date = datetime.datetime.now()
                db.session.commit()

                employee_info_dict = {
                    'id': employee_id,
                    'name': employee_name,
                    'pic_path': profile_image_file_name    
                }
                saferson.update_employee_info(phone, employee_info_dict)
            else:
                user.name = employee_name
                user.updated_date = datetime.datetime.now()
                db.session.commit()

                employee_info_dict = {
                    'id': employee_id,
                    'name': employee_name  
                }
                saferson.update_employee_info(phone, employee_info_dict, mode='QR')
            resp_dict['status'] = True
            resp_dict['msg'] = "Saved Successfully"
        else:
            resp_dict['msg'] = 'Employee phone not found'
    except Exception as e:
        logging.error("update_employee : exception : {}".format(e))
        abort(500)
    logging.info("update_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/delete-employee', methods=['POST'])
@auth.login_required()
def delete_employee():
    """Delete Employee"""
    logging.info("delete_employee : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        country_id = request.json.get('country_id')
        employee_phone = request.json.get('employee_phone')
        emp = User.query.filter_by(country_id = country_id, phone = employee_phone).first()
        if emp :
            country = Country.query.filter_by (country_id = emp.country_id).first()
            phone = country.country_code + emp.phone
            User_Device_Info.query.filter(User_Device_Info.user_id == emp.user_id).delete()
            User_Role_Map.query.filter(User_Role_Map.user_id == emp.user_id).delete()
            User.query.filter(User.user_id == emp.user_id).delete()
            db.session.commit()
            saferson.delete_employee(phone)
            resp_dict['status'] = True
            resp_dict['msg'] = "Deleted Successfully"
        else:
            resp_dict['msg'] = "Employee data not found!"
    except Exception as e:
        logging.error("delete_employee : exception : {}".format(e))
        abort(500)
    logging.info("delete_employee : end")
    return jsonify(resp_dict)

@employee_blueprint.route('/api/profile-image/<string:filename>', methods=['GET'])
def profile_image(filename):
    return send_from_directory(app.config['PROFILE_IMAGES'],filename)

# QR Code Services
@employee_blueprint.route('/api/generate-qr-code', methods=['GET'])
@auth.login_required()
def generate_qr_code():
    """Generate QR Code """
    logging.info("generate_qr_code : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            dt = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            input_data = "{}_{}".format(user.phone, dt)
            #Creating an instance of qrcode
            qr = qrcode.QRCode(version=1,box_size=10,border=5)
            qr.add_data(input_data)
            qr.make(fit=True)
            img = qr.make_image(fill='black', back_color='white')
            
            buffer = BytesIO()
            img.save(buffer,format="JPEG")               
            qr_image = buffer.getvalue() 
            base64.b64encode(qr_image)
            resp_dict['status'] = True
            resp_dict['object'] = 'data:image/jpeg;base64,'+ str(base64.b64encode(qr_image).decode())
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("generate_qr_code : exception : {}".format(e))
        abort(500)
    logging.info("generate_qr_code : end")
    return jsonify(resp_dict)
