import numpy as np
import time 
import sys
import cv2
import os

from face_recognition.recog_inference import FaceRecogInference
from face_detection.run_inference import RetinaFaceInference

from thermal_functions import read_thermal_images, delete_thermal_images, check_thermal_camera_live_status

import psycopg2.extras

from datetime import datetime, timezone
from app import db_url

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()

# what if database connection fails
# change implementation to dynamic batch processing using queue
class Facerson:
    def __init__(self):
        self.stopped = False

        self.face_recognizer_dict = dict()
        self.prev_time = time.time()
        self.wait_time = 3600 * 24

        self.face_detector = RetinaFaceInference()

        self.connection = psycopg2.connect(db_url)
 
    def run(self):
        while True:
            if (time.time() - self.prev_time) > self.wait_time:
                self.reset_face_recognizer_dict()

            curr_item = read_thermal_images()

            if self.stopped:
                break

            #TODO ask kathiravan what is your result when there are no images
            if not curr_item:
                continue
            
            base_path = '/home/kathiravan/safeo/thermal-images/'
                        
            user_email = curr_item['email']
            image_id = curr_item['image_id']
            curr_time = datetime.now(timezone.utc)

            # Read images
            normal_image_name = curr_item['normal_image_file_name']
            normal_path = os.path.join(base_path, normal_image_name)

            thermal_image_name = curr_item['thermal_image_file_name']
            thermal_path = os.path.join(base_path, thermal_image_name)

            temperature_image_name = curr_item['temperature_image_file_name']
            temperature_path = os.path.join(base_path, temperature_image_name)

            normal_img = cv2.imread(normal_path)
            thermal_img = cv2.imread(thermal_path)#(640,480,3)
            temperature_img = cv2.imread(temperature_path)#(640,480,3)
            
            # Apply transofrmation Red + Greaan*Blue on a BGR temperature image
            temperature_img_gray = temperature_img[...,2] + (temperature_img[...,1] * temperature_img[...,0])

            # Detect faces in thermal image
            # pass image through detector
            # bboxes, _ = self.face_detector.detect_faces(thermal_img)

            # average_temperatures = []
            # for curr_bbox in bboxes:
            #     curr_box_int = list(map(int, curr_bbox))
            #     avg_temp = np.mean(temperature_img_gray[curr_box_int[1] : curr_box_int[3], curr_box_int[0]: curr_box_int[2]])
            #     avg_temp = round(avg_temp, 1)
            #     if avg_temp:
            #         average_temperatures.append(avg_temp)
            _, landmarks = self.face_detector.detect_faces(thermal_img)

            average_temperatures = []

            for curr_landmark in landmarks:
                left_x  = int(curr_landmark[0])
                left_y  = int(curr_landmark[5])
                right_x = int(curr_landmark[1])
                right_y = int(curr_landmark[6])
                
                width = (left_x + right_x)//2
                height = width//2
                
                #heuristic 
                x1 = left_x  - width//20
                y1 = left_y  - height//20
                x2 = right_x + width//20
                y2 = right_y + height//20

                region   = temperature_img_gray[x1:x2,y1:y2]
                avg_temp = np.mean(region)
                avg_temp = round(avg_temp, 1)
                if avg_temp:
                    average_temperatures.append(avg_temp)

            individual_names = self.analyse(normal_img, user_email)

            delete_thermal_images(image_id)

            for i, name in enumerate(individual_names):
                if i >= len(average_temperatures):
                    continue
                if name != "unknown":
                    cursor = self.connection.cursor()
                    cursor.execute("SELECT time, attendance_status \
                                    FROM touchless_attendance \
                                    WHERE employee_email = %s \
                                    ORDER BY time \
                                    DESC LIMIT 1", (name, ) )
                    staus_data = cursor.fetchall()

                    if len(staus_data) > 0:
                        last_time, prev_status = staus_data[0][0], staus_data[0][1]
                        time_elapsed = (datetime.now(timezone.utc) - last_time).total_seconds()
                    else:
                        time_elapsed = sys.maxsize
                        prev_status = False

                    if time_elapsed > 60:
                        curr_temp = average_temperatures[i]
                        temp_status = 'high' if curr_temp > 100 else 'normal'

                        curr_status = not prev_status
                        if curr_status == True:
                            num_working_secs = 0
                        else:
                            num_working_secs = time_elapsed

                        cursor.execute("INSERT INTO touchless_attendance (time, employee_email, attendance_status, num_working_secs) \
                                        VALUES (%s, %s, %s, %s)", (curr_time, name, curr_status, num_working_secs))
                        self.connection.commit()
                        
                        cursor.execute("INSERT INTO employee_temperature (time, employee_email, temperature, temperature_status) \
                                        VALUES (%s, %s, %s, %s)", (curr_time, name, curr_temp , temp_status))
                        self.connection.commit()
                         
                    cursor.close()

    def analyse(self, img, user_email):
        if user_email not in self.face_recognizer_dict:
            cursor = self.connection.cursor()
            cursor.execute("SELECT facebank_path FROM touchless_users \
                WHERE user_email = %s", (user_email, ))
            facebank_path = cursor.fetchall()
            cursor.close()

            if len(facebank_path) <= 0:
                return []
            else:
                facebank_path = facebank_path[0][0]
                self.face_recognizer_dict[user_email] = FaceRecogInference(face_bank_path=facebank_path)
        names, scores, bboxes = self.face_recognizer_dict[user_email].recognize_individuals(img)
        
        return names


    def reset_face_recognizer_dict(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT * FROM touchless_users")
        user_data = list(cursor.fetchall())
        cursor.close()

        self.face_recognizer_dict = dict()

        for user_email, facebank_path in user_data:
            self.face_recognizer_dict[user_email] = FaceRecogInference(face_bank_path=facebank_path)

        self.prev_time = time.time()

    def stop(self):
        self.stopped = True
        self.connection.close()
