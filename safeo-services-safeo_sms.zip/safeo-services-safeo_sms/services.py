from app import app
from flask import render_template, request, jsonify
from views import employee, user, admin, datascience

# Safeo Flask App Main 

app.register_blueprint(employee.employee_blueprint)
app.register_blueprint(user.user_blueprint)
app.register_blueprint(admin.admin_blueprint)
app.register_blueprint(datascience.datascience_blueprint)

@app.route('/', methods=['GET'])
@app.route('/api', methods=['GET'])
def home():
   """ API Home """
   return 'Safeo Application API Services...'

@app.route('/timezone', methods=['GET'])
def timezone():
   """ Time zone """
   if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
      return jsonify({'REMOTE_ADDR': request.environ['REMOTE_ADDR']}), 200
   else:
      return jsonify({'HTTP_X_FORWARDED_FOR': request.environ['HTTP_X_FORWARDED_FOR']}), 200

@app.route('/iFrameCommunicator')
def iFrameCommunicator():
   return render_template('iFrameCommunicator.html')

@app.route('/manageCardsInit')
def manageCardsInit():
   return render_template('manageCardsInit.html')

@app.route('/manageCardsSuccess')
def manageCardsSuccess():
   return render_template('manageCardsSuccess.html')

if __name__ == "__main__":
    app.run(debug=False, host='0.0.0.0',port=5001)
