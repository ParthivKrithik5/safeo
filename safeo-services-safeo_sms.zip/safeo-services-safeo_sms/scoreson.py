import numpy as np
import psycopg2
from multiprocessing import Process, Pool
import queue

import psycopg2.extras

# call it in any place of your program
# before working with UUID objects in PostgreSQL
psycopg2.extras.register_uuid()

from heat_map.heat_map_inference import HeatMap
from app import db_url

# what if database connection fails
# change implementation to dynamic batch processing using queue
class Scoreson:
    def __init__(self, in_data_queue):
        self.in_data_queue = in_data_queue
        self.stopped = False
        self.m_weights = 6.3
        self.sd_weights = 6.3
        self.h_weights = 1.5
        self.m_sd_weights = 7
        self.m_sd_H_weights = 8.5
        self.prev_min = 1
    
    def run(self):
        connection = psycopg2.connect(db_url)
        cursor = connection.cursor()

        while True:
            curr_item = self.in_data_queue.get()

            if curr_item == 'KILL WORKER':
                break

            # overall_risk_score = (curr_item['mask_risk_score'] + curr_item['sd_risk_score'] + curr_item['heatmap_risk_score']) / 3
            #Take the weighted average. the average is based on fines for violation that could occur if employee falls sick
            mask_risk_score = max(0,curr_item['mask_risk_score'])
            prod = mask_risk_score*curr_item['sd_risk_score']*curr_item['heatmap_risk_score']
            overall_risk_score = (self.m_weights*mask_risk_score + self.sd_weights *curr_item['sd_risk_score'] + self.h_weights * curr_item['heatmap_risk_score'] + self.m_sd_weights*mask_risk_score*curr_item['sd_risk_score'] + self.m_sd_H_weights *prod ) \
                / (self.m_weights + self.sd_weights * self.h_weights + self.m_sd_weights + self.m_sd_H_weights)


            if overall_risk_score < 0.5:## Second fall below 50 reduces the score by 1/4
                if overall_risk_score < self.prev_min:
                    overall_risk_score+=(0.25*overall_risk_score)
                    self.prev_min = overall_risk_score

            print(f"OVERALL risk score: {overall_risk_score}")

            cursor.execute("INSERT INTO score (time, camera_id, mask_risk_score, sd_risk_score, heatmap_risk_score, overall_risk_score) \
                                VALUES (%s, %s, %s, %s, %s, %s)", (curr_item['time'], curr_item['camera_id'], 
                                curr_item['mask_risk_score'], curr_item['sd_risk_score'], curr_item['heatmap_risk_score'], overall_risk_score))

            connection.commit()
        
        cursor.close()
        connection.close()
    
    def stop(self):
        self.in_data_queue.put('KILL WORKER')

    
