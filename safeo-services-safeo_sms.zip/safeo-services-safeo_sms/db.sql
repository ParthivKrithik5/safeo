create database safeo;

CREATE TABLE tb_functions (
    function_id SERIAL NOT NULL, 
    function_name VARCHAR(200) NOT NULL, 
    function_desc VARCHAR(200) NULL, 
    parent_function_id INTEGER DEFAULT 0, 
    function_url VARCHAR(200) NULL, 
    status CHAR(1) DEFAULT 'A', 
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL, 
    PRIMARY KEY (function_id)
);

insert into tb_function_master values(1,'Safeo','Safeo Covid 19 Safety Solution',0,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(2,'Mask Compliance','Mask Compliance',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(3,'Social Distancing','Social Distancing',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(4,'Sanitization','Sanitization',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(5,'Temperature','Temperature',1,'','A',0,NOW(),0,NOW(),'','U');
insert into tb_function_master values(6,'Touch Less','Touch Less',1,'','A',0,NOW(),0,NOW(),'','U');

create table tb_businesses(
    business_id SERIAL NOT NULL, 
    business_name VARCHAR(200) NOT NULL,
    industry VARCHAR(120) NOT NULL,
    address VARCHAR(600) NOT NULL,
    selected_plan VARCHAR(60) NULL,
    selected_plan_span VARCHAR(20) NULL,
    active_users INTEGER DEFAULT 0,
    touchless_checkin_option VARCHAR(60) DEFAULT 'THERMAL',
    plan_exp_date TIMESTAMP NULL,  
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL, 
    PRIMARY KEY (business_id)
);

create table tb_payment_cards(
    card_id SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    customer_profile_id VARCHAR(60) NULL,
    customer_payment_profile_id VARCHAR(60) NULL,
    status CHAR(1) DEFAULT 'A',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL,
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY (card_id),
    CONSTRAINT fk_payment_card_business FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id)
);

create table tb_invoices(
    invoice_no SERIAL NOT NULL,
    business_id INTEGER NOT NULL,
    card_id INTEGER NOT NULL,
    invoice_sub_total_amount NUMERIC NOT NULL,
    invoice_tax NUMERIC NOT NULL,
    invoice_total_amount NUMERIC NOT NULL,
    invoice_date TIMESTAMP NOT NULL,
    invoice_paid_amount NUMERIC NOT NULL, 
    transcation_id VARCHAR(20) NULL,
    remarks VARCHAR(200) NULL,
    status CHAR(1) DEFAULT 'E',
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL,
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY (invoice_no),
    CONSTRAINT fk_invoice_business FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id),
    CONSTRAINT fk_invoice_card FOREIGN KEY(card_id)  REFERENCES tb_payment_cards(card_id)
);

CREATE TABLE tb_roles (
    role_id SERIAL NOT NULL, 
    role_name VARCHAR(200) NOT NULL, 
    role_desc VARCHAR(1000) NULL,
    business_id INTEGER NOT NULL,
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP DEFAULT NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP DEFAULT NULL, 
    PRIMARY KEY (role_id),
    CONSTRAINT fk_role_business_map FOREIGN KEY(business_id)  REFERENCES tb_businesses(business_id)
);

CREATE TABLE tb_role_function_map (
    role_id INTEGER NOT NULL, 
    function_id INTEGER NOT NULL, 
    CONSTRAINT fk_rf_role_map FOREIGN KEY(role_id)  REFERENCES tb_roles(role_id),
    CONSTRAINT fk_rf_func_map FOREIGN KEY(function_id)  REFERENCES tb_functions(function_id)
);

create table tb_registrations(
   reg_id SERIAL NOT NULL,
   name VARCHAR(120) NOT NULL,
   email VARCHAR(160) NOT NULL,
   password VARCHAR(120) NOT NULL,
   phone VARCHAR(20) NOT NULL,
   business_name VARCHAR(120) NOT NULL,
   industry VARCHAR(120) NOT NULL,
   address VARCHAR(600) NOT NULL,
   status char(1) DEFAULT 'E',
   email_verified_on TIMESTAMP NULL,
   email_verification_token VARCHAR(160) NULL,
   created_date TIMESTAMP NULL,
   updated_date TIMESTAMP NULL,
   PRIMARY KEY (reg_id)
);

CREATE TABLE tb_users (
    user_id SERIAL NOT NULL,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL,
    password VARCHAR(120) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    terms_conditions_agreement CHAR(1) DEFAULT 'Y',
    default_password_changed CHAR(1) DEFAULT 'N',
    status CHAR(1) DEFAULT 'A',  
    created_by INTEGER DEFAULT 0, 
    created_date TIMESTAMP NULL, 
    updated_by INTEGER DEFAULT 0, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(user_id)
);

create table tb_enquires (
    enquiry_id SERIAL NOT NULL,
    name VARCHAR(120) NOT NULL,
    company VARCHAR(160) NOT NULL,
    email VARCHAR(160) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    country VARCHAR(60) NOT NULL,
    message varchar(600) NULL,
    enquiry_type varchar(20) DEFAULT 'DEMO',
    status CHAR(1) DEFAULT 'A',  
    created_date TIMESTAMP NULL, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(enquiry_id)
);

CREATE TABLE tb_user_role_map (
    user_id INTEGER NOT NULL, 
    role_id INTEGER NOT NULL, 
    CONSTRAINT fk_ur_user_map FOREIGN KEY(user_id)  REFERENCES tb_users(user_id),
    CONSTRAINT fk_ur_role_map FOREIGN KEY(role_id)  REFERENCES tb_roles(role_id)
);

-- Data Science Tables

CREATE TABLE camera_details(
        user_email TEXT NOT NULL,
        camera_id UUID NOT NULL,
        camera_name TEXT NOT NULL,
        rtsp_link TEXT NOT NULL,
        floor_name TEXT NOT NULL,
        max_occupancy INTEGER NOT NULL
);

CREATE TABLE heatmap(
        time TIMESTAMP WITH TIME ZONE NOT NULL,
        camera_id  UUID NOT NULL,
        num_people_detected INTEGER NOT NULL,
        max_occupancy INTEGER NOT NULL,
        heatmap_risk_score DOUBLE PRECISION NOT NULL
);

SELECT create_hypertable('heatmap', 'time');

CREATE TABLE mask(
        time TIMESTAMP WITH TIME ZONE NOT NULL,
        camera_id UUID NOT NULL,
        num_no_mask INTEGER NOT NULL,
        num_total_faces INTEGER NOT NULL,
        mask_risk_score DOUBLE PRECISION NOT NULL
);

SELECT create_hypertable('mask', 'time');

CREATE TABLE score(
        time TIMESTAMP WITH TIME ZONE NOT NULL,
        camera_id UUID NOT NULL,
        mask_risk_score DOUBLE PRECISION NOT NULL,
        sd_risk_score DOUBLE PRECISION NOT NULL,
        heatmap_risk_score DOUBLE PRECISION NOT NULL,
        overall_risk_score DOUBLE PRECISION NOT NULL
);

SELECT create_hypertable('score', 'time');

CREATE TABLE social_distance(
        time TIMESTAMP WITH TIME ZONE NOT NULL,
        camera_id UUID NOT NULL,
        num_people_violating INTEGER NOT NULL,
        num_total_people INTEGER NOT NULL,
        sd_risk_score DOUBLE PRECISION NOT NULL
);

SELECT create_hypertable('social_distance', 'time');

CREATE TABLE touchless_users(
	user_email TEXT NOT NULL,
	facebank_path TEXT NOT NULL
);

CREATE TABLE employee_info(
    employee_email TEXT NOT NULL,
    user_email TEXT NOT NULL,
    info_uploaded BOOLEAN NOT NULL,
    employee_name TEXT,
    employee_id TEXT,
    employee_pic_path TEXT
);

CREATE TABLE touchless_attendance(
    time  TIMESTAMP WITH TIME ZONE NOT NULL,
    employee_email TEXT NOT NULL,
    attendance_status BOOLEAN NOT NULL,
    num_working_secs DOUBLE PRECISION NOT NULL
);

SELECT create_hypertable('touchless_attendance', 'time');

-- Compliance
CREATE TABLE compliance_list(
	compliance_id SERIAL NOT NULL,
	name VARCHAR(100) NOT NULL,
	status CHAR(1) DEFAULT 'A',
	created_date TIMESTAMP NULL,
	updated_date TIMESTAMP NULL,
	primary key(compliance_id)
);

insert into compliance_list values(1,'CDC','A', now(), now());
insert into compliance_list values(2,'OSHA','A', now(), now());
insert into compliance_list values(3,'FDA','A', now(), now());
insert into compliance_list values(4,'WHO','A', now(), now());

CREATE TABLE compliance_check_list(
	check_list_id SERIAL NOT NULL,
	compliance_id INTEGER NOT NULL,
	check_list_name VARCHAR(1000) NOT NULL,
	check_list_desc VARCHAR(2000) NOT NULL,
	status CHAR(1) DEFAULT 'A',
	created_date TIMESTAMP NULL,
	updated_date TIMESTAMP NULL,
	primary key(check_list_id),
	CONSTRAINT fk_compliance_id FOREIGN KEY(compliance_id)  REFERENCES compliance_list(compliance_id)
);

insert into compliance_check_list values(1,1,'Glass shield for customer-facing job','Glass shield for customer-facing job','A', now(), now());
insert into compliance_check_list values(2,1,'Encourage online presence/sales','Encourage online presence/sales','A', now(), now());
insert into compliance_check_list values(3,1,'Hand sanitizers for employees and customers','Hand sanitizers for employees and customers','A', now(), now());
insert into compliance_check_list values(4,1,'Clean frequently touched items with EPA-registred items','Clean frequently touched items with EPA-registred items','A', now(), now());
insert into compliance_check_list values(5,1,'Minimize equipment,space sharing','Minimize equipment,space sharing','A', now(), now());
insert into compliance_check_list values(6,1,'Improve ventilation','Improve ventilation','A', now(), now());
insert into compliance_check_list values(7,1,'Keep same employees in the same shift','Keep same employees in the same shift','A', now(), now());
insert into compliance_check_list values(8,1,'Encourage sick employees to stay home','Encourage sick employees to stay home','A', now(), now());

insert into compliance_check_list values(9,2,'Encourage employees to stay home if sick','Encourage employees to stay home if sick','A', now(), now());
insert into compliance_check_list values(10,2,'Encourage hand washing sanitization','Encourage hand washing sanitization','A', now(), now());
insert into compliance_check_list values(11,2,'Use EPA sanitization solutions','Use EPA sanitization solutions','A', now(), now());
insert into compliance_check_list values(12,2,'Restrict room capacity','Restrict room capacity','A', now(), now());
insert into compliance_check_list values(13,2,'Increasing air ventilation','Increasing air ventilation','A', now(), now());
insert into compliance_check_list values(14,2,'Install glass shield when possible','Install glass shield when possible','A', now(), now());
insert into compliance_check_list values(15,2,'Maintain 6ft','Maintain 6ft','A', now(), now());
insert into compliance_check_list values(16,2,'OSHA PPE Standard, 29 CFR 1910 Subpart I (employers need to provide PPE when employees can be exposed to infectious disease)','OSHA PPE Standard, 29 CFR 1910 Subpart I (employers need to provide PPE when employees can be exposed to infectious disease)','A', now(), now());
insert into compliance_check_list values(17,2,'Employers need to provide information to OSHA if workers are infected to COVID at work','Employers need to provide information to OSHA if workers are infected to COVID at work','A', now(), now());
insert into compliance_check_list values(18,2,'Work areas visited by infected workers should be cleaned','Work areas visited by infected workers should be cleaned','A');

insert into compliance_check_list values(19,3,'FDA Test','FDA Test','A');
insert into compliance_check_list values(20,4,'WHO Test','WHO Test','A');

CREATE TABLE compliance_check_list_user(
	check_list_id INTEGER NOT NULL,
	compliance_id INTEGER NOT NULL,
	user_id INTEGER NOT NULL,
	checked_status CHAR(1) DEFAULT 'Y',
	CONSTRAINT fk_user_id FOREIGN KEY(user_id)  REFERENCES tb_users(user_id),
	CONSTRAINT fk_check_list_id FOREIGN KEY(check_list_id)  REFERENCES compliance_check_list(check_list_id),
	CONSTRAINT fk_compliance_id FOREIGN KEY(compliance_id)  REFERENCES compliance_list(compliance_id)
);

-- Thermal
create table thermal_camera_details(
    camera_id SERIAL NOT NULL,
    camera_name VARCHAR(60) NOT NULL,
    user_id INT NOT NULL,
    status CHAR(1) DEFAULT 'A',  
    created_date TIMESTAMP NULL, 
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(camera_id),
    CONSTRAINT fk_thermal_camera_map FOREIGN KEY(user_id)  REFERENCES tb_users(user_id)
);

create table thermal_camera_images(
    image_id SERIAL NOT NULL,
    camera_id INT NOT NULL,
    thermal_image_file_name VARCHAR(100) NOT NULL,
    normal_image_file_name VARCHAR(100) NOT NULL,
    temperature_image_file_name VARCHAR(100) NOT NULL,
    inserted_datetime TIMESTAMP NULL, 
    PRIMARY KEY(image_id),
    CONSTRAINT fk_thermal_camera_map FOREIGN KEY(camera_id)  REFERENCES thermal_camera_details(camera_id)
);

CREATE TABLE employee_temperature (
    time TIMESTAMPTZ NOT NULL,
    employee_email TEXT NOT NULL,
    temperature DOUBLE PRECISION NOT NULL,
    temperature_status TEXT NOT NULL
);

SELECT create_hypertable('employee_temperature', 'time');

CREATE TABLE tb_user_device_info(
	info_id SERIAL NOT NULL,
	user_id INTEGER NOT NULL,
	android_device_id VARCHAR(500) NOT NULL,
	ios_device_id VARCHAR(500) NOT NULL,
	created_date TIMESTAMP NULL,
	updated_date TIMESTAMP NULL,
	primary key(info_id),
	CONSTRAINT fk_device_user_id FOREIGN KEY(user_id)  REFERENCES tb_users(user_id)
);

CREATE TABLE tb_user_notifications(
	notification_id SERIAL NOT NULL,
	user_id INTEGER NOT NULL,
	message VARCHAR(2000) NOT NULL,
	status CHAR(1) DEFAULT 'A',  
	created_date TIMESTAMP NULL,
	updated_date TIMESTAMP NULL,
	primary key(notification_id),
	CONSTRAINT fk_notification_user_id FOREIGN KEY(user_id)  REFERENCES tb_users(user_id)
);

CREATE TABLE tb_plan_details (
    plan_id SERIAL NOT NULL, 
    plan_name VARCHAR(200) NOT NULL, 
    plan_desc VARCHAR(1000) NULL,
    plan_price NUMERIC NOT NULL,
    total_span VARCHAR(20) NOT NULL, 
    created_date TIMESTAMP DEFAULT NULL, 
    updated_date TIMESTAMP DEFAULT NULL, 
    primary key(plan_id)
); 

insert into tb_plan_details values(1,'PRO_MONTHLY','Pro plan with monthly payment',79.99,'MONTHLY', now(), now());

insert into tb_plan_details values(2,'PRO_YEALY','Pro plan with yearly payment',959.88,'YEARLY', now(), now());

ALTER TABLE tb_user_notifications ADD COLUMN read_status CHAR(1) DEFAULT 'U';

CREATE TABLE tb_country (
    country_id SERIAL NOT NULL,
    long_name VARCHAR(100) NOT NULL,
    short_name VARCHAR(2) NOT NULL,
    country_code VARCHAR(4) NOT NULL,
    status CHAR(1) DEFAULT 'A', 
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(country_id)
);

INSERT INTO tb_country(long_name,short_name,country_code,created_date) VALUES ('UNITED_STATES_OF_AMERICA','US','01', now());
INSERT INTO tb_country(long_name,short_name,country_code,created_date) VALUES ('INDIA','IN','91', now());

CREATE TABLE tb_sms_txn(
    seq_id SERIAL NOT NULL,
    country_id INTEGER NOT NULL,
    phone VARCHAR(16) NOT NULL,
    message VARCHAR(200) NOT NULL,
    status CHAR(1) DEFAULT 'E',
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(seq_id),
    CONSTRAINT fk_tb_sms_txn FOREIGN KEY(country_id)  REFERENCES tb_country(country_id)
    
);

CREATE TABLE tb_otp(
    otp_id SERIAL NOT NULL,
    country_id INTEGER NOT NULL,
    phone VARCHAR(16) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    status CHAR(1) DEFAULT 'E', 
    exp_date TIMESTAMP NOT NULL,
    created_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP NULL,
    PRIMARY KEY(otp_id),
    CONSTRAINT fk_tb_otp FOREIGN KEY(country_id)  REFERENCES tb_country(country_id)  
);

--ALTER TABLE tb_registrations DROP COLUMN email_verification_token;
ALTER TABLE tb_registrations RENAME email_verified_on TO sms_verified_on;
ALTER TABLE tb_registrations ADD COLUMN country_id INTEGER , ADD FOREIGN KEY (country_id)  REFERENCES tb_country(country_id);

ALTER TABLE tb_users ADD COLUMN country_id INTEGER, ADD FOREIGN KEY (country_id)  REFERENCES tb_country(country_id);

ALTER TABLE tb_enquires ADD COLUMN country_id INTEGER, ADD FOREIGN KEY (country_id)  REFERENCES tb_country(country_id);
