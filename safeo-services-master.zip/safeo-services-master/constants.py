STATUS = {
    'ACTIVE':'A',
    'DE-ACTIVE':'D',
    'ENTRY':'E',
    'VERIFIED':'V',
    'YES':'Y',
    'NO':'N',
    'DEMO':'DEMO',
    'ISSUE':'ISSUE',
    'ERROR':'E',
    'COMPLETED':'C',
    'SENT':'S'
}

#Authorize.net Production Mode
PRODUCTION = False

# Authorize.net keys
# Dev
API_LOGIN_KEY_DEV = '4UZ3Kq2zkv'
TRANSACTION_KEY_DEV = '6a6Q5W6f8MDaf2qJ'

# PROD
API_LOGIN_KEY_PRD = '8AvZ47x8Tq'
TRANSACTION_KEY_PRD = '4KPX2m98334jHu3e'

manage_cards_success_url = 'https://www.chups.co/jasperserver/manageCardsSuccess.html'
manage_cards_init_url = 'https://www.chups.co/jasperserver/manageCardsInit.html'
auth_manage_cards_url_dev = 'https://test.authorize.net/customer/manage'
auth_manage_cards_url_prd =  'https://accept.authorize.net/customer/manage'

# Plans
FREEMIUM = 'Freemium'
PRO = 'Pro'
ENTERPRISE = 'Enterprise'

# No of Users
FREEMIUM_NO_OF_USERS = 4
PRO_NO_OF_USERS = 75
MONTHLY = 'MONTHLY'
YEARLY = 'YEARLY'

# Price
FREEMIUM_PRICE = 0
FREEMIUM_MAX_ALLOWD_CAMERAS = 5
PRO_MONTHLY_PRICE = 79.99
PRO_YEALY_PRICE = 959.88
PRO_MAX_ALLOWD_CAMERAS = 15

# Default Compliance List
DEFAULT_COMPLIANCE_LIST = [1,2]

# Check In Options
QR = 'QR'
THERMAL = 'THERMAL'

READ_STATUS = {'READ':'R','UNREAD':'U'}
