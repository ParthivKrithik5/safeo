import os, json, datetime
from dateutil.relativedelta import relativedelta

from flask import Blueprint, abort, jsonify, request, send_from_directory
from fpdf import FPDF

from app import  app, auth, logging, db
from utils import get_plan_details, get_random_string, create_customer_profile, create_an_accept_payment_transaction, \
    get_customer_payment_profile, get_accept_customer_profile_page, get_customer_profile, forgot_password_mail
from models import User, Business, PaymentCard, Invoice, User_Role_Map, Role, get_current_user, get_business, get_invoices, get_payment_card, \
    get_invoice_by_no, Compliance_Check_List, Compliance_List, Compliance_Check_List_User, get_safety_regulations_score, \
    get_admin_user, add_notification_message, get_pro_plan_price
import constants

import saferson

# Admin API Services

admin_blueprint = Blueprint('admin', __name__)

@admin_blueprint.route('/api/purchase-plans', methods=['GET'])
@auth.login_required()
def purchase_plans():
    """Purchase Plans"""
    logging.info("purchase_plans : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        resp_dict['status'] = True
        resp_dict['object'] = get_plan_details()
    except Exception as e:
        logging.error("purchase_plans : exception : {}".format(e))
        abort(500)
    logging.info("purchase_plans : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/pro-plan-details', methods=['GET'])
@auth.login_required()
def pro_plan_details():
    """Pro Plan Details"""
    logging.info("pro_plan_details : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        resp_dict['status'] = True
        resp_dict['object'] = {
            'max_allowed_cameras' : constants.PRO_MAX_ALLOWD_CAMERAS,
            'plan_monthly_price' : get_pro_price('PRO_MONTHLY'),
            'plan_yealy_price' : get_pro_price('PRO_YEALY')
        }
    except Exception as e:
        logging.error("pro_plan_details : exception : {}".format(e))
        abort(500)
    logging.info("pro_plan_details : end")
    return jsonify(resp_dict)
   
@admin_blueprint.route('/api/payment-keys', methods=['GET'])
@auth.login_required()
def payment_keys():
    """Payment Authentication Keys"""
    logging.info("payment_keys : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        resp_dict['status'] = True
        resp_dict['object'] = {
            'api_login_key' :  constants.API_LOGIN_KEY,
            'transaction_key' : constants.CLIENT_KEY
        }
    except Exception as e:
        logging.error("payment_keys : exception : {}".format(e))
        abort(500)
    logging.info("payment_keys : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/select-freemimum-plan', methods=['POST'])
@auth.login_required()
def select_freemimum_plan():
    """Select Freemium Plan"""
    logging.info("select_freemimum_plan : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            if business:      
                business.selected_plan = constants.FREEMIUM
                business.active_users = 1
                business.updated_date = datetime.datetime.now()
                business.updated_by = user.user_id
                db.session.commit()

                add_notification_message(user.email, 'You have selected the freemium plan')

                resp_dict['status'] = True
                resp_dict['msg'] = 'Created Successfully'
            else:
                resp_dict['msg'] = 'Your login session has expired, please login again'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("select_freemimum_plan : exception : {}".format(e))
        abort(500)
    logging.info("select_freemimum_plan : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/select-pro-plan', methods=['POST'])
@auth.login_required()
def select_pro_plan():
    """Select Pro Plan"""
    logging.info("select-pro-plan : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        payable_term = request.json.get('payable_term') # Monthly/Yearly
        payable_amount = request.json.get('payable_amount')

        exp_date =None
        plan_duration = constants.MONTHLY
        if payable_term == 'Monthly':
            exp_date = datetime.datetime.now()+relativedelta(months=1)
            plan_duration = constants.MONTHLY
        elif payable_term == 'Yearly':
            exp_date = datetime.datetime.now()+relativedelta(years=1)
            plan_duration =  constants.YEARLY

        user = get_current_user()
        if user:
            business = get_business(user)

            # Create Customer Profile
            paymentCard = get_payment_card(business.business_id)
            customerProfileId = ''
            customerPaymentProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
                card_id = paymentCard.card_id
            else:
                card_id = paymentCard.card_id
                customerProfileId = paymentCard.customer_profile_id
                customerPaymentProfileId = paymentCard.customer_payment_profile_id

            if not customerPaymentProfileId:
                card_present, customerPaymentProfileId = get_customer_profile(customerProfileId)
                if card_present == constants.STATUS['NO']:
                    resp_dict['msg'] = 'No credit card available'
                    return jsonify(resp_dict)

                # Save Customer Payment Profile Id
                paymentCard.customer_payment_profile_id = customerPaymentProfileId
                paymentCard.updated_by = user.user_id
                paymentCard.updated_date = datetime.datetime.now()
                db.session.commit()

            invoice_sub_total_amount = payable_amount
            invoice_tax = 0
            invoice_total_amount = invoice_sub_total_amount+invoice_tax
            invoice_paid_amount = 0
            invoice = Invoice(business.business_id, card_id, invoice_sub_total_amount, invoice_tax, invoice_total_amount, invoice_paid_amount)
            db.session.add(invoice)
            db.session.commit()

            transId, error_message = create_an_accept_payment_transaction(customerProfileId, customerPaymentProfileId, \
                invoice.invoice_no, invoice_total_amount)      
            if not transId:
                invoice.status = constants.STATUS['ERROR']
                invoice.remarks = error_message
                invoice.updated_by = user.user_id
                invoice.updated_date = datetime.datetime.now()
                db.session.commit()

                resp_dict['msg'] = error_message
                return jsonify(resp_dict)

            invoice.invoice_paid_amount = invoice_total_amount
            invoice.transcation_id = transId
            invoice.status = constants.STATUS['COMPLETED']
            invoice.updated_date = datetime.datetime.now()
            invoice.updated_by = user.user_id
            db.session.commit()

            business.selected_plan = constants.PRO
            business.active_users = 1
            business.selected_plan_span = plan_duration
            business.plan_exp_data = exp_date
            business.updated_date = datetime.datetime.now()
            business.updated_by = user.user_id
            db.session.commit()

            add_notification_message(user.email, 'You have selected the pro plan')

            resp_dict['status'] = True
            resp_dict['msg'] = 'Created Successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("select-pro-plan : exception : {}".format(e))
        abort(500)
    logging.info("select-pro-plan : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/user-profile', methods=['GET'])
@auth.login_required()
def user_profile():
    """Fetching User Profile"""
    logging.info("user_profile : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            profile_dict =  {
                'user_id' : user.user_id,
                'name' : user.name,
                'email' : user.email,
                'phone' : user.phone,
                'business_name' : business.business_name,
                'industry' : business.industry,
                'address': business.address
            }
            resp_dict['status'] = True
            resp_dict['object'] = profile_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("user_profile : exception : {}".format(e))
        abort(500)
    logging.info("user_profile : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/update-user-profile', methods=['POST'])
@auth.login_required()
def update_user_profile():
    """Update User Profile"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("update_user_profile : start")
    try:
        name = request.json.get('name')
        phone = request.json.get('phone')
        business_name =  request.json.get('business_name')
        industry = request.json.get('industry')
        address = request.json.get('address')
        
        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"
       
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        user = get_current_user()
        if user:
            user.name = name
            user.phone = phone
            user.updated_date = datetime.datetime.now()
            user.updated_by = user.user_id
            db.session.commit()

            business = get_business(user)
            business.business_name = business_name
            business.industry = industry
            business.address = address
            db.session.commit()

            resp_dict['status'] = True
            resp_dict['msg'] = 'User Profile updated successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("update_user_profile : exception : {}".format(e))
        abort(500)
    logging.info("update_user_profile : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/update-password', methods=['POST'])
@auth.login_required()
def update_password():
    """Update password"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("update_password : start")
    try:
        old_password = request.json.get('old_password')
        new_password = request.json.get('new_password')

        # Input validation
        if not old_password or not new_password :
            resp_dict['msg'] = 'Old password and New password are required'
            return jsonify(resp_dict)
        if old_password == new_password:
            resp_dict['msg'] = 'Old password and New password cannot be same'
            return jsonify(resp_dict)

        user = get_current_user()
        if user:
            # Old password validation
            if not user.verify_password(old_password):
                resp_dict['msg'] = 'Old password mismatch'
                return jsonify(resp_dict)

            user.hash_password(new_password)
            user.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
            resp_dict['msg'] = 'Password updated successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("update_password : exception : {}".format(e))
        abort(500)
    logging.info("update_password : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/billing-info', methods=['GET'])
@auth.login_required()
def billing_info():
    """Fetch Card, Billing address, Plan and Invoice Details"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("billing_info : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            invoices =  get_invoices(business.business_id)
            paymentCard = get_payment_card(business.business_id)
            card_number = ''
            card_holder_name = ''
            billing_address = ''
            response_dict ={}
            no_of_camera = 0

            cameras = saferson.get_camera_names(user.email)
            if cameras:
                no_of_camera = int(len(cameras))
            
            if paymentCard and paymentCard.customer_profile_id:
                card_present, customerPaymentProfileId = get_customer_profile(paymentCard.customer_profile_id)
                if customerPaymentProfileId != '':
                    response_dict = get_customer_payment_profile(paymentCard.customer_profile_id, customerPaymentProfileId)
            
            if response_dict:
                card_number = response_dict['credit_card']
                card_holder_name = response_dict['first_name']+" "+response_dict['last_name']
                billing_address = response_dict['address']+", "+response_dict['city']+", "+response_dict['state']+", "+\
                    response_dict['zip_code']+", "+response_dict['country']+", "+response_dict['phone_number']
            
            invoice_list=[]
            for invoice in invoices:
                invoice_dict={}
                invoice_dict['invoice_no'] = invoice.invoice_no
                invoice_dict['invoice_paid_amount'] = invoice.invoice_paid_amount
                invoice_dict['invoice_date'] = (invoice.invoice_date).strftime("%b %d, %Y")
                invoice_list.append(invoice_dict)
                
            billing_info_dict =  {
                'plan' : business.selected_plan,
                'no_cameras' : no_of_camera,
                'no_users' : business.active_users,
                'payment_card_number' : card_number,
                'payment_card_holder_name' : card_holder_name,
                'billing_address' : str(billing_address),
                'invoice_list' : invoice_list
            }
            resp_dict['status'] = True
            resp_dict['object'] = billing_info_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("billing_info : exception : {}".format(e))
        abort(500)
    logging.info("billing_info : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/manage-cards', methods=['GET'])
@auth.login_required()
def manage_cards():
    """Payment Gateway Manage Cards"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("manage_cards : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            paymentCard = get_payment_card(business.business_id)
            
            customerProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
            else:
                customerProfileId = paymentCard.customer_profile_id

            token, error_message = get_accept_customer_profile_page(paymentCard.customer_profile_id)
            if token == '':
                resp_dict['msg'] = error_message
                return jsonify(resp_dict)

            auth_manage_cards_url = constants.auth_manage_cards_url_dev
            if constants.PRODUCTION:
                auth_manage_cards_url = constants.auth_manage_cards_url_prd
            
            manage_card_dict= {
                'token':token,
                'auth_manage_cards_url':auth_manage_cards_url,
                'manage_cards_success_url':constants.manage_cards_success_url,
                'manage_cards_init_url':constants.manage_cards_init_url,
            }
            resp_dict['status'] = True
            resp_dict['object'] = manage_card_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("manage_cards : exception : {}".format(e))
        abort(500)
    logging.info("manage_cards : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/check-card-status', methods=['GET'])
@auth.login_required()
def check_card_status():
    """Check Card Availability in the customer profile"""
    resp_dict = {"status":False, "msg":"", "object":None}
    logging.info("check_card_status : start")
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            paymentCard = get_payment_card(business.business_id)
            
            customerProfileId = ''
            if not paymentCard:
                customerProfileId, error_message = create_customer_profile(user.name, user.email)  
                if customerProfileId == '':
                    resp_dict['msg'] = error_message
                    return jsonify(resp_dict)

                paymentCard = PaymentCard(business.business_id, customerProfileId, '')
                paymentCard.created_by = user.user_id
                db.session.add(paymentCard)
                db.session.commit()
            else:
                customerProfileId = paymentCard.customer_profile_id
            
            card_present, customerPaymentProfileId = get_customer_profile(customerProfileId)
            card_status_dict= {
                'card_present':card_present,
            }
            resp_dict['status'] = True
            resp_dict['object'] = card_status_dict
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("check_card_status : exception : {}".format(e))
        abort(500)
    logging.info("check_card_status : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/invoice-pdf-download/<invoice_no>')
@auth.login_required()
def invoice_pdf_download(invoice_no):
    """PDF invoice file download"""
    logging.info("invoice_pdf_download : start")
    filename = 'invoice_{}.pdf'.format(invoice_no)
    pdf = FPDF() 
    pdf.add_page() 
    invoice = get_invoice_by_no(invoice_no)
    user = get_current_user()   
    if user and invoice:
        business = get_business(user)
        paymentCard = get_payment_card(business.business_id)
        billing_address = ''
        if paymentCard:
            logging.info(str(paymentCard.customer_profile_id), str(paymentCard.customer_payment_profile_id))
            response_dict = get_customer_payment_profile(paymentCard.customer_profile_id, paymentCard.customer_payment_profile_id)
            if response_dict:
                billing_address = response_dict['address']+", "+response_dict['city']+", "+response_dict['state']+", "+\
                    response_dict['zip_code']+", "+response_dict['country']
        
        pdf.set_font('Arial', 'B', size = 15)
        pdf.cell(200, 10, txt = "Safeo", ln = 1, align = 'C') 

        pdf.set_font('Arial', size = 10)
        pdf.cell(200, 10, txt = "1007 North Orange Street 4th Floor, Unit #6,", ln = 1, align = 'C')
        pdf.cell(200, 10, txt = "19801 Wilmington, DE, US", ln = 1, align = 'C')

        pdf.set_font('Arial', 'BU', size = 10)
        pdf.cell(200, 10, txt = "Invoice", ln = 1, align = 'C') 

        pdf.set_font("Arial", size = 10) 
        pdf.cell(200, 10, txt = "Invoice # {} :".format(invoice.invoice_no), ln = 1, align = 'L') 
        pdf.cell(200, 10, txt = "Invoice Date : {}".format((invoice.invoice_date).strftime("%b %d, %Y")), ln = 1, align = 'L') 
        pdf.cell(200, 10, txt = "Txn Ref No :  {}".format(invoice.transcation_id), ln = 1, align = 'L') 
        pdf.cell(200, 10, txt = "Billing Address :  {}".format(billing_address), ln = 1, align = 'L') 

        pdf.cell(200, 10, txt = "Plan - {}               - ${}".format(business.selected_plan, invoice.invoice_sub_total_amount), ln = 1, align = 'C') 
        pdf.cell(200, 10, txt = "Subtotal : ${}".format(invoice.invoice_sub_total_amount), ln = 1, align = 'R') 
        pdf.cell(200, 10, txt = "Tax : ${}".format(invoice.invoice_tax), ln = 1, align = 'R') 
        pdf.cell(200, 10, txt = "Total : ${}".format(invoice.invoice_total_amount), ln = 1, align = 'R') 
        pdf.cell(200, 10, txt = "Total Paid : ${}".format(invoice.invoice_paid_amount), ln = 1, align = 'R') 
        pdf.cell(200, 10, txt = "-- Thank you --", ln = 5, align = 'C') 
    else:
        pdf.set_font('Arial', 'B', size = 15)
        pdf.cell(200, 10, txt = "No Data Found!", ln = 1, align = 'C') 
    # save the pdf with name .pdf 
    pdf.output(os.path.join(app.config['INVOICE_PDF'], filename)) 
    logging.info("invoice_pdf_download : end")
    return send_from_directory(app.config['INVOICE_PDF'], filename, as_attachment=True)

# Compliance Services
@admin_blueprint.route('/api/safety-regulation-scores', methods=['GET'])
@auth.login_required()
def safety_regulation_scores():
    """Safety Regulation Scores"""
    logging.info("safety_regulation_scores : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        compliance_dict_list = []
        user = get_current_user()
        result = saferson.get_safety_insights(user.email)
        
        resp_dict['status'] = True
        resp_dict['object'] = get_safety_regulations_score(user, result)
    except Exception as e:
        logging.error("safety_regulation_scores : exception : {}".format(e))
        abort(500)
    logging.info("safety_regulation_scores : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/compliance-list', methods=['GET'])
@auth.login_required()
def compliance_list():
    """Complaince List"""
    logging.info("compliance_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        compliance_dict_list = []
        user = get_current_user()
        compliance_id_list = Compliance_Check_List_User.query.with_entities(Compliance_Check_List_User.compliance_id) \
            .filter(Compliance_Check_List_User.user_id==user.user_id).distinct().all()
        compliance_id_list =[id[0] for id in compliance_id_list]

        list_compliance_list = Compliance_List.query.filter(Compliance_List.compliance_id.notin_(compliance_id_list)).all()
        for compliance_list in list_compliance_list:
             compliance_dict_list.append({'compliance_id':compliance_list.compliance_id, 'name':compliance_list.name})
        resp_dict['status'] = True
        resp_dict['object'] = compliance_dict_list
    except Exception as e:
        logging.error("compliance_list : exception : {}".format(e))
        abort(500)
    logging.info("compliance_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/compliance-check-list/<compliance_id>', methods=['GET'])
@auth.login_required()
def compliance_check_list(compliance_id):
    """CDC Compiance Check List"""
    logging.info("compliance_check_list : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        compliance_dict_list = []
        user = get_current_user()

        result = saferson.get_safety_insights(user.email, start_date_str=None, end_date_str=None, freq='day')
        solution_list = {
            'heatmap_data':result['heatmap_data'],
            'mask_data':result['mask_data'],
            'sd_data':result['sd_data']}

        compliance_list_object = Compliance_List.query.filter(Compliance_List.compliance_id == compliance_id).first()
        compliance_check_list_user_list = Compliance_Check_List_User.query.filter((Compliance_Check_List_User.user_id == user.user_id) & \
            (Compliance_Check_List_User.compliance_id == compliance_id)).all()
        
        for compliance_check_list_user in compliance_check_list_user_list:
            compliance_check_list = Compliance_Check_List.query.filter(Compliance_Check_List.check_list_id == compliance_check_list_user.check_list_id).first()
            compliance_dict_list.append({
                'check_list_id':compliance_check_list.check_list_id,
                'check_list_name':compliance_check_list.check_list_name,
                'check_list_desc':compliance_check_list.check_list_desc,
                'checked_status':compliance_check_list_user.checked_status,
                'check_list_bullet_points':[]
                })

        resp_dict['status'] = True
        resp_dict['object'] = {'compliance_id':compliance_list_object.compliance_id,
                               'name':compliance_list_object.name,
                               'compliance_check_list' : compliance_dict_list,
                               'solution_list':solution_list}
    except Exception as e:
        logging.error("compliance_check_list : exception : {}".format(e))
        abort(500)
    logging.info("compliance_check_list : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/add-compliance', methods=['POST'])
@auth.login_required()
def add_compliance():
    """Add Compiance"""
    logging.info("add_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        list_compliance_id = request.json.get('list_compliance_id')
        user = get_current_user()
        for compliance_id in list_compliance_id:
            list_compliance_check_list = Compliance_Check_List.query.filter(Compliance_Check_List.compliance_id == compliance_id).all()
            for compliance_check_list in list_compliance_check_list:
                compliance_check_list_user = Compliance_Check_List_User(compliance_check_list.compliance_id, compliance_check_list.check_list_id, user.user_id, constants.STATUS['NO'])
                db.session.add(compliance_check_list_user)
                db.session.commit()
        resp_dict['status'] = True
        resp_dict['msg'] = 'Saved Successfully'
    except Exception as e:
        logging.error("add_compliance : exception : {}".format(e))
        abort(500)
    logging.info("add_compliance : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/update-compliance', methods=['POST'])
@auth.login_required()
def update_compliance():
    """Update User Compliance Check List Checked Status"""
    logging.info("update_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        compliance_id = request.json.get('compliance_id')
        check_list_id = request.json.get('check_list_id')
        checked_status = request.json.get('checked_status')
        if not compliance_id or not check_list_id or not checked_status:
            resp_dict['msg'] = 'Input data missing'
            return jsonify(resp_dict)

        user = get_current_user()
        compliance_check_list_user = Compliance_Check_List_User.query.filter((Compliance_Check_List_User.user_id == user.user_id) & \
            (Compliance_Check_List_User.compliance_id == compliance_id) & \
            (Compliance_Check_List_User.check_list_id == check_list_id) ).first()
        compliance_check_list_user.checked_status = checked_status
        db.session.commit()

        resp_dict['status'] = True
        resp_dict['msg'] = 'Updated Successfully'
    except Exception as e:
        logging.error("update_compliance : exception : {}".format(e))
        abort(500)
    logging.info("update_compliance : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/delete-compliance', methods=['POST'])
@auth.login_required()
def delete_compliance():
    """CDC Compiance Delete"""
    logging.info("delete_compliance : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        compliance_id = request.json.get('compliance_id')
        user = get_current_user()
        compliance_check_list_user_list = Compliance_Check_List_User.query.filter((Compliance_Check_List_User.user_id == user.user_id) & \
            (Compliance_Check_List_User.compliance_id == compliance_id)).delete()
        db.session.commit()
        
        resp_dict['status'] = True
        resp_dict['msg'] = 'Deleted Successfully'
    except Exception as e:
        logging.error("delete_compliance : exception : {}".format(e))
        abort(500)
    logging.info("delete_compliance : end")
    return jsonify(resp_dict)

# QR Reader Services
@admin_blueprint.route('/api/touchless-checkin-user-reg', methods=['POST'])
@auth.login_required()
def touchless_checkin_user_reg():
    """Create a user account for QR code reader"""
    logging.info("Touchless Checkin User Reg : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        email = request.json.get('email')        
        if User.query.filter_by(email=email).first():
            resp_dict['msg'] = email+' address is already added, please try another email address'
            return jsonify(resp_dict)

        user = get_current_user()
        if user:
            business = get_business(user)
            role = None
            if business.touchless_checkin_option == constants.THERMAL:
                role_name = str(business.business_id)+'_ADMIN_THERMAL'
                role = Role.query.filter(Role.role_name == role_name).first()
                if not role:
                    # Save Role
                    role_desc = 'ADMIN_THERMAL'
                    role = Role(role_name, role_desc, business.business_id)
                    db.session.add(role)
                    db.session.commit()
            elif business.touchless_checkin_option == constants.QR:
                role_name = str(business.business_id)+'_ADMIN_QR'
                role = Role.query.filter(Role.role_name == role_name).first()
                if not role:
                    # Save Role
                    role_desc = 'ADMIN_QR'
                    role = Role(role_name, role_desc, business.business_id)
                    db.session.add(role)
                    db.session.commit()

            # Save User
            new_password = get_random_string()
            user = User('', email, '', '')
            user.hash_password(new_password)
            user.terms_conditions_agreement = constants.STATUS['YES']
            user.created_by = user.user_id
            db.session.add(user)
            db.session.commit()

            # User & Role Mapping
            user_role_map = User_Role_Map(user.user_id, role.role_id)
            db.session.add(user_role_map)
            db.session.commit()

            # Send mail with new password
            forgot_password_mail(user.email, new_password)
        
            resp_dict['status'] = True
            resp_dict['msg'] = 'Email added Successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("touchless_checkin_user_reg : exception : {}".format(e))
        abort(500)
    logging.info("touchless_checkin_user_reg : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/qr-code-checkin', methods=['POST'])
@auth.login_required()
def qr_code_checkin():
    """QR code check in"""
    logging.info("qr_code_checkin : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        qr_data = request.json.get('qr_data')        
        qr_data_splited = qr_data.split('_')
        email =  qr_data_splited[0]
        qr_time =  qr_data_splited[1]
        user = User.query.filter(User.email==email).first()
        if user:
            qr_time = datetime.datetime.strptime(qr_time,'%Y-%m-%d %H:%M:%S')
            cur_time = datetime.datetime.now()
            t_diff = relativedelta(cur_time,qr_time)
            logging.info('{h}h {m}m {s}s'.format(h=t_diff.hours, m=t_diff.minutes, s=t_diff.seconds))
            if t_diff.hours>0 or t_diff.minutes>2:
                resp_dict['msg'] = 'Your QR code expired, please refresh your code'
                return jsonify(resp_dict)
            
            saferson.update_qr_attendace(email) 
            
            resp_dict['status'] = True
            resp_dict['msg'] = '{} successfully checked in'.format(user.name)
        else:
            resp_dict['msg'] = 'Invalid QR code'
    except Exception as e:
        logging.error("qr_code_checkin : exception : {}".format(e))
        abort(500)
    logging.info("qr_code_checkin : end")
    return jsonify(resp_dict)

@admin_blueprint.route('/api/choose-touchless-checkin-option', methods=['POST'])
@auth.login_required()
def choose_touchless_checkin_option():
    """Choose Touchless Checkin Option"""
    logging.info("choose_touchless_checkin_option : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        selected_checkin_option = request.json.get('selected_checkin_option')        
        user = get_current_user()
        if user:
            business = get_business(user)
            business.touchless_checkin_option = selected_checkin_option.upper()
            business.updated_date = datetime.datetime.now()
            db.session.commit()
            saferson.enable_face_recog(user.email)
            resp_dict['status'] = True
            resp_dict['msg'] = 'Updated Successfully'
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("choose_touchless_checkin_option : exception : {}".format(e))
        abort(500)
    logging.info("choose_touchless_checkin_option : end")
    return jsonify(resp_dict)
    
@admin_blueprint.route('/api/touchless-checkin-settings', methods=['GET'])
@auth.login_required()
def touchless_checkin_settings():
    """Choose Touchless Checkin Option"""
    logging.info("touchless_checkin_settings : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            business = get_business(user)
            reg_email = ''
            if business.touchless_checkin_option == constants.THERMAL:
                reg_email =  get_admin_user(business, 'ADMIN_THERMAL')
            elif business.touchless_checkin_option == constants.QR:
                reg_email =  get_admin_user(business, 'ADMIN_QR')

            resp_dict['status'] = True
            resp_dict['object'] = {
                'touchless_checkin_option' : business.touchless_checkin_option,
                'email' : reg_email
            }
        else:
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("touchless_checkin_settings : exception : {}".format(e))
        abort(500)
    logging.info("touchless_checkin_settings : end")
    return jsonify(resp_dict)
    