import json, datetime, re

from flask import Blueprint, abort, jsonify, request
from sqlalchemy import desc

from app import app, auth, db, logging
from models import User, Registration, Business, Role, User_Role_Map, Enquiry, get_user_role, \
    get_business, get_current_user, Compliance_Check_List_User, Compliance_Check_List, User_Device_Info, User_Notification
from utils import email_confirmation_mail, validate_token, enquiry_mail, get_random_string, forgot_password_mail
import constants

import saferson
# User API Services

user_blueprint = Blueprint('user', __name__)

@user_blueprint.route('/api/registration', methods=['POST'])
def registration():
    """User registration"""
    logging.info("registration : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        name = request.json.get('name')
        email = request.json.get('email')
        password = request.json.get('password')
        phone = request.json.get('phone')
        business_name =  request.json.get('business_name')
        industry = request.json.get('industry')
        address = request.json.get('address')
        
        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif not password:
            input_validation = "Password is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not business_name:
            input_validation = "Business Name is required"
        elif not industry:
            input_validation = "Industry is required"
        elif not address:
            input_validation = "Address is required"

        strong_pass_val_msg = strong_password_validation(password)
        if strong_pass_val_msg:
            input_validation = strong_pass_val_msg
        
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        # User duplicate validation
        if User.query.filter_by(email=email).first():
            resp_dict['msg'] = 'Eamil address already exists, please try another email address'
            return jsonify(resp_dict)

        registration = Registration(name, email, phone, business_name, industry, address)
        registration.hash_password(password)
        db.session.add(registration)
        db.session.commit()

        # Send Email Verification Mail
        email_confirmation_mail(registration.reg_id, registration.email)
        resp_dict = {"status":True, \
            "msg":'Your account is registered successfully with us, please check your email for confirmation', \
            "object":None}

    except Exception as e:
        logging.error("registration : exception : {}".format(e))
        abort(500)
    logging.info("registration : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/send-verification-email', methods = ['POST'])
def send_verification_email():
    """Resending a verification email"""
    logging.info("send_verification_email : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        email = request.json.get('email')
        if not email:
            resp_dict['msg'] = 'Eamil address is required '
            return jsonify(resp_dict)

        registration = Registration.query.filter_by(email=email).order_by(Registration.reg_id.desc()).first()
        if not registration:
            resp_dict['msg'] = 'Eamil address is not registered with us'
            return jsonify(resp_dict)
        
        if registration.status == constants.STATUS['VERIFIED']:
            resp_dict['msg'] = 'Your eamil address is already verified'
            return jsonify(resp_dict)
            
        # Send Email Verification Mail
        email_confirmation_mail(registration.reg_id, registration.email)
        resp_dict = {"status":True, \
            "msg":'Email verification mail sent successfully'}
        
    except Exception as e:
        logging.error("send_verification_email : exception : {}".format(e))
        abort(500)
    logging.info("send_verification_email : end")
    return jsonify(resp_dict)
    
@user_blueprint.route('/api/verify-email/<token>')
def verifyEmail(token):
    """Token verification"""
    try:
        # Token Validation
        reg_id = validate_token(token)

        # Update Registration Model
        registration = Registration.query.get(reg_id)
        if registration.email_verified_on or registration.status != constants.STATUS['ENTRY']:
            return str('Account already confirmed. Please login.')
        
        registration.email_verified_on = datetime.datetime.now()
        registration.updated_date = datetime.datetime.now()
        registration.status = constants.STATUS['VERIFIED']
        db.session.commit()

        # Save Address
        business = Business(registration.business_name,registration.industry, registration.address)
        business.touchless_checkin_option = ''
        #business.selected_plan = constants.FREEMIUM
        #business.active_users = constants.FREEMIUM_NO_OF_USERS
        db.session.add(business)
        db.session.commit()

        # Save Role
        role_name = str(business.business_id)+'_ADMIN'
        role_desc = 'ADMIN'
        role = Role(role_name, role_desc, business.business_id)
        db.session.add(role)
        db.session.commit()

        # Save User
        user = User(registration.name, registration.email, registration.password, registration.phone)
        db.session.add(user)
        db.session.commit()

        # User & Role Mapping
        user_role_map = User_Role_Map(user.user_id, role.role_id)
        db.session.add(user_role_map)
        db.session.commit()

        list_compliance_check_list = Compliance_Check_List.query.filter(Compliance_Check_List.compliance_id.in_(constants.DEFAULT_COMPLIANCE_LIST)).all()
        for compliance_check_list in list_compliance_check_list:
            compliance_check_list_user = Compliance_Check_List_User(compliance_check_list.compliance_id, compliance_check_list.check_list_id, user.user_id, constants.STATUS['NO'])
            db.session.add(compliance_check_list_user)
            db.session.commit()
        
        return str('You have confirmed your account. Thanks!')
    except Exception as e:
        return str('The confirmation link is invalid or has expired.')

@user_blueprint.route('/api/login', methods=['POST'])
def login():
    """Login authentication"""
    logging.info("login : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        email = request.json.get('email')
        password = request.json.get('password')
        device_id = request.json.get('device_id')
        device_type = request.json.get('device_type')

        if not email or not password:
            resp_dict['msg'] = 'Login credentials required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(email=email).first()
        if not user:
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        # User status validation
        if user.status != constants.STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        # User password  verification
        if not user.verify_password(password):
            resp_dict['msg'] = 'Invalid login credentials!'
            return jsonify(resp_dict)

        if device_id and device_type:
            user_device_info = User_Device_Info.query.filter(User_Device_Info.user_id == user.user_id).first()
            if user_device_info:
                if device_type == 'IOS':
                    user_device_info.ios_device_id =  device_id
                if device_type == 'ANDROID':
                    user_device_info.android_device_id =  device_id
                db.session.commit()
            else:
                user_device_info = User_Device_Info(user.user_id)
                user_device_info.ios_device_id = ''
                user_device_info.android_device_id = ''
                if device_type == 'IOS':
                    user_device_info.ios_device_id =  device_id
                if device_type == 'ANDROID':
                    user_device_info.android_device_id =  device_id
                db.session.add(user_device_info)
                db.session.commit()

        token = user.generate_auth_token()
        plan = ''
        camera_count = 0
        checkin_option = ''
        business = get_business(user)
        if business:
            plan = ('' if not business.selected_plan else business.selected_plan)
            camera_count = len(saferson.get_camera_names(user.email))
            checkin_option =  business.touchless_checkin_option
        role = get_user_role(user)
        
        resp_dict['status'] = True
        resp_dict['object'] = \
            {'token':token.decode('ascii'), 
            'user_id':user.user_id,
            'name':user.name, 
            'email':user.email,
            'role':role,
            'checkin_option':checkin_option,
            'plan': plan,
            'camera_count':camera_count,
            'agreement_accept_status':user.terms_conditions_agreement}
    except Exception as e:
        logging.error("login : exception : {}".format(e))
        abort(500)
    logging.info("login : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/login-data', methods=['GET'])
@auth.login_required()
def login_data():
    """Login Data"""
    logging.info("login_data : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            plan = ''
            camera_count = 0
            checkin_option = ''
            business = get_business(user)
            if business:
                plan = ('' if not business.selected_plan else business.selected_plan)
                camera_count = len(saferson.get_camera_names(user.email))
                checkin_option =  business.touchless_checkin_option
            role = get_user_role(user)

            resp_dict['status'] = True 
            resp_dict['object'] = {
                'user_id':user.user_id,
                'name':user.name, 
                'email':user.email,
                'role':role,
                'checkin_option':checkin_option,
                'plan': plan,
                'camera_count':camera_count,
                'agreement_accept_status':user.terms_conditions_agreement
            }
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("login_data : exception : {}".format(e))
        abort(500)
    logging.info("login_data : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/reset-password', methods=['POST'])
def reset_password():
    """Reset password - Sending a mail with new password"""
    logging.info("reset_password : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        email = request.json.get('email')
        if not email:
            resp_dict['msg'] = 'Email address is required!'
            return jsonify(resp_dict)

        user = User.query.filter_by(email=email).first()
        if not user:
            resp_dict['msg'] = 'This email address is not registered with Us'
            return jsonify(resp_dict)

        # User status validation
        if user.status != constants.STATUS['ACTIVE']:
            resp_dict['msg'] = 'Your active is disabled, please check with admin'
            return jsonify(resp_dict)

        new_password = get_random_string()
        user.hash_password(new_password)
        user.updated_date = datetime.datetime.now()
        db.session.commit()

        # Send mail with new password
        forgot_password_mail(user.email, new_password)
       
        resp_dict['status'] = True
        resp_dict['msg'] = 'Mail sent to you with reset password'
    except Exception as e:
        logging.error("reset_password : exception : {}".format(e))
        abort(500)
    logging.info("reset_password : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/save-enquiry', methods=['POST'])
def save_enquiry():
    """Reset password - Sending a mail with new password"""
    logging.info("save_enquiry : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        # Input Validation
        name = request.json.get('name')
        company = request.json.get('company')
        email = request.json.get('email')
        phone = request.json.get('phone')
        country = request.json.get('country')
        message = request.json.get('message')
        enquiry_type = request.json.get('enquiry_type')

        # Input data validation
        input_validation = ''
        if not name:
            input_validation = "Name is required"
        elif not email:
            input_validation = "Email Address is required"
        elif  not company:
            input_validation = "Company Name is required"
        elif not phone:
            input_validation = "Phone is required"
        elif not country:
            input_validation = "Country is required"
        
        if input_validation:
            resp_dict['msg'] = input_validation
            return jsonify(resp_dict)

        enquiry = Enquiry(name, company, email, phone, country, message, enquiry_type)
        db.session.add(enquiry)
        db.session.commit()

        # Send enquiry email
        enquiry_mail('kathiravan.rajendran@skoruz.com', name, company, email, phone, country, message)
        resp_dict['status'] = True
        resp_dict['msg'] = 'Enquiry submitted successfully'
    except Exception as e:
        logging.error("save_enquiry : exception : {}".format(e))
        abort(500)
    logging.info("save_enquiry : end")
    return jsonify(resp_dict)

def strong_password_validation(password):
    message = ''
    try:
        if len(password) < 8:
            message = "Password should be at least 8 characters : 8-15"
        elif len(password) > 15:
            message = "Password should not exceed 15 characters : 8-15"
        elif not re.search("[a-z]", password):
            message = "Password should contain at least one lowercase : a-z"
        elif not re.search("[A-Z]", password):
            message = "Password should contain at least one uppercase : A-Z"
        elif not re.search("[0-9]", password):
            message = "Password should contain at least one digit : 0-9"
        elif not re.search("[_@$^&!%#*]", password):
            message = "Password should contain at least one character : {_@$^&!%#*}"
    except Exception as e:
        logging.error("strong_password_validation : exception : {}".format(e))
        message = ''
    return message

@user_blueprint.route('/api/get-notifications', methods=['GET'])
@auth.login_required()
def get_notifications():
    """Get User Notifications"""
    logging.info("get_notifications : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        user = get_current_user()
        if user:
            user_notifications = User_Notification.query.filter((User_Notification.user_id==user.user_id) &
                    (User_Notification.status == constants.STATUS['ACTIVE'])
                    ).order_by(desc(User_Notification.notification_id)).all()
            
            notification_list=[]
            for user_notification in  user_notifications:
                notification_dict = dict()
                notification_dict['notification_id'] = user_notification.notification_id
                notification_dict['message'] = user_notification.message
                notification_list.append(notification_dict)

            resp_dict['status'] = True
            resp_dict['object'] = notification_list
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("get_notifications : exception : {}".format(e))
        abort(500)
    logging.info("get_notifications : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/read-notification', methods=['POST'])
@auth.login_required()
def read_notification():
    """Update User Notification As Read"""
    logging.info("read_notification : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        notification_id = request.json.get('notification_id')
        user = get_current_user()
        if user:
            user_notification = User_Notification.query.filter(User_Notification.notification_id==notification_id).first()
            user_notification.read_status = constants.READ_STATUS['READ']
            user_notification.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("read_notification : exception : {}".format(e))
        abort(500)
    logging.info("read_notification : end")
    return jsonify(resp_dict)

@user_blueprint.route('/api/delete-notification', methods=['POST'])
@auth.login_required()
def delete_notification():
    """Update User Notification As De-Active"""
    logging.info("delete_notification : start")
    resp_dict = {"status":False, "msg":"", "object":None}
    try:
        notification_id = request.json.get('notification_id')
        user = get_current_user()
        if user:
            user_notification = User_Notification.query.filter(User_Notification.notification_id==notification_id).first()
            user_notification.status = constants.STATUS['DE-ACTIVE']
            user_notification.updated_date = datetime.datetime.now()
            db.session.commit()
            resp_dict['status'] = True
        else:
            resp_dict['status'] = False
            resp_dict['msg'] = 'Your login session has expired, please login again'
    except Exception as e:
        logging.error("delete_notification : exception : {}".format(e))
        abort(500)
    logging.info("delete_notification : end")
    return jsonify(resp_dict)

