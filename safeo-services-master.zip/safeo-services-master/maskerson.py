import numpy as np
import os
from mask_detection.mask_detector import MaskDetector,SSDMaskDetector
import cv2

# what if database connection fails
# change implementation to dynamic batch processing using queue
class Maskerson:
    def __init__(self, in_data_queue, out_data_queue):
        self.in_data_queue = in_data_queue
        self.out_data_queue = out_data_queue
        self.stopped = False
        self.collect_dir = 'collected_data'
        self.collected_count = 0
        if not os.path.exists(self.collect_dir):
            os.makedirs(self.collect_dir)
        else:
            self.collected_count = len(os.listdir(self.collect_dir))
        
        # self.mask_detector = MaskDetector()
        self.mask_detector = SSDMaskDetector()
    
    def run(self):
        while True:
            curr_item = self.in_data_queue.get()

            if curr_item == 'KILL WORKER':
                break
            
            mask_risk_score = self.analyse(curr_item['frame'])
            
            curr_item['mask_risk_score'] = mask_risk_score

            del curr_item['frame']

            self.out_data_queue.put(curr_item)
        
    def analyse(self, img):
        mask_status_list, face_bboxes = self.mask_detector.infer_model(img, detect_faces=True)
        if len(mask_status_list) == 0:
            return -1 #Not applicable when room is empty, Also handles model error cases
        no_mask_list,_  = np.where(mask_status_list == 'No Mask')
        num_no_mask = len(no_mask_list)

        num_total_faces = len(mask_status_list)

        if num_total_faces == 0:
                mask_risk_score = -1
        else:
            mask_risk_score = num_no_mask / num_total_faces
            if self.collected_count <=5000:
                img_name = f"IMG_{self.collected_count}_{round(mask_risk_score,3)}.jpg"
                cv2.imwrite(os.path.join(self.collect_dir,img_name),img)
                self.collected_count+=1

        return mask_risk_score
    
    def stop(self):
        self.in_data_queue.put('KILL WORKER')

    
